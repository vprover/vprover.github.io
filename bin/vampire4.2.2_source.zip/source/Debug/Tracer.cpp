
/*
 * File Tracer.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#include <climits>
#include <iostream>

#include "Tracer.hpp"

extern const char* VERSION_STRING;

#if VDEBUG


#define CP_FIRST_POINT UINT_MAX
#define CP_LAST_POINT 0u





 
 

using namespace std;
using namespace Debug;

const char* Tracer::_lastControlPoint;
Tracer* Tracer::_current = 0;
unsigned Tracer::_depth = 0;
unsigned Tracer::_passedControlPoints = 0L;
ControlPointKind Tracer::_lastPointKind = CP_MID;
bool Tracer::_forced = false;

bool Tracer::canWatch = false;


#define WATCH_ADDR 0
#if WATCH_ADDR
void* watchAddrLastValue = (void*)0;
#endif

Tracer::Tracer (const char* fun) 
  :
  _fun (fun),
  _previous (_current)
{

  _current = this;
  controlPoint(_fun,CP_ENTRY);
  _depth++;
} 


Tracer::~Tracer () 
{

  _current = _previous;
  _depth--;
  controlPoint(_fun,CP_EXIT);
} 


void Tracer::controlPoint (const char* description, ControlPointKind cpk)
{








  _lastPointKind = cpk;

#if WATCH_ADDR
  if (canWatch) {
    void* newVal = *((void**)WATCH_ADDR);
    if (newVal != watchAddrLastValue) {
      cout << "W! " << newVal << " (timestamp: "
	   << _passedControlPoints << ")\n";
      watchAddrLastValue = newVal;
      cout << "Stack on " << (cpk == CP_EXIT ? "exiting" : "entering")
	   << " the last function on the stack:\n";
      printStack(cout);
    }
  }
#endif

  _passedControlPoints++;

  _lastControlPoint = description;
  if (_forced ||
      (_passedControlPoints <= CP_LAST_POINT &&
       _passedControlPoints >= CP_FIRST_POINT)) {
    outputLastControlPoint(cout);
  }
} 


void Tracer::controlPoint (const char* description)
{
  controlPoint (description,CP_MID);
} 


void Tracer::outputLastControlPoint (ostream& str)
{
  spaces(str,_depth);
  str << (_lastPointKind == CP_ENTRY ? '+' : 
          _lastPointKind == CP_EXIT ? '-' : ' ')
      << _lastControlPoint 
      << " ("
      << _passedControlPoints 
      << ")\n";
} 


void Tracer::printOnlyStack (ostream& str)
{
  int depth = 0;
  printStackRec (_current, str, depth);
} 


void Tracer::printStack (ostream& str)
{
  int depth = 0;

  str << "Version : " << VERSION_STRING << "\n";
  str << "Control points passed: " << _passedControlPoints << "\n"
      << "last control point:\n";
  outputLastControlPoint(str);
  printStackRec (_current, str, depth);
} 


void Tracer::printStackRec(Tracer* current, ostream& str, int& depth)
{
  if (!current) { 
    return;
  }
  printStackRec(current->_previous,str,depth);
  spaces(str,depth);
  str << current->_fun << "\n";
  depth ++;
} 


void Tracer::spaces (ostream& str,int n)
{
  while (n > 0) {
    n--;
    str << ' ';
  }
} 

#endif 


/*
 * File GlobalSubsumption.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __GlobalSubsumption__
#define __GlobalSubsumption__

#include "Forwards.hpp"
#include "Indexing/GroundingIndex.hpp"
#include "Shell/Options.hpp"

#include "InferenceEngine.hpp"

namespace Inferences
{

using namespace Kernel;
using namespace Indexing;
using namespace Saturation;
using namespace SAT;

class GlobalSubsumption
: public ForwardSimplificationEngine
{
public:
  CLASS_NAME(GlobalSubsumption);
  USE_ALLOCATOR(GlobalSubsumption);

  GlobalSubsumption(const Options& opts) : _index(0),
      _uprOnly(opts.globalSubsumptionSatSolverPower()==Options::GlobalSubsumptionSatSolverPower::PROPAGATION_ONLY),
      _explicitMinim(opts.globalSubsumptionExplicitMinim()!=Options::GlobalSubsumptionExplicitMinim::OFF),
      _randomizeMinim(opts.globalSubsumptionExplicitMinim()==Options::GlobalSubsumptionExplicitMinim::RANDOMIZED),
      _splittingAssumps(opts.globalSubsumptionAvatarAssumptions()!= Options::GlobalSubsumptionAvatarAssumptions::OFF),
      _splitter(0) {}

 
  GlobalSubsumption(const Options& opts, GroundingIndex* idx) : GlobalSubsumption(opts) { _index = idx; }

  void attach(SaturationAlgorithm* salg) override;
  void detach() override;
  bool perform(Clause* cl, Clause*& replacement, ClauseIterator& premises) override;
  
  Clause* perform(Clause* cl, Stack<Unit*>& prems);
 
private:  
  struct Unit2ClFn;
      
  GroundingIndex* _index;

 
  bool _uprOnly;

 
  bool _explicitMinim;

 
  bool _randomizeMinim;

 
  bool _splittingAssumps;

 
  Splitter* _splitter;
  
 
  DHMap<unsigned, unsigned> _splits2vars;
  
   
  DHMap<unsigned, unsigned> _vars2splits;
      
protected:  
  unsigned splitLevelToVar(SplitLevel lev) {        
    CALL("GlobalSubsumption::splitLevelToVar");
    unsigned* pvar;
              
    if(_splits2vars.getValuePtr(lev, pvar)) {
      SATSolver& solver = _index->getSolver();
      *pvar = solver.newVar();
      ALWAYS(_vars2splits.insert(*pvar,lev));
    }
    
    return *pvar;
  }  
  
  bool isSplitLevelVar(unsigned var, SplitLevel& lev) {
    CALL("GlobalSubsumption::isSplitLevelVar");
    
    return _vars2splits.find(var,lev);
  }
};

};

#endif 

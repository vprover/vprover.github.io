
/*
 * File BackwardDemodulation.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#include "Lib/DHMultiset.hpp"
#include "Lib/Environment.hpp"
#include "Lib/Int.hpp"
#include "Lib/List.hpp"
#include "Lib/Metaiterators.hpp"
#include "Lib/TimeCounter.hpp"
#include "Lib/VirtualIterator.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/ColorHelper.hpp"
#include "Kernel/EqHelper.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/Ordering.hpp"
#include "Kernel/Renaming.hpp"
#include "Kernel/SortHelper.hpp"
#include "Kernel/Term.hpp"

#include "Indexing/Index.hpp"
#include "Indexing/TermIndex.hpp"
#include "Indexing/IndexManager.hpp"

#include "Saturation/SaturationAlgorithm.hpp"

#include "Shell/Options.hpp"
#include "Shell/Statistics.hpp"

#include "BackwardDemodulation.hpp"

namespace Inferences {

using namespace Lib;
using namespace Kernel;
using namespace Indexing;
using namespace Saturation;

void BackwardDemodulation::attach(SaturationAlgorithm* salg)
{
  CALL("BackwardDemodulation::attach");
  BackwardSimplificationEngine::attach(salg);
  _index=static_cast<DemodulationSubtermIndex*>(
	  _salg->getIndexManager()->request(DEMODULATION_SUBTERM_SUBST_TREE) );
}

void BackwardDemodulation::detach()
{
  CALL("BackwardDemodulation::detach");
  _index=0;
  _salg->getIndexManager()->release(DEMODULATION_SUBTERM_SUBST_TREE);
  BackwardSimplificationEngine::detach();
}

struct BackwardDemodulation::RemovedIsNonzeroFn
{
  DECL_RETURN_TYPE(bool);
  OWN_RETURN_TYPE operator() (BwSimplificationRecord arg)
  {
    return arg.toRemove!=0;
  }
};

struct BackwardDemodulation::RewritableClausesFn
{
  RewritableClausesFn(DemodulationSubtermIndex* index) : _index(index) {}
  DECL_RETURN_TYPE(VirtualIterator<pair<TermList,TermQueryResult> >);
  OWN_RETURN_TYPE operator() (TermList lhs)
  {
    return pvi( pushPairIntoRightIterator(lhs, _index->getInstances(lhs, true)) );
  }
private:
  DemodulationSubtermIndex* _index;
};


struct BackwardDemodulation::ResultFn
{
  typedef DHMultiset<Clause*> ClauseSet;

  ResultFn(Clause* cl, BackwardDemodulation& parent)
  : _cl(cl), _parent(parent), _ordering(parent._salg->getOrdering())
  {
    ASS_EQ(_cl->length(),1);
    _eqLit=(*_cl)[0];
    _eqSort = SortHelper::getEqualityArgumentSort(_eqLit);
    _removed=SmartPtr<ClauseSet>(new ClauseSet());
  }
  DECL_RETURN_TYPE(BwSimplificationRecord);
 
  OWN_RETURN_TYPE operator() (pair<TermList,TermQueryResult> arg)
  {
    CALL("BackwardDemodulation::ResultFn::operator()");

    TermQueryResult qr=arg.second;

    if( !ColorHelper::compatible(_cl->color(), qr.clause->color()) ) {
      
      return BwSimplificationRecord(0);
    }

    if(_cl==qr.clause || _removed->find(qr.clause)) {
      
      
      return BwSimplificationRecord(0);
    }

    unsigned qrSort = SortHelper::getTermSort(qr.term, qr.literal);
    if(qrSort!=_eqSort) {
      return BwSimplificationRecord(0);
    }


    TermList lhs=arg.first;
    TermList rhs=EqHelper::getOtherEqualitySide(_eqLit, lhs);

    TermList lhsS=qr.term;
    TermList rhsS;

    if(!qr.substitution->isIdentityOnResultWhenQueryBound()) {
      
      
      
      
      
      TermList lhsSBadVars=qr.substitution->applyToQuery(lhs);
      TermList rhsSBadVars=qr.substitution->applyToQuery(rhs);
      Renaming rNorm, qNorm, qDenorm;
      rNorm.normalizeVariables(lhsSBadVars);
      qNorm.normalizeVariables(lhsS);
      qDenorm.makeInverse(qNorm);
      ASS_EQ(lhsS,qDenorm.apply(rNorm.apply(lhsSBadVars)));
      rhsS=qDenorm.apply(rNorm.apply(rhsSBadVars));
    } else {
      rhsS=qr.substitution->applyToBoundQuery(rhs);
    }

    if(_ordering.compare(lhsS,rhsS)!=Ordering::GREATER) {
      return BwSimplificationRecord(0);
    }

    if(_parent.getOptions().demodulationRedundancyCheck() && qr.literal->isEquality() &&
	(qr.term==*qr.literal->nthArgument(0) || qr.term==*qr.literal->nthArgument(1)) ) {
      TermList other=EqHelper::getOtherEqualitySide(qr.literal, qr.term);
      Ordering::Result tord=_ordering.compare(rhsS, other);
      if(tord!=Ordering::LESS && tord!=Ordering::LESS_EQ) {
	unsigned eqSort = SortHelper::getEqualityArgumentSort(qr.literal);
	Literal* eqLitS=Literal::createEquality(true, lhsS, rhsS, eqSort);
	bool isMax=true;
	Clause::Iterator cit(*qr.clause);
	while(cit.hasNext()) {
	  Literal* lit2=cit.next();
	  if(qr.literal==lit2) {
	    continue;
	  }
	  if(_ordering.compare(eqLitS, lit2)==Ordering::LESS) {
	    isMax=false;
	    break;
	  }
	}
	if(isMax) {

	  
	  
	  
	  
	  
	  return BwSimplificationRecord(0);
	}
      }

    }

    Literal* resLit=EqHelper::replace(qr.literal,lhsS,rhsS);
    if(EqHelper::isEqTautology(resLit)) {
      env.statistics->backwardDemodulationsToEqTaut++;
      _removed->insert(qr.clause);
      return BwSimplificationRecord(qr.clause);
    }


    Inference* inf = new Inference2(Inference::BACKWARD_DEMODULATION, _cl, qr.clause);
    Unit::InputType inpType = (Unit::InputType)
	Int::max(_cl->inputType(), qr.clause->inputType());

    unsigned cLen=qr.clause->length();
    Clause* res = new(cLen) Clause(cLen, inpType, inf);

    (*res)[0]=resLit;

    unsigned next=1;
    for(unsigned i=0;i<cLen;i++) {
      Literal* curr=(*qr.clause)[i];
      if(curr!=qr.literal) {
	(*res)[next++] = curr;
      }
    }
    ASS_EQ(next,cLen);

    res->setAge(qr.clause->age());
    env.statistics->backwardDemodulations++;

    _removed->insert(qr.clause);
    return BwSimplificationRecord(qr.clause,res);
  }
private:
  unsigned _eqSort;
  Literal* _eqLit;
  Clause* _cl;
  SmartPtr<ClauseSet> _removed;

  BackwardDemodulation& _parent;
  Ordering& _ordering;
};


void BackwardDemodulation::perform(Clause* cl,
	BwSimplificationRecordIterator& simplifications)
{
  CALL("BackwardDemodulation::perform");

  if(cl->length()!=1 || !(*cl)[0]->isEquality() || !(*cl)[0]->isPositive() ) {
    simplifications=BwSimplificationRecordIterator::getEmpty();
    return;
  }
  Literal* lit=(*cl)[0];

  BwSimplificationRecordIterator replacementIterator=
    pvi( getFilteredIterator(
	    getMappingIterator(
		    getMapAndFlattenIterator(
			    EqHelper::getDemodulationLHSIterator(lit, false, _salg->getOrdering(), _salg->getOptions()),
			    RewritableClausesFn(_index)),
		    ResultFn(cl, *this)),
 	    RemovedIsNonzeroFn()) );

  
  
  

  TimeCounter tc(TC_BACKWARD_DEMODULATION);
  simplifications=getPersistentIterator(replacementIterator);
}

}

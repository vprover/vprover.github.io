
/*
 * File Induction.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Debug/RuntimeStatistics.hpp"

#include "Lib/Environment.hpp"
#include "Lib/Set.hpp"
#include "Lib/Array.hpp"

#include "Kernel/TermIterators.hpp"
#include "Kernel/Signature.hpp"
#include "Kernel/Clause.hpp"
#include "Kernel/Unit.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/Sorts.hpp"
#include "Kernel/Theory.hpp"


#include "Saturation/SaturationAlgorithm.hpp"

#include "Shell/Options.hpp"
#include "Shell/Statistics.hpp"

#include "Induction.hpp"

namespace Inferences
{
using namespace Kernel;
using namespace Lib; 


TermList ConstantReplacement::transformSubterm(TermList trm)
{
  CALL("ConstantReplacement::transformSubterm");

  if(trm.isTerm() && trm.term()->functor()==_f){
   return _r;
  }
  return trm;
}

ClauseIterator Induction::generateClauses(Clause* premise)
{
  CALL("Induction::generateClauses");

  return pvi(InductionClauseIterator(premise));
}

InductionClauseIterator::InductionClauseIterator(Clause* premise)
{
  CALL("InductionClauseIterator::InductionClauseIterator");

  if(premise->length()==1){
    Literal* lit = (*premise)[0];
     
    if(lit->isNegative() && lit->ground()){

      Set<unsigned> ta_constants;
      Set<unsigned> int_constants;
      TermFunIterator it(lit);
      while(it.hasNext()){
        unsigned f = it.next();
        if(env.signature->functionArity(f)==0 && 
           env.signature->isTermAlgebraSort(env.signature->getFunction(f)->fnType()->result())){
          ta_constants.insert(f);
        }
        if(env.signature->functionArity(f)==0 && 
           env.signature->getFunction(f)->fnType()->result()==Sorts::SRT_INTEGER){
          int_constants.insert(f);
        }
      }
      
      
      
      
      
      
      Set<unsigned>::Iterator citer1(int_constants);
      while(citer1.hasNext()){
        unsigned c = citer1.next();

        
        unsigned freshS = env.signature->addSkolemFunction(0);
        Signature::Symbol* symbol = env.signature->getFunction(freshS);
        symbol->setType(new FunctionType(Sorts::SRT_INTEGER));
        TermList fresh(Term::createConstant(freshS));

        TermList zero(theory->representConstant(IntegerConstantType(0)));
        TermList one(theory->representConstant(IntegerConstantType(1)));
        TermList mone(theory->representConstant(IntegerConstantType(-1)));

        
        ConstantReplacement cr1(c,zero);
        Literal* Lzero = cr1.transform(lit);

        
        TermList fpo(Term::create2(env.signature->getInterpretingSymbol(Theory::INT_PLUS),fresh,one));
        ConstantReplacement cr2(c,fpo);
        Literal* Lfpo = cr2.transform(lit);

        
        TermList fpmo(Term::create2(env.signature->getInterpretingSymbol(Theory::INT_PLUS),fresh,mone));
        ConstantReplacement cr3(c,fpmo);
        Literal* Lfpmo = cr3.transform(lit);

        
        ConstantReplacement cr4(c,fresh);
        Literal* nLfresh = Literal::complementaryLiteral(cr4.transform(lit));

        
        Literal* cLz = Literal::create2(env.signature->getInterpretingSymbol(Theory::INT_LESS),true,TermList(Term::createConstant(c)),zero);

        
        
        
        
        Inference* inf1 = new Inference1(Inference::INDUCTION,premise);
        Inference* inf2 = new Inference1(Inference::INDUCTION,premise);
        Inference* inf3 = new Inference1(Inference::INDUCTION,premise);
        Clause* r1 = new(3) Clause(3,premise->inputType(),inf1);
        Clause* r2 = new(3) Clause(3,premise->inputType(),inf2);
        Clause* r3 = new(2) Clause(2,premise->inputType(),inf3);

        (*r1)[0] = Lzero;
        (*r1)[1] = Lfpo; 
        (*r1)[2] = Lfpmo;

        (*r2)[0] = Lzero;
        (*r2)[1] = Lfpo;
        (*r2)[2] = cLz;

        (*r3)[0] = Lzero;
        (*r3)[1] = nLfresh;

        _clauses.push(r1);
        _clauses.push(r2);
        _clauses.push(r3);

      }

      
      
      
      
      
      
      
      
      
      

      Set<unsigned>::Iterator citer2(ta_constants);
      while(citer2.hasNext()){
        unsigned c = citer2.next();

        TermAlgebra* ta = env.signature->getTermAlgebraOfSort(env.signature->getFunction(c)->fnType()->result());
        unsigned ta_sort = ta->sort();

        Array<Stack<TermList>> skolemTerms(env.sorts->sorts());

        Stack<Literal*> baseLits;
        Stack<Literal*> conLits;

        for(unsigned i=0;i<ta->nConstructors();i++){
          TermAlgebraConstructor* con = ta->constructor(i);

          
          if(con->arity()==0){
            TermList cont(Term::createConstant(con->functor()));
            ConstantReplacement cr(c,cont);
            baseLits.push(cr.transform(lit));
          }
          
          else{
            
            
            Stack<TermList> argTerms; 
            ZIArray<unsigned> skolemIndex(env.sorts->sorts());
            for(unsigned i=0;i<con->arity();i++){
              unsigned srt = con->argSort(i);

              if(skolemTerms[srt].size()<skolemIndex[srt]+1){         
                unsigned xn = env.signature->addSkolemFunction(0);
                Signature::Symbol* symbol = env.signature->getFunction(xn);
                symbol->setType(new FunctionType(srt));
                skolemTerms[srt].push(TermList(Term::createConstant(xn)));
              }
              ASS(skolemTerms[srt].size() >= skolemIndex[srt]+1);
              argTerms.push(skolemTerms[srt][skolemIndex[srt]]); 
              skolemIndex[srt] = skolemIndex[srt]+1;
            }
            TermList cont(Term::create(con->functor(),(unsigned)argTerms.size(), argTerms.begin()));
            ConstantReplacement cr(c,cont);
            conLits.push(cr.transform(lit));
          }
        }

        Stack<Literal*> xfnLits;

        Stack<TermList>::Iterator xnit(skolemTerms[ta_sort]);
        while(xnit.hasNext()){
          
          TermList xnt = xnit.next();
          ConstantReplacement crX(c,xnt);
          Literal* nLxn = Literal::complementaryLiteral(crX.transform(lit));
          xfnLits.push(nLxn);
        }

      
      
      
      
      
      
      
    
      
      Stack<Literal*>::Iterator bit(baseLits);
      while(bit.hasNext()){
        Literal* blit = bit.next();

        
        {
          Inference* inf = new Inference1(Inference::INDUCTION,premise);
          unsigned size = conLits.size()+1;
          Clause* r = new(size) Clause(size,premise->inputType(),inf);
          for(unsigned i=0;i<conLits.size();i++){ (*r)[i]= conLits[i]; }
          (*r)[size-1]=blit;
          _clauses.push(r);
        }

        
        Stack<Literal*>::Iterator xnit(xfnLits);
        while(xnit.hasNext()){
          Literal* xnlit = xnit.next();
          Inference* inf = new Inference1(Inference::INDUCTION,premise);
          Clause* r = new(2) Clause(2,premise->inputType(),inf);
          (*r)[0]=xnlit;
          (*r)[1]=blit;
          _clauses.push(r);
        }
      }
    }
    }
  }
}

}

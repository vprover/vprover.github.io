
/*
 * File InferenceEngine.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __InferenceEngine__
#define __InferenceEngine__

#include "Forwards.hpp"
#include "Lib/SmartPtr.hpp"

#include "Lib/VirtualIterator.hpp"
#include "Lib/List.hpp"

#include "Lib/Allocator.hpp"

namespace Inferences
{

using namespace Lib;
using namespace Kernel;
using namespace Saturation;
using namespace Shell;

class InferenceEngine
{
public:
  CLASS_NAME(InferenceEngine);
  USE_ALLOCATOR(InferenceEngine);

  InferenceEngine() : _salg(0) {}
  virtual ~InferenceEngine()
  {
    
    ASS(!_salg);
  }
  virtual void attach(SaturationAlgorithm* salg)
  {
    CALL("InferenceEngine::attach");
    ASS(!_salg);
    _salg=salg;
  }
  virtual void detach()
  {
    CALL("InferenceEngine::detach");
    ASS(_salg);
    _salg=0;
  }

 
  bool attached() const { return _salg; }

  virtual const Options& getOptions() const;
protected:
  SaturationAlgorithm* _salg;
};















class GeneratingInferenceEngine
: public InferenceEngine
{
public:
  virtual ClauseIterator generateClauses(Clause* premise) = 0;
};

class ImmediateSimplificationEngine
: public InferenceEngine
{
public:
 
  virtual Clause* simplify(Clause* cl) = 0;
};

class ForwardSimplificationEngine
: public InferenceEngine
{
public:
 
  virtual bool perform(Clause* cl, Clause*& replacement, ClauseIterator& premises) = 0;
};


struct BwSimplificationRecord
{
  BwSimplificationRecord() {}
  BwSimplificationRecord(Clause* toRemove)
  : toRemove(toRemove), replacement(0) {}
  BwSimplificationRecord(Clause* toRemove, Clause* replacement)
  : toRemove(toRemove), replacement(replacement) {}

  Clause* toRemove;
  Clause* replacement;
};
typedef VirtualIterator<BwSimplificationRecord> BwSimplificationRecordIterator;

class BackwardSimplificationEngine
: public InferenceEngine
{
public:
 
  virtual void perform(Clause* premise, BwSimplificationRecordIterator& simplifications) = 0;
};


class DummyGIE
: public GeneratingInferenceEngine
{
public:
  CLASS_NAME(DummyGIE);
  USE_ALLOCATOR(DummyGIE);

  ClauseIterator generateClauses(Clause* premise)
  {
    return ClauseIterator::getEmpty();
  }
};


class CompositeISE
: public ImmediateSimplificationEngine
{
public:
  CLASS_NAME(CompositeISE);
  USE_ALLOCATOR(CompositeISE);

  CompositeISE() : _inners(0) {}
  virtual ~CompositeISE();
  void addFront(ImmediateSimplificationEngine* fse);
  Clause* simplify(Clause* cl);
  void attach(SaturationAlgorithm* salg);
  void detach();
private:
  typedef List<ImmediateSimplificationEngine*> ISList;
  ISList* _inners;
};
















class CompositeGIE
: public GeneratingInferenceEngine
{
public:
  CLASS_NAME(CompositeGIE);
  USE_ALLOCATOR(CompositeGIE);

  CompositeGIE() : _inners(0) {}
  virtual ~CompositeGIE();
  void addFront(GeneratingInferenceEngine* fse);
  ClauseIterator generateClauses(Clause* premise);
  void attach(SaturationAlgorithm* salg);
  void detach();
private:
  typedef List<GeneratingInferenceEngine*> GIList;
  GIList* _inners;
};

class DuplicateLiteralRemovalISE
: public ImmediateSimplificationEngine
{
public:
  CLASS_NAME(DuplicateLiteralRemovalISE);
  USE_ALLOCATOR(DuplicateLiteralRemovalISE);

  Clause* simplify(Clause* cl);
};

class TrivialInequalitiesRemovalISE
: public ImmediateSimplificationEngine
{
public:
  Clause* simplify(Clause* cl);
};

};

#endif

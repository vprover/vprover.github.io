
/*
 * File TermAlgebraReasoning.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __TermAlgebraReasoning__
#define __TermAlgebraReasoning__

#include "Forwards.hpp"

#include "Indexing/AcyclicityIndex.hpp"

#include "Inferences/InferenceEngine.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/Signature.hpp"
#include "Kernel/Term.hpp"

#include "Saturation/SaturationAlgorithm.hpp"

namespace Inferences {

class DistinctnessISE
  : public ImmediateSimplificationEngine
{

public:
  CLASS_NAME(DistinctnessISE);
  USE_ALLOCATOR(DistinctnessISE);
  
  Kernel::Clause* simplify(Kernel::Clause* c);
};

class InjectivityGIE
  : public GeneratingInferenceEngine {
public:
  CLASS_NAME(InjectivityGIE);
  USE_ALLOCATOR(InjectivityGIE);
  
  Kernel::ClauseIterator generateClauses(Kernel::Clause* c);

private:
  struct SubtermIterator;
  struct SubtermEqualityFn;
};

class InjectivityISE
  : public ImmediateSimplificationEngine
{
public:
  CLASS_NAME(InjectivityISE);
  USE_ALLOCATOR(InjectivityISE);
  
  Kernel::Clause* simplify(Kernel::Clause* c);
};

class NegativeInjectivityISE
  : public ImmediateSimplificationEngine
{
public:
  CLASS_NAME(NegativeInjectivityISE);
  USE_ALLOCATOR(NegativeInjectivityISE);

  Kernel::Clause* simplify(Kernel::Clause* c);

private:
  bool litCondition(Clause* c, unsigned i);
};

class AcyclicityGIE
  : public GeneratingInferenceEngine {
public:
  CLASS_NAME(AcyclicityGIE);
  USE_ALLOCATOR(AcyclicityGIE);

  void attach(Saturation::SaturationAlgorithm* salg);
  void detach();
  Kernel::ClauseIterator generateClauses(Kernel::Clause *c);
private:
  struct AcyclicityGenIterator;
  struct AcyclicityGenFn;
  
  Indexing::AcyclicityIndex *_acyclIndex;
};

class AcyclicityGIE1
  : public GeneratingInferenceEngine {
public:
  CLASS_NAME(AcyclicityGIE1);
  USE_ALLOCATOR(AcyclicityGIE1);
  
  Kernel::ClauseIterator generateClauses(Kernel::Clause* c);

private:
  struct SubtermDisequalityFn;
  struct LiteralIterator;
  struct SubtermDisequalityIterator;
};
  
};

#endif


/*
 * File BinaryResolution.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Debug/RuntimeStatistics.hpp"

#include "Lib/Environment.hpp"
#include "Lib/Int.hpp"
#include "Lib/Metaiterators.hpp"
#include "Lib/PairUtils.hpp"
#include "Lib/VirtualIterator.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/ColorHelper.hpp"
#include "Kernel/Unit.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/LiteralSelector.hpp"
#include "Kernel/SortHelper.hpp"

#include "Indexing/Index.hpp"
#include "Indexing/LiteralIndex.hpp"
#include "Indexing/IndexManager.hpp"

#include "Saturation/SaturationAlgorithm.hpp"

#include "Shell/Options.hpp"
#include "Shell/Statistics.hpp"

#include "BinaryResolution.hpp"

namespace Inferences
{

using namespace Lib;
using namespace Kernel;
using namespace Indexing;
using namespace Saturation;

void BinaryResolution::attach(SaturationAlgorithm* salg)
{
  CALL("BinaryResolution::attach");
  ASS(!_index);

  GeneratingInferenceEngine::attach(salg);
  _index=static_cast<GeneratingLiteralIndex*> (
	  _salg->getIndexManager()->request(GENERATING_SUBST_TREE) );

  _unificationWithAbstraction = env.options->unificationWithAbstraction()!=Options::UnificationWithAbstraction::OFF;
}

void BinaryResolution::detach()
{
  CALL("BinaryResolution::detach");
  ASS(_salg);

  _index=0;
  _salg->getIndexManager()->release(GENERATING_SUBST_TREE);
  GeneratingInferenceEngine::detach();
}


struct BinaryResolution::UnificationsFn
{
  UnificationsFn(GeneratingLiteralIndex* index,bool cU)
  : _index(index),_unificationWithAbstraction(cU) {}
  DECL_RETURN_TYPE(VirtualIterator<pair<Literal*, SLQueryResult> >);
  OWN_RETURN_TYPE operator()(Literal* lit)
  {
    if(lit->isEquality()) {
      
      return OWN_RETURN_TYPE::getEmpty();
    }
    if(_unificationWithAbstraction){
      return pvi( pushPairIntoRightIterator(lit, _index->getUnificationsWithConstraints(lit, true)) );
    }
    return pvi( pushPairIntoRightIterator(lit, _index->getUnifications(lit, true)) );
  }
private:
  GeneratingLiteralIndex* _index;
  bool _unificationWithAbstraction;
};

struct BinaryResolution::ResultFn
{
  ResultFn(Clause* cl, Limits* limits, bool afterCheck, Ordering* ord, LiteralSelector& selector, BinaryResolution& parent)
  : _cl(cl), _limits(limits), _afterCheck(afterCheck), _ord(ord), _selector(selector), _parent(parent) {}
  DECL_RETURN_TYPE(Clause*);
  OWN_RETURN_TYPE operator()(pair<Literal*, SLQueryResult> arg)
  {
    CALL("BinaryResolution::ResultFn::operator()");

    SLQueryResult& qr = arg.second;
    Literal* resLit = arg.first;

    return BinaryResolution::generateClause(_cl, resLit, qr, _parent.getOptions(), _limits, _afterCheck ? _ord : 0, &_selector);
  }
private:
  Clause* _cl;
  Limits* _limits;
  bool _afterCheck;
  Ordering* _ord;
  LiteralSelector& _selector;
  BinaryResolution& _parent;
};

Clause* BinaryResolution::generateClause(Clause* queryCl, Literal* queryLit, SLQueryResult qr, const Options& opts, Limits* limits, Ordering* ord, LiteralSelector* ls)
{
  CALL("BinaryResolution::generateClause");
  ASS(qr.clause->store()==Clause::ACTIVE);

  if(!ColorHelper::compatible(queryCl->color(),qr.clause->color()) ) {
    env.statistics->inferencesSkippedDueToColors++;
    if(opts.showBlocked()) {
      env.beginOutput();
      env.out()<<"Blocked resolution of "<<queryCl->toString()<<" and "<<qr.clause->toString()<<endl;
      env.endOutput();
    }
    if(opts.colorUnblocking()) {
      SaturationAlgorithm* salg = SaturationAlgorithm::tryGetInstance();
      if(salg) {
	ColorHelper::tryUnblock(queryCl, salg);
	ColorHelper::tryUnblock(qr.clause, salg);
      }
    }
    return 0;
  }

  auto constraints = qr.constraints;
  bool withConstraints = !constraints.isEmpty() && !constraints->isEmpty();
  unsigned clength = queryCl->length();
  unsigned dlength = qr.clause->length();
  unsigned newAge=Int::max(queryCl->age(),qr.clause->age())+1;
  bool shouldLimitWeight=limits && limits->ageLimited() && newAge > limits->ageLimit()
	&& limits->weightLimited();
  unsigned weightLimit;
  if(shouldLimitWeight) {
    bool isNonGoal=queryCl->inputType()==0 && qr.clause->inputType()==0;
    if(isNonGoal) {
      weightLimit=limits->nonGoalWeightLimit();
    } else {
      weightLimit=limits->weightLimit();
    }
  }


  unsigned wlb=0;
  if(shouldLimitWeight) {
    for(unsigned i=0;i<clength;i++) {
      Literal* curr=(*queryCl)[i];
      if(curr!=queryLit) {
        wlb+=curr->weight();
      }
    }
    for(unsigned i=0;i<dlength;i++) {
      Literal* curr=(*qr.clause)[i];
      if(curr!=qr.literal) {
        wlb+=curr->weight();
      }
    }
    if(wlb > weightLimit) {
      RSTAT_CTR_INC("binary resolutions skipped for weight limit before building clause");
      env.statistics->discardedNonRedundantClauses++;
      return 0;
    }
  }

  unsigned conlength = withConstraints ? constraints->size() : 0;
  unsigned newLength = clength+dlength-2+conlength;

  Inference* inf = new Inference2((withConstraints?Inference::CONSTRAINED_RESOLUTION:Inference::RESOLUTION), 
                                  queryCl, qr.clause);
  Unit::InputType inpType = (Unit::InputType)
  	Int::max(queryCl->inputType(), qr.clause->inputType());

  Clause* res = new(newLength) Clause(newLength, inpType, inf);

  Literal* queryLitAfter = 0;
  if (ord && queryCl->numSelected() > 1) {
    TimeCounter tc(TC_LITERAL_ORDER_AFTERCHECK);
    queryLitAfter = qr.substitution->applyToQuery(queryLit);
  }
#if VDEBUG
  
#endif

  unsigned next = 0;
  if(withConstraints){
  for(unsigned i=0;i<constraints->size();i++){
      pair<TermList,TermList> con = (*constraints)[i]; 

#if VDEBUG
      
#endif

      TermList qT = qr.substitution->applyToQuery(con.first);
      TermList rT = qr.substitution->applyToResult(con.second);

      unsigned sort = SortHelper::getResultSort(rT.term()); 
      Literal* constraint = Literal::createEquality(false,qT,rT,sort);

      static Options::UnificationWithAbstraction uwa = opts.unificationWithAbstraction();
      if(uwa==Options::UnificationWithAbstraction::GROUND &&
         !constraint->ground() &&
         (!theory->isInterpretedFunction(qT) && !theory->isInterpretedConstant(qT)) && 
         (!theory->isInterpretedFunction(rT) && !theory->isInterpretedConstant(rT))){

        
        res->destroy();
        return 0;
      } 

      (*res)[next] = constraint; 
      next++;    
  }
  }
  for(unsigned i=0;i<clength;i++) {
    Literal* curr=(*queryCl)[i];
    if(curr!=queryLit) {
      Literal* newLit=qr.substitution->applyToQuery(curr);
      if(shouldLimitWeight) {
        wlb+=newLit->weight() - curr->weight();
        if(wlb > weightLimit) {
          RSTAT_CTR_INC("binary resolutions skipped for weight limit while building clause");
          env.statistics->discardedNonRedundantClauses++;
          res->destroy();
          return 0;
        }
      }
      if (queryLitAfter && i < queryCl->numSelected()) {
        TimeCounter tc(TC_LITERAL_ORDER_AFTERCHECK);

        Ordering::Result o = ord->compare(newLit,queryLitAfter);

        if (o == Ordering::GREATER ||
            (ls->isPositiveForSelection(newLit)    
                && (o == Ordering::GREATER_EQ || o == Ordering::EQUAL))) { 
          env.statistics->inferencesBlockedForOrderingAftercheck++;
          res->destroy();
          return 0;
        }
      }
      (*res)[next] = newLit;
      next++;
    }
  }

  Literal* qrLitAfter = 0;
  if (ord && qr.clause->numSelected() > 1) {
    TimeCounter tc(TC_LITERAL_ORDER_AFTERCHECK);
    qrLitAfter = qr.substitution->applyToResult(qr.literal);
  }

  for(unsigned i=0;i<dlength;i++) {
    Literal* curr=(*qr.clause)[i];
    if(curr!=qr.literal) {
      Literal* newLit = qr.substitution->applyToResult(curr);
      if(shouldLimitWeight) {
        wlb+=newLit->weight() - curr->weight();
        if(wlb > weightLimit) {
          RSTAT_CTR_INC("binary resolutions skipped for weight limit while building clause");
          env.statistics->discardedNonRedundantClauses++;
          res->destroy();
          return 0;
        }
      }
      if (qrLitAfter && i < qr.clause->numSelected()) {
        TimeCounter tc(TC_LITERAL_ORDER_AFTERCHECK);

        Ordering::Result o = ord->compare(newLit,qrLitAfter);

        if (o == Ordering::GREATER ||
            (ls->isPositiveForSelection(newLit)   
                && (o == Ordering::GREATER_EQ || o == Ordering::EQUAL))) { 
          env.statistics->inferencesBlockedForOrderingAftercheck++;
          res->destroy();
          return 0;
        }
      }

      (*res)[next] = newLit;
      next++;
    }
  }

  res->setAge(newAge);
  if(withConstraints){
    env.statistics->cResolution++;
  }
  else{ 
    env.statistics->resolution++;
  }

  

  return res;
}

ClauseIterator BinaryResolution::generateClauses(Clause* premise)
{
  CALL("BinaryResolution::generateClauses");

  

  Limits* limits = _salg->getLimits();

  
  auto it1 = getMappingIterator(premise->getSelectedLiteralIterator(),UnificationsFn(_index,_unificationWithAbstraction));
  
  auto it2 = getFlattenedIterator(it1);
  
  auto it3 = getMappingIterator(it2,ResultFn(premise, limits,
      getOptions().literalMaximalityAftercheck() && _salg->getLiteralSelector().isBGComplete(), &_salg->getOrdering(),_salg->getLiteralSelector(),*this));
  
  auto it4 = getFilteredIterator(it3, NonzeroFn());
  
  auto it5 = getTimeCountedIterator(it4,TC_RESOLUTION);

  return pvi(it5);
}

}

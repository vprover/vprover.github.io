
/*
 * File Instantiation.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Debug/RuntimeStatistics.hpp"

#include "Lib/Environment.hpp"
#include "Lib/Metaiterators.hpp"
#include "Lib/VirtualIterator.hpp"
#include "Lib/DArray.hpp"
#include "Lib/Set.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/Sorts.hpp"
#include "Kernel/SortHelper.hpp"
#include "Kernel/Substitution.hpp"
#include "Kernel/SubstHelper.hpp"
#include "Kernel/Theory.hpp"
#include "Kernel/TermIterators.hpp"

#include "Shell/Statistics.hpp"

#include "Instantiation.hpp"

namespace Inferences
{

using namespace Lib;
using namespace Kernel;

void Instantiation::registerClause(Clause* cl)
{
  CALL("Instantiation::registerClause");
  ASS(cl);

  

  Clause::Iterator cit(*cl);
  while(cit.hasNext()){
    Literal* lit = cit.next();
    SubtermIterator it(lit);
    while(it.hasNext()){
      TermList t = it.next();
      if(t.isTerm() && t.term()->ground()){
        unsigned sort;
        if(SortHelper::tryGetResultSort(t,sort)){
          if(sort==Sorts::SRT_DEFAULT) continue;
          Set<Term*>* cans_check=0;
          Stack<Term*>* cans=0;
          if(sorted_candidates.isEmpty() || !sorted_candidates.find(sort,cans)){
            cans_check = new Set<Term*>();
            cans = new Stack<Term*>();
            sorted_candidates.insert(sort,cans);
            sorted_candidates_check.insert(sort,cans_check);
          }
          else{ ALWAYS(sorted_candidates_check.find(sort,cans_check)); }
          ASS(cans_check && cans);
          
          if(!cans_check->contains(t.term())){
            cans_check->insert(t.term());
            cans->push(t.term());
          }
        }
      }
    }
  }

}

void Instantiation::tryMakeLiteralFalse(Literal* lit, Stack<Substitution>& subs)
{
  CALL("Instantiation::tryMakeLiteralFalse");

    if(theory->isInterpretedPredicate(lit)){ 
      Interpretation interpretation = theory->interpretPredicate(lit);
      

      
      switch(interpretation){
        case Theory::EQUAL:
        case Theory::INT_LESS: 
        case Theory::RAT_LESS:
        case Theory::REAL_LESS:
        {
          TermList* left = lit->nthArgument(0); TermList* right = lit->nthArgument(1); 
          unsigned var;
          Term* t = 0;
          if(left->isVar() && !right->isVar()){
           t = right->term(); 
           var = left->var();
          }
          if(right->isVar() && !left->isVar()){
           t = left->term(); 
           var = right->var();
          }
          if(t){
            
            VariableIterator vit(t);
            while(vit.hasNext()) if(vit.next().var()==var) return;

            
            Substitution s1;
            s1.bind(var,t);
            subs.push(s1);
            if(lit->polarity()){
             t = tryGetDifferentValue(t);
             if(t){
               Substitution s2;
               s2.bind(var,t);
               subs.push(s2);
             }
            }
          }
          break;
        }
        default: 
          break;
      }
    }

}

Term* Instantiation::tryGetDifferentValue(Term* t)
{
  CALL("Instantiation::tryGetDifferentValue");

  unsigned sort = SortHelper::getResultSort(t);

  try {
        switch(sort){
          case Sorts::SRT_INTEGER:
            {
              IntegerConstantType constant;
              if(theory->tryInterpretConstant(t,constant)){
                return theory->representConstant(constant+1);
              }
              break;
            }
          case Sorts::SRT_RATIONAL:
            {
              RationalConstantType constant;
              RationalConstantType one(1,1);
              if(theory->tryInterpretConstant(t,constant)){
                return theory->representConstant(constant+one);
              }
              break;
            }
          case Sorts::SRT_REAL:
            {
              RealConstantType constant;
              RealConstantType one(RationalConstantType(1,1));
              if(theory->tryInterpretConstant(t,constant)){
                return theory->representConstant(constant+one);
              }
              break;
            }
          default:
            break;
            
        }
  } catch (ArithmeticException&) {
    
  }

  return 0;
}

VirtualIterator<Term*> Instantiation::getCandidateTerms(Clause* cl, unsigned var,unsigned sort)
{
  CALL("Instantiation::getCandidateTerms");

  Stack<Term*>* cans=0;
  VirtualIterator<Term*> res = VirtualIterator<Term*>::getEmpty();
  if(sorted_candidates.find(sort,cans) && cans->size()){
    res = pvi(Stack<Term*>::Iterator(*cans));
  }
  return res; 
}

class Instantiation::AllSubstitutionsIterator{
public:
  AllSubstitutionsIterator(Clause* cl,Instantiation* ins)
  {
    CALL("Instantiation::AllSubstitutionsIterator");
    DHMap<unsigned,unsigned> sortedVars;
    SortHelper::collectVariableSorts(cl,sortedVars);
    VirtualIterator<std::pair<unsigned,unsigned>> it = sortedVars.items();

    while(it.hasNext()){
       std::pair<unsigned,unsigned> item = it.next();
       DArray<Term*>* array = new DArray<Term*>();
       array->initFromIterator(ins->getCandidateTerms(cl,item.first,item.second));
       candidates.insert(item.first,array);
       current.insert(item.first,0);
    }
    variables = candidates.domain();
    finished = !variables.hasNext();
    if(!finished) currently = variables.next();
  }

  bool hasNext(){ return !finished; }

  Substitution next()
  {
    CALL("AllSubstitutionsIterator::next")
    Substitution sub;
    VirtualIterator<unsigned> vs = candidates.domain(); 
    while(vs.hasNext()){
      unsigned v = vs.next();
      DArray<Term*>* cans;
      if(candidates.find(v,cans) && cans->size()!=0){
        unsigned at = current.get(v);
        sub.bind(v,(* cans)[at]);
      }
    }
    

    
    if(!candidates.find(currently) || candidates.get(currently)->size()==0 || 
       candidates.get(currently)->size() == current.get(currently)+1){
      if(variables.hasNext()) currently = variables.next();
      else finished=true;
    }
    else{
      current.set(currently,(current.get(currently)+1));
    }

    return sub; 
  }

private:
  DHMap<unsigned,DArray<Term*>*> candidates;
  DHMap<unsigned,unsigned> current;
  VirtualIterator<unsigned> variables;
  unsigned currently;
  bool finished;
};

struct Instantiation::ResultFn
{
  ResultFn(Clause* cl) : _cl(cl) {}
  DECL_RETURN_TYPE(Clause*);
  OWN_RETURN_TYPE operator()(Substitution sub)
  {
    CALL("Instantiation::ResultFn::operator()");

    Inference* inf = new Inference1(Inference::INSTANTIATION,_cl);
    unsigned clen = _cl->length();
    Clause* res = new(clen) Clause(clen,_cl->inputType(),inf);
    res->setAge(_cl->age()+1);

    for(unsigned i=0;i<clen;i++){
      (*res)[i] = SubstHelper::apply((*_cl)[i],sub);
    }

    return res; 
  }
private:
  Clause* _cl;
};

ClauseIterator Instantiation::generateClauses(Clause* premise)
{
  CALL("Instantiation::generateClauses");

  

  Stack<Substitution> subs;
  for(unsigned i=0;i<premise->length();i++){
    Literal* lit = (*premise)[i];
    tryMakeLiteralFalse(lit,subs);
  }

  return pvi(getConcatenatedIterator(
  
               getMappingIterator(
                  getPersistentIterator(Stack<Substitution>::Iterator(subs)),
                  ResultFn(premise)
               ),
               getMappingIterator(
                 AllSubstitutionsIterator(premise,this),
                 ResultFn(premise)
              )
         ));

}

}


/*
 * File FOOLParamodulation.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Lib/Environment.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/EqHelper.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/Term.hpp"
#include "Kernel/TermIterators.hpp"
#include "Kernel/Signature.hpp"
#include "Kernel/Sorts.hpp"

#include "FOOLParamodulation.hpp"

namespace Inferences {

ClauseIterator FOOLParamodulation::generateClauses(Clause* premise) {
  CALL("FOOLParamodulation::generateClauses");

 

  static TermList troo(Term::foolTrue());
  static TermList fols(Term::foolFalse());

 
  TermList booleanTerm;
  unsigned literalPosition = 0;

  ArrayishObjectIterator<Clause> literals = premise->getSelectedLiteralIterator();
  while (literals.hasNext()) {
    Literal* literal = literals.next();

    
    if (literal->isEquality() && literal->polarity()) {
      TermList* lhs = literal->nthArgument(0);
      TermList* rhs = literal->nthArgument(1);
      if ((lhs->isTerm() && env.signature->isFoolConstantSymbol(false,lhs->term()->functor())) ||
          (rhs->isTerm() && env.signature->isFoolConstantSymbol(false,rhs->term()->functor()))) {
        literalPosition++;
        continue;
      }
    }

    
    NonVariableIterator nvi(literal);
    while (nvi.hasNext()) {
      TermList subterm = nvi.next();
      unsigned functor = subterm.term()->functor();

      
      if (env.signature->isFoolConstantSymbol(false,functor) || env.signature->isFoolConstantSymbol(true,functor)) {
        continue;
      }

      unsigned resultType = env.signature->getFunction(functor)->fnType()->result();
      if (resultType == Sorts::SRT_BOOL) {
        booleanTerm = subterm;
        goto substitution;
      }
    }
    literalPosition++;
  }

  
  
  return ClauseIterator::getEmpty();

  substitution:

  
  unsigned conclusionLength = premise->length() + 1;
  Inference* inference = new Inference1(Inference::FOOL_PARAMODULATION, premise);
  Clause* conclusion = new(conclusionLength) Clause(conclusionLength, premise->inputType(), inference);
  conclusion->setAge(premise->age() + 1);

  
  
  for (unsigned i = 0; i < conclusion->length() - 1; i++) {
    (*conclusion)[i] = i == literalPosition ? EqHelper::replace((*premise)[i], booleanTerm, troo) : (*premise)[i];
  }

  
  (*conclusion)[conclusion->length() - 1] = Literal::createEquality(true, booleanTerm, fols, Sorts::SRT_BOOL);

  return pvi(getSingletonIterator(conclusion));
}

}

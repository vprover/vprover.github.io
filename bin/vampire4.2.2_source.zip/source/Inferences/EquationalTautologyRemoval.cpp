
/*
 * File EquationalTautologyRemoval.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "EquationalTautologyRemoval.hpp"

#include "Lib/DHSet.hpp"
#include "Lib/Environment.hpp"
#include "Shell/Statistics.hpp"
#include "Kernel/Clause.hpp"

namespace Inferences
{

Clause* EquationalTautologyRemoval::simplify(Clause* cl)
{
  CALL("EquationalTautologyRemoval::simplify");

  
  
  
  

  bool has_neg_eq = false;
  bool has_pos_eq = false;
  bool has_complement = false;

  static DHSet<int> preds;
  preds.reset();

  for (unsigned i = 0; i < cl->length(); i++) {
    Literal* lit = (*cl)[i];

    if (lit->isEquality()) {
      if (lit->isNegative()) {
        has_neg_eq = true;
      } else {
        has_pos_eq = true;
      }
    } else {
      ASS_G(lit->functor(),0);

      int pred = lit->isNegative() ? -lit->functor() : lit->functor();

      if (preds.find(-pred)) {
        has_complement = true;
      }

      preds.insert(pred);
    }
  }

  if (!has_neg_eq || (!has_pos_eq && !has_complement)) {
    return cl;
  }

  _cc.reset();

  
  for (unsigned i = 0; i < cl->length(); i++) {
    Literal* lit = (*cl)[i];

    if (!lit->isEquality()) {
      int pred = lit->isNegative() ? -lit->functor() : lit->functor();
      if (!preds.find(-pred)) {
        continue;
      }
    }

    
    Literal* oplit = Literal::complementaryLiteral(lit);
    _cc.addLiteral(oplit);
  }

  if (_cc.getStatus(false) == DP::DecisionProcedure::UNSATISFIABLE) {
    

    env.statistics->deepEquationalTautologies++;
    return 0;
  } else {
    return cl;
  }
}

}

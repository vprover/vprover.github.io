
/*
 * File TheoryInstAndSimp.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#if VZ3

#define DPRINT 0

#include "Debug/RuntimeStatistics.hpp"

#include "Lib/Environment.hpp"
#include "Lib/Metaiterators.hpp"
#include "Lib/VirtualIterator.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/Unit.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/Signature.hpp"
#include "Kernel/Term.hpp"
#include "Kernel/Substitution.hpp"
#include "Kernel/TermIterators.hpp"
#include "Kernel/SubstHelper.hpp"

#include "Saturation/SaturationAlgorithm.hpp"
#include "Saturation/Splitter.hpp"

#include "Shell/Options.hpp"
#include "Shell/Statistics.hpp"
#include "Shell/TheoryFlattening.hpp"

#include "SAT/SATLiteral.hpp"
#include "SAT/SAT2FO.hpp"
#include "SAT/Z3Interfacing.hpp"

#include "TheoryInstAndSimp.hpp"

namespace Inferences
{

using namespace Lib;
using namespace Kernel;
using namespace Shell;
using namespace Saturation;
using namespace SAT;


void TheoryInstAndSimp::attach(SaturationAlgorithm* salg)
{
  CALL("Superposition::attach");

  GeneratingInferenceEngine::attach(salg);
  _splitter = salg->getSplitter();
}

void TheoryInstAndSimp::selectTheoryLiterals(Clause* cl, Stack<Literal*>& theoryLits,bool forZ3)
{
  CALL("TheoryInstAndSimp::selectTheoryLiterals");
#if DPRINT
  cout << "selectTheoryLiterals["<<forZ3<<"] in " << cl->toString() << endl;
#endif

  static Shell::Options::TheoryInstSimp selection = env.options->theoryInstAndSimp();
  ASS(selection!=Shell::Options::TheoryInstSimp::OFF);

  Stack<Literal*> weak;
  Set<unsigned> strong_vars;
  Set<unsigned> strong_symbols;
  Array<Stack<Literal*>> var_to_lits(cl->varCnt());
  

  Clause::Iterator it(*cl);
  while(it.hasNext()){
    Literal* lit = it.next();
    bool interpreted = theory->isInterpretedPredicate(lit);

    
    

    
    if(interpreted && lit->isEquality() && !lit->isTwoVarEquality()) {  
      for(TermList* ts = lit->args(); ts->isNonEmpty(); ts = ts->next()){
        if(ts->isTerm() && !env.signature->getFunction(ts->term()->functor())->interpreted()){
          interpreted=false;
          break;
        }
      }
    }

    if(forZ3){
    
    
    
    for(TermList* ts = lit->args(); ts->isNonEmpty(); ts = ts->next()){
      if(ts->isTerm()){
        Term* t = ts->term();
        if(theory->isInterpretedPartialFunction(t->functor()) &&
           theory->isZero(*(t->nthArgument(1)))){
          
          interpreted=false;
#if DPRINT
          cout << "forZ3 interpreted is false for " << lit->toString() << endl;
#endif
        }
      }
    }
    }

    if(interpreted){    
      VariableIterator vit(lit); 
      bool pos_equality = lit->isEquality() && lit->polarity();
      
      bool is_weak = !vit.hasNext() || pos_equality;
      if(selection != Shell::Options::TheoryInstSimp::ALL && 
         selection != Shell::Options::TheoryInstSimp::FULL && 
         is_weak){
        weak.push(lit);
      }
      else{
#if DPRINT
        cout << "select " << lit->toString() << endl;
#endif
        theoryLits.push(lit);
        while(vit.hasNext()){ 
          unsigned v = vit.next().var();
          strong_vars.insert(v); 
          var_to_lits[v].push(lit);
        }
        NonVariableIterator nit(lit);
        while(nit.hasNext()){ strong_symbols.insert(nit.next().term()->functor());}
      }
    } 
  }
  if(selection == Shell::Options::TheoryInstSimp::OVERLAP){

  Stack<Literal*>::Iterator wit(weak);
  while(wit.hasNext()){
    Literal* lit = wit.next();
#if DPRINT
	cout << "consider weak " << lit->toString() << endl;
#endif
    VariableIterator vit(lit);
    bool add = false;
    while(vit.hasNext() && !add){
      if(strong_vars.contains(vit.next().var())){
        add=true; 
#if DPRINT
	cout << "add weak as has strong var" << endl;
#endif
      }
    }
    if(!add){
      NonVariableIterator nit(lit); 
      while(nit.hasNext() && !add){
        if(strong_symbols.contains(nit.next().term()->functor())){
          add=true;
#if DPRINT
        cout << "add weak as has strong symbol" << endl;
#endif
        }
      }
    }
    if(add){
#if DPRINT
        cout << "select " << lit->toString() << endl;
#endif
        theoryLits.push(lit);
        VariableIterator vit(lit);
        while(vit.hasNext()){ var_to_lits[vit.next().var()].push(lit); } 
    }
  }
 
  }
  
  
  if(forZ3){
    Stack<Literal*>::Iterator tlit(theoryLits);
    Stack<Literal*> deselected;
    while(tlit.hasNext()){
      Literal* lit = tlit.next();
      NonVariableIterator nit(lit);
      bool deselect=false;
      while(nit.hasNext() && !deselect){
        Term* t = nit.next().term();
        deselect = !(theory->isInterpretedFunction(t->functor()) || theory->isInterpretedConstant(t->functor())); 
        if(deselect){ cout << t->toString() << endl; }
      }
      if(deselect){ deselected.push(lit);}
    }
    Stack<Literal*>::Iterator dit(deselected);
    while(dit.hasNext()){ 
      Literal* lit = dit.next();
      theoryLits.remove(lit);
#if DPRINT
	cout << "deselect1 " << lit->toString() << endl;
#endif
    }
  }
  for(unsigned i=0;i<var_to_lits.size();i++){
    if(var_to_lits[i].size()==1){
      Literal * lit = var_to_lits[i][0]; 
      
      if(lit->isEquality() && !lit->polarity() &&
         ((lit->nthArgument(0)->isVar() && lit->nthArgument(0)->var()==i) || 
          (lit->nthArgument(1)->isVar() && lit->nthArgument(1)->var()==i))
         ){
#if DPRINT
        cout << "deselect2 " << lit->toString() << endl;
#endif
        theoryLits.remove(lit);
      }
    }
  }
}

Term* getFreshConstant(unsigned index, unsigned srt)
{
  CALL("TheoryInstAndSimp::getFreshConstant");
  static Stack<Stack<Term*>*> constants;

  while(srt+1 > constants.length()){
    Stack<Term*>* stack = new Stack<Term*>;
    constants.push(stack);
  }
  Stack<Term*>* sortedConstants = constants[srt]; 
  while(index+1 > sortedConstants->length()){
    unsigned sym = env.signature->addFreshFunction(0,"$inst");
    FunctionType* type = new FunctionType(srt);
    env.signature->getFunction(sym)->setType(type);
    Term* fresh = Term::createConstant(sym);
    sortedConstants->push(fresh);
  }
  return (*sortedConstants)[index];
}

VirtualIterator<Solution> TheoryInstAndSimp::getSolutions(Stack<Literal*>& theoryLiterals, bool guarded){
  CALL("TheoryInstAndSimp::getSolutions");

  BYPASSING_ALLOCATOR;

  

  
  
  static SAT2FO naming;
  static Z3Interfacing solver(*env.options,naming);
  solver.reset(); 


  
  
  
  Substitution subst;

  Stack<Literal*>::Iterator it(theoryLiterals);
  Stack<unsigned> vars;
  unsigned used = 0;
  while(it.hasNext()){
    
    Literal* lit = Literal::complementaryLiteral(it.next());
    
    DHMap<unsigned,unsigned > srtMap;
    SortHelper::collectVariableSorts(lit,srtMap); 
    TermVarIterator vit(lit);
    while(vit.hasNext()){
      unsigned var = vit.next();
      unsigned sort = srtMap.get(var);
      TermList fc;
      if(!subst.findBinding(var,fc)){
        Term* fc = getFreshConstant(used++,sort);
#if DPRINT
    cout << "bind " << var << " to " << fc->toString() << endl;
#endif
        subst.bind(var,fc);
        vars.push(var);
      }
    }
#if DPRINT
    cout << "skolem " << lit->toString();
#endif

    lit = SubstHelper::apply(lit,subst);

#if DPRINT
    cout << " to get " << lit->toString() << endl;
#endif

    
    SATLiteral slit = naming.toSAT(lit);

    
    static SATLiteralStack satLits;
    satLits.reset();
    satLits.push(slit);
    SATClause* sc = SATClause::fromStack(satLits); 
    
    
    try{
      solver.addClause(sc,guarded);
    }
    catch(UninterpretedForZ3Exception){
      return VirtualIterator<Solution>::getEmpty();
    }
  }

  
  SATSolver::Status status = solver.solve(UINT_MAX);

  if(status == SATSolver::UNSATISFIABLE){
#if DPRINT
    cout << "z3 says unsat" << endl;
#endif
    return pvi(getSingletonIterator(Solution(false)));
  }
  else if(status == SATSolver::SATISFIABLE){
    Solution sol = Solution(true);
    Stack<unsigned>::Iterator vit(vars);
    while(vit.hasNext()){
      unsigned v = vit.next();
      Term* t = subst.apply(v).term();
      ASS(t);
      
      t = solver.evaluateInModel(t);
      
      if(t){
        
        sol.subst.bind(v,t);
      } else {
        
        env.statistics->theoryInstSimpLostSolution++;
        goto fail;
      }
    }
#if DPRINT
    cout << "solution with " << sol.subst.toString() << endl;
#endif
    return pvi(getSingletonIterator(sol));
  }

  fail:
#if DRPINT
    cout << "no solution" << endl;
#endif

  
  return VirtualIterator<Solution>::getEmpty(); 

}


struct InstanceFn
{
  InstanceFn(Clause* premise, Clause* cl,Stack<Literal*>& tl,Splitter* splitter, 
             SaturationAlgorithm* salg, TheoryInstAndSimp* parent,bool& red) : 
         _premise(premise), _cl(cl), _theoryLits(tl), _splitter(splitter), 
         _salg(salg), _parent(parent), _red(red) {}
  
  DECL_RETURN_TYPE(Clause*);
  OWN_RETURN_TYPE operator()(Solution sol)
  {
    CALL("TheoryInstAndSimp::InstanceFn::operator()");

    
    if(!sol.status){
#if DPRINT
      cout << "Potential theory tautology" << endl;
#endif
      
      
      bool containsPartial = false;
      Stack<Literal*>::Iterator lit(_theoryLits);
      while(lit.hasNext()){
        NonVariableIterator tit(lit.next());
        while(tit.hasNext()){
          if(theory->isInterpretedPartialFunction(tit.next().term()->functor())){
            containsPartial=true;
            goto partial_check_end;
          }
        }
      }
partial_check_end:

      
      if(containsPartial){
        auto solutions = _parent->getSolutions(_theoryLits,false);
        
        if(solutions.hasNext() && !solutions.next().status){
          containsPartial=false;
        }
      }

      if(!containsPartial){
        env.statistics->theoryInstSimpTautologies++;
        
        
        _red=true;
      }

      return 0;
    }
    
    if(sol.subst.isEmpty()){
      return 0;
    }
#if DPRINT
    cout << "Instantiate " << _cl->toString() << endl;
    cout << "with " << sol.subst.toString() << endl;
#endif
    Inference* inf_inst = new Inference1(Inference::INSTANTIATION,_cl);
    Clause* inst = new(_cl->length()) Clause(_cl->length(),_cl->inputType(),inf_inst);

    Inference* inf_simp = new Inference1(Inference::INTERPRETED_SIMPLIFICATION,inst);
    unsigned newLen = _cl->length() - _theoryLits.size();
    Clause* res = new(newLen) Clause(newLen,_cl->inputType(),inf_simp);

#if VDEBUG
    unsigned skip = 0;
#endif
    unsigned j=0;
    for(unsigned i=0;i<_cl->length();i++){
      Literal* lit = (*_cl)[i];
      Literal* lit_inst = SubstHelper::apply(lit,sol.subst);
      (*inst)[i] = lit_inst;
      
      if(!_theoryLits.find(lit)){
        (*res)[j] = lit_inst; 
        j++;
      }
#if VDEBUG
      else{skip++;}
#endif
    }
    ASS_EQ(skip, _theoryLits.size());
    ASS_EQ(j,newLen);

    if(_splitter){
      _splitter->onNewClause(inst);
    }

    env.statistics->theoryInstSimp++;
#if DPRINT
    cout << "to get " << res->toString() << endl;
#endif
    return res;
  }

private:
  Clause* _premise;
  Clause* _cl;
  Stack<Literal*>& _theoryLits;
  Splitter* _splitter;
  SaturationAlgorithm* _salg;
  TheoryInstAndSimp* _parent;
  bool& _red;
};

ClauseIterator TheoryInstAndSimp::generateClauses(Clause* premise,bool& premiseRedundant)
{
  CALL("TheoryInstAndSimp::generateClauses");

  if(premise->isTheoryDescendant()){ return ClauseIterator::getEmpty(); }

  static Stack<Literal*> selectedLiterals;
  selectedLiterals.reset();

  selectTheoryLiterals(premise,selectedLiterals,false);

  
  if(selectedLiterals.isEmpty()){
        return ClauseIterator::getEmpty();
  }

  
  env.statistics->theoryInstSimpCandidates++;

  
  

  
  static Options::TheoryInstSimp thi = env.options->theoryInstAndSimp();
  static TheoryFlattening flattener((thi==Options::TheoryInstSimp::FULL),true);

  Clause* flattened = flattener.apply(premise,selectedLiterals);

  ASS(flattened);

  
  if(_splitter && flattened!=premise){
    _splitter->onNewClause(flattened);
  }

  static Stack<Literal*> theoryLiterals;
  theoryLiterals.reset();

  
  
  selectTheoryLiterals(flattened,theoryLiterals,true);

  
  

#if DPRINT
  cout << "Generate instances of " << premise->toString() << endl;
  cout << "With flattened " << flattened->toString() << endl;
#endif
  if(theoryLiterals.isEmpty()){
     
     return ClauseIterator::getEmpty();
  }

  auto it1 = getSolutions(theoryLiterals);

  auto it2 = getMappingIterator(it1,
               InstanceFn(premise,flattened,theoryLiterals,_splitter,_salg,this,premiseRedundant));

  
  auto it3 = getFilteredIterator(it2, NonzeroFn());

  
  auto it4 = getTimeCountedIterator(it3,TC_THEORY_INST_SIMP);

  return pvi(it4);
}

}

#endif

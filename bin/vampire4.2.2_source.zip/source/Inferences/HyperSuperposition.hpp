
/*
 * File HyperSuperposition.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __HyperSuperposition__
#define __HyperSuperposition__

#include "Forwards.hpp"

#include "InferenceEngine.hpp"

namespace Inferences
{

using namespace Kernel;
using namespace Indexing;
using namespace Saturation;

class HyperSuperposition
: public ForwardSimplificationEngine
{
public:
  CLASS_NAME(HyperSuperposition);
  USE_ALLOCATOR(HyperSuperposition);

  HyperSuperposition() : _index(0) {}

  void attach(SaturationAlgorithm* salg) override;
  void detach() override;

  Clause* generateClause(Clause* queryCl, Literal* queryLit, SLQueryResult res, Limits* limits=0);
  ClauseIterator generateClauses(Clause* premise);

  bool perform(Clause* cl, Clause*& replacement, ClauseIterator& premises) override;
private:
  typedef pair<TermList,TermList> TermPair;
 
  typedef pair<TermPair, int> RewriterEntry;
  typedef Stack<RewriterEntry> RewriterStack;

 
  typedef pair<Clause*,Clause*> ClausePair;
  typedef Stack<ClausePair> ClausePairStack;

  bool tryToUnifyTwoTermPairs(RobSubstitution& subst, TermList tp1t1, int bank11,
      TermList tp1t2, int bank12, TermList tp2t1, int bank21, TermList tp2t2, int bank22);

  bool tryMakeTopUnifiableByRewriter(TermList t1, TermList t2, int t2Bank, int& nextAvailableBank, ClauseStack& premises,
      RewriterStack& rewriters, RobSubstitution& subst, Color& infClr);

  bool tryGetRewriters(Term* t1, Term* t2, int t2Bank, int& nextAvailableBank, ClauseStack& premises,
      RewriterStack& rewriters, RobSubstitution& subst, Color& infClr);

  void tryUnifyingSuperpositioins(Clause* cl, unsigned literalIndex, Term* t1, Term* t2,
      bool disjointVariables, ClauseStack& acc);

  bool tryGetUnifyingPremises(Term* t1, Term* t2, Color clr, bool disjointVariables, ClauseStack& premises);

 
  Clause* tryGetContradictionFromUnification(Clause* cl, Term* t1, Term* t2, bool disjointVariables, ClauseStack& premStack);

  bool trySimplifyingFromUnification(Clause* cl, Term* t1, Term* t2, bool disjointVariables, ClauseStack& premStack,
      Clause*& replacement, ClauseIterator& premises);
  bool tryUnifyingNonequalitySimpl(Clause* cl, Clause*& replacement, ClauseIterator& premises);
  bool tryUnifyingToResolveSimpl(Clause* cl, Clause*& replacement, ClauseIterator& premises);


  Literal* getUnifQueryLit(Literal* base);
  void resolveFixedLiteral(Clause* cl, unsigned litIndex, ClausePairStack& acc);

  void tryUnifyingNonequality(Clause* cl, unsigned literalIndex, ClausePairStack& acc);
  void tryUnifyingToResolveWithUnit(Clause* cl, unsigned literalIndex, ClausePairStack& acc);

  static bool rewriterEntryComparator(RewriterEntry p1, RewriterEntry p2);

  UnitClauseLiteralIndex* _index;
};

};

#endif

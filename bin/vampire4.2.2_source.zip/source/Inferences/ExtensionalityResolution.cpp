
/*
 * File ExtensionalityResolution.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Debug/RuntimeStatistics.hpp"

#include "Lib/Environment.hpp"
#include "Lib/Metaiterators.hpp"
#include "Lib/PairUtils.hpp"
#include "Lib/VirtualIterator.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/Unit.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/RobSubstitution.hpp"
#include "Kernel/SortHelper.hpp"
#include "Kernel/ColorHelper.hpp"

#include "Saturation/SaturationAlgorithm.hpp"

#include "Shell/Options.hpp"
#include "Shell/Statistics.hpp"

#include "ExtensionalityResolution.hpp"

using namespace Inferences;
using namespace Lib;
using namespace Kernel;
using namespace Indexing;
using namespace Saturation;



struct ExtensionalityResolution::ForwardPairingFn
{
  ForwardPairingFn (ExtensionalityClauseContainer* extClauses)
  : _extClauses(extClauses) {}
  DECL_RETURN_TYPE(VirtualIterator<pair<Literal*, ExtensionalityClause> >);
  OWN_RETURN_TYPE operator()(Literal* lit)
  {
    CALL("ExtensionalityResolution::ForwardPairingFn::operator()");
    
    if (!lit->isEquality() || lit->isPositive()) {
      return OWN_RETURN_TYPE::getEmpty();
    }

    unsigned s = SortHelper::getEqualityArgumentSort(lit);
    
    return pvi(
      pushPairIntoRightIterator(
        lit,
        _extClauses->activeIterator(s)));
  }
private:
  ExtensionalityClauseContainer* _extClauses;
};

struct ExtensionalityResolution::ForwardUnificationsFn
{
  ForwardUnificationsFn() { _subst = RobSubstitutionSP(new RobSubstitution()); }
  DECL_RETURN_TYPE(VirtualIterator<pair<pair<Literal*, ExtensionalityClause>, RobSubstitution*> >);
  OWN_RETURN_TYPE operator()(pair<Literal*, ExtensionalityClause> arg)
  {
    CALL("ExtensionalityResolution::ForwardUnificationsFn::operator()");
    
    Literal* trmEq = arg.first;
    Literal* varEq = arg.second.literal;

    SubstIterator unifs = _subst->unifiers(varEq,0,trmEq,1,true);
    if (!unifs.hasNext()) {
      return OWN_RETURN_TYPE::getEmpty();
    }
    return pvi(pushPairIntoRightIterator(arg, unifs));
  }
private:
  RobSubstitutionSP _subst;
};

struct ExtensionalityResolution::ForwardResultFn
{
  ForwardResultFn(Clause* otherCl, ExtensionalityResolution& parent) : _otherCl(otherCl), _parent(parent) {}
  DECL_RETURN_TYPE(Clause*);
  OWN_RETURN_TYPE operator()(pair<pair<Literal*, ExtensionalityClause>, RobSubstitution*> arg)
  {
    CALL("ExtensionalityResolution::ForwardResultFn::operator()");
    
    RobSubstitution* subst = arg.second;
    Literal* otherLit = arg.first.first;
    Clause* extCl = arg.first.second.clause;
    Literal* extLit = arg.first.second.literal;

    return performExtensionalityResolution(extCl, extLit, _otherCl, otherLit, subst,
                                             env.statistics->forwardExtensionalityResolution,
                                             _parent.getOptions());
  }
private:
  Clause* _otherCl;
  ExtensionalityResolution& _parent;
};



struct ExtensionalityResolution::NegEqSortFn
{
  NegEqSortFn (unsigned sort) : _sort(sort) {}
  DECL_RETURN_TYPE(bool);
  OWN_RETURN_TYPE operator()(Literal* lit)
  {
    CALL("ExtensionalityResolution::NegEqSortFn::operator()");
    
    return lit->isEquality() && lit->isNegative() &&
      SortHelper::getEqualityArgumentSort(lit) == _sort;
  }
private:
  unsigned _sort;
};

struct ExtensionalityResolution::BackwardPairingFn
{
  BackwardPairingFn (unsigned sort) : _sort(sort) {}
  DECL_RETURN_TYPE(VirtualIterator<pair<Clause*, Literal*> >);
  OWN_RETURN_TYPE operator()(Clause* cl)
  {
    CALL("ExtensionalityResolution::BackwardPairingFn::operator()");
    
    return pvi(pushPairIntoRightIterator(
        cl,
        getFilteredIterator(
          cl->getSelectedLiteralIterator(),
          NegEqSortFn(_sort))));
  }
private:
  unsigned _sort;
};

struct ExtensionalityResolution::BackwardUnificationsFn
{
  BackwardUnificationsFn(Literal* extLit)
  : _extLit (extLit) { _subst = RobSubstitutionSP(new RobSubstitution()); }
  DECL_RETURN_TYPE(VirtualIterator<pair<pair<Clause*, Literal*>, RobSubstitution*> >);
  OWN_RETURN_TYPE operator()(pair<Clause*, Literal*> arg)
  {
    CALL("ExtensionalityResolution::BackwardUnificationsFn::operator()");
    
    Literal* otherLit = arg.second;
    
    SubstIterator unifs = _subst->unifiers(_extLit,0,otherLit,1,true);
    if (!unifs.hasNext()) {
      return OWN_RETURN_TYPE::getEmpty();
    }
    return pvi(pushPairIntoRightIterator(arg, unifs));
  }
private:
  Literal* _extLit;
  RobSubstitutionSP _subst;
};

struct ExtensionalityResolution::BackwardResultFn
{
  BackwardResultFn(Clause* extCl, Literal* extLit, ExtensionalityResolution& parent) : _extCl(extCl), _extLit(extLit), _parent(parent) {}
  DECL_RETURN_TYPE(Clause*);
  OWN_RETURN_TYPE operator()(pair<pair<Clause*, Literal*>, RobSubstitution*> arg)
  {
    CALL("ExtensionalityResolution::BackwardResultFn::operator()");
    
    RobSubstitution* subst = arg.second;
    Clause* otherCl = arg.first.first;
    Literal* otherLit = arg.first.second;

    return performExtensionalityResolution(_extCl, _extLit, otherCl, otherLit, subst,
                                             env.statistics->backwardExtensionalityResolution,
                                             _parent.getOptions());
  }
private:
  Clause* _extCl;
  Literal* _extLit;
  ExtensionalityResolution& _parent;
};



Clause* ExtensionalityResolution::performExtensionalityResolution(
  Clause* extCl, Literal* extLit,
  Clause* otherCl, Literal* otherLit,
  RobSubstitution* subst,
  unsigned& counter,
  const Options& opts)
{
  CALL("ExtensionalityResolution::performExtensionalityResolution");
  
  if(!ColorHelper::compatible(extCl->color(),otherCl->color()) ) {
    env.statistics->inferencesSkippedDueToColors++;
    if(opts.showBlocked()) {
      env.beginOutput();
      env.out()<<"Blocked extensionality resolution of "<<extCl->toString()<<" and "<<otherCl->toString()<<endl;
      env.endOutput();
    }
    return 0;
  }

  unsigned extLen = extCl->length();
  unsigned otherLen = otherCl->length();
  
  unsigned newLength = otherLen + extLen - 2;
  Unit::InputType newInputType = Unit::getInputType(extCl->inputType(), otherCl->inputType());
  Inference* inf = new Inference2(Inference::EXTENSIONALITY_RESOLUTION, extCl, otherCl);
  Clause* res = new(newLength) Clause(newLength, newInputType, inf);

  unsigned next = 0;

  for(unsigned i = 0; i < extLen; i++) {
    Literal* curr = (*extCl)[i];
    if (curr != extLit) {
      (*res)[next++] = subst->apply(curr, 0);
    }
  }

  for(unsigned i = 0; i < otherLen; i++) {
    Literal* curr = (*otherCl)[i];
    if (curr != otherLit) {
      (*res)[next++] = subst->apply(curr, 1);
    }
  }
    
  ASS_EQ(next,newLength);
  counter++;
     
  return res;
}
  
ClauseIterator ExtensionalityResolution::generateClauses(Clause* premise)
{
  CALL("ExtensionalityResolution::generateClauses");

  ExtensionalityClauseContainer* extClauses = _salg->getExtensionalityClauseContainer();
  ClauseIterator backwardIterator;

  Literal* extLit = extClauses->addIfExtensionality(premise);
  
  if (extLit) {
    
    
    
    auto it1 =
        getMapAndFlattenIterator(
          
          
          
          
          
          
          
          _salg->activeClauses(),
          BackwardPairingFn(extLit->twoVarEqSort()));

    
    
    
    auto it2 = getMapAndFlattenIterator(it1,BackwardUnificationsFn(extLit));

    
    auto it3 = getMappingIterator(it2,BackwardResultFn(premise, extLit, *this));

    
    auto it4 = getFilteredIterator(it3, NonzeroFn());

    backwardIterator = pvi(it4);
  } else {
    backwardIterator = ClauseIterator::getEmpty();
  }
  
  
  
  
  auto it1 = getMapAndFlattenIterator(premise->getSelectedLiteralIterator(),ForwardPairingFn(extClauses));

  
  
  
  
  auto it2 = getMapAndFlattenIterator(it1,ForwardUnificationsFn());

  
  auto it3 = getMappingIterator(it2,ForwardResultFn(premise, *this));

  
  auto it4 = getFilteredIterator(it3, NonzeroFn());

  
  
  auto it5 = getConcatenatedIterator(it4,backwardIterator);

  return pvi(it5);
}

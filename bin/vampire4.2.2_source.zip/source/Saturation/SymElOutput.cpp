
/*
 * File SymElOutput.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Lib/Environment.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/FormulaUnit.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/Signature.hpp"
#include "Kernel/Term.hpp"

#include "SymElOutput.hpp"

namespace Saturation
{

using namespace Lib;
using namespace Kernel;

SymElOutput::SymElOutput()
: _symElNextClauseNumber(0)
{

}

void SymElOutput::init(SaturationAlgorithm* sa)
{
  CALL("SymElOutput::init");

  _sa=sa;
}

void SymElOutput::onAllProcessed()
{
  CALL("SymElOutput::onAllProcessed");

  _symElRewrites.reset();
  _symElColors.reset();
}

void SymElOutput::onInputClause(Clause* c)
{
  CALL("SymElOutput::onInputClause");

  checkForPreprocessorSymbolElimination(c);
}


void SymElOutput::onNonRedundantClause(Clause* c)
{
  CALL("SymElOutput::onNonRedundantClause");

  if(c->color()==COLOR_TRANSPARENT && !c->skip()) {
    Clause* tgt=c;
    Clause* src;
    bool notFound=false;
    do {
      src=tgt;
      if(!_symElRewrites.find(src, tgt)) {
	ASS_EQ(src, c); 
	notFound=true;
	break;
      }
    } while(tgt);
    if(!notFound) {
      
      outputSymbolElimination(_symElColors.get(src), c);
    }
  }
  
  
  
}

void SymElOutput::onParenthood(Clause* cl, Clause* parent)
{
  CALL("SymElOutput::onParenthood");

  Color pcol=parent->color();


  if(pcol!=COLOR_TRANSPARENT && cl->color()==COLOR_TRANSPARENT) {
    onSymbolElimination(parent->color(), cl);
  }
  if(pcol==COLOR_TRANSPARENT && _symElRewrites.find(parent)) {
    
    
    
    
    
    
    _symElRewrites.insert(cl, parent);
  }
}

void SymElOutput::onSymbolElimination(Color eliminated,
					      Clause* c, bool nonRedundant)
{
  CALL("SymElOutput::onSymbolElimination");
  ASS_EQ(c->color(),COLOR_TRANSPARENT);

  if(!c->skip() && c->noSplits()) {
    if(!_symElColors.insert(c,eliminated)) {
      
      return;
    }
    if(nonRedundant) {
      outputSymbolElimination(eliminated, c);
    }
    else {
      _symElRewrites.insert(c,0);
    }
  }
}

void SymElOutput::outputSymbolElimination(Color eliminated, Clause* c)
{
  CALL("SymElOutput::outputSymbolElimination");
  ASS_EQ(c->color(),COLOR_TRANSPARENT);
  ASS(!c->skip());

  env.beginOutput();

  
  env.out()<<"%";
  if(eliminated==COLOR_LEFT) {
    env.out()<<"Left";
  } else {
    ASS_EQ(eliminated, COLOR_RIGHT);
    env.out()<<"Right";
  }
  env.out()<<" symbol elimination"<<endl;

  vstring cname = "inv"+Int::toString(_symElNextClauseNumber);
  while(env.signature->isPredicateName(cname, 0)) {
    _symElNextClauseNumber++;
    cname = "inv"+Int::toString(_symElNextClauseNumber);
  }

  _printer.printAsClaim(cname, c);

  
  _symElNextClauseNumber++;

  env.endOutput();
}


void SymElOutput::checkForPreprocessorSymbolElimination(Clause* cl)
{
  CALL("SymElOutput::checkForPreprocessorSymbolElimination");

  if(!env.colorUsed || cl->color()!=COLOR_TRANSPARENT || cl->skip()) {
    return;
  }

  
  

  Color inputColor=COLOR_TRANSPARENT;

  static DHMap<Unit*, Color> inputFormulaColors;
  static Stack<Unit*> units;
  units.reset();
  units.push(cl);

  while(units.isNonEmpty()) {
    Unit* u=units.pop();
    Inference::Iterator iit=u->inference()->iterator();


    if(!u->inference()->hasNext(iit)) {
      Color uCol;
      if(u->isClause()) {
	uCol=static_cast<Clause*>(u)->color();
      } else if(!inputFormulaColors.find(u,uCol)){
	uCol=static_cast<FormulaUnit*>(u)->getColor();
	inputFormulaColors.insert(u,uCol);
      }
      if(uCol!=COLOR_TRANSPARENT) {
#if VDEBUG
	inputColor=static_cast<Color>(inputColor|uCol);
	ASS_NEQ(inputColor, COLOR_INVALID);
#else
	inputColor=uCol;
	break;
#endif
      }
    } else {
      while(u->inference()->hasNext(iit)) {
        Unit* premUnit=u->inference()->next(iit);
        units.push(premUnit);
      }
    }
  }

  if(inputColor!=COLOR_TRANSPARENT) {
    onSymbolElimination(inputColor, cl);
  }
}


}


/*
 * File SaturationAlgorithm.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Debug/RuntimeStatistics.hpp"

#include "Lib/DHSet.hpp"
#include "Lib/Environment.hpp"
#include "Lib/Metaiterators.hpp"
#include "Lib/SharedSet.hpp"
#include "Lib/Stack.hpp"
#include "Lib/Timer.hpp"
#include "Lib/VirtualIterator.hpp"
#include "Lib/System.hpp"

#include "Indexing/LiteralIndexingStructure.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/ColorHelper.hpp"
#include "Kernel/EqHelper.hpp"
#include "Kernel/FormulaUnit.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/InferenceStore.hpp"
#include "Kernel/KBO.hpp"
#include "Kernel/LiteralSelector.hpp"
#include "Kernel/MLVariant.hpp"
#include "Kernel/Problem.hpp"
#include "Kernel/SubformulaIterator.hpp"
#include "Kernel/Unit.hpp"

#include "Inferences/InferenceEngine.hpp"
#include "Inferences/BackwardDemodulation.hpp"
#include "Inferences/BackwardSubsumptionResolution.hpp"
#include "Inferences/BinaryResolution.hpp"
#include "Inferences/CTFwSubsAndRes.hpp"
#include "Inferences/EqualityFactoring.hpp"
#include "Inferences/EqualityResolution.hpp"
#include "Inferences/ExtensionalityResolution.hpp"
#include "Inferences/FOOLParamodulation.hpp"
#include "Inferences/Factoring.hpp"
#include "Inferences/ForwardDemodulation.hpp"
#include "Inferences/ForwardLiteralRewriting.hpp"
#include "Inferences/ForwardSubsumptionAndResolution.hpp"
#include "Inferences/GlobalSubsumption.hpp"
#include "Inferences/HyperSuperposition.hpp"
#include "Inferences/InnerRewriting.hpp"
#include "Inferences/TermAlgebraReasoning.hpp"
#include "Inferences/SLQueryBackwardSubsumption.hpp"
#include "Inferences/Superposition.hpp"
#include "Inferences/URResolution.hpp"
#include "Inferences/Instantiation.hpp"
#include "Inferences/TheoryInstAndSimp.hpp"

#include "Saturation/ExtensionalityClauseContainer.hpp"

#include "Shell/AnswerExtractor.hpp"
#include "Shell/Options.hpp"
#include "Shell/Statistics.hpp"
#include "Shell/UIHelper.hpp"

#include "Splitter.hpp"

#include "ConsequenceFinder.hpp"
#include "LabelFinder.hpp"
#include "Splitter.hpp"
#include "SymElOutput.hpp"
#include "SaturationAlgorithm.hpp"
#include "AWPassiveClauseContainer.hpp"
#include "Discount.hpp"
#include "LRS.hpp"
#include "Otter.hpp"

using namespace Lib;
using namespace Kernel;
using namespace Shell;
using namespace Saturation;

#define REPORT_CONTAINERS 0
#define REPORT_FW_SIMPL 0
#define REPORT_BW_SIMPL 0


SaturationAlgorithm* SaturationAlgorithm::s_instance = 0;

SaturationAlgorithm::SaturationAlgorithm(Problem& prb, const Options& opt)
  : MainLoop(prb, opt),
    _limits(opt),
    _clauseActivationInProgress(false),
    _fwSimplifiers(0), _bwSimplifiers(0), _splitter(0),
    _consFinder(0), _labelFinder(0), _symEl(0), _answerLiteralManager(0),
    _instantiation(0),
#if VZ3
    _theoryInstSimp(0),
#endif
    _generatedClauseCount(0),
    _activationLimit(0)
{
  CALL("SaturationAlgorithm::SaturationAlgorithm");
  ASS_EQ(s_instance, 0);  

  _activationLimit = opt.activationLimit();

  _ordering = OrderingSP(Ordering::create(prb, opt));
  if (!Ordering::trySetGlobalOrdering(_ordering)) {
    
    cerr << "SaturationAlgorithm cannot set its ordering as global" << endl;
  }
  _selector = LiteralSelector::getSelector(*_ordering, opt, opt.selection());

  _completeOptionSettings = opt.complete(prb);

  _unprocessed = new UnprocessedClauseContainer();
  _passive = new AWPassiveClauseContainer(opt);
  _active = new ActiveClauseContainer(opt);

  _active->attach(this);
  _passive->attach(this);

  _active->addedEvent.subscribe(this, &SaturationAlgorithm::onActiveAdded);
  _active->removedEvent.subscribe(this, &SaturationAlgorithm::activeRemovedHandler);
  _passive->addedEvent.subscribe(this, &SaturationAlgorithm::onPassiveAdded);
  _passive->removedEvent.subscribe(this, &SaturationAlgorithm::passiveRemovedHandler);
  _passive->selectedEvent.subscribe(this, &SaturationAlgorithm::onPassiveSelected);
  _unprocessed->addedEvent.subscribe(this, &SaturationAlgorithm::onUnprocessedAdded);
  _unprocessed->removedEvent.subscribe(this, &SaturationAlgorithm::onUnprocessedRemoved);
  _unprocessed->selectedEvent.subscribe(this, &SaturationAlgorithm::onUnprocessedSelected);

  if (opt.extensionalityResolution() != Options::ExtensionalityResolution::OFF) {
    _extensionality = new ExtensionalityClauseContainer(opt);
    
  } else {
    _extensionality = 0;
  }
  
  if (opt.maxWeight()) {
    _limits.setLimits(0,opt.maxWeight());
  }

  s_instance=this;
}

SaturationAlgorithm::~SaturationAlgorithm()
{
  CALL("SaturationAlgorithm::~SaturationAlgorithm");
  ASS_EQ(s_instance,this);

  s_instance=0;

  if (_splitter) {
    delete _splitter;
  }
  if (_consFinder) {
    delete _consFinder;
  }
  if (_symEl) {
    delete _symEl;
  }

  _active->detach();
  _passive->detach();

  if (_generator) {
    _generator->detach();
  }
  if (_immediateSimplifier) {
    _immediateSimplifier->detach();
  }

  while (_fwSimplifiers) {
    ForwardSimplificationEngine* fse = FwSimplList::pop(_fwSimplifiers);
    fse->detach();
    delete fse;
  }
  while (_bwSimplifiers) {
    BackwardSimplificationEngine* bse = BwSimplList::pop(_bwSimplifiers);
    bse->detach();
    delete bse;
  }

  delete _unprocessed;
  delete _active;
  delete _passive;
}

void SaturationAlgorithm::tryUpdateFinalClauseCount()
{
  CALL("SaturationAlgorithm::tryUpdateFinalClauseCount");

  SaturationAlgorithm* inst = tryGetInstance();
  if (!inst) {
    return;
  }
  env.statistics->finalActiveClauses = inst->_active->size();
  env.statistics->finalPassiveClauses = inst->_passive->size();
  if (inst->_extensionality != 0) {
    env.statistics->finalExtensionalityClauses = inst->_extensionality->size();
  }
}

bool SaturationAlgorithm::isComplete()
{
  return _completeOptionSettings && !env.statistics->inferencesSkippedDueToColors;
}

ClauseIterator SaturationAlgorithm::activeClauses()
{
  CALL("SaturationAlgorithm::activeClauses");

  LiteralIndexingStructure* gis=getIndexManager()->getGeneratingLiteralIndexingStructure();
  return pvi( getMappingIterator(gis->getAll(), SLQueryResult::ClauseExtractFn()) );
}

ClauseIterator SaturationAlgorithm::passiveClauses()
{
  return _passive->iterator();
}

size_t SaturationAlgorithm::activeClauseCount()
{
  return _active->size();
}

size_t SaturationAlgorithm::passiveClauseCount()
{
  return _passive->size();
}


void SaturationAlgorithm::onActiveAdded(Clause* c)
{
  CALL("SaturationAlgorithm::onActiveAdded");

  if (env.options->showActive()) {
    env.beginOutput();    
    env.out() << "[SA] active: " << c->toString() << std::endl;
    env.endOutput();             
  }          
}

void SaturationAlgorithm::onActiveRemoved(Clause* c)
{
  CALL("SaturationAlgorithm::onActiveRemoved");

  ASS(c->store()==Clause::ACTIVE);
  c->setStore(Clause::NONE);
  
}

void SaturationAlgorithm::onAllProcessed()
{
  CALL("SaturationAlgorithm::onAllProcessed");
  ASS(clausesFlushed());

  if (_symEl) {
    _symEl->onAllProcessed();
  }

  if (_splitter) {
    _splitter->onAllProcessed();
  }

  if (_consFinder) {
    _consFinder->onAllProcessed();
  }
}

void SaturationAlgorithm::onPassiveAdded(Clause* c)
{
  if (env.options->showPassive()) {
    env.beginOutput();
    env.out() << "[SA] passive: " << c->toString() << std::endl;
    env.endOutput();
  }
  
  
  
  onNonRedundantClause(c);
}

void SaturationAlgorithm::onPassiveRemoved(Clause* c)
{
  CALL("SaturationAlgorithm::onPassiveRemoved");

  ASS(c->store()==Clause::PASSIVE);
  c->setStore(Clause::NONE);
  
}

void SaturationAlgorithm::onPassiveSelected(Clause* c)
{
}

void SaturationAlgorithm::onUnprocessedAdded(Clause* c)
{
  
}

void SaturationAlgorithm::onUnprocessedRemoved(Clause* c)
{
  
}

void SaturationAlgorithm::onUnprocessedSelected(Clause* c)
{
  
}

void SaturationAlgorithm::onNewClause(Clause* cl)
{
  CALL("SaturationAlgorithm::onNewClause");

  if (_splitter) {
    _splitter->onNewClause(cl);
  }

  if (env.options->showNew()) {
    env.beginOutput();
    env.out() << "[SA] new: " << cl->toString() << std::endl;
    env.endOutput();
  }

  if (cl->isPropositional()) {
    onNewUsefulPropositionalClause(cl);
  }

  if (_answerLiteralManager) {
    _answerLiteralManager->onNewClause(cl);
  }
}

void SaturationAlgorithm::onNewUsefulPropositionalClause(Clause* c)
{
  CALL("SaturationAlgorithm::onNewUsefulPropositionalClause");
  ASS(c->isPropositional());
  
  if (env.options->showNewPropositional()) {
    env.beginOutput();
    env.out() << "[SA] new propositional: " << c->toString() << std::endl;
    env.endOutput();
  }

  if (_consFinder) {
    _consFinder->onNewPropositionalClause(c);
  }
  if (_labelFinder){
    _labelFinder->onNewPropositionalClause(c);
  }
}

void SaturationAlgorithm::onClauseRetained(Clause* cl)
{
  CALL("SaturationAlgorithm::onClauseRetained");

  

}

void SaturationAlgorithm::onClauseReduction(Clause* cl, Clause* replacement, Clause* premise, bool forward)
{
  CALL("SaturationAlgorithm::onClauseReduction/5");
  ASS(cl);

  ClauseIterator premises;
  
  if (premise) {
    premises = pvi( getSingletonIterator(premise) );
  }
  else {
    premises=ClauseIterator::getEmpty();
  }

  onClauseReduction(cl, replacement, premises, forward);
}

void SaturationAlgorithm::onClauseReduction(Clause* cl, Clause* replacement,
    ClauseIterator premises, bool forward)
{
  CALL("SaturationAlgorithm::onClauseReduction/4");
  ASS(cl);

  static ClauseStack premStack;
  premStack.reset();
  premStack.loadFromIterator(premises);

  if (env.options->showReductions()) {
    env.beginOutput();
    env.out() << "[SA] " << (forward ? "forward" : "backward") << " reduce: " << cl->toString() << endl;
    if(replacement){ env.out() << "     replaced by " << replacement->toString() << endl; }
    ClauseStack::Iterator pit(premStack);
    while(pit.hasNext()){
      Clause* premise = pit.next();
      if(premise){ env.out() << "     using " << premise->toString() << endl; }
    }
    env.endOutput();
  }

  if (_splitter) {
    _splitter->onClauseReduction(cl, pvi( ClauseStack::Iterator(premStack) ), replacement);
  }

  if (replacement) {
    onParenthood(replacement, cl);
    while (premStack.isNonEmpty()) {
      onParenthood(replacement, premStack.pop());
    }
  }
}


void SaturationAlgorithm::onNonRedundantClause(Clause* c)
{
  CALL("SaturationAlgorithm::onNonRedundantClause");

  if (_symEl) {
    _symEl->onNonRedundantClause(c);
  }
}

void SaturationAlgorithm::onParenthood(Clause* cl, Clause* parent)
{
  CALL("SaturationAlgorithm::onParenthood");

  if (_symEl) {
    _symEl->onParenthood(cl, parent);
  }
}

void SaturationAlgorithm::activeRemovedHandler(Clause* cl)
{
  CALL("SaturationAlgorithm::activeRemovedHandler");

  onActiveRemoved(cl);
}

void SaturationAlgorithm::passiveRemovedHandler(Clause* cl)
{
  CALL("SaturationAlgorithm::passiveRemovedHandler");

  onPassiveRemoved(cl);
}

int SaturationAlgorithm::elapsedTime()
{
  return env.timer->elapsedMilliseconds()-_startTime;
}

void SaturationAlgorithm::addInputClause(Clause* cl)
{
  CALL("SaturationAlgorithm::addInputClause");

  cl->markInput();

  if (_symEl) {
    _symEl->onInputClause(cl);
  }

  bool sosForAxioms = _opt.sos() == Options::Sos::ON || _opt.sos() == Options::Sos::ALL; 
  sosForAxioms = sosForAxioms && cl->inputType()==Clause::AXIOM;

  bool isTheory = cl->inference()->rule()==Inference::THEORY;
  bool sosForTheory = _opt.sos() == Options::Sos::THEORY && _opt.sosTheoryLimit() == 0;

  if (sosForAxioms || (isTheory && sosForTheory)){
    addInputSOSClause(cl);
  } else {
    addNewClause(cl);
  }

  if(_instantiation){
    _instantiation->registerClause(cl);
  }

  env.statistics->initialClauses++;
}

LiteralSelector& SaturationAlgorithm::getSosLiteralSelector()
{
  CALL("SaturationAlgorithm::getSosLiteralSelector");

  if (_opt.sos() == Options::Sos::ALL || _opt.sos() == Options::Sos::THEORY) {
    if (!_sosLiteralSelector) {
      _sosLiteralSelector = new TotalLiteralSelector(getOrdering(), getOptions());
    }
    return *_sosLiteralSelector;
  }
  else {
    return *_selector;
  }
}

void SaturationAlgorithm::addInputSOSClause(Clause* cl)
{
  CALL("SaturationAlgorithm::addInputSOSClause");
  ASS_EQ(cl->inputType(),Clause::AXIOM);

  
  
  cl->incRefCnt();

  onNewClause(cl);

simpl_start:

  Clause* simplCl=_immediateSimplifier->simplify(cl);
  if (simplCl != cl) {
    if (!simplCl) {
      onClauseReduction(cl, 0, 0);
      goto fin;
    }

    simplCl->incRefCnt();
    cl->decRefCnt(); 

    onNewClause(simplCl);
    onClauseReduction(cl, simplCl, 0);
    cl=simplCl;
    goto simpl_start;
  }

  if (cl->isEmpty()) {
    addNewClause(cl);
    goto fin;
  }

  ASS(!cl->numSelected());
  {
    LiteralSelector& sosSelector = getSosLiteralSelector();
    sosSelector.select(cl);
  }

  cl->setStore(Clause::ACTIVE);
  env.statistics->activeClauses++;
  _active->add(cl);

  onSOSClauseAdded(cl);

fin:
  cl->decRefCnt();
}


void SaturationAlgorithm::init()
{
  CALL("SaturationAlgorithm::init");

  ClauseIterator toAdd = _prb.clauseIterator();

  while (toAdd.hasNext()) {
    Clause* cl=toAdd.next();
    addInputClause(cl);
  }

  if (_splitter) {
    _splitter->init(this);
  }
  if (_consFinder) {
    _consFinder->init(this);
  }
  if (_symEl) {
    _symEl->init(this);
  }

  _startTime=env.timer->elapsedMilliseconds();
}

Clause* SaturationAlgorithm::doImmediateSimplification(Clause* cl0)
{
  CALL("SaturationAlgorithm::doImmediateSimplification");

  static bool sosTheoryLimit = _opt.sos()==Options::Sos::THEORY;
  static unsigned sosTheoryLimitDepth = _opt.sosTheoryLimit();

  if(sosTheoryLimit && cl0->isTheoryDescendant() && cl0->inference()->maxDepth() > sosTheoryLimitDepth){
    return 0;
  }

  Clause* cl=cl0;

  Clause* simplCl=_immediateSimplifier->simplify(cl);
  if (simplCl != cl) {
    if (simplCl) {
      addNewClause(simplCl);
    }
    onClauseReduction(cl, simplCl, 0);
    return 0;
  }

  if (cl != cl0 && cl0->isInput()) {
    
    cl->markInput();
  }

  return cl;
}

void SaturationAlgorithm::addNewClause(Clause* cl)
{
  CALL("SaturationAlgorithm::addNewClause");

  

  
  
  
  
  cl->incRefCnt();
  onNewClause(cl);
  _newClauses.push(cl);
  
  
  
  cl->decRefCnt();
}

void SaturationAlgorithm::newClausesToUnprocessed()
{
  CALL("SaturationAlgorithm::newClausesToUnprocessed");

  while (_newClauses.isNonEmpty()) {
    Clause* cl=_newClauses.popWithoutDec();

    switch(cl->store())
    {
    case Clause::UNPROCESSED:
      break;
    case Clause::PASSIVE:
      onNonRedundantClause(cl);
      break;
    case Clause::NONE:
      addUnprocessedClause(cl);
      break;
#if VDEBUG
    case Clause::SELECTED:
    case Clause::ACTIVE:
      cout << "FAIL: " << cl->toString() << endl;
      
      cout << cl->toString() << endl;
      ASSERTION_VIOLATION_REP(cl->store());
#endif
    }
    cl->decRefCnt(); 
  }
}

bool SaturationAlgorithm::clausesFlushed()
{
  return _unprocessed->isEmpty() && _newClauses.isEmpty();
}


void SaturationAlgorithm::addUnprocessedClause(Clause* cl)
{
  CALL("SaturationAlgorithm::addUnprocessedClause");

  _generatedClauseCount++;
  env.statistics->generatedClauses++;

  env.checkTimeSometime<64>();


  cl=doImmediateSimplification(cl);
  if (!cl) {
    return;
  }

  if (cl->isEmpty()) {
    handleEmptyClause(cl);
    return;
  }

  cl->setStore(Clause::UNPROCESSED);
  _unprocessed->add(cl);
}

void SaturationAlgorithm::handleEmptyClause(Clause* cl)
{
  CALL("SaturationAlgorithm::handleEmptyClause");
  ASS(cl->isEmpty());

  if (isRefutation(cl)) {
    onNonRedundantClause(cl);

    if(cl->isTheoryDescendant() ){
      ASSERTION_VIOLATION_REP("A pure theory descendant is empty, which means theory axioms are inconsistent");
      reportSpiderFail();
      
      throw MainLoop::MainLoopFinishedException(Statistics::REFUTATION_NOT_FOUND);
    }

    throw RefutationFoundException(cl);
  }
  
  

  if (_splitter && _splitter->handleEmptyClause(cl)) {
    return;
  }

  
  ASSERTION_VIOLATION;
  
  
}

bool SaturationAlgorithm::forwardSimplify(Clause* cl)
{
  CALL("SaturationAlgorithm::forwardSimplify");

  if (!getLimits()->fulfillsLimits(cl)) {
    RSTAT_CTR_INC("clauses discarded by weight limit in forward simplification");
    env.statistics->discardedNonRedundantClauses++;
    return false;
  }

  FwSimplList::Iterator fsit(_fwSimplifiers);

  while (fsit.hasNext()) {
    ForwardSimplificationEngine* fse=fsit.next();

    {
      Clause* replacement = 0;
      ClauseIterator premises = ClauseIterator::getEmpty();

      if (fse->perform(cl,replacement,premises)) {
        if (replacement) {
          addNewClause(replacement);
        }
        onClauseReduction(cl, replacement, premises);

        return false;
      }
    }
  }

  
  cl->incRefCnt();

  if ( _splitter && !_opt.splitAtActivation() ) {
    if (_splitter->doSplitting(cl)) {
      return false;
    }
  }

  return true;
}

void SaturationAlgorithm::backwardSimplify(Clause* cl)
{
  CALL("SaturationAlgorithm::backwardSimplify");


  BwSimplList::Iterator bsit(_bwSimplifiers);
  while (bsit.hasNext()) {
    BackwardSimplificationEngine* bse=bsit.next();

    BwSimplificationRecordIterator simplifications;
    bse->perform(cl,simplifications);
    while (simplifications.hasNext()) {
      BwSimplificationRecord srec=simplifications.next();
      Clause* redundant=srec.toRemove;
      ASS_NEQ(redundant, cl);

      Clause* replacement=srec.replacement;

      if (replacement) {
	addNewClause(replacement);
      }
      onClauseReduction(redundant, replacement, cl, false);

      
      
      

      redundant->incRefCnt(); 

      removeActiveOrPassiveClause(redundant);

      redundant->decRefCnt();
    }
  }
}

void SaturationAlgorithm::removeActiveOrPassiveClause(Clause* cl)
{
  CALL("SaturationAlgorithm::removeActiveOrPassiveClause");

  if (_clauseActivationInProgress) {
    
    
    _postponedClauseRemovals.push(cl);
    return;
  }

  switch(cl->store()) {
  case Clause::PASSIVE:
    _passive->remove(cl);
    break;
  case Clause::ACTIVE:
    _active->remove(cl);
    break;
  default:
    ASS_REP2(false, cl->store(), *cl);
  }
  
}

void SaturationAlgorithm::addToPassive(Clause* cl)
{
  CALL("SaturationAlgorithm::addToPassive");
  ASS_EQ(cl->store(), Clause::UNPROCESSED);

  cl->setStore(Clause::PASSIVE);
  env.statistics->passiveClauses++;

  _passive->add(cl);
}

bool SaturationAlgorithm::activate(Clause* cl)
{
  CALL("SaturationAlgorithm::activate");

  if (_consFinder && _consFinder->isRedundant(cl)) {
    return false;
  }

  if (_splitter && _opt.splitAtActivation()) {
    if (_splitter->doSplitting(cl)) {
      return false;
    }
  }

  bool redundant=false;
  ClauseIterator instances = ClauseIterator::getEmpty();
#if VZ3
  if(_theoryInstSimp){
    instances = _theoryInstSimp->generateClauses(cl,redundant);
  }
#endif
  if(redundant){ 
    removeActiveOrPassiveClause(cl);
    return false; 
  }

  _clauseActivationInProgress=true;

  if (!cl->numSelected()) {
    TimeCounter tc(TC_LITERAL_SELECTION);

    _selector->select(cl);
  }

  ASS_EQ(cl->store(), Clause::SELECTED);
  cl->setStore(Clause::ACTIVE);
  env.statistics->activeClauses++;
  _active->add(cl);


    ClauseIterator toAdd= pvi(getConcatenatedIterator(instances,_generator->generateClauses(cl)));

    while (toAdd.hasNext()) {
      Clause* genCl=toAdd.next();

      addNewClause(genCl);

      Inference::Iterator iit=genCl->inference()->iterator();
      while (genCl->inference()->hasNext(iit)) {
        Unit* premUnit=genCl->inference()->next(iit);
        ASS(premUnit->isClause());
        Clause* premCl=static_cast<Clause*>(premUnit);

        onParenthood(genCl, premCl);
      }
    }

  _clauseActivationInProgress=false;


  
  while (_postponedClauseRemovals.isNonEmpty()) {
    Clause* cl=_postponedClauseRemovals.pop();
    if (cl->store() != Clause::ACTIVE &&
	cl->store() != Clause::PASSIVE) {
      continue;
    }
    removeActiveOrPassiveClause(cl);
  }

  return true; 
}

void SaturationAlgorithm::doUnprocessedLoop()
{
  CALL("SaturationAlgorithm::doUnprocessedLoop");

start:

  newClausesToUnprocessed();

  while (! _unprocessed->isEmpty()) {
    Clause* c = _unprocessed->pop();
    ASS(!isRefutation(c));

    if (forwardSimplify(c)) {
      onClauseRetained(c);
      addToPassive(c);
      ASS_EQ(c->store(), Clause::PASSIVE);
    }
    else {
      ASS_EQ(c->store(), Clause::UNPROCESSED);
      c->setStore(Clause::NONE);
    }

    newClausesToUnprocessed();

    if (env.timeLimitReached()) {
      throw TimeLimitExceededException();
    }
  }

  ASS(clausesFlushed());
  onAllProcessed();
  if (!clausesFlushed()) {
    
    goto start;
  }

}

void SaturationAlgorithm::handleUnsuccessfulActivation(Clause* cl)
{
  CALL("SaturationAlgorithm::handleUnsuccessfulActivation");

  
  cl->setStore(Clause::NONE);
}

bool SaturationAlgorithm::handleClauseBeforeActivation(Clause* c)
{
  return true;
}

void SaturationAlgorithm::initAlgorithmRun()
{
  CALL("SaturationAlgorithm::initAlgorithmRun");

  init();
}


UnitList* SaturationAlgorithm::collectSaturatedSet()
{
  CALL("SaturationAlgorithm::collectSaturatedSet");

  LiteralIndexingStructure* gis=getIndexManager()->getGeneratingLiteralIndexingStructure();

  UnitList* res = 0;
  SLQueryResultIterator qrit = gis->getAll();
  while (qrit.hasNext()) {
    SLQueryResult qres = qrit.next();
    UnitList::push(qres.clause, res);
    qres.clause->incRefCnt();
  }
  return res;
}

void SaturationAlgorithm::doOneAlgorithmStep()
{
  CALL("SaturationAlgorithm::doOneAlgorithmStep");

  doUnprocessedLoop();

  if (_passive->isEmpty()) {
    MainLoopResult::TerminationReason termReason =
	isComplete() ? Statistics::SATISFIABLE : Statistics::REFUTATION_NOT_FOUND;
    MainLoopResult res(termReason);

    
    
    

    if (termReason == Statistics::SATISFIABLE && getOptions().proof() != Options::Proof::OFF) {
      res.saturatedSet = collectSaturatedSet();

      if (_splitter) {
        res.saturatedSet = _splitter->explicateAssertionsForSaturatedClauseSet(res.saturatedSet);
      }
    }
    throw MainLoopFinishedException(res);
  }

  Clause* cl = _passive->popSelected();
  ASS_EQ(cl->store(),Clause::PASSIVE);
  cl->setStore(Clause::SELECTED);

  if (!handleClauseBeforeActivation(cl)) {
    return;
  }

  bool isActivated=activate(cl);
  if (!isActivated) {
    handleUnsuccessfulActivation(cl);
  }
}


MainLoopResult SaturationAlgorithm::runImpl()
{
  CALL("SaturationAlgorithm::runImpl");

  unsigned l = 0;
  try
  {
    for (;;l++) {
      if (_activationLimit && l > _activationLimit) {
        throw ActivationLimitExceededException();
      }

      doOneAlgorithmStep();

      Timer::syncClock();
      if (env.timeLimitReached()) {
        throw TimeLimitExceededException();
      }
    }
  }
  catch(ThrowableBase&)
  {
    tryUpdateFinalClauseCount();
    throw;
  }

}

#if VZ3
void SaturationAlgorithm::setTheoryInstAndSimp(TheoryInstAndSimp* t)
{
  ASS(t);
  _theoryInstSimp=t;
  _theoryInstSimp->attach(this);
}
#endif

void SaturationAlgorithm::setGeneratingInferenceEngine(GeneratingInferenceEngine* generator)
{
  CALL("SaturationAlgorithm::setGeneratingInferenceEngine");

  ASS(!_generator);
  _generator=generator;
  _generator->attach(this);
}

void SaturationAlgorithm::setImmediateSimplificationEngine(ImmediateSimplificationEngine* immediateSimplifier)
{
  CALL("SaturationAlgorithm::setImmediateSimplificationEngine");

  ASS(!_immediateSimplifier);
  _immediateSimplifier=immediateSimplifier;
  _immediateSimplifier->attach(this);
}

void SaturationAlgorithm::addForwardSimplifierToFront(ForwardSimplificationEngine* fwSimplifier)
{
  FwSimplList::push(fwSimplifier, _fwSimplifiers);
  fwSimplifier->attach(this);
}

void SaturationAlgorithm::addBackwardSimplifierToFront(BackwardSimplificationEngine* bwSimplifier)
{
  BwSimplList::push(bwSimplifier, _bwSimplifiers);
  bwSimplifier->attach(this);
}

SaturationAlgorithm* SaturationAlgorithm::createFromOptions(Problem& prb, const Options& opt, IndexManager* indexMgr)
{
  CALL("SaturationAlgorithm::createFromOptions");

  SaturationAlgorithm* res;
  switch(opt.saturationAlgorithm()) {
  case Shell::Options::SaturationAlgorithm::DISCOUNT:
    res=new Discount(prb, opt);
    break;
  case Shell::Options::SaturationAlgorithm::LRS:
    res=new LRS(prb, opt);
    break;
  case Shell::Options::SaturationAlgorithm::OTTER:
    res=new Otter(prb, opt);
    break;
  default:
    NOT_IMPLEMENTED;
  }
  if (indexMgr) {
    res->_imgr = SmartPtr<IndexManager>(indexMgr, true);
    indexMgr->setSaturationAlgorithm(res);
  }
  else {
    res->_imgr = SmartPtr<IndexManager>(new IndexManager(res));
  }

  if(opt.splitting()){
    res->_splitter = new Splitter();
  }

  
  CompositeGIE* gie=new CompositeGIE();

  if(opt.instantiation()!=Options::Instantiation::OFF){
    res->_instantiation = new Instantiation();
    
    gie->addFront(res->_instantiation);
  }

  if (prb.hasEquality()) {
    gie->addFront(new EqualityFactoring());
    gie->addFront(new EqualityResolution());
    gie->addFront(new Superposition());
  }
  gie->addFront(new Factoring());
  if (opt.binaryResolution()) {
    gie->addFront(new BinaryResolution());
  }
  if (opt.unitResultingResolution() != Options::URResolution::OFF) {
    gie->addFront(new URResolution());
  }
  if (opt.extensionalityResolution() != Options::ExtensionalityResolution::OFF) {
    gie->addFront(new ExtensionalityResolution());
  }
  if (opt.FOOLParamodulation()) {
    gie->addFront(new FOOLParamodulation());
  }
  if(prb.hasEquality() && env.signature->hasTermAlgebras()) {
    if (opt.termAlgebraCyclicityCheck() == Options::TACyclicityCheck::RULE) {
      gie->addFront(new AcyclicityGIE());
    } else if (opt.termAlgebraCyclicityCheck() == Options::TACyclicityCheck::RULELIGHT) {
      gie->addFront(new AcyclicityGIE1());
    }
    if (opt.termAlgebraInferences()) {
      gie->addFront(new InjectivityGIE());
    }
  }
#if VZ3
  if (opt.theoryInstAndSimp() != Shell::Options::TheoryInstSimp::OFF){
    res->setTheoryInstAndSimp(new TheoryInstAndSimp());
    
  }
#endif

  res->setGeneratingInferenceEngine(gie);

  res->setImmediateSimplificationEngine(createISE(prb, opt));

  
  if (prb.hasEquality() && opt.innerRewriting()) {
    res->addForwardSimplifierToFront(new InnerRewriting());
  }
  if (opt.hyperSuperposition()) {
    res->addForwardSimplifierToFront(new HyperSuperposition());
  }
  if (opt.globalSubsumption()) {
    res->addForwardSimplifierToFront(new GlobalSubsumption(opt));
  }
  if (opt.forwardLiteralRewriting()) {
    res->addForwardSimplifierToFront(new ForwardLiteralRewriting());
  }
  if (prb.hasEquality()) {
    switch(opt.forwardDemodulation()) {
    case Options::Demodulation::ALL:
    case Options::Demodulation::PREORDERED:
      res->addForwardSimplifierToFront(new ForwardDemodulation());
      break;
    case Options::Demodulation::OFF:
      break;
#if VDEBUG
    default:
      ASSERTION_VIOLATION;
#endif
    }
  }
  if (opt.forwardSubsumption()) {
    if (opt.forwardSubsumptionResolution()) {
      
      res->addForwardSimplifierToFront(new ForwardSubsumptionAndResolution(true));
    }
    else {
      
      res->addForwardSimplifierToFront(new ForwardSubsumptionAndResolution(false));
    }
  }
  else if (opt.forwardSubsumptionResolution()) {
    USER_ERROR("Forward subsumption resolution requires forward subsumption to be enabled.");
  }

  
  if (prb.hasEquality()) {
    switch(opt.backwardDemodulation()) {
    case Options::Demodulation::ALL:
    case Options::Demodulation::PREORDERED:
      res->addBackwardSimplifierToFront(new BackwardDemodulation());
      break;
    case Options::Demodulation::OFF:
      break;
#if VDEBUG
    default:
      ASSERTION_VIOLATION;
#endif
    }
  }
  if (opt.backwardSubsumption() != Options::Subsumption::OFF) {
    bool byUnitsOnly=opt.backwardSubsumption()==Options::Subsumption::UNIT_ONLY;
    res->addBackwardSimplifierToFront(new SLQueryBackwardSubsumption(byUnitsOnly));
  }
  if (opt.backwardSubsumptionResolution() != Options::Subsumption::OFF) {
    bool byUnitsOnly=opt.backwardSubsumptionResolution()==Options::Subsumption::UNIT_ONLY;
    res->addBackwardSimplifierToFront(new BackwardSubsumptionResolution(byUnitsOnly));
  }

  if (opt.mode()==Options::Mode::CONSEQUENCE_ELIMINATION) {
    res->_consFinder=new ConsequenceFinder();
  }
  if (opt.showSymbolElimination()) {
    res->_symEl=new SymElOutput();
  }
  if (opt.questionAnswering()==Options::QuestionAnsweringMode::ANSWER_LITERAL) {
    res->_answerLiteralManager = AnswerLiteralManager::getInstance();
  }
  return res;
} 


/*
 * File ExtensionalityClauseContainer.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */
#include "Kernel/Clause.hpp"
#include "Kernel/SortHelper.hpp"
#include "Kernel/Term.hpp"

#include "Shell/Statistics.hpp"
#include "Shell/TheoryFinder.hpp"

#include "Saturation/ExtensionalityClauseContainer.hpp"

namespace Saturation
{

using namespace Shell;

Literal* ExtensionalityClauseContainer::addIfExtensionality(Clause* c) {
  CALL("ExtensionalityClauseContainer::addIfExtensionality");
  
  
  if (c->isExtensionality()) {
    
    return getSingleVarEq(c);
  }

  
  
  unsigned clen = c->length();
  if (clen < 2 || (_maxLen > 1 && clen > _maxLen))
    return 0;

  Literal* varEq = 0;
  unsigned sort;

  if (_onlyKnown) {
    
    
    if(!TheoryFinder::matchKnownExtensionality(c))
      return 0;

    
    varEq = getSingleVarEq(c);
    sort = varEq->twoVarEqSort();
  } else if (!_onlyTagged || c->isTaggedExtensionality()) {
    
    
    
    
    static DArray<bool> negEqSorts(_sortCnt);
    negEqSorts.init(_sortCnt, false);
  
    for (Clause::Iterator ci(*c); ci.hasNext(); ) {
      Literal* l = ci.next();

      if (l->isTwoVarEquality() && l->isPositive()) {
        if (varEq != 0)
          return 0;

        sort = l->twoVarEqSort();
        if (negEqSorts[sort])
          return 0;

        varEq = l;
      } else if (l->isEquality()) {
        if (!_allowPosEq && l->isPositive())
          return 0;
      
        unsigned negEqSort = SortHelper::getEqualityArgumentSort(l);
        if (varEq == 0)
          negEqSorts[negEqSort] = true;
        else if (sort == negEqSort)
          return 0;
      }
    }
  }

  if (varEq != 0) {
    
    c->setExtensionality(true);
    add(ExtensionalityClause(c, varEq, sort));
    _size++;
    env.statistics->extensionalityClauses++;
    return varEq;
  }

  return 0;
}

Literal* ExtensionalityClauseContainer::getSingleVarEq(Clause* c) {
  CALL("ExtensionalityClauseContainer::getSingleVarEq");
  
  for (unsigned i = 0; i < c->length(); ++i) {
    Literal* varEq = (*c)[i];
    if (varEq->isTwoVarEquality() && varEq->isPositive()) {
      return varEq;
      break;
    }
  }
  ASSERTION_VIOLATION;
}

void ExtensionalityClauseContainer::add(ExtensionalityClause c) {
  CALL("ExtensionalityClauseContainer::add");
  
  ExtensionalityClauseList::push(c, _clausesBySort[c.sort]);
}

struct ExtensionalityClauseContainer::ActiveFilterFn
{
  ActiveFilterFn(ExtensionalityClauseContainer& parent) : _parent(parent) {}
  DECL_RETURN_TYPE(bool);
  OWN_RETURN_TYPE operator()(ExtensionalityClause extCl)
  {
    CALL("ExtensionalityClauseContainer::ActiveFilterFn::operator()");
    
    if (extCl.clause->store() != Clause::ACTIVE) {
      extCl.clause->setExtensionality(false);
      _parent._size--;
      return false;
    }
    return true;
  }
private:
  ExtensionalityClauseContainer& _parent;
};

ExtensionalityClauseIterator ExtensionalityClauseContainer::activeIterator(unsigned sort) {
  CALL("ExtensionalityClauseContainer::activeIterator");
  
  return pvi(getFilteredDelIterator(
               ExtensionalityClauseList::DelIterator(_clausesBySort[sort]),
               ActiveFilterFn(*this)));
}

void ExtensionalityClauseContainer::print (ostream& out) {
  CALL("ExtensionalityClauseContainer::print");
  
  out << "#####################" << endl;

  for(size_t i = 0; i < _clausesBySort.size(); ++i) {
    ExtensionalityClauseList::Iterator it(_clausesBySort[i]);
    while(it.hasNext()) {
      ExtensionalityClause c = it.next();
      out << c.clause->toString() << endl
          << c.literal->toString() << endl
          << c.sort << endl;
    }
  }
  
  out << "#####################" << endl;
}

}

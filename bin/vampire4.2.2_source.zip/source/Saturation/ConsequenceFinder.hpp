
/*
 * File ConsequenceFinder.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __ConsequenceFinder__
#define __ConsequenceFinder__

#include "Forwards.hpp"

#include "Lib/Allocator.hpp"
#include "Lib/Array.hpp"
#include "Lib/Event.hpp"
#include "Lib/Int.hpp"
#include "Lib/Stack.hpp"

#include "Kernel/Clause.hpp"

#include "Inferences/TautologyDeletionISE.hpp"

namespace Saturation {

using namespace Kernel;
using namespace Inferences;

class ConsequenceFinder {
public:
  CLASS_NAME(ConsequenceFinder);
  USE_ALLOCATOR(ConsequenceFinder);
  
  ~ConsequenceFinder();

  void init(SaturationAlgorithm* sa);

  bool isRedundant(Clause* cl);

  void onNewPropositionalClause(Clause* cl);
  void onAllProcessed();

private:

  void onClauseInserted(Clause* cl);
  void onClauseRemoved(Clause* cl);

  void indexClause(unsigned indexNum, Clause* cl, bool add);

  SaturationAlgorithm* _sa;

  Stack<unsigned> _redundantsToHandle;

  typedef SkipList<Clause*,Int> ClauseSL;

 
  ZIArray<ClauseSL*> _index;
 
  ZIArray<bool> _redundant;

  TautologyDeletionISE _td;
  DuplicateLiteralRemovalISE _dlr;

 
  SubscriptionData _sdInsertion;
 
  SubscriptionData _sdRemoval;
};

}

#endif 

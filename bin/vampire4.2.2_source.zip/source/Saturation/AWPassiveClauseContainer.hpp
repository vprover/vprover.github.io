
/*
 * File AWPassiveClauseContainer.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __AWPassiveClauseContainer__
#define __AWPassiveClauseContainer__

#include "Lib/Comparison.hpp"
#include "Kernel/Clause.hpp"
#include "Kernel/ClauseQueue.hpp"
#include "ClauseContainer.hpp"

#include "Lib/Allocator.hpp"

namespace Saturation {

using namespace Kernel;

class AgeQueue
: public ClauseQueue
{
public:
  AgeQueue(const Options& opt) : _opt(opt) {}
protected:

  virtual bool lessThan(Clause*,Clause*);

  friend class AWPassiveClauseContainer;

private:
  const Options& _opt;
};

class WeightQueue
  : public ClauseQueue
{
public:
  WeightQueue(const Options& opt) : _opt(opt) {}
protected:
  virtual bool lessThan(Clause*,Clause*);

  friend class AWPassiveClauseContainer;
private:
  const Options& _opt;
};

class AWPassiveClauseContainer
: public PassiveClauseContainer
{
public:
  CLASS_NAME(AWPassiveClauseContainer);
  USE_ALLOCATOR(AWPassiveClauseContainer);

  AWPassiveClauseContainer(const Options& opt);
  virtual ~AWPassiveClauseContainer();
  void add(Clause* cl);

  void remove(Clause* cl);

  Clause* popSelected();
 
  bool isEmpty() const
  { return _ageQueue.isEmpty() && _weightQueue.isEmpty(); }

  ClauseIterator iterator();

  void updateLimits(long long estReachableCnt);

  virtual unsigned size() const { return _size; }


  static Comparison compareWeight(Clause* cl1, Clause* cl2, const Options& opt);
protected:
  void onLimitsUpdated(LimitsChangeType change);

private:

 
  AgeQueue _ageQueue;
 
  WeightQueue _weightQueue;
 
  int _ageRatio;
 
  int _weightRatio;
 
  int _balance;

  unsigned _size;

  const Options& _opt;
}; 

class AWClauseContainer: public ClauseContainer
{
public:
  AWClauseContainer(const Options& opt);

  void add(Clause* cl);
  bool remove(Clause* cl);

 
  void setAgeWeightRatio(int age,int weight)
  {
    ASS(age >= 0);
    ASS(weight >= 0);
    ASS(age > 0 || weight > 0);

    _ageRatio = age;
    _weightRatio = weight;
  }

  Clause* popSelected();
 
  bool isEmpty() const;

  unsigned size() const { return _size; }

  static Comparison compareWeight(Clause* cl1, Clause* cl2);

private:
 
  AgeQueue _ageQueue;
 
  WeightQueue _weightQueue;
 
  int _ageRatio;
 
  int _weightRatio;
 
  int _balance;

  unsigned _size;
};


};

#endif

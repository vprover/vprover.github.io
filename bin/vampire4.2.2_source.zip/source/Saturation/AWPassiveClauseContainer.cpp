
/*
 * File AWPassiveClauseContainer.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include <math.h>

#include "Debug/RuntimeStatistics.hpp"

#include "Lib/Environment.hpp"
#include "Lib/Int.hpp"
#include "Lib/Timer.hpp"
#include "Kernel/Term.hpp"
#include "Kernel/Clause.hpp"
#include "Shell/Statistics.hpp"
#include "Shell/Options.hpp"

#include "SaturationAlgorithm.hpp"

#if VDEBUG
#include <iostream>
#endif

#include "AWPassiveClauseContainer.hpp"

namespace Saturation
{
using namespace Lib;
using namespace Kernel;


AWPassiveClauseContainer::AWPassiveClauseContainer(const Options& opt)
:  _ageQueue(opt), _weightQueue(opt), _balance(0), _size(0), _opt(opt)
{
  CALL("AWPassiveClauseContainer::AWPassiveClauseContainer");

  _ageRatio = _opt.ageRatio();
  _weightRatio = _opt.weightRatio();
  ASS_GE(_ageRatio, 0);
  ASS_GE(_weightRatio, 0);
  ASS(_ageRatio > 0 || _weightRatio > 0);

}

AWPassiveClauseContainer::~AWPassiveClauseContainer()
{
  ClauseQueue::Iterator cit(_ageQueue);
  while (cit.hasNext()) {
    Clause* cl=cit.next();
    ASS(cl->store()==Clause::PASSIVE);
    cl->setStore(Clause::NONE);
  }
}

ClauseIterator AWPassiveClauseContainer::iterator()
{
  return pvi( ClauseQueue::Iterator(_weightQueue) );
}

Comparison AWPassiveClauseContainer::compareWeight(Clause* cl1, Clause* cl2, const Options& opt)
{
  CALL("AWPassiveClauseContainer::compareWeight");

  
  
  unsigned cl1Weight=cl1->weight();
  unsigned cl2Weight=cl2->weight();

  if (opt.increasedNumeralWeight()) {
    cl1Weight=cl1Weight*2+cl1->getNumeralWeight();
    cl2Weight=cl2Weight*2+cl2->getNumeralWeight();
  }

  int nwcNumer = opt.nonGoalWeightCoeffitientNumerator();
  int nwcDenom = opt.nonGoalWeightCoeffitientDenominator();

  if (cl1->inputType()==0 && cl2->inputType()!=0) {
    return Int::compare(cl1Weight*nwcNumer, cl2Weight*nwcDenom);
  } else if (cl1->inputType()!=0 && cl2->inputType()==0) {
    return Int::compare(cl1Weight*nwcDenom, cl2Weight*nwcNumer);
  }
  return Int::compare(cl1Weight, cl2Weight);
}

bool WeightQueue::lessThan(Clause* c1,Clause* c2)
{
  CALL("WeightQueue::lessThan");

  Comparison weightCmp=AWPassiveClauseContainer::compareWeight(c1, c2, _opt);
  if (weightCmp!=EQUAL) {
    return weightCmp==LESS;
  }

  if (c1->age() < c2->age()) {
    return true;
  }
  if (c2->age() < c1->age()) {
    return false;
  }
  if (c1->inputType() < c2->inputType()) {
    return false;
  }
  if (c2->inputType() < c1->inputType()) {
    return true;
  }
  return c1->number() < c2->number();
} 


bool AgeQueue::lessThan(Clause* c1,Clause* c2)
{
  CALL("AgeQueue::lessThan");

  if (c1->age() < c2->age()) {
    return true;
  }
  if (c2->age() < c1->age()) {
    return false;
  }

  Comparison weightCmp=AWPassiveClauseContainer::compareWeight(c1, c2, _opt);
  if (weightCmp!=EQUAL) {
    return weightCmp==LESS;
  }

  if (c1->inputType() < c2->inputType()) {
    return false;
  }
  if (c2->inputType() < c1->inputType()) {
    return true;
  }

  return c1->number() < c2->number();
} 

void AWPassiveClauseContainer::add(Clause* cl)
{
  CALL("AWPassiveClauseContainer::add");
  ASS(_ageRatio > 0 || _weightRatio > 0);

  if (_ageRatio) {
    _ageQueue.insert(cl);
  }
  if (_weightRatio) {
    _weightQueue.insert(cl);
  }
  _size++;
  addedEvent.fire(cl);
} 

void AWPassiveClauseContainer::remove(Clause* cl)
{
  CALL("AWPassiveClauseContainer::remove");
  ASS(cl->store()==Clause::PASSIVE);

  if (_ageRatio) {
    ALWAYS(_ageQueue.remove(cl));
  }
  if (_weightRatio) {
    ALWAYS(_weightQueue.remove(cl));
  }
  _size--;

  removedEvent.fire(cl);

  ASS(cl->store()!=Clause::PASSIVE);
}


Clause* AWPassiveClauseContainer::popSelected()
{
  CALL("AWPassiveClauseContainer::popSelected");
  ASS( ! isEmpty());

  _size--;

  bool byWeight;
  if (! _ageRatio) {
    byWeight = true;
  }
  else if (! _weightRatio) {
    byWeight = false;
  }
  else if (_balance > 0) {
    byWeight = true;
  }
  else if (_balance < 0) {
    byWeight = false;
  }
  else {
    byWeight = (_ageRatio <= _weightRatio);
  }

  if (byWeight) {
    _balance -= _ageRatio;
    Clause* cl = _weightQueue.pop();
    _ageQueue.remove(cl);
    selectedEvent.fire(cl);
    return cl;
  }
  _balance += _weightRatio;
  Clause* cl = _ageQueue.pop();
  _weightQueue.remove(cl);
  selectedEvent.fire(cl);
  return cl;
} 



void AWPassiveClauseContainer::updateLimits(long long estReachableCnt)
{
  CALL("AWPassiveClauseContainer::updateLimits");
  ASS_GE(estReachableCnt,0);

  int maxAge, maxWeight;

  if (estReachableCnt>static_cast<long long>(_size)) {
    maxAge=-1;
    maxWeight=-1;
    goto fin;
  }

  {
    ClauseQueue::Iterator wit(_weightQueue);
    ClauseQueue::Iterator ait(_ageQueue);

    if (!wit.hasNext() && !ait.hasNext()) {
      
      return;
    }

    long long remains=estReachableCnt;
    Clause* wcl=0;
    Clause* acl=0;
    if (_ageRatio==0 || (_opt.lrsWeightLimitOnly() && _weightRatio!=0) ) {
      ASS(wit.hasNext());
      while ( remains && wit.hasNext() ) {
	wcl=wit.next();
	remains--;
      }
    } else if (_weightRatio==0) {
      ASS(ait.hasNext());
      while ( remains && ait.hasNext() ) {
	acl=ait.next();
	remains--;
      }
    } else {
      ASS(wit.hasNext()&&ait.hasNext());

      int balance=(_ageRatio<=_weightRatio)?1:0;
      while (remains) {
	ASS_G(remains,0);
	if ( (balance>0 || !ait.hasNext()) && wit.hasNext()) {
	  wcl=wit.next();
	  if (!acl || _ageQueue.lessThan(acl, wcl)) {
	    balance-=_ageRatio;
	    remains--;
	  }
	} else if (ait.hasNext()){
	  acl=ait.next();
	  if (!wcl || _weightQueue.lessThan(wcl, acl)) {
	    balance+=_weightRatio;
	    remains--;
	  }
	} else {
	  break;
	}
      }
    }

    
    maxAge=(_ageRatio && acl!=0)?-1:0;
    maxWeight=(_weightRatio && wcl!=0)?-1:0;
    if (acl!=0 && ait.hasNext()) {
      maxAge=acl->age();
    }
    if (wcl!=0 && wit.hasNext()) {
      maxWeight=static_cast<int>(ceil(wcl->getEffectiveWeight(_opt)));
    }
  }

fin:
#if OUTPUT_LRS_DETAILS
  cout<<env.timer->elapsedDeciseconds()<<"\tLimits to "<<maxAge<<"\t"<<maxWeight<<"\t by est "<<estReachableCnt<<"\n";
#endif

  getSaturationAlgorithm()->getLimits()->setLimits(maxAge,maxWeight);
}

void AWPassiveClauseContainer::onLimitsUpdated(LimitsChangeType change)
{
  CALL("AWPassiveClauseContainer::onLimitsUpdated");

  if (change==LIMITS_LOOSENED) {
    return;
  }

  Limits* limits=getSaturationAlgorithm()->getLimits();
  if ( (!limits->ageLimited() && _ageRatio) || (!limits->weightLimited() && _weightRatio) ) {
    return;
  }

  
  
  
  

  unsigned ageLimit=limits->ageLimit();
  unsigned weightLimit=limits->weightLimit();

  static Stack<Clause*> toRemove(256);
  ClauseQueue::Iterator wit(_weightQueue);
  while (wit.hasNext()) {
    Clause* cl=wit.next();

    bool shouldStay=true;

    if (cl->age()>ageLimit) {
      if (cl->getEffectiveWeight(_opt)>weightLimit) {
        shouldStay=false;
      }
    } else if (cl->age()==ageLimit) {
      
      unsigned clen=cl->length();
      int maxSelWeight=0;
      for(unsigned i=0;i<clen;i++) {
        maxSelWeight=max((int)(*cl)[i]->weight(),maxSelWeight);
      }
      
      
      
      if (cl->weight()-maxSelWeight>=weightLimit) {
	
        shouldStay=false;
      }
    }
    if (!shouldStay) {
      toRemove.push(cl);
    }
  }

#if OUTPUT_LRS_DETAILS
  if (toRemove.isNonEmpty()) {
    cout<<toRemove.size()<<" passive deleted, "<< (size()-toRemove.size()) <<" remains\n";
  }
#endif

  while (toRemove.isNonEmpty()) {
    Clause* removed=toRemove.pop();
    RSTAT_CTR_INC("clauses discarded from passive on weight limit update");
    env.statistics->discardedNonRedundantClauses++;
    remove(removed);
  }
}

AWClauseContainer::AWClauseContainer(const Options& opt)
: _ageQueue(opt), _weightQueue(opt), _ageRatio(1), _weightRatio(1), _balance(0), _size(0)
{
}

bool AWClauseContainer::isEmpty() const
{
  CALL("AWClauseContainer::isEmpty");

  ASS(!_ageRatio || !_weightRatio || _ageQueue.isEmpty()==_weightQueue.isEmpty());
  return _ageQueue.isEmpty() && _weightQueue.isEmpty();
}

void AWClauseContainer::add(Clause* cl)
{
  CALL("AWClauseContainer::add");
  ASS(_ageRatio > 0 || _weightRatio > 0);

  if (_ageRatio) {
    _ageQueue.insert(cl);
  }
  if (_weightRatio) {
    _weightQueue.insert(cl);
  }
  _size++;
  addedEvent.fire(cl);
}

bool AWClauseContainer::remove(Clause* cl)
{
  CALL("AWClauseContainer::remove");

  bool removed;
  if (_ageRatio) {
    removed = _ageQueue.remove(cl);
    if (_weightRatio) {
      ALWAYS(_weightQueue.remove(cl)==removed);
    }
  }
  else {
    ASS(_weightRatio);
    removed = _weightQueue.remove(cl);
  }

  if (removed) {
    _size--;
    removedEvent.fire(cl);
  }
  return removed;
}


Clause* AWClauseContainer::popSelected()
{
  CALL("AWClauseContainer::popSelected");
  ASS( ! isEmpty());

  _size--;

  bool byWeight;
  if (! _ageRatio) {
    byWeight = true;
  }
  else if (! _weightRatio) {
    byWeight = false;
  }
  else if (_balance > 0) {
    byWeight = true;
  }
  else if (_balance < 0) {
    byWeight = false;
  }
  else {
    byWeight = (_ageRatio <= _weightRatio);
  }

  Clause* cl;
  if (byWeight) {
    _balance -= _ageRatio;
    cl = _weightQueue.pop();
    ALWAYS(_ageQueue.remove(cl));
  }
  else {
    _balance += _weightRatio;
    cl = _ageQueue.pop();
    ALWAYS(_weightQueue.remove(cl));
  }
  selectedEvent.fire(cl);
  return cl;
}



}

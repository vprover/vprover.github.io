
/*
 * File CliqueFinder.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __CliqueFinder__
#define __CliqueFinder__

#include "Lib/DHMap.hpp"

namespace FMB {

  class CliqueFinder {
  public:
    static unsigned findMaxCliqueSize(DHMap<unsigned,DHSet<unsigned>*>* Ngraph)
    {
      CALL("FMB::CliqueFinder::findMaxCliqueSize");

      

      
      DArray<Stack<unsigned>> atleast;
      atleast.ensure(Ngraph->size()+1); 

      DHMap<unsigned,DHSet<unsigned>*>::Iterator miter(*Ngraph);
      while(miter.hasNext()){
        unsigned c;
        DHSet<unsigned>* nbs;
        miter.next(c,nbs);
        unsigned size = nbs->size();
        

        
        

        for(;size>0;size--){
          atleast[size].push(c);
        }
      }
      

      for(unsigned i=atleast.size()-1;i>1;i--){
        
        if(atleast[i].size() == i+1){
          
          if(checkClique(Ngraph,atleast[i])){
            
            
            return i+1;
          }
        }
        
        
        else if (atleast[i].size() > i+1){
          
          unsigned left = atleast[i].size();
          Stack<unsigned>::Iterator niter(atleast[i]);
          while(niter.hasNext() && left >= i+1){
            unsigned c = niter.next();
            
            auto ns = Ngraph->get(c);
            if(ns->size()==i){
              Stack<unsigned> clique;
              clique.loadFromIterator(ns->iterator());
              clique.push(c);
              if(checkClique(Ngraph,clique)){
                
                return i+1;
              }
              left--;
            }
          }
          
        }
      }

      
      
      
      return 1;
    }
  private:

    
    static bool checkClique(DHMap<unsigned,DHSet<unsigned>*>* Ngraph, Stack<unsigned>& clique)
    {
      CALL("FMB::CliqueFinder::checkClique");
      
      

      for(unsigned i=0;i<clique.size()-1;i++){
        unsigned c1 = clique[i];
        auto ns = Ngraph->get(c1);
        
        
        for(unsigned j=i+1;j<clique.size();j++){
          unsigned c2 = clique[j];
          
          if(!ns->find(c2)){ return false; }
        }
      }
      return true;
    }


  };



}

#endif

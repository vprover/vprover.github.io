
/*
 * File SortInference.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __SortInference__
#define __SortInference__

#include "Forwards.hpp"

#include "Lib/DHMap.hpp"
#include "Lib/IntUnionFind.hpp"
#include "Kernel/Signature.hpp"

namespace FMB {
using namespace Kernel;
using namespace Shell;
using namespace Lib;

struct SortedSignature{
    CLASS_NAME(SortedSignature);
    USE_ALLOCATOR(SortedSignature);

    unsigned sorts;
    DArray<Stack<unsigned>> sortedConstants;
    DArray<Stack<unsigned>> sortedFunctions;

    
    DArray<DArray<unsigned>> functionSignatures;
    
    DArray<DArray<unsigned>> predicateSignatures;

    
    DArray<unsigned> sortBounds;
    
    
    unsigned distinctSorts;

    
    
    DArray<unsigned> varEqSorts;

    
    
    
    DArray<unsigned> parents;

    
    
    DHMap<unsigned,Stack<unsigned>*> distinctToVampire;
    
    
    
    
    DHMap<unsigned,Stack<unsigned>*> vampireToDistinct;
    
    
    DHMap<unsigned,unsigned> vampireToDistinctParent;

    
    
    ZIArray<bool> monotonicSorts;
};

class SortInference {
public:
  CLASS_NAME(SortInference);
  USE_ALLOCATOR(SortInference);    
  
  SortInference(ClauseList* clauses,
                DArray<unsigned> del_f,
                DArray<unsigned> del_p,
                Stack<DHSet<unsigned>*> equiv_v_sorts,
                Stack<std::pair<unsigned,unsigned>>& cons) :
                _clauses(clauses), _del_f(del_f), _del_p(del_p),
                _equiv_v_sorts(equiv_v_sorts), _equiv_vs(env.sorts->sorts()),
                _sort_constraints(cons) {

                  _sig = new SortedSignature();
                  _print = env.options->showFMBsortInfo();

                   
                  _ignoreInference = !clauses; 
                  _expandSubsorts = env.options->fmbAdjustSorts() == Options::FMBAdjustSorts::EXPAND;

                  _usingMonotonicity = true;
                  _collapsingMonotonicSorts = (env.options->fmbAdjustSorts() != Options::FMBAdjustSorts::OFF && 
                                               env.options->fmbAdjustSorts() != Options::FMBAdjustSorts::EXPAND);
                  _assumeMonotonic = _collapsingMonotonicSorts && 
                                     env.options->fmbAdjustSorts() != Options::FMBAdjustSorts::GROUP;

                  _distinctSorts=0;
                  _collapsed=0;

                  ASS(! (_expandSubsorts && _collapsingMonotonicSorts) );
                  ASS( _collapsingMonotonicSorts || !_assumeMonotonic); 
                }

   void doInference();                

   SortedSignature* getSignature(){ return _sig; } 

private:

   unsigned getDistinctSort(unsigned subsort, unsigned vampireSort, bool createNew=true);

  bool _print;
  bool _ignoreInference;
  bool _expandSubsorts;
  bool _usingMonotonicity;
  bool _collapsingMonotonicSorts;
  bool _assumeMonotonic;

  unsigned _distinctSorts;
  unsigned _collapsed;
  DHSet<unsigned> monotonicVampireSorts;
  ZIArray<unsigned> posEqualitiesOnSort;

  SortedSignature* _sig;
  ClauseList* _clauses;
  DArray<unsigned> _del_f;
  DArray<unsigned> _del_p;
  Stack<DHSet<unsigned>*> _equiv_v_sorts;
  IntUnionFind _equiv_vs;

  Stack<std::pair<unsigned,unsigned>>& _sort_constraints;

};

}

#endif 

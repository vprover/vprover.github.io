
/*
 * File DefinitionIntroduction.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __DefinitionIntroduction__
#define __DefinitionIntroduction__

#include "Kernel/Signature.hpp"
#include "Kernel/Term.hpp"
#include "Kernel/TermIterators.hpp"

#include "Lib/Environment.hpp"
#include "Lib/DHMap.hpp"

#include "Forwards.hpp"

namespace FMB {

  
  class DefinitionIntroduction{

  public:
    DefinitionIntroduction(ClauseIterator cit) : _cit(cit) {
      
    }


    bool hasNext(){
      TimeCounter tc(TC_FMB_DEF_INTRO);
      CALL("DefinitionIntroduction::hasNext");
      
      if(_processed.length()==0){
        
        if(_cit.hasNext()) process(_cit.next());
        
        else return false;
      } 
      return true; 
    }

    Clause* next(){
      TimeCounter tc(TC_FMB_DEF_INTRO);
      CALL("DefinitionIntroduction::next");
      ASS_G(_processed.length(),0);
      return _processed.pop();
    }

  private:

    void process(Clause* c){
      CALL("DefinitionIntroduction::process");

      

      static Stack<Literal*> lits; 
      lits.reset();

      bool anyUpdated = false;

      for(unsigned i=0;i<c->length();i++){
        Literal* l = (*c)[i];
        bool updated = false;

        

        Stack<TermList> args; 
        for(TermList* ts = l->args(); ts->isNonEmpty(); ts = ts->next()){
          
          if(ts->isVar() ||  ts->term()->arity()==0 || !ts->term()->ground()){
            args.push(*ts);
          }
          else{
            ASS(ts->term()->ground());
            Term* t = addGroundDefinition(ts->term(),c);
            ASS(t->shared());
            args.push(TermList(t)); 
            updated |= (t != ts->term());
          }
        }
        if(!updated){
          lits.push(l); 
        }
        else{
          anyUpdated = true;
          Literal* nl = Literal::create(l,args.begin());
          lits.push(nl);
        }
      }

      if(anyUpdated){
        Clause* cl = Clause::fromStack(lits,c->inputType(),
                     new Inference1(Inference::FMB_DEF_INTRO,c));
         _processed.push(cl);
      }else{
         _processed.push(c);
      }
    }

    Term* addGroundDefinition(Term* term, Clause* from){
      CALL("DefinitionIntroduction::addGroundDefinition");

      
      ASS(term->ground());
      if(term->arity()==0) return term;

      Term* retC=0;
      if(_introduced.find(term,retC)){ return retC; }

      PolishSubtermIterator it(term);
      while(it.hasNext() || retC==0){
        Term* t = it.hasNext() ? it.next().term() : term;
        
        if(t->arity()==0) continue;
        if(!_introduced.find(t)){
          unsigned newConstant = env.signature->addFreshFunction(0,"fmbdef");
          unsigned srt = SortHelper::getResultSort(t);
          env.signature->getFunction(newConstant)->setType(new FunctionType(srt));
          Term* c = Term::createConstant(newConstant); 
          _introduced.insert(t,c);
          if(term==t) retC=c;

          
          bool updated = false;
          Stack<TermList> args;
          for(TermList* ts = t->args(); ts->isNonEmpty(); ts = ts->next()){
            ASS(ts->term()->ground());
            
            if(ts->term()->arity()==0){args.push(*ts);}
            else{
              Term* argT;
              ALWAYS(_introduced.find(ts->term(),argT));
              args.push(TermList(argT));
              updated = true; 
            }
          }
          if(updated){
            t = Term::create(t,args.begin());
          }
          unsigned sort = SortHelper::getResultSort(t); 
          Literal* l = Literal::createEquality(true,TermList(t),TermList(c),sort);
          static Stack<Literal*> lstack;
          lstack.reset();
          lstack.push(l);
          Clause* def = Clause::fromStack(lstack,from->inputType(),
                    new Inference1(Inference::FMB_DEF_INTRO,from));

          
          _processed.push(def); 
        }
      }
      ASS(retC);
#if VDEBUG
      Term* otherRetC = 0;
      ASS(_introduced.find(term,otherRetC));
      ASS(retC==otherRetC);
#endif
      return retC;
    }

    ClauseIterator _cit;
    Stack<Clause*> _processed;

    DHMap<Term*,Term*> _introduced;
    DHMap<Term*,unsigned> _introducedNG;

  };

} 
#endif

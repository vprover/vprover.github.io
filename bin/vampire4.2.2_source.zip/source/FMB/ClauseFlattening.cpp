
/*
 * File ClauseFlattening.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Kernel/Term.hpp"
#include "Kernel/Clause.hpp"
#include "Kernel/SortHelper.hpp"
#include "Kernel/Substitution.hpp"
#include "Kernel/SubstHelper.hpp"
#include "Kernel/Inference.hpp"

#include "Lib/Map.hpp"
#include "Lib/Stack.hpp"
#include "Lib/Array.hpp"
#include "Lib/VirtualIterator.hpp"

#include "ClauseFlattening.hpp"

namespace FMB{

bool ClauseFlattening::isShallow(Literal* lit)
{
  CALL("ClauseFlattening::isShallow(Literal)");
  
  Term* check = 0;

  if(lit->isEquality()){
   
   if(lit->isTwoVarEquality()) return lit->polarity()==1;

   
   if(lit->nthArgument(0)->isVar()){
     check = lit->nthArgument(1)->term();
   }
   else if(lit->nthArgument(1)->isVar()){
     check = lit->nthArgument(0)->term();
   }
   else return false;
  }
  
  else check = lit;

  TermList* a = check->args();
  while(!a->isEmpty()){ 
    if(!a->isVar()) return false; 
    a = a->next();
  }
  return true;
}

Clause* ClauseFlattening::resolveNegativeVariableEqualities(Clause* cl)
{
  CALL("ClauseFlattening::resolveNegativeVariableEqualities");

  Array<Literal*> lits;
  Stack<Literal*> inequalities;
  int n = 0;
  for (unsigned i = 0;i < cl->length();i++) {
    Literal* lit = (*cl)[i];
    if (lit->isEquality() &&
        lit->isNegative() &&
        lit->nthArgument(0)->isVar() &&
        lit->nthArgument(1)->isVar()) {
      inequalities.push(lit);
    }
    else {
      lits[n++] = lit;
    }
  }
  if (inequalities.isEmpty()) {
    return cl;
  }
  bool diffVar = false;
  while (!inequalities.isEmpty()) {
    Literal* ineq = inequalities.pop();
    unsigned v1 = ineq->nthArgument(0)->var();
    TermList* v2 = ineq->nthArgument(1);
    if (v1 == v2->var()) { 
      continue;
    }
    diffVar = true;
    Substitution subst;
    subst.bind(v1,*v2);
    cl = new(n) Clause(n,cl->inputType(),
                       new Inference1(Inference::EQUALITY_RESOLUTION,cl));
    for (int i = n-1;i >= 0;i--) {
      Literal* lit = SubstHelper::apply<Substitution>(lits[i],subst);
      (*cl)[i] = lit;
      lits[i] = lit;
    }
  }
  if (!diffVar) { 
    cl = new(n) Clause(n,cl->inputType(),
                       new Inference1(Inference::EQUALITY_RESOLUTION,cl));
    for (int i = n-1;i >= 0;i--) {
      (*cl)[i] = lits[i];
    }
  }
  return cl;
} 

Clause* ClauseFlattening::flatten(Clause* cl)
{
  CALL("ClauseFlattening::flatten");
  TimeCounter tc(TC_FMB_FLATTENING);

  cl = resolveNegativeVariableEqualities(cl);

  
  unsigned maxVar = 0;
  VirtualIterator<unsigned> varIt = cl->getVariableIterator();
  while (varIt.hasNext()) {
    unsigned var = varIt.next();
    if (var > maxVar) {
      maxVar = var;
    }
  }

  
  Stack<Literal*> lits;
  for(int i= cl->length()-1; i>=0;i--){
    lits.push((*cl)[i]);
  }

  
  
  
  

  
  Stack<Literal*> result;

  
  bool updated=false;

  
  while(!lits.isEmpty()){
    Literal* lit = lits.pop();
    
    
    if(isShallow(lit)){
      if(!result.find(lit)){
        result.push(lit);
      }
    }
    else{
      updated=true;
      if(lit->isEquality()){
        

        unsigned litArgSort = SortHelper::getEqualityArgumentSort(lit);

        TermList* lhs = lit->nthArgument(0);
        TermList* rhs = lit->nthArgument(1);

        
        if(rhs->isVar()){ TermList* tmp = lhs; lhs=rhs; rhs=tmp; }
        ASS(!rhs->isVar());

        if(!lhs->isVar()){
          
          if(lit->polarity()){
            
            TermList v1; v1.makeVar(++maxVar);
            TermList v2; v2.makeVar(++maxVar);
            lits.push(Literal::createEquality(false,*lhs,v1,litArgSort));
            lits.push(Literal::createEquality(false,*rhs,v2,litArgSort));
            lits.push(Literal::createEquality(true,v1,v2,litArgSort));
            continue;
          }
          else{
            
            
            TermList v; v.makeVar(++maxVar);
            lits.push(Literal::createEquality(false,*lhs,v,litArgSort));
            lits.push(Literal::createEquality(false,*rhs,v,litArgSort));
            continue;
          }
        }
        ASS(lhs->isVar());
        
        Term* t = rhs->term();
        
        Stack<TermList> args;
        for(TermList* ts = t->args(); ts->isNonEmpty(); ts = ts->next()){
          if(ts->isVar()){
            args.push(*ts);
          }
          else{
            TermList v; v.makeVar(++maxVar);
            args.push(v);
            unsigned rSort = SortHelper::getResultSort(ts->term());
            lits.push(Literal::createEquality(false,*ts,v,rSort));
          }
        }
        
        Term* nt = Term::create(t->functor(),args.length(),args.begin());
        
        lits.push(Literal::createEquality(lit->polarity(),*lhs,TermList(nt),litArgSort)); 
      }

      else{ 
        
        
        Stack<TermList> args;
        for(TermList* ts = lit->args();ts->isNonEmpty(); ts = ts->next()){
          if(ts->isVar()){
            args.push(*ts);
          }
          else{
            TermList v; v.makeVar(++maxVar);
            args.push(v);
            unsigned rSort = SortHelper::getResultSort(ts->term());
            lits.push(Literal::createEquality(false,*ts,v,rSort));
          }
        }
        
        lits.push(Literal::create(lit,args.begin()));
      }
    
    }
  }

  
  if(!updated) return cl;

  return Clause::fromStack(result,cl->inputType(),
                            new Inference1(Inference::FMB_FLATTENING,cl));
}

}


/*
 * File FiniteModelBuilder.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __FiniteModelBuilder__
#define __FiniteModelBuilder__

#include "Forwards.hpp"

#if VZ3
#include "z3++.h"
#include "z3_api.h"
#endif

#include "Kernel/MainLoop.hpp"
#include "SAT/SATSolver.hpp"
#include "Lib/ScopedPtr.hpp"
#include "SortInference.hpp"
#include "Lib/BinaryHeap.hpp"

namespace FMB {
using namespace Lib;
using namespace Kernel;
using namespace Inferences;
using namespace Shell;
using namespace SAT;

 
  struct GroundedTerm{
    unsigned f;
    DArray<unsigned> grounding;

    vstring toString(){
      vstring ret = Lib::Int::toString(f)+"[";
      for(unsigned i=0;i<grounding.size();i++){
        if(i>0) ret +=",";
        ret+=Lib::Int::toString(grounding[i]);
      }
      return ret+"]";
    }

  };

class FiniteModelBuilder : public MainLoop {
public:
  CLASS_NAME(FiniteModedlBuilder);
  USE_ALLOCATOR(FiniteModelBuilder);    
  
  FiniteModelBuilder(Problem& prb, const Options& opt);
  ~FiniteModelBuilder();

protected:
  
  virtual void init();

  
  virtual MainLoopResult runImpl();

private:

  
  void onModelFound();

  
  void addGroundClauses();
  
  void addNewInstances();

  
  unsigned estimateInstanceCount();

  
  void addNewFunctionalDefs();

  unsigned estimateFunctionalDefCount();

  
  void addNewTotalityDefs();

  
  void addNewSymmetryOrderingAxioms(unsigned modelSize,Stack<GroundedTerm>& groundedTerms); 
  
  void addNewSymmetryCanonicityAxioms(unsigned modelSize,Stack<GroundedTerm>& groundedTerms,unsigned maxModelSize);

  
  
  void addNewSymmetryAxioms(){
      ASS(_sortedSignature);
    
    for(unsigned s=0;s<_sortedSignature->sorts;s++){
      
      unsigned modelSize = _sortModelSizes[s];
      for(unsigned m=1;m<=modelSize;m++){
        
        addNewSymmetryOrderingAxioms(m,_sortedGroundedTerms[s]);
        addNewSymmetryCanonicityAxioms(m,_sortedGroundedTerms[s],modelSize);
      }
    }
  }
  
  
  void addUseModelSize(unsigned size);

  
  
  
  SATLiteral getSATLiteral(unsigned func, const DArray<unsigned>& elements,bool polarity,
                           bool isFunction);

  
  bool reset();

  
  void createSymmetryOrdering();
  
  DArray<Stack<GroundedTerm>> _sortedGroundedTerms;

  
  ScopedPtr<SATSolverWithAssumptions> _solver;

  
  
  
  DHMap<unsigned,Literal*> _deletedFunctions;
  DHMap<unsigned,Unit*> _deletedPredicates;
  DHMap<unsigned,Unit*> _partiallyDeletedPredicates; 
  DHMap<unsigned,bool> _trivialPredicates;
  
  DArray<unsigned> del_f;
  DArray<unsigned> del_p;

  
  void addSATClause(SATClause* cl);
  
  void addSATClause(SATLiteral lit){
    static SATLiteralStack satClauseLits;
    satClauseLits.reset();
    satClauseLits.push(lit);
    addSATClause(SATClause::fromStack(satClauseLits));
  }
  
  SATClauseStack _clausesToBeAdded;

  
  SortedSignature* _sortedSignature;
  
  ClauseList* _groundClauses;
  ClauseList* _clauses;

  
  DArray<unsigned> _fminbound;
  
  
  DHMap<Clause*,DArray<unsigned>*> _clauseVariableSorts;

  
  
  
  DArray<unsigned> f_offsets;
  DArray<unsigned> p_offsets;

  
  bool _xmass;

  

 
  DArray<unsigned> marker_offsets;

  

 
  unsigned totalityMarker_offset;
 
  unsigned instancesMarker_offset;

  

 
  unsigned which_sort(unsigned var) {
    ASS_GE(var,marker_offsets[0]);
    unsigned j;
    for (j = 0; j < _distinctSortSizes.size()-1; j++) {
      if (var < marker_offsets[j+1]) {
        return j;
      }
    }
    ASS_EQ(j,_distinctSortSizes.size()-1);
    ASS_GE(var,_distinctSortSizes[j]);
    return j;
  }

 

  
  
  unsigned _startModelSize; 
  
  bool _isAppropriate;
  
  float _symmetryRatio;

  
  unsigned _sizeWeightRatio;

  
  DArray<unsigned> _sortModelSizes;
  DArray<unsigned> _distinctSortSizes;

  enum ConstraintSign {
    EQ,     
    LEQ,    
    GEQ,    
    STAR    
  };

  typedef DArray<pair<ConstraintSign,unsigned>> Constraint_Generator_Vals;

  class DSAEnumerator { 
  public:
    virtual bool init(unsigned, DArray<unsigned>&, Stack<std::pair<unsigned,unsigned>>&, Stack<std::pair<unsigned,unsigned>>&) { return true; }
    virtual void learnNogood(Constraint_Generator_Vals& nogood, unsigned weight) = 0;
    virtual bool increaseModelSizes(DArray<unsigned>& newSortSizes, DArray<unsigned>& sortMaxes) = 0;
    virtual bool isFmbComplete(unsigned noDomains) { return false; }
    virtual ~DSAEnumerator() {}
  };

  DSAEnumerator* _dsaEnumerator;

  class HackyDSAE : public DSAEnumerator {
    struct Constraint_Generator {
      CLASS_NAME(FiniteModedlBuilder::HackyDSAE::Constraint_Generator);
      USE_ALLOCATOR(FiniteModelBuilder::HackyDSAE::Constraint_Generator);

      Constraint_Generator_Vals _vals;
      unsigned _weight;

      Constraint_Generator(unsigned size, unsigned weight)
        : _vals(size), _weight(weight) {}
      Constraint_Generator(Constraint_Generator_Vals& vals, unsigned weight)
        : _vals(vals), _weight(weight) {}
    };

    struct Constraint_Generator_Compare {
      static Comparison compare (Constraint_Generator* c1, Constraint_Generator* c2)
      { return c1->_weight < c2->_weight ? LESS : c1->_weight == c2->_weight ? EQUAL : GREATER; }
    };

    typedef Lib::BinaryHeap<Constraint_Generator*,Constraint_Generator_Compare> Constraint_Generator_Heap;

    Stack<std::pair<unsigned,unsigned>>* _distinct_sort_constraints;
    Stack<std::pair<unsigned,unsigned>>* _strict_distinct_sort_constraints;

   
    Constraint_Generator_Heap _constraints_generators;

    unsigned _maxWeightSoFar;

    

  protected:
    bool checkConstriant(DArray<unsigned>& newSortSizes, Constraint_Generator_Vals& constraint);

  public:
    CLASS_NAME(FiniteModedlBuilder::HackyDSAE);
    USE_ALLOCATOR(FiniteModelBuilder::HackyDSAE);

    HackyDSAE() : _maxWeightSoFar(0) {}

    bool init(unsigned, DArray<unsigned>&, Stack<std::pair<unsigned,unsigned>>& dsc, Stack<std::pair<unsigned,unsigned>>& sdsc) override {
      _distinct_sort_constraints = &dsc;
      _strict_distinct_sort_constraints = &sdsc;
      return true;
    }

    bool isFmbComplete(unsigned noDomains) override { return noDomains == 1; }
    void learnNogood(Constraint_Generator_Vals& nogood, unsigned weight) override;
    bool increaseModelSizes(DArray<unsigned>& newSortSizes, DArray<unsigned>& sortMaxes) override;
  };

#if VZ3
  class SmtBasedDSAE : public DSAEnumerator {
    z3::context _context;
    z3::solver  _smtSolver;
    unsigned _lastWeight;
    DArray<z3::expr*> _sizeConstants;
  protected:
    unsigned loadSizesFromSmt(DArray<unsigned>& szs);
    void reportZ3OutOfMemory();
  public:
    
    CLASS_NAME(FiniteModedlBuilder::SmtBasedDSAE);
    USE_ALLOCATOR(FiniteModelBuilder::SmtBasedDSAE);

    SmtBasedDSAE() : _smtSolver(_context) {}

    bool init(unsigned, DArray<unsigned>&, Stack<std::pair<unsigned,unsigned>>&, Stack<std::pair<unsigned,unsigned>>&) override;
    void learnNogood(Constraint_Generator_Vals& nogood, unsigned weight) override;
    bool increaseModelSizes(DArray<unsigned>& newSortSizes, DArray<unsigned>& sortMaxes) override;
    bool isFmbComplete(unsigned) override { return true; }
  };
#endif

  
  
  Stack<std::pair<unsigned,unsigned>> _distinct_sort_constraints;
  
  Stack<std::pair<unsigned,unsigned>> _strict_distinct_sort_constraints;

  
  DArray<unsigned> _distinctSortConstantCount;
  
  DArray<unsigned> _distinctSortMins;
  DArray<unsigned> _distinctSortMaxs;
  

public: 
    static void output_cg(Constraint_Generator_Vals& cgv) {
      cout << "[";
      for (unsigned i = 0; i < cgv.size(); i++) {
        cout << cgv[i].second;
        switch(cgv[i].first) {
        case EQ:
          cout << "=";
          break;
        case LEQ:
          cout << ">";
          break;
        case GEQ:
          cout << "<";
          break;
        case STAR:
          cout << "*";
          break;
        default:
          ASSERTION_VIOLATION;
        }
        if (i < cgv.size()-1) {
          cout << ", ";
        }
      }
      cout << "]";
    }

};
}

#endif 

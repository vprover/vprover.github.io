
/*
 * File Monotonicity.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Monotonicity__
#define __Monotonicity__

#include "Forwards.hpp"

#include "Lib/Stack.hpp"
#include "Lib/DHMap.hpp"
#include "Lib/ScopedPtr.hpp"

#include "Kernel/Term.hpp"
#include "Kernel/Clause.hpp"
#include "Kernel/SortHelper.hpp"

#include "SAT/SATSolver.hpp"
#include "SAT/SATLiteral.hpp"
#include "SAT/SATClause.hpp"

#include "Lib/Allocator.hpp"

namespace FMB {
  using namespace Kernel;
  using namespace SAT;
  using namespace Lib;

class Monotonicity{

  CLASS_NAME(Monotonicity);
  USE_ALLOCATOR(Monotonicity);

public:
  
  Monotonicity(ClauseList* clauses, unsigned srt);

  bool check(){ return _result;}

  static void addSortPredicates(bool withMon, ClauseList*& clauses, DArray<unsigned>& del_f);
  static void addSortFunctions(bool withMon, ClauseList*& clauses);

private:
  
  void monotone(Clause* c, Literal* l); 
  
  void safe(Clause* c, Literal* l, TermList* t); 
  void safe(Clause* c, Literal* l, TermList* t, SATLiteral add); 
  void safe(Clause* c, Literal* l, TermList* t, Stack<SATLiteral>& slits);

  
  
  bool guards(Literal* l, unsigned var, Stack<SATLiteral>& slits);

 
  unsigned _srt; 
  
  
  bool _result;

  DHMap<unsigned,SATLiteral> _pF;
  DHMap<unsigned,SATLiteral> _pT;

  ScopedPtr<SATSolver> _solver;

};

}
#endif

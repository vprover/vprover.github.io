
/*
 * File PortfolioMode.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Lib/Environment.hpp"
#include "Lib/Int.hpp"
#include "Lib/Portability.hpp"
#include "Lib/Stack.hpp"
#include "Lib/System.hpp"
#include "Lib/ScopedLet.hpp"
#include "Lib/TimeCounter.hpp"
#include "Lib/Timer.hpp"
#include "Lib/Sys/Multiprocessing.hpp"

#include "Shell/Options.hpp"
#include "Shell/Statistics.hpp"
#include "Shell/UIHelper.hpp"
#include "Shell/Normalisation.hpp"
#include "Shell/TheoryFinder.hpp"

#include <unistd.h>

#include "Saturation/ProvingHelper.hpp"

#include "Kernel/Problem.hpp"

#include "Schedules.hpp"

#include "PortfolioMode.hpp"

using namespace Lib;
using namespace CASC;

PortfolioMode::PortfolioMode() : _slowness(1.0), _syncSemaphore(2) {
  
  
  

  _syncSemaphore.set(SEM_LOCK,1);    
  _syncSemaphore.set(SEM_PRINTED,0); 
}

bool PortfolioMode::perform(float slowness)
{
  CALL("PortfolioMode::perform");

  PortfolioMode pm;
  pm._slowness = slowness;

  bool resValue;
  try {
      resValue = pm.searchForProof();
  } catch (Exception& exc) {
      cerr << "% Exception at proof search level" << endl;
      exc.cry(cerr);
      System::terminateImmediately(1); 
  }

  if (outputAllowed()) {
    env.beginOutput();
    if (resValue) {
      addCommentSignForSZS(env.out());
      env.out()<<"Success in time "<<Timer::msToSecondsString(env.timer->elapsedMilliseconds())<<endl;
    }
    else {
      addCommentSignForSZS(env.out());
      env.out()<<"Proof not found in time "<<Timer::msToSecondsString(env.timer->elapsedMilliseconds())<<endl;
      if (env.remainingTime()/100>0) {
        addCommentSignForSZS(env.out());
        env.out()<<"SZS status GaveUp for "<<env.options->problemName()<<endl;
      }
      else {
        
        
        
        addCommentSignForSZS(env.out());
        env.out()<<"SZS status Timeout for "<<env.options->problemName()<<endl;
      }
    }
    if (env.options && env.options->timeStatistics()) {
      TimeCounter::printReport(env.out());
    }
    env.endOutput();
  }

  return resValue;
}

bool PortfolioMode::searchForProof()
{
  CALL("PortfolioMode::searchForProof");

  env.timer->makeChildrenIncluded();
  TimeCounter::reinitialize();

  _prb = UIHelper::getInputProblem(*env.options);
  Shell::Property* property = _prb->getProperty();

  {
    TimeCounter tc(TC_PREPROCESSING);

    
    ScopedLet<Statistics::ExecutionPhase> phaseLet(env.statistics->phase,Statistics::NORMALIZATION);
    Normalisation norm;
    norm.normalise(*_prb);

    TheoryFinder tf(_prb->units(),property);
    tf.search();
  }

  
  Timer::setTimeLimitEnforcement(false);

  return performStrategy(property);
}

bool PortfolioMode::performStrategy(Shell::Property* property)
{
  CALL("PortfolioMode::performStrategy");

  Schedule main;
  Schedule fallback;

  getSchedules(*property,main,fallback);

  
  Schedule::BottomFirstIterator it(fallback);
  main.loadFromIterator(it);

  int terminationTime = env.remainingTime()/100;

  if (terminationTime <= 0) {
    return false;
  }

  return runSchedule(main,terminationTime);
}

void PortfolioMode::getSchedules(Property& prop, Schedule& quick, Schedule& fallback)
{
  CALL("PortfolioMode::getSchedules");

  switch(env.options->schedule()) {
  case Options::Schedule::CASC_2014_EPR:
    Schedules::getCasc2014EprSchedule(prop,quick,fallback);
    break;
  case Options::Schedule::CASC_2014:
    Schedules::getCasc2014Schedule(prop,quick,fallback);
    break;
  case Options::Schedule::CASC_2016:
    Schedules::getCasc2016Schedule(prop,quick,fallback);
    break;
  case Options::Schedule::CASC:
  case Options::Schedule::CASC_2017:
    Schedules::getCasc2017Schedule(prop,quick,fallback);
    break;
  case Options::Schedule::CASC_SAT_2014:
    Schedules::getCascSat2014Schedule(prop,quick,fallback);
    break;
  case Options::Schedule::CASC_SAT_2016:
    Schedules::getCascSat2016Schedule(prop,quick,fallback);
    break;
  case Options::Schedule::CASC_SAT:
  case Options::Schedule::CASC_SAT_2017:
    Schedules::getCascSat2017Schedule(prop,quick,fallback);
    break;
  case Options::Schedule::SMTCOMP_2016:
    Schedules::getSmtcomp2016Schedule(prop,quick,fallback);
    break;
  case Options::Schedule::SMTCOMP:
  case Options::Schedule::SMTCOMP_2017:
    Schedules::getSmtcomp2017Schedule(prop,quick,fallback);
    break;

  case Options::Schedule::LTB_HH4_2015_FAST:
    Schedules::getLtb2015Hh4FastSchedule(prop,quick);
    break;
  case Options::Schedule::LTB_HH4_2015_MIDD:
    Schedules::getLtb2015Hh4MiddSchedule(prop,quick);
    break;
  case Options::Schedule::LTB_HH4_2015_SLOW:
    Schedules::getLtb2015Hh4SlowSchedule(prop,quick);
    break;
  case Options::Schedule::LTB_HH4_2017:
    Schedules::getLtb2017Hh4Schedule(prop,quick);
    break;

  case Options::Schedule::LTB_HLL_2015_FAST:
    Schedules::getLtb2015HllFastSchedule(prop,quick);
    break;
  case Options::Schedule::LTB_HLL_2015_MIDD:
    Schedules::getLtb2015HllMiddSchedule(prop,quick);
    break;
  case Options::Schedule::LTB_HLL_2015_SLOW:
    Schedules::getLtb2015HllSlowSchedule(prop,quick);
    break;
  case Options::Schedule::LTB_HLL_2017:
    Schedules::getLtb2017HllSchedule(prop,quick);
    break;

  case Options::Schedule::LTB_ISA_2015_FAST:
    Schedules::getLtb2015IsaFastSchedule(prop,quick);
    break;
  case Options::Schedule::LTB_ISA_2015_MIDD:
    Schedules::getLtb2015IsaMiddSchedule(prop,quick);
    break;
  case Options::Schedule::LTB_ISA_2015_SLOW:
    Schedules::getLtb2015IsaSlowSchedule(prop,quick);
    break;
  case Options::Schedule::LTB_ISA_2017:
    Schedules::getLtb2017IsaSchedule(prop,quick);
    break;

  case Options::Schedule::LTB_MZR_2015_FAST:
    Schedules::getLtb2015MzrFastSchedule(prop,quick);
    break;
  case Options::Schedule::LTB_MZR_2015_MIDD:
    Schedules::getLtb2015MzrMiddSchedule(prop,quick);
    break;
  case Options::Schedule::LTB_MZR_2015_SLOW:
    Schedules::getLtb2015MzrSlowSchedule(prop,quick);
    break;
  case Options::Schedule::LTB_MZR_2017:
    Schedules::getLtb2017MzrSchedule(prop,quick);
    break;
  case Options::Schedule::LTB_2014:
    Schedules::getLtb2014Schedule(prop,quick);
    break;
  case Options::Schedule::LTB_2014_MZR:
    Schedules::getLtb2014MzrSchedule(prop,quick,fallback);
    break;

  case Options::Schedule::LTB_DEFAULT_2017:
    Schedules::getLtb2017DefaultSchedule(prop,quick);
    break;
  default:
    INVALID_OPERATION("Unknown schedule");
  }
}

static unsigned milliToDeci(unsigned timeInMiliseconds) {
  return timeInMiliseconds/100;
}

bool PortfolioMode::runSchedule(Schedule& schedule, int terminationTime)
{
  CALL("PortfolioMode::runSchedule");

  
  DHMap<vstring,int> used;

  
  unsigned coreNumber = System::getNumberOfCores();
  if (coreNumber < 1) { coreNumber = 1; }

  int parallelProcesses = min(coreNumber,env.options->multicore());

  
  if (parallelProcesses == 0) {
    if (coreNumber >= 8) {
      coreNumber = coreNumber-2;
    }
    parallelProcesses = coreNumber;
  }

  UIHelper::portfolioParent = true; 

  if (outputAllowed()) {
    env.beginOutput();
    addCommentSignForSZS(env.out());
    env.out() << "Starting " << (parallelProcesses == 1 ? "sequential " : "") <<
        "portfolio solving with schedule \"" << env.options->scheduleName() << "\"";
    if (parallelProcesses > 1) {
      env.out() << " and " << parallelProcesses << " parallel processes.";
    }
    env.out() << endl;
    env.endOutput();
  }

  int processesLeft = parallelProcesses;
  Schedule::BottomFirstIterator it(schedule);

  int slices = schedule.length();
  while (it.hasNext()) {
    while (processesLeft) {
      slices--;
      ASS_G(processesLeft,0);

     

      int elapsedTime = milliToDeci(env.timer->elapsedMilliseconds());
      if (elapsedTime >= terminationTime) {
        
        goto finish_up;
      }

      vstring sliceCode = it.next();
      vstring chopped;

      
      int sliceTime = getSliceTime(sliceCode,chopped);
      int usedTime;
      if (used.find(chopped,usedTime) && usedTime >= sliceTime) {
        
        continue;
      }
      used.insert(chopped,sliceTime);

      int remainingTime = terminationTime - elapsedTime;
      if (sliceTime > remainingTime) {
        sliceTime = remainingTime;
      }
      ASS_GE(sliceTime,0);

      pid_t childId=Multiprocessing::instance()->fork();
      ASS_NEQ(childId,-1);
      if (!childId) {
        
        try {
          runSlice(sliceCode,sliceTime); 
        } catch (Exception& exc) {
          if (outputAllowed()) {
            cerr << "% Exception at run slice level" << endl;
            exc.cry(cerr);
          }
          System::terminateImmediately(1); 
        }
        ASSERTION_VIOLATION; 
      }
      Timer::syncClock();
      ASS(childIds.insert(childId));

      if (outputAllowed()) {
        env.beginOutput();
        addCommentSignForSZS(env.out()) << "spawned child "<< childId << " with time: " << sliceTime << " (total remaining time " << remainingTime << ")" << endl;
        env.endOutput();
      }

      processesLeft--;
      if (!it.hasNext()) {
        break;
      }
    }

   

    if (processesLeft==0) {
      if(waitForChildAndCheckIfProofFound()) { return true; }
      
      processesLeft++;
    }
  }

  finish_up:

  while (parallelProcesses!=processesLeft) {
    ASS_L(processesLeft, parallelProcesses);
    if(waitForChildAndCheckIfProofFound()) { return true; }
    
    processesLeft++;
    Timer::syncClock();
  }
  return false;
}

unsigned PortfolioMode::getSliceTime(vstring sliceCode,vstring& chopped)
{
  CALL("PortfolioMode::getSliceTime");

  unsigned pos = sliceCode.find_last_of('_');
  vstring sliceTimeStr = sliceCode.substr(pos+1);
  chopped.assign(sliceCode.substr(0,pos));
  unsigned sliceTime;
  ALWAYS(Int::stringToUnsignedInt(sliceTimeStr,sliceTime));
  ASS_G(sliceTime,0); 

  unsigned time = _slowness * sliceTime + 1;
  if (time < 10) {
    time++;
  }
  return time;
} 

bool PortfolioMode::waitForChildAndCheckIfProofFound()
{
  CALL("PortfolioMode::waitForChildAndCheckIfProofFound");
  ASS(!childIds.isEmpty());

  int resValue;
  pid_t finishedChild = Multiprocessing::instance()->waitForChildTermination(resValue);
#if VDEBUG
  ALWAYS(childIds.remove(finishedChild));
#endif
  if (!resValue) {
    

   
    return true;
  }
  

 
  return false;
} 


void PortfolioMode::runSlice(vstring sliceCode, unsigned timeLimitInDeciseconds)
{
  CALL("PortfolioMode::runSlice");

  Options opt = *env.options;
  opt.readFromEncodedOptions(sliceCode);
  opt.setTimeLimitInDeciseconds(timeLimitInDeciseconds);
  int stl = opt.simulatedTimeLimit();
  if (stl) {
    opt.setSimulatedTimeLimit(int(stl * _slowness));
  }
  runSlice(opt);
} 

void PortfolioMode::runSlice(Options& strategyOpt)
{
  CALL("PortfolioMode::runSlice(Option&)");

  System::registerForSIGHUPOnParentDeath();
  UIHelper::portfolioParent=false;

  int resultValue=1;
  env.timer->reset();
  env.timer->start();
  TimeCounter::reinitialize();
  Timer::setTimeLimitEnforcement(true);

  Options opt = strategyOpt;
  
  opt.setNormalize(false);
  opt.setForcedOptionValues();
  opt.checkGlobalOptionConstraints();
  *env.options = opt; 

  if (outputAllowed()) {
    env.beginOutput();
    addCommentSignForSZS(env.out()) << opt.testId() << " on " << opt.problemName() << endl;
    env.endOutput();
  }

  Saturation::ProvingHelper::runVampire(*_prb, opt);

  
  if (env.statistics->terminationReason == Statistics::REFUTATION ||
      env.statistics->terminationReason == Statistics::SATISFIABLE) {
    resultValue=0;

   
  }

  System::ignoreSIGHUP(); 

  bool outputResult = false;
  if (!resultValue) {
    _syncSemaphore.dec(SEM_LOCK); 

    if (!_syncSemaphore.get(SEM_PRINTED)) {
      _syncSemaphore.set(SEM_PRINTED,1);
      outputResult = true;
    }

    _syncSemaphore.inc(SEM_LOCK); 
  }

  if((outputAllowed() && resultValue) || outputResult) { 
    env.beginOutput();
    UIHelper::outputResult(env.out());
    env.endOutput();
  }
  else{
   
  }

  exit(resultValue);
} 






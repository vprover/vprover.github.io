
/*
 * File Global.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#if VDEBUG
#  include "Debug/Assertion.hpp"
#endif

#include "Lib/Enumerator.hpp"

#include "Kernel/Formula.hpp"
#include "Kernel/Unit.hpp"

#include "Shell/UIHelper.hpp"

#include "Lib/Array.hpp"
#include "Lib/Environment.hpp"
#include "Lib/List.hpp"
#include "Lib/System.hpp"



Lib::Enumerator Lib::Enumerator::unitEnumerator;
unsigned Kernel::Unit::_lastNumber = 0;
bool Shell::UIHelper::portfolioParent=false;
bool Shell::UIHelper::satisfiableStatusWasAlreadyOutput=false;

Lib::vstring Kernel::Formula::_connectiveNames[] =
  {"atomic", "and", "or", "imp", "iff", "xor", "not", "forall", "exists"};




Lib::ZIArray<Lib::List<VoidFunc>*> Lib::System::s_terminationHandlers(2);

Lib::Environment Lib::env;


struct __Lib_System_Init_Invoker
{
  __Lib_System_Init_Invoker()
  {
    Lib::System::onInitialization();
  }
};

__Lib_System_Init_Invoker __Lib_System_Init_Invoker_obj;


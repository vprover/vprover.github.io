
/*
 * File Substitution.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#if VDEBUG
#  include "Lib/Int.hpp"
#  include "Term.hpp"
#endif

#include "Substitution.hpp"

namespace Kernel
{

void Substitution::bind(int v,Term* t)
{
  CALL("Substitution::bind(int,Term*)");
  TermList ts;
  ts.setTerm(t);
  bind(v,ts);
}
void Substitution::rebind(int v,Term* t)
{
  TermList ts;
  ts.setTerm(t);
  rebind(v,ts);
}

void Substitution::bind(int v,TermList t)
{
  CALL("Substitution::bind(int,TermList)");

  ALWAYS(_map.insert(v, t));
} 

void Substitution::rebind(int v,TermList t)
{
  _map.set(v,t);
}

void Substitution::unbind(int v)
{
  CALL("Substitution::unbind");

  ALWAYS(_map.remove(v));
} 

void Substitution::reset()
{
  CALL("Substitution::reset");

  _map.reset();
}

TermList Substitution::apply(unsigned var)
{
  TermList res;
  if(!findBinding(var, res)) {
    res = TermList(var,false);
  }
  return res;
}

bool Substitution::findBinding(int var, TermList& res) const
{
  CALL("Substitution::findBinding");

  return _map.find(var, res);
} 


#if VDEBUG
 vstring Substitution::toString() const
 {
   vstring result("[");
   VirtualIterator<std::pair<unsigned,TermList>> items = _map.items();
   bool first=true;
   while(items.hasNext()){
     std::pair<unsigned,TermList> item = items.next();
     if(!first){result+=",";}
     first=false;
     result += Lib::Int::toString(item.first) + " -> " + item.second.toString(); 
   }
   result += ']';
   return result;
 } 
#endif

}


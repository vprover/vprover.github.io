
/*
 * File FormulaTransformer.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __FormulaTransformer__
#define __FormulaTransformer__

#include "Forwards.hpp"

#include "Inference.hpp"
#include "Sorts.hpp"

namespace Kernel {

class FormulaTransformer {
public:
 
  virtual Formula* transform(Formula* f);

protected:
  FormulaTransformer() {}
  virtual ~FormulaTransformer() {}

  Formula* apply(Formula* f);
  TermList apply(TermList ts);

 
  virtual bool preApply(Formula*& f) { return true; }
  virtual void postApply(Formula* orig, Formula*& res) {}

  virtual Formula* applyLiteral(Formula* f) { return f; }

  virtual Formula* applyAnd(Formula* f) { return applyJunction(f); }
  virtual Formula* applyOr(Formula* f) { return applyJunction(f); }

 
  virtual Formula* applyJunction(Formula* f);

  virtual Formula* applyNot(Formula* f);

  virtual Formula* applyImp(Formula* f) { return applyBinary(f); }
  virtual Formula* applyIff(Formula* f) { return applyBinary(f); }
  virtual Formula* applyXor(Formula* f) { return applyBinary(f); }

 
  virtual Formula* applyBinary(Formula* f);

  virtual Formula* applyForAll(Formula* f) { return applyQuantified(f); }
  virtual Formula* applyExists(Formula* f) { return applyQuantified(f); }

 
  virtual Formula* applyQuantified(Formula* f);


  virtual Formula* applyTrueFalse(Formula* f) { return f; }
};

class TermTransformingFormulaTransformer : public FormulaTransformer
{
public:
  TermTransformingFormulaTransformer(TermTransformer& termTransformer) : _termTransformer(termTransformer) {}
protected:
  virtual Formula* applyLiteral(Formula* f);

  TermTransformer& _termTransformer;
};

class TermTransformerTransformTransformedFormulaTransformer : public FormulaTransformer
{
  public:
    TermTransformerTransformTransformedFormulaTransformer(TermTransformerTransformTransformed& termTransformer)
      : _termTransformer(termTransformer) {}
  protected:
    virtual Formula* applyLiteral(Formula* f);

    TermTransformerTransformTransformed& _termTransformer;
};

class PolarityAwareFormulaTransformer : protected FormulaTransformer {
public:
  ~PolarityAwareFormulaTransformer();

  virtual Formula* transformWithPolarity(Formula* f, int polarity=1);
protected:
  PolarityAwareFormulaTransformer();

  virtual Formula* applyNot(Formula* f);

  virtual Formula* applyImp(Formula* f);

  virtual Formula* applyBinary(Formula* f);

  int polarity() const { return _polarity; }

  unsigned getVarSort(unsigned var) const;

private:
  DHMap<unsigned,unsigned>* _varSorts;
  int _polarity;
};

class FormulaUnitTransformer
{
public:
  virtual ~FormulaUnitTransformer() {}

  virtual FormulaUnit* transform(FormulaUnit* unit) = 0;

  void transform(UnitList*& units);
};


class LocalFormulaUnitTransformer : public FormulaUnitTransformer
{
public:
  LocalFormulaUnitTransformer(Inference::Rule rule)
  : _rule(rule) {}

  using FormulaUnitTransformer::transform;

  virtual Formula* transform(Formula* f) = 0;

  virtual FormulaUnit* transform(FormulaUnit* unit);

private:
  Inference::Rule _rule;
};

template<class FT>
class FTFormulaUnitTransformer : public LocalFormulaUnitTransformer
{
public:
  FTFormulaUnitTransformer(Inference::Rule rule, FT& formulaTransformer)
  : LocalFormulaUnitTransformer(rule), _formulaTransformer(formulaTransformer) {}

  using LocalFormulaUnitTransformer::transform;

  virtual Formula* transform(Formula* f)
  {
    CALL("FTFormulaUnitTransformer::transform(Formula*)");
    return _formulaTransformer.transform(f);
  }

private:
  FT& _formulaTransformer;
};


class ScanAndApplyFormulaUnitTransformer {
public:
  virtual ~ScanAndApplyFormulaUnitTransformer() {}

  void apply(Problem& prb);
  bool apply(UnitList*& units);

  virtual void scan(UnitList* units) {}
  bool apply(Unit* u, Unit*& res);
  virtual UnitList* getIntroducedFormulas() { return 0; }

protected:
  virtual bool apply(FormulaUnit* unit, Unit*& res) {
    return false;
  }
  virtual bool apply(Clause* cl, Unit*& res) {
    return false;
  }

  virtual void updateModifiedProblem(Problem& prb);
};

class ScanAndApplyLiteralTransformer : public ScanAndApplyFormulaUnitTransformer {
public:
  using ScanAndApplyFormulaUnitTransformer::apply;
protected:

 
  ScanAndApplyLiteralTransformer(Inference::Rule infRule) : _infRule(infRule) {}

 
  virtual Literal* apply(Literal* l, UnitStack& premAcc) = 0;

  virtual bool apply(FormulaUnit* unit, Unit*& res);
  virtual bool apply(Clause* cl, Unit*& res);

private:
  struct LitFormulaTransformer;

  Inference::Rule _infRule;
};


}

#endif 


/*
 * File SubstHelper.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __SubstHelper__
#define __SubstHelper__

#include "Lib/DArray.hpp"
#include "Lib/Recycler.hpp"

#include "Formula.hpp"
#include "SortHelper.hpp"
#include "Term.hpp"

namespace Kernel {

using namespace Lib;

class SubstHelper
{
public:
 
  template<class Applicator>
  static TermList apply(TermList t, Applicator& applicator, bool noSharing=false)
  {
    CALL("SubstHelper::apply(TermList...)");
    return applyImpl<false,Applicator>(t, applicator, noSharing);
  }

 
  template<class Applicator>
  static Term* apply(Term* t, Applicator& applicator, bool noSharing=false)
  {
    CALL("SubstHelper::apply(Term*...)");
    return applyImpl<false,Applicator>(t, applicator, noSharing);
  }

 
  template<class Applicator>
  static Literal* apply(Literal* lit, Applicator& applicator)
  {
    CALL("SubstHelper::apply(Literal*...)");
    return static_cast<Literal*>(apply(static_cast<Term*>(lit),applicator));
  }

 
  template<class Applicator>
  static Formula* apply(Formula* f, Applicator& applicator)
  {
    CALL("SubstHelper::apply(Formula*...)");
    return applyImpl<false>(f, applicator, false);
  }


 
  template<class Applicator>
  static TermList applySV(TermList t, Applicator& applicator, bool noSharing=false)
  {
    return applyImpl<true,Applicator>(t, applicator, noSharing);
  }
  template<class Applicator>
  static Term* applySV(Term* t, Applicator& applicator, bool noSharing=false)
  {
    return applyImpl<true,Applicator>(t, applicator, noSharing);
  }
  template<class Applicator>
  static Literal* applySV(Literal* lit, Applicator& applicator)
  {
    return static_cast<Literal*>(applySV(static_cast<Term*>(lit),applicator));
  }


 
  template<class Subst>
  static Literal* applyToLiteral(Literal* lit, Subst subst)
  {
    CALL("SubstHelper::applyToLiteral");
    static DArray<TermList> ts(32);

    int arity = lit->arity();
    ts.ensure(arity);
    int i = 0;
    for (TermList* args = lit->args(); ! args->isEmpty(); args = args->next()) {
      ts[i++]=subst.apply(*args);
    }
    return Literal::create(lit,ts.array());
  }

  template<class Map>
  class MapApplicator
  {
  public:
    MapApplicator(Map* map) : _map(map) {}
    TermList apply(unsigned var) {
      TermList res;
      if(!_map->find(var, res)) {
	res = TermList(var, false);
      }
      return res;
    }
  private:
    Map* _map;
  };

  template<class Map>
  static MapApplicator<Map> getMapApplicator(Map* m)
  {
    return MapApplicator<Map>(m);
  }

private:
  template<bool ProcessSpecVars, class Applicator>
  static Term* applyImpl(Term* t, Applicator& applicator, bool noSharing=false);
  template<bool ProcessSpecVars, class Applicator>
  static TermList applyImpl(TermList t, Applicator& applicator, bool noSharing=false);
  template<bool ProcessSpecVars, class Applicator>
  static Formula* applyImpl(Formula* f, Applicator& applicator, bool noSharing);
  template<bool ProcessSpecVars, class Applicator>
  static FormulaList* applyImpl(FormulaList* f, Applicator& applicator, bool noSharing);

 
  static bool canBeShared(TermList * terms, size_t len)
  {
    CALL("SubstHelper::anyNonShareable");

    for(unsigned i=0;i<len;i++) {
      TermList trm=terms[i];
      if(trm.isSpecialVar()||(trm.isTerm()&&!trm.term()->shared())) {
	return false;
      }
    }
    return true;
  }

};

namespace SubstHelper_Aux
{
template<bool ProcessSpecVars>
struct SpecVarHandler
{
};
template<>
struct SpecVarHandler<true>
{
  template<class Applicator>
  static TermList apply(Applicator& a, unsigned specVar) { return a.applyToSpecVar(specVar); }
};
template<>
struct SpecVarHandler<false>
{
  template<class Applicator>
  static TermList apply(Applicator& a, unsigned specVar) { return TermList(specVar, true); }
};
}

template<bool ProcessSpecVars, class Applicator>
TermList SubstHelper::applyImpl(TermList trm, Applicator& applicator, bool noSharing)
{
  CALL("SubstHelper::applyImpl(TermList...)");

  using namespace SubstHelper_Aux;

  if(trm.isOrdinaryVar()) {
    return applicator.apply(trm.var());
  }
  else if(trm.isSpecialVar()) {
    return SpecVarHandler<ProcessSpecVars>::apply(applicator, trm.var());
  }
  else {
    ASS(trm.isTerm());
    return TermList(applyImpl<ProcessSpecVars>(trm.term(), applicator, noSharing));
  }
}


template<bool ProcessSpecVars, class Applicator>
Term* SubstHelper::applyImpl(Term* trm, Applicator& applicator, bool noSharing)
{
  CALL("SubstHelper::applyImpl(Term*...)");

  using namespace SubstHelper_Aux;

  if(trm->isSpecial()) {
    Term::SpecialTermData* sd = trm->getSpecialData();
    switch(trm->functor()) {
    case Term::SF_ITE:
      return Term::createITE(
	  applyImpl<ProcessSpecVars>(sd->getCondition(), applicator, noSharing),
	  applyImpl<ProcessSpecVars>(*trm->nthArgument(0), applicator, noSharing),
	  applyImpl<ProcessSpecVars>(*trm->nthArgument(1), applicator, noSharing),
          sd->getSort()
	  );
    case Term::SF_LET:
      return Term::createLet(
	  sd->getFunctor(),
	  sd->getVariables(),
	  applyImpl<ProcessSpecVars>(sd->getBinding(), applicator, noSharing),
	  applyImpl<ProcessSpecVars>(*trm->nthArgument(0), applicator, noSharing),
	  sd->getSort()
	  );
    case Term::SF_FORMULA:
      return Term::createFormula(
      applyImpl<ProcessSpecVars>(sd->getFormula(), applicator, noSharing)
      );
    case Term::SF_LET_TUPLE:
      return Term::createTupleLet(
        sd->getFunctor(),
        sd->getTupleSymbols(),
        applyImpl<ProcessSpecVars>(sd->getBinding(), applicator, noSharing),
        applyImpl<ProcessSpecVars>(*trm->nthArgument(0), applicator, noSharing),
        sd->getSort()
        );
    case Term::SF_TUPLE:
      return Term::createTuple(applyImpl<ProcessSpecVars>(sd->getTupleTerm(), applicator, noSharing));
    }
    ASSERTION_VIOLATION;
  }

  Stack<TermList*>* toDo;
  Stack<Term*>* terms;
  Stack<bool>* modified;
  Stack<TermList>* args;

  Recycler::get(toDo);
  Recycler::get(terms);
  Recycler::get(modified);
  Recycler::get(args);

  toDo->reset();
  terms->reset();
  modified->reset();
  args->reset();

  modified->push(false);
  toDo->push(trm->args());

  for(;;) {
    TermList* tt=toDo->pop();
    if(tt->isEmpty()) {
      if(terms->isEmpty()) {
	
	
	ASS(toDo->isEmpty());
	break;
      }
      Term* orig=terms->pop();
      if(!modified->pop()) {
	args->truncate(args->length() - orig->arity());
	args->push(TermList(orig));
	continue;
      }
      
      
      
      TermList* argLst=&args->top() - (orig->arity()-1);

      bool shouldShare=!noSharing && canBeShared(argLst, orig->arity());

      Term* newTrm;
      if(shouldShare) {
	newTrm=Term::create(orig,argLst);
      }
      else {
	newTrm=Term::createNonShared(orig,argLst);
      }
      args->truncate(args->length() - orig->arity());
      args->push(TermList(newTrm));

      modified->setTop(true);
      continue;
    }
    toDo->push(tt->next());

    TermList tl=*tt;
    if(tl.isOrdinaryVar()) {
      TermList tDest=applicator.apply(tl.var());
      args->push(tDest);
      if(tDest!=tl) {
	modified->setTop(true);
      }
      continue;
    }
    if(tl.isSpecialVar()) {
      TermList tDest=SpecVarHandler<ProcessSpecVars>::apply(applicator,tl.var());
      args->push(tDest);
      if(tDest!=tl) {
	modified->setTop(true);
      }
      continue;
    }
    ASS(tl.isTerm());
    Term* t=tl.term();
    if(t->shared() && t->ground()) {
      args->push(tl);
      continue;
    }
    if(t->isSpecial()) {
      
      args->push(TermList(applyImpl<ProcessSpecVars>(t, applicator, noSharing)));
      continue;
    }
    terms->push(t);
    modified->push(false);
    toDo->push(t->args());
  }
  ASS(toDo->isEmpty());
  ASS(terms->isEmpty());
  ASS_EQ(modified->length(),1);
  ASS_EQ(args->length(),trm->arity());

  Term* result;
  if(!modified->pop()) {
    result=trm;
  }
  else {
    
    
    
    TermList* argLst=&args->top() - (trm->arity()-1);
    ASS_EQ(args->size(), trm->arity());
    if(trm->isLiteral()) {
      ASS(!noSharing);
      Literal* lit = static_cast<Literal*>(trm);
      result=Literal::create(lit,argLst);
    }
    else {
      bool shouldShare=!noSharing && canBeShared(argLst, trm->arity());
      if(shouldShare) {
	result=Term::create(trm,argLst);
      } else {
	result=Term::createNonShared(trm,argLst);
      }
    }
  }

  Recycler::release(args);
  Recycler::release(modified);
  Recycler::release(terms);
  Recycler::release(toDo);

  return result;
}

template<bool ProcessSpecVars, class Applicator>
Formula* SubstHelper::applyImpl(Formula* f, Applicator& applicator, bool noSharing)
{
  CALL("SubstHelper::applyImpl(Formula*...)");

  switch (f->connective()) {
  case LITERAL:
  {
    Literal* lit = static_cast<Literal*>(applyImpl<ProcessSpecVars>(f->literal(), applicator, noSharing));
    return lit == f->literal() ? f : new AtomicFormula(lit);
  }

  case AND:
  case OR:
  {
    FormulaList* newArgs = applyImpl<ProcessSpecVars>(f->args(), applicator, noSharing);
    if (newArgs == f->args()) {
      return f;
    }
    return new JunctionFormula(f->connective(), newArgs);
  }

  case IMP:
  case IFF:
  case XOR:
  {
    Formula* l = applyImpl<ProcessSpecVars>(f->left(), applicator, noSharing);
    Formula* r = applyImpl<ProcessSpecVars>(f->right(), applicator, noSharing);
    if (l == f->left() && r == f->right()) {
      return f;
    }
    return new BinaryFormula(f->connective(), l, r);
  }

  case NOT:
  {
    Formula* arg = applyImpl<ProcessSpecVars>(f->uarg(), applicator, noSharing);
    if (f->uarg() == arg) {
      return f;
    }
    return new NegatedFormula(arg);
  }

  case FORALL:
  case EXISTS:
  {
    bool varsModified = false;
    Formula::VarList* newVars = 0;
    Formula::VarList::Iterator vit(f->vars());
    while(vit.hasNext()) {
      unsigned v = vit.next();
      TermList binding = applicator.apply(v);
      ASS(binding.isVar());
      unsigned newVar = binding.var();
      Formula::VarList::push(newVar, newVars);
      if(newVar!=v) {
	varsModified = true;
      }
    }

    Formula* arg = applyImpl<ProcessSpecVars>(f->qarg(), applicator, noSharing);
    if (!varsModified && arg == f->qarg()) {
      Formula::VarList::destroy(newVars);
      return f;
    }
    
    return new QuantifiedFormula(f->connective(),newVars,0,arg);
  }

  case BOOL_TERM:
    return BoolTermFormula::create(applyImpl<ProcessSpecVars>(f->getBooleanTerm(), applicator, noSharing));

  case TRUE:
  case FALSE:
    return f;
  default:
    ASSERTION_VIOLATION;
  }
}

template<bool ProcessSpecVars, class Applicator>
FormulaList* SubstHelper::applyImpl(FormulaList* fs, Applicator& applicator, bool noSharing)
{
  CALL("SubstHelper::applyImpl(FormulaList*...)");

  if (FormulaList::isEmpty(fs)) {
    return fs;
  }

  Stack<FormulaList*> args;
  while (FormulaList::isNonEmpty(fs)) {
    args.push(fs);
    fs = fs->tail();
  }

  FormulaList* res = args.top()->tail();
  ASS(FormulaList::isEmpty(res));

  while (args.isNonEmpty()) {
    fs = args.pop();
    Formula* g = fs->head();
    FormulaList* gs = fs->tail();
    Formula* h = applyImpl<ProcessSpecVars>(g, applicator, noSharing);
    FormulaList* hs = res; 

    if (gs == hs && g == h) {
      res = fs;
    } else {
      res = new FormulaList(h,hs);
    }
  }

  return res;
} 

};

#endif

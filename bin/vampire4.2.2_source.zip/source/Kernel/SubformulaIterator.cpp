
/*
 * File SubformulaIterator.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Debug/Tracer.hpp"

#include "SubformulaIterator.hpp"

namespace Kernel {

class SubformulaIterator::Element {
public:
  Element (FormulaList* list, int polarity, Element* rest)
    : _tag(FORMULA_LIST),
      _formulaList(list),
      _polarity(polarity),
      _rest(rest)
  {}
  Element (Formula* f, int polarity, Element* rest)
    : _tag(FORMULA),
      _formula(f),
      _polarity(polarity),
      _rest(rest)
  {}
  Element (TermList* ts, int polarity, Element* rest)
    : _tag(TERM_LIST),
      _termList(ts),
      _polarity(polarity),
      _rest(rest)
  {}
  Element (Term* t, int polarity, Element* rest)
    : _tag(TERM),
      _term(t),
      _polarity(polarity),
      _rest(rest)
  {}
  enum Tag {
    FORMULA_LIST,
    FORMULA,
    TERM_LIST,
    TERM
  };
  Tag _tag;
  union{
    FormulaList* _formulaList;
    Formula* _formula;
    TermList* _termList;
    Term* _term;
  };
  int _polarity;
  Element* _rest;

  CLASS_NAME(SubformulaIterator::Element);
  USE_ALLOCATOR(SubformulaIterator::Element);
};


SubformulaIterator::SubformulaIterator (Formula* f)
  : _current(f),
    _currentPolarity(1),
    _reserve(0)
{
} 


SubformulaIterator::SubformulaIterator (FormulaList* ts)
  : _current(0),
    _reserve(new Element(ts,1,0))
{
} 


bool SubformulaIterator::hasNext ()
{
  CALL("SubformulaIterator::hasNext");

  if (_current) {
    return true;
  }

  
  while (_reserve) {
    switch (_reserve->_tag) {
      case Element::Tag::FORMULA_LIST: {
        FormulaList *first = _reserve->_formulaList;
        if (FormulaList::isEmpty(first)) {
          Element *rest = _reserve->_rest;
          delete _reserve;
          _reserve = rest;
          break;
        } else { 
          _current = first->head();
          _currentPolarity = _reserve->_polarity;
          _reserve->_formulaList = first->tail();
          return true;
        }
      }

      case Element::Tag::FORMULA: {
        _current = _reserve->_formula;
        _currentPolarity = _reserve->_polarity;
        Element *rest = _reserve->_rest;
        delete _reserve;
        _reserve = rest;
        return true;
      }

      case Element::Tag::TERM_LIST: {
        TermList* first = _reserve->_termList;
        if (!first->isTerm()) {
          Element *rest = _reserve->_rest;
          delete _reserve;
          _reserve = rest;
        } else { 
          _reserve->_termList = first->next();
          _reserve = new Element(first->term(), _reserve->_polarity, _reserve);
        }
        break;
      }

      case Element::Tag::TERM: {
        Term* term = _reserve->_term;
        int polarity = _reserve->_polarity;
        Element* rest = new Element(term->args(), polarity, _reserve->_rest);
        if (!term->isSpecial()) {
          delete _reserve;
          _reserve = rest;
          break;
        }

        switch (term->functor()) {
          case Term::SF_ITE: {
            _current = term->getSpecialData()->getCondition();
            _currentPolarity = polarity;
            delete _reserve;
            _reserve = rest;
            return true;
          }
          case Term::SF_LET: {
            delete _reserve;
            TermList binding = term->getSpecialData()->getBinding();
            if (!binding.isTerm()) {
              _reserve = rest;
            } else {
              
              _reserve = new Element(binding.term(), polarity, rest);
            }
            break;
          }
          case Term::SF_LET_TUPLE: {
            delete _reserve;
            TermList binding = term->getSpecialData()->getBinding();
            if (!binding.isTerm()) {
              _reserve = rest;
            } else {
              
              _reserve = new Element(binding.term(), polarity, rest);
            }
            break;
          }
          case Term::SF_FORMULA: {
            _current = term->getSpecialData()->getFormula();
            _currentPolarity = polarity;
            delete _reserve;
            _reserve = rest;
            return true;
          }
          case Term::SF_TUPLE: {
            delete _reserve;
            Term* tupleTerm = term->getSpecialData()->getTupleTerm();
            
            _reserve = new Element(tupleTerm, polarity, rest);
            break;
          }
#if VDEBUG
          default:
            ASSERTION_VIOLATION;
#endif
        }
        break;
      }

#if VDEBUG
      default:
        ASSERTION_VIOLATION;
#endif
    }
  }
  
  return false;
} 


Formula* SubformulaIterator::next ()
{
  CALL("SubformulaIterator::next/0");

  int dummy;
  return next(dummy);
}

Formula* SubformulaIterator::next (int& resultPolarity)
{
  CALL("SubformulaIterator::next/1");

  Formula* result = _current;
  resultPolarity = _currentPolarity;

  switch (result->connective()) {
  case LITERAL:
    _reserve = new Element(result->literal()->args(), resultPolarity, _reserve);
    _current = 0;
    break;

  case TRUE:
  case FALSE:
  case NAME:
    _current = 0;
    break;

  case AND:
  case OR:
    _reserve = new Element(result->args(), resultPolarity, _reserve);
    _current = 0;
    break;

  case IMP:
    _current = result->left();
    _currentPolarity = -resultPolarity;
    _reserve = new Element(result->right(), resultPolarity, _reserve);
    break;

  case IFF:
  case XOR:
    _current = result->left();
    _currentPolarity = 0;
    _reserve = new Element(result->right(), 0, _reserve);
    break;

  case NOT:
    _current = result->uarg();
    _currentPolarity = -resultPolarity;
    break;

  case FORALL:
  case EXISTS:
    _current = result->qarg();
    _currentPolarity = resultPolarity;
    break;

  case BOOL_TERM: {
    _current = 0;
    TermList ts = result->getBooleanTerm();
    if (!ts.isVar()) {
      
      _reserve = new Element(ts.term(), resultPolarity, _reserve);
    }
    break;
  }

#if VDEBUG
  default:
    ASSERTION_VIOLATION;
#endif
  }

  return result;
} 


SubformulaIterator::~SubformulaIterator ()
{
  while (_reserve) {
    Element* next = _reserve->_rest;
    delete _reserve;
    _reserve = next;
  }
} 

}

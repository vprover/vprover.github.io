
/*
 * File Assignment.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */

#if GNUMP
#include "Lib/Metaiterators.hpp"

#include "Assignment.hpp"

namespace Kernel
{

VarIterator Assignment::getAssignedVars() const
{
  CALL("Assignment::getAssignedVars");

  return pvi( getStaticCastIterator<Var>(AssignmentMap::KeyIterator(_data)) );
}

BoundNumber Assignment::evalCoeffs(Constraint::CoeffIterator coeffs) 
{
  CALL("Assignment::evalCoeffs");

  BoundNumber res = BoundNumber::zero();
  while(coeffs.hasNext()) {
    Constraint::Coeff coeff = coeffs.next();
    ASS(isAssigned(coeff.var));
    res+=BoundNumber(coeff.value) * (*this)[coeff.var];
  }
  return res;
}

bool Assignment::isSatisfied(const Constraint* c)
{
  CALL("Assignment::isSatisfied(const Constraint*)");

  BoundNumber lhs = evalCoeffs(c->coeffs());
  BoundNumber rhs(c->freeCoeff());

  switch(c->type()) {
  case CT_EQ:
    return lhs==rhs;
  case CT_GR:
    return lhs>rhs;
  case CT_GREQ:
    return lhs>=rhs;
  default:
    ASSERTION_VIOLATION;
    return false;
  }
}

bool Assignment::isSatisfied(Kernel::ConstraintList* constraints)
{
  CALL("Assignment::isSatisfied(ConstraintList*)");

  ConstraintList::Iterator cit(constraints);
  while(cit.hasNext()) {
    if(!isSatisfied(cit.next())) {
      return false;
    }
  }
  return true;
}


#if VDEBUG
void Assignment::assertSatisfied(const Constraint* c)
{
  CALL("Assignment::assertSatisfied(const Constraint*)");

  BoundNumber lhs = evalCoeffs(c->coeffs());
  BoundNumber rhs(c->freeCoeff());

  switch(c->type()) {
  case CT_EQ:
    ASS_REP2(lhs==rhs, c->toString(), lhs);
    break;
  case CT_GR:
    ASS_REP2(lhs>rhs, c->toString(), lhs);
    break;
  case CT_GREQ:
    ASS_REP2(lhs>=rhs, c->toString(), lhs);
    break;
  }
}

void Assignment::assertSatisfied(ConstraintList* constraints)
{
  CALL("Assignment::assertSatisfied(ConstraintList*)");

  ConstraintList::Iterator cit(constraints);
  while(cit.hasNext()) {
    assertSatisfied(cit.next());
  }
}
#endif

}
#endif 

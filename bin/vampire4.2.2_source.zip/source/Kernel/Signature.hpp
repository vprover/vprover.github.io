
/*
 * File Signature.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Signature__
#define __Signature__

#include "Forwards.hpp"

#include "Debug/Assertion.hpp"

#include "Lib/Allocator.hpp"
#include "Lib/Stack.hpp"
#include "Lib/Map.hpp"
#include "Lib/DHMap.hpp"
#include "Lib/VString.hpp"
#include "Lib/Environment.hpp"

#include "Shell/TermAlgebra.hpp"
#include "Shell/Options.hpp"

#include "Sorts.hpp"
#include "Theory.hpp"


namespace Kernel {

using namespace std;
using namespace Lib;

class Signature
{
 public:
 
  class Symbol {
  protected:
   
    vstring _name;
   
    unsigned _arity;
   
    unsigned _interpreted : 1;
   
    unsigned _introduced : 1;
   
    unsigned _protected : 1;
   
    unsigned _skip : 1;
   
    unsigned _label : 1;
   
    unsigned _equalityProxy : 1;
   
    unsigned _color : 2;
   
    unsigned _stringConstant : 1;
   
    unsigned _numericConstant : 1;
   
    unsigned _answerPredicate : 1;
   
    unsigned _overflownConstant : 1;
   
    unsigned _termAlgebraCons : 1;
   
    mutable BaseType* _type;
   
    List<unsigned>* _distinctGroups;
   
    unsigned _usageCount;
   
    unsigned _inGoal : 1;
   
    unsigned _inUnit : 1;

    ~Symbol();
  public:
   
    Symbol(const vstring& nm,unsigned arity, bool interpreted=false, bool stringConstant=false,bool numericConstant=false,bool overflownConstant=false);
    void destroyFnSymbol();
    void destroyPredSymbol();

    void addColor(Color color);
   
    void markIntroduced() { _introduced=1; }
   
    void unmarkIntroduced(){ _introduced=0; }
   
    void markProtected() { _protected=1; }
   
    void markSkip() { _skip=1; }
   
    void markLabel() { ASS_EQ(arity(), 0); _label=1; markProtected(); }
   
    void markAnswerPredicate() { _answerPredicate=1; markProtected(); }
   
    void markEqualityProxy() { _equalityProxy=1; }
   
    void markOverflownConstant() { _overflownConstant=1; }
   
    void markTermAlgebraCons() { _termAlgebraCons=1; }

   
    bool skip() const { return _skip; }
   
    bool label() const { return _label; }
   
    Color color() const { return static_cast<Color>(_color); }
   
    inline unsigned arity() const { return _arity; }
   
    inline const vstring& name() const { return _name; }
   
    inline bool interpreted() const { return _interpreted; }
   
    inline bool introduced() const { return _introduced; }
   
    inline bool protectedSymbol() const { return _protected; }
   
    inline bool stringConstant() const { return _stringConstant; }
   
    inline bool numericConstant() const { return _numericConstant; }
   
    inline bool answerPredicate() const { return _answerPredicate; }
   
    inline bool equalityProxy() const { return _equalityProxy; }
   
    inline bool overflownConstant() const { return _overflownConstant; }
   
    inline bool termAlgebraCons() const { return _termAlgebraCons; }

   
    inline void incUsageCnt(){ _usageCount++; }
   
    inline unsigned usageCnt() const { return _usageCount; }
   
    inline void resetUsageCnt(){ _usageCount=0; }

    inline void markInGoal(){ _inGoal=1; }
    inline bool inGoal(){ return _inGoal; }
    inline void markInUnit(){ _inUnit=1; }
    inline bool inUnit(){ return _inUnit; }
      
   
    inline bool integerConstant() const
    { return interpreted() && arity()==0 && fnType()->result()==Sorts::SRT_INTEGER; }
   
    inline bool rationalConstant() const
    { return interpreted() && arity()==0 && fnType()->result()==Sorts::SRT_RATIONAL; }
   
    inline bool realConstant() const
    { return interpreted() && arity()==0 && fnType()->result()==Sorts::SRT_REAL; }
          
   
    inline bool interpretedNumber() const
    { return integerConstant() || rationalConstant() || realConstant(); }
    
   
    inline IntegerConstantType integerValue() const
    { ASS(integerConstant()); return static_cast<const IntegerSymbol*>(this)->_intValue; }
   
    inline RationalConstantType rationalValue() const
    { ASS(rationalConstant()); return static_cast<const RationalSymbol*>(this)->_ratValue; }
   
    inline RealConstantType realValue() const
    { ASS(realConstant()); return static_cast<const RealSymbol*>(this)->_realValue; }

    const List<unsigned>* distinctGroups() const { return _distinctGroups; }
   
    void addToDistinctGroup(unsigned group,unsigned this_number);

    void setType(BaseType* type);
    void forceType(BaseType* type);
    FunctionType* fnType() const;
    PredicateType* predType() const;

    CLASS_NAME(Signature::Symbol);
    USE_ALLOCATOR(Symbol);
  }; 

  
  class VarSymbol{
  protected:
   
    vstring _name;
  public: 
   
    VarSymbol(const vstring& nm);
    
   
    inline const vstring& name() const {return _name;}
    
    CLASS_NAME("Signature::VarSymbol");
    USE_ALLOCATOR(VarSymbol);
  };
  
  
  class InterpretedSymbol
  : public Symbol
  {
    friend class Signature;
    friend class Symbol;
  protected:
    Interpretation _interp;
    bool _containsInterp;

  public:

    InterpretedSymbol(const vstring& nm, Interpretation interp)
    : Symbol(nm, Theory::getArity(interp), true), _interp(interp), _containsInterp(true)
    {
      CALL("InterpretedSymbol");
    }

    InterpretedSymbol(const vstring& nm)
    : Symbol(nm, 0, true), _containsInterp(false)
    {
      CALL("InterpretedSymbol");
    }
    CLASS_NAME(Signature::InterpretedSymbol);
    USE_ALLOCATOR(InterpretedSymbol);

   
    inline Interpretation getInterpretation() const { ASS_REP(interpreted(), _name); ASS_REP(_containsInterp, _name); return _interp; }
  };

  class IntegerSymbol
  : public Symbol
  {
    friend class Signature;
    friend class Symbol;
  protected:
    IntegerConstantType _intValue;

  public:
    IntegerSymbol(const IntegerConstantType& val)
    : Symbol(val.toString(), 0, true), _intValue(val)
    {
      CALL("IntegerSymbol");

      setType(new FunctionType(Sorts::SRT_INTEGER));
    }
    CLASS_NAME(Signature::IntegerSymbol);
    USE_ALLOCATOR(IntegerSymbol);
  };

  class RationalSymbol
  : public Symbol
  {
    friend class Signature;
    friend class Symbol;
  protected:
    RationalConstantType _ratValue;

  public:
    RationalSymbol(const RationalConstantType& val)
    : Symbol(val.toString(), 0, true), _ratValue(val)
    {
      CALL("RationalSymbol");

      setType(new FunctionType(Sorts::SRT_RATIONAL));
    }
    CLASS_NAME(Signature::RationalSymbol);
    USE_ALLOCATOR(RationalSymbol);
  };

  class RealSymbol
  : public Symbol
  {
    friend class Signature;
    friend class Symbol;
  protected:
    RealConstantType _realValue;

  public:
    RealSymbol(const RealConstantType& val)
    : Symbol((env.options->proof() == Shell::Options::Proof::PROOFCHECK) ? "$to_real("+val.toString()+")" : val.toNiceString(), 0, true), _realValue(val)
    {
      CALL("RealSymbol");

      setType(new FunctionType(Sorts::SRT_REAL));
    }
    CLASS_NAME(Signature::RealSymbol);
    USE_ALLOCATOR(RealSymbol);
  };
    
  
  
  
  
 
  unsigned addVar(const vstring& name){
    CALL("Signature::addVar");
    bool added;
    return addVar(name, added);
  }
  
  const vstring& varName(Var number){
    return _vars[number]->name();
  }
  
 
  size_t vars() const {return _vars.length(); }
  
  
 
  inline VarSymbol* getVar(unsigned n){
    CALL("Signature::getVar");
    ASS(n<vars());
    return _vars[n];
  }
  
  unsigned addVar(const vstring& name, bool& added);
  
  
  

  unsigned addPredicate(const vstring& name,unsigned arity,bool& added);
  unsigned addFunction(const vstring& name,unsigned arity,bool& added,bool overflowConstant = false);

 
  unsigned addPredicate(const vstring& name,unsigned arity)
  {
    bool added;
    return addPredicate(name,arity,added);
  }
 
  unsigned addFunction(const vstring& name,unsigned arity)
  {
    bool added;
    return addFunction(name,arity,added);
  }
 
  unsigned addStringConstant(const vstring& name);
  unsigned addFreshFunction(unsigned arity, const char* prefix, const char* suffix = 0);
  unsigned addSkolemFunction(unsigned arity,const char* suffix = 0);
  unsigned addFreshPredicate(unsigned arity, const char* prefix, const char* suffix = 0);
  unsigned addSkolemPredicate(unsigned arity,const char* suffix = 0);
  unsigned addNamePredicate(unsigned arity);

  

  unsigned addInterpretedFunction(Interpretation itp, const vstring& name);
  unsigned addInterpretedPredicate(Interpretation itp, const vstring& name);

  unsigned addIntegerConstant(const vstring& number,bool defaultSort);
  unsigned addRationalConstant(const vstring& numerator, const vstring& denominator,bool defaultSort);
  unsigned addRealConstant(const vstring& number,bool defaultSort);

  unsigned addIntegerConstant(const IntegerConstantType& number);
  unsigned addRationalConstant(const RationalConstantType& number);
  unsigned addRealConstant(const RealConstantType& number);

  vstring getInterpretationName(Interpretation interp);
  unsigned getInterpretingSymbol(Interpretation interp);

  unsigned getStructureInterpretationFunctor(unsigned theorySort, Theory::StructuredSortInterpretation ssi);

 
  bool haveInterpretingSymbol(Interpretation interp) const { return _iSymbols.find(interp); }

 
  bool anyInterpretedSymbols() const
  {
    CALL("Signature::anyInterpretedSymbols");
    ASS_G(_iSymbols.size(),0); 

    return _iSymbols.size()!=1;
  }

 
  const vstring& functionName(int number);
 
  const vstring& predicateName(int number)
  {
    return _preds[number]->name();
  }
 
  const unsigned functionArity(int number)
  {
    CALL("Signature::functionArity");
    return _funs[number]->arity();
  }
 
  const unsigned predicateArity(int number)
  {
    CALL("Signature::predicateArity");
    return _preds[number]->arity();
  }

  const bool predicateColored(int number)
  {
    return _preds[number]->color()!=COLOR_TRANSPARENT;
  }

  const bool functionColored(int number)
  {
    return _funs[number]->color()!=COLOR_TRANSPARENT;
  }

 
  bool isPredicateName(vstring name, unsigned arity)
  {
    vstring symbolKey = key(name,arity);
    unsigned tmp;
    return _predNames.find(symbolKey,tmp);
  }

 
  unsigned functions() const { return _funs.length(); }
 
  unsigned predicates() const { return _preds.length(); }

 
  inline Symbol* getFunction(unsigned n)
  {
    ASS_REP(n < _funs.length(),n);
    return _funs[n];
  } 
 
  inline Symbol* getPredicate(unsigned n)
  {
    ASS(n < _preds.length());
    return _preds[n];
  } 

  Signature();
  ~Signature();

  CLASS_NAME(Signature);
  USE_ALLOCATOR(Signature);

  bool functionExists(const vstring& name,unsigned arity) const;
  bool predicateExists(const vstring& name,unsigned arity) const;

  unsigned getFunctionNumber(const vstring& name, unsigned arity) const;
  unsigned getPredicateNumber(const vstring& name, unsigned arity) const;
  
  Unit* getDistinctGroupPremise(unsigned group);
  unsigned createDistinctGroup(Unit* premise = 0);
  void addToDistinctGroup(unsigned constantSymbol, unsigned groupId);
  bool hasDistinctGroups(){ return _distinctGroupsAddedTo; }
  void noDistinctGroupsLeft(){ _distinctGroupsAddedTo=false; }
  Stack<Stack<unsigned>*> getDistinctGroupMembers(){ return _distinctGroupMembers; }

  bool hasTermAlgebras() { return !_termAlgebras.isEmpty(); }
      
  static vstring key(const vstring& name,int arity);

 
  unsigned strings() const {return _strings;}
 
  unsigned integers() const {return _integers;}
 
  unsigned rationals() const {return _rationals;}
 
  unsigned reals() const {return _reals;}

  static const unsigned STRING_DISTINCT_GROUP;
  static const unsigned INTEGER_DISTINCT_GROUP;
  static const unsigned RATIONAL_DISTINCT_GROUP;
  static const unsigned REAL_DISTINCT_GROUP;
  static const unsigned LAST_BUILT_IN_DISTINCT_GROUP;

  unsigned getFoolConstantSymbol(bool isTrue){ 
    if(!_foolConstantsDefined){
      _foolFalse = addFunction("$$false",0); 
      getFunction(_foolFalse)->setType(new FunctionType(Sorts::SRT_BOOL));
      _foolTrue = addFunction("$$true",0);
      getFunction(_foolTrue)->setType(new FunctionType(Sorts::SRT_BOOL));
      _foolConstantsDefined=true;
    }
    return isTrue ? _foolTrue : _foolFalse;
  }
  bool isFoolConstantSymbol(bool isTrue, unsigned number){
    if(!_foolConstantsDefined) return false;
    return isTrue ? number==_foolTrue : number==_foolFalse;
  }

  bool isTermAlgebraSort(unsigned sort) { return _termAlgebras.find(sort); }
  Shell::TermAlgebra *getTermAlgebraOfSort(unsigned sort) { return _termAlgebras.get(sort); }
  void addTermAlgebra(Shell::TermAlgebra *ta) { _termAlgebras.insert(ta->sort(), ta); }
  VirtualIterator<Shell::TermAlgebra*> termAlgebrasIterator() const { return _termAlgebras.range(); }
  Shell::TermAlgebraConstructor* getTermAlgebraConstructor(unsigned functor);

  void recordDividesNvalue(TermList n){
    _dividesNvalues.push(n);
  }
  Stack<TermList>& getDividesNvalues(){ return _dividesNvalues; }

  static bool symbolNeedsQuoting(vstring name, bool interpreted, unsigned arity);

private:
  Stack<TermList> _dividesNvalues;

  bool _foolConstantsDefined;
  unsigned _foolTrue;
  unsigned _foolFalse;

  static bool isProtectedName(vstring name);
  static bool charNeedsQuoting(char c, bool first);
 
  Stack<VarSymbol*> _vars;
 
  Stack<Symbol*> _funs;
 
  Stack<Symbol*> _preds;
 
  SymbolMap _funNames;
 
  SymbolMap _predNames;
 
  SymbolMap _arityCheck;
 
  int _nextFreshSymbolNumber;

 
  unsigned _skolemFunctionCount;

 
  SymbolMap _varNames;
  
  
  Stack<Unit*> _distinctGroupPremises;
  
  Stack<Stack<unsigned>*> _distinctGroupMembers;
  
  bool _distinctGroupsAddedTo;

 
  DHMap<Interpretation, unsigned> _iSymbols;
 
  unsigned _strings;
 
  unsigned _integers;
 
  unsigned _rationals;
 
  unsigned _reals;

  
  DHMap<unsigned, Shell::TermAlgebra*> _termAlgebras;

  void defineOptionTermAlgebra(unsigned optionSort);
  void defineEitherTermAlgebra(unsigned eitherSort);
}; 

}

#endif 

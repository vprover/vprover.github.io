
/*
 * File Inference.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Inference__
#define __Inference__

#include <cstdlib>

#include "Kernel/Unit.hpp"
#include "Lib/Allocator.hpp"
#include "Lib/VString.hpp"

using namespace std;
using namespace Lib;

namespace Kernel {

class Inference
{
public:
 
  enum Rule {
   
    INPUT,
   
    NEGATED_CONJECTURE,
   
    ANSWER_LITERAL,






   
    RECTIFY,






















   
    CLOSURE,
   
    FLATTEN,
   
    REORDER_LITERALS,
   
    ENNF,
   
    NNF,




















   
    SKOLEMIZE,
   
    CLAUSIFY,
   
    FORMULIFY,
   
    REMOVE_DUPLICATE_LITERALS,


   
    RESOLUTION,
   
    CONSTRAINED_RESOLUTION,
   
    EQUALITY_PROXY_REPLACEMENT,
   
    EQUALITY_PROXY_AXIOM1,
   
    EQUALITY_PROXY_AXIOM2,
   
    DEFINITION_UNFOLDING,
   
    DEFINITION_FOLDING,
   
    SKOLEM_PREDICATE_INTRODUCTION,
   
    PREDICATE_SKOLEMIZE,


   
    PREDICATE_DEFINITION,
   
    PREDICATE_DEFINITION_UNFOLDING,
   
    PREDICATE_DEFINITION_MERGING,
   
    EQUIVALENCE_DISCOVERY,
   
    FORMULA_SHARING,
   
    REDUCE_FALSE_TRUE,
   
    LOCAL_SIMPLIFICATION,
   
    NORMALIZATION,
   
    EQUALITY_PROPAGATION,
   
    TRIVIAL_INEQUALITY_REMOVAL,
   
    FACTORING,
   
    CONSTRAINED_FACTORING,
   
    SUBSUMPTION_RESOLUTION,
   
    SUPERPOSITION,
   
    CONSTRAINED_SUPERPOSITION,
   
    EQUALITY_FACTORING,
   
    EQUALITY_RESOLUTION,
   
    EXTENSIONALITY_RESOLUTION,
   
    FORWARD_DEMODULATION,
   
    BACKWARD_DEMODULATION,
   
    FORWARD_LITERAL_REWRITING,
   
    INNER_REWRITING,
   
    CONDENSATION,
   
    EVALUATION,
   
    INTERPRETED_SIMPLIFICATION,
   
    UNUSED_PREDICATE_DEFINITION_REMOVAL,
   
    PURE_PREDICATE_REMOVAL,
   
    INEQUALITY_SPLITTING,
   
    INEQUALITY_SPLITTING_NAME_INTRODUCTION,
   
    GROUNDING,
   
    EQUALITY_AXIOM,
   
    CHOICE_AXIOM,
   
    THEORY,
   
    TERM_ALGEBRA_EXHAUSTIVENESS,
   
    TERM_ALGEBRA_DISTINCTNESS,
   
    TERM_ALGEBRA_INJECTIVITY,
   
    TERM_ALGEBRA_DISCRIMINATION,
   
    TERM_ALGEBRA_ACYCLICITY,
   
    FOOL_AXIOM,
    
    THEORY_FLATTENING,
   
    BOOLEAN_TERM_ENCODING,
   
    FOOL_ELIMINATION,
   
    FOOL_ITE_ELIMINATION,
   
    FOOL_LET_ELIMINATION,
   
    FOOL_PARAMODULATION,
   
    AVATAR_DEFINITION,
   
    AVATAR_COMPONENT,
   
    AVATAR_REFUTATION,
   
    AVATAR_SPLIT_CLAUSE,
   
    AVATAR_CONTRADICTION_CLAUSE,
   
    SAT_COLOR_ELIMINATION,
   
    GENERAL_SPLITTING,
   
    GENERAL_SPLITTING_COMPONENT,
   
    COMMON_NONPROP_MERGE,
   
    PROP_REDUCE,
   
    CLAUSE_NAMING,
   
    BDDZATION,
   
    TAUTOLOGY_INTRODUCTION,
   
    COLOR_UNBLOCKING,
   
    INSTANCE_GENERATION,
   
    UNIT_RESULTING_RESOLUTION,
   
    HYPER_SUPERPOSITION,
   
    GLOBAL_SUBSUMPTION,
   
    SAT_INSTGEN_REFUTATION,
   
    DISTINCT_EQUALITY_REMOVAL,
   
    EXTERNAL,
   
    CLAIM_DEFINITION,
   
    BFNT_FLATTENING,
   
    BFNT_DISTINCT,
   
    BFNT_TOTALITY,
   
    FMB_FLATTENING,
   
    FMB_FUNC_DEF,
   
    FMB_DEF_INTRO, 
   
    ADD_SORT_PREDICATES,
   
    ADD_SORT_FUNCTIONS,
   
    INSTANTIATION,
   
    MODEL_NOT_FOUND,
  }; 

  explicit Inference(Rule r);

 
  virtual void destroy();
 
  virtual ~Inference() {}

 
  virtual void minimizePremises() {}

  static vstring ruleName(Rule rule);
  vstring name() const { return ruleName(_rule); }

  
  
  static bool positionIn(TermList& subterm,TermList* term, vstring& position);
  static bool positionIn(TermList& subterm,Term* term, vstring& position);

  CLASS_NAME(Inference);
  USE_ALLOCATOR(Inference);

 
  struct Iterator {
   
    union {
      void* pointer;
      int integer;
    };
  };

  virtual Iterator iterator();
  virtual bool hasNext(Iterator& it);
  virtual Unit* next(Iterator& it);

 
  Rule rule() const { return _rule; }

 
  void setExtra(vstring e){ _extra=e; }
 
  vstring extra() { return _extra; }

  unsigned maxDepth(){ return _maxDepth; }

protected:
 
  Rule _rule;
 
  vstring _extra;
 
  unsigned _maxDepth;
}; 

class Inference1
  : public Inference
{
public:
  Inference1(Rule rule,Unit* premise)
    : Inference(rule),
      _premise1(premise)
  { 
    _premise1->incRefCnt(); 
    _maxDepth = premise->inference()->maxDepth()+1; 
    if(_rule == EVALUATION){ _maxDepth = premise->inference()->maxDepth(); }
  }

  virtual void destroy();
  virtual Iterator iterator();
  virtual bool hasNext(Iterator& it);
  virtual Unit* next(Iterator& it);

  CLASS_NAME(Inference1);
  USE_ALLOCATOR(Inference1);

protected:
 
  Unit* _premise1;
};

class InferenceMany
  : public Inference
{
public:
  InferenceMany(Rule rule,UnitList* premises);
  virtual ~InferenceMany() { UnitList::destroy(_premises); }

  virtual void destroy();
  virtual Iterator iterator();
  virtual bool hasNext(Iterator& it);
  virtual Unit* next(Iterator& it);

  CLASS_NAME(InferenceMany);
  USE_ALLOCATOR(InferenceMany);

protected:
 
  UnitList* _premises;
};

class Inference2
  : public Inference
{
public:
  Inference2(Rule rule,Unit* premise1,Unit* premise2)
    : Inference(rule),
      _premise1(premise1),
      _premise2(premise2)
  {
    _premise1->incRefCnt();
    _premise2->incRefCnt();
    _maxDepth = max(premise1->inference()->maxDepth(),premise2->inference()->maxDepth())+1;
  }

  virtual void destroy();
  virtual Iterator iterator();
  virtual bool hasNext(Iterator& it);
  virtual Unit* next(Iterator& it);

  CLASS_NAME(Inference2);
  USE_ALLOCATOR(Inference2);

protected:
 
  Unit* _premise1;
 
  Unit* _premise2;
};


}
#endif

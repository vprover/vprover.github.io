
/*
 * File ELiteralSelector.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#ifndef __ELiteralSelector__
#define __ELiteralSelector__

#include "Forwards.hpp"
#include "Lib/SmartPtr.hpp"
#include "Ordering.hpp"

#include "LiteralSelector.hpp"

namespace Kernel {

class ELiteralSelector
: public LiteralSelector
{
public:
  CLASS_NAME(ELiteralSelector);
  USE_ALLOCATOR(ELiteralSelector);

  enum Values {
    
    SelectNegativeLiterals = 0,
    SelectPureVarNegLiterals = 1,
    
    
    SelectSmallestNegLit = 2,
    
    SelectDiffNegLit = 3,
    SelectGroundNegLit = 4,
    SelectOptimalLit = 5
  };

  ELiteralSelector(const Ordering& ordering, const Options& options, Values value) :
    LiteralSelector(ordering, options), _value(value) {}

  bool isBGComplete() const override { return true; }
protected:
  void doSelection(Clause* c, unsigned eligible) override;

private:
  LiteralList* getMaximalsInOrder(Clause* c, unsigned eligible);

  unsigned lit_standard_diff(Literal* lit);
  unsigned lit_sel_diff_weight(Literal* lit);

  Values _value;
};

};

#endif

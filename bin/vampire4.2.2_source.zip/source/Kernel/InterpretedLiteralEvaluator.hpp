
/*
 * File InterpretedLiteralEvaluator.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __InterpretedLiteralEvaluator__
#define __InterpretedLiteralEvaluator__

#include "Forwards.hpp"

#include "Lib/DArray.hpp"
#include "Lib/Stack.hpp"

#include "TermTransformer.hpp"
#include "Theory.hpp"

namespace Kernel {

class InterpretedLiteralEvaluator
  :  private TermTransformer
{
public:
  CLASS_NAME(InterpretedLiteralEvaluator);
  USE_ALLOCATOR(InterpretedLiteralEvaluator);
  
  InterpretedLiteralEvaluator();
  ~InterpretedLiteralEvaluator();

  bool evaluate(Literal* lit, bool& isConstant, Literal*& resLit, bool& resConst,Stack<Literal*>& sideConditions);
protected:
  class Evaluator;
  class EqualityEvaluator;
  class ConversionEvaluator;
  template<class T> class TypedEvaluator;
  class IntEvaluator;
  class RatEvaluator;
  class RealEvaluator;

  typedef Stack<Evaluator*> EvalStack;
  virtual TermList transformSubterm(TermList trm);
  Evaluator* getFuncEvaluator(unsigned func);
  Evaluator* getPredEvaluator(unsigned pred);
  EvalStack _evals;
  DArray<Evaluator*> _funEvaluators;
  DArray<Evaluator*> _predEvaluators;

  bool balancable(Literal* lit);
  bool balance(Literal* lit,Literal*& res,Stack<Literal*>& sideConditions);
  
  
  bool balancePlus(Interpretation plus, Interpretation unaryMinus, Term* AplusB, TermList* A, TermList C, TermList& result);

  
  
  
  template<typename ConstantType>
  bool balanceMultiply(Interpretation divide,ConstantType zero,             
                       Term* AmultiplyB, TermList* A, TermList C, TermList& result,
                       Interpretation under, bool& swap, Stack<Literal*>& sideConditions);

  bool balanceIntegerMultiply(
                                                  Term* AmultiplyB, TermList* A, TermList C, TermList& result,
                                                  Interpretation under, bool& swap,
                                                  Stack<Literal*>& sideConditions);

  
  
  
  
  bool balanceDivide(Interpretation multiply, 
                       Term* AmultiplyB, TermList* A, TermList C, TermList& result,
                       Interpretation under, bool& swap, Stack<Literal*>& sideConditions);
  
};


}

#endif 

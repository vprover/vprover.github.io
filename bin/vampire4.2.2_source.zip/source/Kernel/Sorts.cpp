
/*
 * File Sorts.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Sorts.hpp"

#include "Lib/Environment.hpp"
#include "Kernel/Theory.hpp"
#include "Shell/Options.hpp"

#include "Signature.hpp"

using namespace Kernel;

Sorts::Sorts()
{
  CALL("Sorts::Sorts");

  unsigned aux;

  aux = addSort("$i",true);
  ASS_EQ(aux, SRT_DEFAULT);

  aux = addSort("$o",true);
  ASS_EQ(aux, SRT_BOOL);

  aux = addSort("$int",true);
  ASS_EQ(aux, SRT_INTEGER);

  aux = addSort("$rat",true);
  ASS_EQ(aux, SRT_RATIONAL);

  aux = addSort("$real",true);
  ASS_EQ(aux, SRT_REAL);
    
 _hasSort = false;
} 

Sorts::~Sorts()
{
  CALL("Sorts::~Sorts");

  while(_sorts.isNonEmpty()) {
    delete _sorts.pop();
  }
} 

unsigned Sorts::addSort(const vstring& name, bool interpreted)
{
  CALL("Sorts::addSort/2");
  bool dummy;
  return addSort(name, dummy, interpreted);
} 

Sorts::SortInfo::SortInfo(const vstring& name,const unsigned id, bool interpreted)
{
  CALL("Sorts::SortInfo::SortInfo");

  if (Signature::symbolNeedsQuoting(name,interpreted,0)) { 
    _name = "'" + name + "'";
  } else {
    _name = name;
  }

  _id = id;
}

unsigned Sorts::addSort(const vstring& name, bool& added, bool interpreted)
{
  CALL("Sorts::addSort/3");

  unsigned result;
  if (_sortNames.find(name,result)) {
    added = false;
    return result;
  }
  _hasSort = true;
  result = _sorts.length();
  _sorts.push(new SortInfo(name, result,interpreted));
  _sortNames.insert(name, result);
  added = true;
  return result;
} 


unsigned Sorts::addArraySort(const unsigned indexSort, const unsigned innerSort)
{
  CALL("Sorts::addArraySort");

  vstring name = "$array(";
  name+=env.sorts->sortName(indexSort);
  name+=",";
  name+=env.sorts->sortName(innerSort);
  name+=")";
  unsigned result;
  if(_sortNames.find(name,result)){
    return result;
  }

  _hasSort = true;
  result = _sorts.length(); 

  ArraySort* sort = new ArraySort(name,indexSort,innerSort,result);
  _sorts.push(sort);
  _sortNames.insert(name,result);

  return result;
}

struct SortInfoToInt{
  DECL_RETURN_TYPE(unsigned);
  unsigned operator()(Sorts::SortInfo* s){ return s->id(); }
};

VirtualIterator<unsigned> Sorts::getStructuredSorts(const StructuredSort ss)
{
  CALL("Sorts::getStructuredSorts");
  Stack<SortInfo*>::Iterator all(_sorts);
  VirtualIterator<SortInfo*> arraySorts = pvi(getFilteredIterator(all,
               [ss](SortInfo* s){ return s->hasStructuredSort(ss);}));
  
  return pvi(getMappingIterator(arraySorts,SortInfoToInt()));
}

unsigned Sorts::addTupleSort(unsigned arity, unsigned sorts[])
{
  CALL("Sorts::addTupleSort");

  vstring name = "[";
  for (unsigned i = 0; i < arity; i++) {
    name += env.sorts->sortName(sorts[i]);
    if (i != arity - 1) {
      name += ",";
    }
  }
  name += "]";
  unsigned result;
  if(_sortNames.find(name, result)) {
    return result;
  }

  _hasSort = true;
  result = _sorts.length();

  _sorts.push(new TupleSort(name,result,arity,sorts));
  _sortNames.insert(name, result);

  return result;
}

bool Sorts::haveSort(const vstring& name)
{
  CALL("Sorts::haveSort");
  return _sortNames.find(name);
} 

bool Sorts::findSort(const vstring& name, unsigned& idx)
{
  CALL("Sorts::findSort");
  return _sortNames.find(name, idx);
} 

const vstring& Sorts::sortName(unsigned idx) const
{
  CALL("Sorts::sortName");
  if (env.options->showFOOL() && idx == SRT_BOOL) {
    static vstring name("$bool");
    return name;
  }
  return _sorts[idx]->name();
} 

BaseType::BaseType(unsigned arity, const unsigned* sorts)
{
  CALL("BaseType::BaseType");

  if (!arity) {
    _args = 0;
    return;
  }

  _args = SortVector::allocate(arity);
  if (!sorts) {
    
    for (unsigned i = 0; i < arity; i++) {
      (*_args)[i] = Sorts::SRT_DEFAULT;
    }
    return;
  }
  
  for (unsigned i = 0; i < arity; i++) {
    (*_args)[i] = sorts[i];
  }
} 

BaseType::BaseType(std::initializer_list<unsigned> sorts)
{
  CALL("BaseType::BaseType");

  if (sorts.size() == 0) {
    _args = 0;
    return;
  }

  _args = SortVector::allocate(sorts.size());
  
  unsigned i = 0;
  for (auto sort : sorts) {
    (*_args)[i++] = sort;
  }
} 
 
BaseType::~BaseType()
{
  CALL("BaseType::~BaseType");

  if (_args) {
    _args->deallocate();
  }
} 
 
bool BaseType::isSingleSortType(unsigned srt) const
{
  CALL("BaseType::isAllDefault");

  unsigned len = arity();
  for (unsigned i = 0; i <len; i++) {
    if (arg(i) != srt) {
      return false;
    }
  }
  return true;
} 

bool BaseType::operator==(const BaseType& o) const
{
  CALL("BaseType::operator==");

  if (isFunctionType() != o.isFunctionType()) {
    return false;
  }
  if (isFunctionType()) {
    if (static_cast<const FunctionType&>(*this).result() != 
	static_cast<const FunctionType&>(o).result()) {
      return false;
    }
  }
  unsigned len = arity();
  if (len != o.arity()) {
    return false;
  }
  for (unsigned i=0; i < len; i++) {
    if (arg(i) != o.arg(i)) {
      return false;
    }
  }
  return true;
} 

vstring BaseType::argsToString() const
{
  CALL("BaseType::argsToString");

  vstring res = "(";
  unsigned ar = arity();
  ASS(ar);
  for (unsigned i = 0; i < ar; i++) {
    res += env.sorts->sortName(arg(i));
    if (i != ar-1) {
      res += " * ";
    }
  }
  res += ')';
  return res;
} 

vstring PredicateType::toString() const
{
  CALL("PredicateType::toString");
  return arity() ? argsToString() + " > $o" : "$o";
} 

PredicateType* PredicateType::makeTypeUniformRange(unsigned arity, unsigned argsSort)
{
  CALL("PredicateType::makeTypeUniformRange");

  static Stack<unsigned> argSorts;
  argSorts.reset();
  for (unsigned i=0; i<arity; i++) {
    argSorts.push(argsSort);
  }
  return new PredicateType(arity, argSorts.begin());
} 


vstring FunctionType::toString() const
{
  CALL("FunctionType::toString");
  return (arity() ? argsToString() + " > " : "") + env.sorts->sortName(result());
} 

bool FunctionType::isSingleSortType(unsigned srt) const
{
  CALL("FunctionType::isSingleSortType");

  if (result() != srt) {
    return false;
  }
  return BaseType::isSingleSortType(srt);
} 

FunctionType* FunctionType::makeTypeUniformRange(unsigned arity, unsigned argsSort, unsigned rangeSort)
{
  CALL("FunctionType::makeTypeUniformRange");

  static Stack<unsigned> argSorts;
  argSorts.reset();
  for (unsigned i=0; i<arity; i++) {
    argSorts.push(argsSort);
  }
  return new FunctionType(arity, argSorts.begin(), rangeSort);
} 

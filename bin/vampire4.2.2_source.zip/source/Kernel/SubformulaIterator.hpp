
/*
 * File SubformulaIterator.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __SubformulaIterator__
#define __SubformulaIterator__

#include "Lib/VirtualIterator.hpp"

#include "Formula.hpp"

namespace Kernel {

class SubformulaIterator
: public IteratorCore<Formula*>
{
public:
  SubformulaIterator (Formula*);
  SubformulaIterator (FormulaList*);
  ~SubformulaIterator ();

  bool hasNext ();
  Formula* next ();
  Formula* next (int& polarity);
private:
  class Element;
  Formula* _current;
  int _currentPolarity;
  Element* _reserve;
}; 

}

#endif 



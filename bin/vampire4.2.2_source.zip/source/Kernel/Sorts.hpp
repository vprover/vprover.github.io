
/*
 * File Sorts.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Sorts__
#define __Sorts__

#include "Forwards.hpp"

#include "Lib/DArray.hpp"
#include "Lib/Map.hpp"
#include "Lib/Stack.hpp"
#include "Lib/Vector.hpp"
#include "Lib/Allocator.hpp"
#include "Lib/VString.hpp"

namespace Kernel {

class Sorts {
public:
  CLASS_NAME(Sorts);
  USE_ALLOCATOR(Sorts);

 
  
  enum DefaultSorts {
   
    SRT_DEFAULT = 0,
   
    SRT_BOOL = 1,
   
    SRT_INTEGER = 2,
   
    SRT_RATIONAL = 3,
   
    SRT_REAL = 4,
   
    FIRST_USER_SORT = 5
  };

 
  enum class StructuredSort {
   
    ARRAY,
   
    LIST,
   
    TUPLE,
   
    LAST_STRUCTURED_SORT
  };

  Sorts();
  ~Sorts();

  class SortInfo
  {
  public:
    CLASS_NAME(SortInfo);
    USE_ALLOCATOR(SortInfo);
  
    SortInfo(const vstring& name,const unsigned id, bool interpreted = false);
    virtual ~SortInfo() {}
    
    const vstring& name() const { return _name; }
    const unsigned id() const { return _id; }

    virtual bool hasStructuredSort(StructuredSort sort) { return false; }

  protected:
    vstring _name;
    unsigned _id;
  };

 
  class StructuredSortInfo : public SortInfo
  {
  public:
    CLASS_NAME(StructuredSortInfo);
    USE_ALLOCATOR(StructuredSortInfo);

    StructuredSortInfo(vstring name, StructuredSort sort,unsigned id): 
      SortInfo(name,id), _sort(sort) { (void)_sort; }

    bool hasStructuredSort(StructuredSort sort) override {
      return sort==_sort;
    }

  private:
    StructuredSort _sort;
  };

 
  class ArraySort : public StructuredSortInfo
  {
  public:
    CLASS_NAME(ArraySort);
    USE_ALLOCATOR(ArraySort);

    ArraySort(vstring name, unsigned indexSort, unsigned innerSort,unsigned id) : 
      StructuredSortInfo(name,StructuredSort::ARRAY, id), 
      _indexSort(indexSort), _innerSort(innerSort)
    { 
#if VDEBUG
      
#endif
    }

    unsigned getIndexSort(){ return _indexSort; }
    unsigned getInnerSort(){ return _innerSort; }

  private:
    
    unsigned _indexSort;
    unsigned _innerSort;

  };

  class TupleSort : public StructuredSortInfo
  {
  public:
    CLASS_NAME(TupleSort);
    USE_ALLOCATOR(TupleSort);

    TupleSort(vstring name, unsigned id, unsigned arity, unsigned sorts[])
      : StructuredSortInfo(name, StructuredSort::TUPLE, id), _sorts(arity) {
      for (unsigned i = 0; i < arity; i++) {
        _sorts[i] = sorts[i];
      }
    }

    unsigned arity() const { return (unsigned)_sorts.size(); }
    unsigned* sorts() { return _sorts.array(); }
    unsigned argument(unsigned index) const { ASS_G(arity(), index); return _sorts[index]; }

  private:
    DArray<unsigned> _sorts;
  };

  unsigned addSort(const vstring& name, bool& added, bool interpreted);
  unsigned addSort(const vstring& name, bool interpreted);

  unsigned addArraySort(unsigned indexSort, unsigned innerSort);
  ArraySort* getArraySort(unsigned sort){
    ASS(hasStructuredSort(sort,StructuredSort::ARRAY));
    return static_cast<ArraySort*>(_sorts[sort]);
  }

  unsigned addTupleSort(unsigned arity, unsigned sorts[]);
  TupleSort* getTupleSort(unsigned sort) {
    ASS(hasStructuredSort(sort,StructuredSort::TUPLE));
    return static_cast<TupleSort*>(_sorts[sort]);
  }

  bool haveSort(const vstring& name);
  bool findSort(const vstring& name, unsigned& idx);

  VirtualIterator<unsigned> getStructuredSorts(const StructuredSort ss);

  bool hasStructuredSort(unsigned sort) {
    if(sort > _sorts.size()) return false;
    unsigned sorts = (unsigned)StructuredSort::LAST_STRUCTURED_SORT;
    for (unsigned ss = 0; ss < sorts; ss++) {
      if (_sorts[sort]->hasStructuredSort(static_cast<StructuredSort>(ss))) {
        return true;
      }
    }
    return false;
  }

  bool hasStructuredSort(unsigned sort, StructuredSort structured){
    if(sort > _sorts.size()) return false;
    return _sorts[sort]->hasStructuredSort(structured);
  }

  const vstring& sortName(unsigned idx) const;

 
  unsigned sorts() const { return _sorts.length(); }
 
  bool hasSort() const {return _hasSort;}

private:
  SymbolMap _sortNames;
  Stack<SortInfo*> _sorts;
 
  bool _hasSort;

};

class BaseType
{
public:
  CLASS_NAME(BaseType);
  USE_ALLOCATOR(BaseType);

  virtual ~BaseType();

  unsigned arg(unsigned idx) const
  {
    CALL("BaseType::arg");
    return (*_args)[idx];
  }

  unsigned arity() const { return _args ? _args->length() : 0; }
  virtual bool isSingleSortType(unsigned sort) const;
  bool isAllDefault() const { return isSingleSortType(Sorts::SRT_DEFAULT); }

  virtual bool isFunctionType() const { return false; }

  bool operator==(const BaseType& o) const;
  bool operator!=(const BaseType& o) const { return !(*this==o); }

  virtual vstring toString() const = 0;
protected:
  BaseType(unsigned arity, const unsigned* sorts=0);
  BaseType(std::initializer_list<unsigned> sorts);

  vstring argsToString() const;
private:
  typedef Vector<unsigned> SortVector;
  SortVector* _args;
};

class PredicateType : public BaseType
{
public:
  CLASS_NAME(PredicateType);
  USE_ALLOCATOR(PredicateType);

  PredicateType(unsigned arity, const unsigned* argumentSorts)
   : BaseType(arity, argumentSorts) {}
  PredicateType(std::initializer_list<unsigned> sorts) : BaseType(sorts) {}

  virtual vstring toString() const;

  static PredicateType* makeTypeUniformRange(unsigned arity, unsigned argsSort);
};

class FunctionType : public BaseType
{
public:
  CLASS_NAME(FunctionType);
  USE_ALLOCATOR(FunctionType);

  FunctionType(unsigned arity, const unsigned* argumentSorts, unsigned resultSort)
   : BaseType(arity, argumentSorts), _result(resultSort) {}
  FunctionType(unsigned resultSort)
   : BaseType(0, 0), _result(resultSort) {}
  FunctionType(std::initializer_list<unsigned> argSorts, unsigned resultSort)
   : BaseType(argSorts), _result(resultSort) {}

  unsigned result() const { return _result; }

  virtual bool isSingleSortType(unsigned sort) const;
  virtual bool isFunctionType() const { return true; }

  virtual vstring toString() const;

  static FunctionType* makeTypeUniformRange(unsigned arity, unsigned argsSort, unsigned rangeSort);
private:
  unsigned _result;
};

}

#endif 

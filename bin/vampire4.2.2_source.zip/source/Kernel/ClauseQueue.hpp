
/*
 * File ClauseQueue.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __ClauseQueue__
#define __ClauseQueue__

#if VDEBUG
#include <ostream>
using namespace std;
#endif

#include "Debug/Assertion.hpp"

#include "Lib/Reflection.hpp"

namespace Kernel {

class Clause;

class ClauseQueue
{
public:
  ClauseQueue();
  virtual ~ClauseQueue();
  void insert(Clause*);
  bool remove(Clause*);
  void removeAll();
  Clause* pop();
 
  bool isEmpty() const
  { return _left->nodes[0] == 0; }
#if VDEBUG
  void output(ostream&) const;
#endif

  friend class Iterator;
protected:
 
  virtual bool lessThan(Clause*,Clause*) = 0;
 
  class Node {
  public:
   
    Clause* clause;
   
    Node* nodes[1];
  };
 
  unsigned _height;
 
  Node* _left;

public:
 
  class Iterator {
  public:
    DECL_ELEMENT_TYPE(Clause*);

   
    inline explicit Iterator(ClauseQueue& queue)
      : _current(queue._left)
    {}
   
    inline bool hasNext() const
    { return _current->nodes[0]; }
   
    inline Clause* next()
    {
      _current = _current->nodes[0];
      ASS(_current);
      return _current->clause;
    }
  private:
   
    Node* _current;
  }; 
















}; 

} 

#endif

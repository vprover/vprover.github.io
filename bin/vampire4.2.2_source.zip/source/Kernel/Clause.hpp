
/*
 * File Clause.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Clause__
#define __Clause__

#include <iosfwd>

#include "Forwards.hpp"

#include "Lib/Allocator.hpp"
#include "Lib/Event.hpp"
#include "Lib/InverseLookup.hpp"
#include "Lib/Metaiterators.hpp"
#include "Lib/Reflection.hpp"
#include "Lib/Stack.hpp"

#include "Unit.hpp"


namespace Kernel {

using namespace Lib;

class Clause
  : public Unit
{
private:
 
  ~Clause() { ASSERTION_VIOLATION; }
 
  void operator delete(void* ptr) { ASSERTION_VIOLATION; }
public:
  typedef ArrayishObjectIterator<Clause> Iterator;

  DECL_ELEMENT_TYPE(Literal*);
  DECL_ITERATOR_TYPE(Iterator);

 
  enum Store {
   
    PASSIVE = 0u,
   
    ACTIVE = 1u,
   
    UNPROCESSED = 2u,
   
    NONE = 3u,  
   
    SELECTED = 4u
  };

  Clause(unsigned length,InputType it,Inference* inf);


  void* operator new(size_t,unsigned length);
  void operator delete(void* ptr,unsigned length);

  static Clause* fromStack(const Stack<Literal*>& lits, InputType it, Inference* inf);

  template<class Iter>
  static Clause* fromIterator(Iter litit, InputType it, Inference* inf)
  {
    CALL("Clause::fromIterator");

    static Stack<Literal*> st;
    st.reset();
    st.loadFromIterator(litit);
    return fromStack(st, it, inf);
  }

  static Clause* fromClause(Clause* c);

 
  Literal*& operator[] (int n)
  { return _literals[n]; }
 
  Literal* operator[] (int n) const
  { return _literals[n]; }

 
  unsigned length() const { return _length; }
 
  unsigned size() const { return _length; }

 
  Literal** literals() { return _literals; }

 
  bool isEmpty() const { return _length == 0; }

  void destroy();
  void destroyExceptInferenceObject();
  vstring literalsOnlyToString() const;
  vstring toString() const;
  vstring toTPTPString() const;
  vstring toNiceString() const;

 
  Store store() const { return _store; }

  void setStore(Store s);

 
  unsigned age() const { return _age; }
 
  void setAge(unsigned a) { _age = a; }

 
  unsigned numSelected() const { return _numSelected; }
 
  void setSelected(unsigned s)
  {
    ASS(s >= 0);
    ASS(s <= _length);
    _numSelected = s;
    notifyLiteralReorder();
  }

 
  bool in_active() const {return _in_active;}
 
  void toggle_in_active() {_in_active=!_in_active;}

 
  unsigned weight() const
  {
    if(!_weight) {
      computeWeight();
    }
    return _weight;
  }
  void computeWeight() const;

 
  Color color() const
  {
    if(static_cast<Color>(_color)==COLOR_INVALID) {
      computeColor();
    }
    return static_cast<Color>(_color);
  }
  void computeColor() const;
  void updateColor(Color c) {
    _color = c;
  }

  bool isExtensionality() const { return _extensionality; }
  bool isTaggedExtensionality() const { return _extensionalityTag; }
  void setExtensionality(bool e) { _extensionality = e; }

  bool isComponent() const { return _component; }
  void setComponent(bool c) { _component = c; }

  bool isTheoryDescendant() const { return _theoryDescendant; }
  void setTheoryDescendant(bool t) { _theoryDescendant=t; }
  
  bool skip() const;

  unsigned getLiteralPosition(Literal* lit);
  void notifyLiteralReorder();

  bool shouldBeDestroyed();
  void destroyIfUnnecessary();

  void incRefCnt() { _refCnt++; }
  void decRefCnt()
  {
    CALL("Clause::decRefCnt");

    ASS_G(_refCnt,0);
    _refCnt--;
    destroyIfUnnecessary();
  }

  unsigned getReductionTimestamp() { return _reductionTimestamp; }
  void invalidateMyReductionRecords()
  {
    _reductionTimestamp++;
    if(_reductionTimestamp==0) {
      INVALID_OPERATION("Clause reduction timestamp overflow!");
    }
  }
  bool validReductionRecord(unsigned savedTimestamp) {
    return savedTimestamp == _reductionTimestamp;
  }

  ArrayishObjectIterator<Clause> getSelectedLiteralIterator()
  { return ArrayishObjectIterator<Clause>(*this,numSelected()); }

  bool isGround();
  bool isPropositional();
  bool isHorn();

  VirtualIterator<unsigned> getVariableIterator();


  bool contains(Literal* lit);
  void assertValid();
  void incFreezeCount(){ _freeze_count++;}
  int getFreezeCount(){ return _freeze_count;}


 
  void markInput() { _input=1; }
 
  bool isInput() { return _input; }


  SplitSet* splits() const { return _splits; }
  bool noSplits() const;
  void setSplits(SplitSet* splits,bool replace=false) {
    CALL("Clause::setSplits");
    ASS(replace || !_splits);
    _splits=splits;
  }
  
  int getNumActiveSplits() const { return _numActiveSplits; }
  void setNumActiveSplits(int newVal) { _numActiveSplits = newVal; }
  void incNumActiveSplits() { _numActiveSplits++; }
  void decNumActiveSplits() { _numActiveSplits--; }

  VirtualIterator<vstring> toSimpleClauseStrings();


 
  void setAux(void* ptr)
  {
    ASS(_auxInUse);
    _auxTimestamp=_auxCurrTimestamp;
    _auxData=ptr;
  }
 
  template<typename T>
  bool tryGetAux(T*& ptr)
  {
    ASS(_auxInUse);
    if(_auxTimestamp==_auxCurrTimestamp) {
      ptr=static_cast<T*>(_auxData);
      return true;
    }
    return false;
  }
 
  template<typename T>
  T* getAux()
  {
    ASS(_auxInUse);
    ASS(_auxTimestamp==_auxCurrTimestamp);
    return static_cast<T*>(_auxData);
  }
  bool hasAux()
  {
    return _auxTimestamp==_auxCurrTimestamp;
  }

 
  static void requestAux()
  {
#if VDEBUG
    ASS(!_auxInUse);
    _auxInUse=true;
#endif
    _auxCurrTimestamp++;
    if(_auxCurrTimestamp==0) {
      INVALID_OPERATION("Auxiliary clause value timestamp overflow!");
    }
  }
 
  static void releaseAux()
  {
#if VDEBUG
    ASS(_auxInUse);
    _auxInUse=false;
#endif
  }

  unsigned splitWeight() const;
  unsigned getNumeralWeight();
  float getEffectiveWeight(const Shell::Options& opt);

  void collectVars(DHSet<unsigned>& acc);
  unsigned varCnt();
  unsigned maxVar(); 

protected:
 
  unsigned _length : 25;
 
  mutable unsigned _color : 2;
 
  unsigned _input : 1;
 
  unsigned _extensionality : 1;
  unsigned _extensionalityTag : 1;
 
  unsigned _component : 1;
 
  unsigned _theoryDescendant : 1;

 
  unsigned _numSelected;
 
  unsigned _age;
 
  mutable unsigned _weight;
 
  Store _store;
 
  bool _in_active;
 
  unsigned _refCnt;
 
  unsigned _reductionTimestamp;
 
  InverseLookup<Literal>* _literalPositions;

  SplitSet* _splits;
  int _numActiveSplits;

  size_t _auxTimestamp;
  void* _auxData;

  static size_t _auxCurrTimestamp;
#if VDEBUG
  static bool _auxInUse;
#endif
  int _freeze_count;


 
  Literal* _literals[1];
}; 

}

#endif

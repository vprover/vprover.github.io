
/*
 * File Unit.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Unit__
#define __Unit__

#include "Forwards.hpp"

#include "Lib/List.hpp"
#include "Lib/VString.hpp"

namespace Kernel {

using namespace std;
using namespace Lib;

class Unit
{
protected:
  ~Unit() {}
public:
 
  enum Kind {
   
    CLAUSE = 0,
   
    FORMULA = 1
  };

 
  enum InputType {
   
    AXIOM = 0,
   
    ASSUMPTION = 1,
   
    CONJECTURE = 2,
   
    NEGATED_CONJECTURE = 3,
   
    CLAIM = 4,
   
    EXTENSIONALITY_AXIOM = 5,
   
    MODEL_DEFINITION = 6
  };

  static InputType getInputType(UnitList* units);
  static InputType getInputType(InputType t1, InputType t2);

  void destroy();
  vstring toString() const;
  unsigned varCnt();
  unsigned getPriority() const;

  vstring inferenceAsString() const;

 
  bool isClause() const
  { return _kind == CLAUSE; }

  Clause* asClause();

 
  InputType inputType() const
  { return (InputType)_inputType; }
 
  void setInputType(InputType it)
  { _inputType=it; }

 
  unsigned number() const { return _number; }

 
  Inference* inference() { return _inference; }
 
  const Inference* inference() const { return _inference; }
 
  void setInference(Inference* inf) { _inference = inf; }
 
  int adam() const {return _adam;}

 
  inline Color inheritedColor() const
  {
    return static_cast<Color>(_inheritedColor);
  }
  void setInheritedColor(Color color)
  {
    ASS_NEQ(color,COLOR_INVALID);
    _inheritedColor = color;
  } 

  void invalidateInheritedColor() { _inheritedColor = COLOR_INVALID; }

  Color getColor();
  unsigned getWeight();

  Formula* getFormula();
  void collectAtoms(Stack<Literal*>& acc);
  void collectPredicates(Stack<unsigned>& acc);

 
  void incRefCnt();
 
  void decRefCnt();

 
  inline void markIncluded() {_included = 1;}
 
  inline bool included() const {return _included;}

 
  inline bool isFromPreprocessing()
  { return !_firstNonPreprocessingNumber || _number<_firstNonPreprocessingNumber; }


  void assertValid();


  static void onPreprocessingEnd();

protected:
 
  unsigned _number;
 
  unsigned _kind : 1;
 
  unsigned _inputType : 3;
 
  unsigned _inheritedColor : 2;
 
  unsigned _included : 1;
 
  Inference* _inference;
 
  int _adam;

  Unit(Kind kind,Inference* inf,InputType it);

 
  static unsigned _lastNumber;

 
  static unsigned _firstNonPreprocessingNumber;
}; 

std::ostream& operator<< (ostream& out, const Unit& u );

}
#endif

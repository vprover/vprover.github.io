
/*
 * File Rational.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef RATIONAL_HPP_
#define RATIONAL_HPP_

#if GNUMP

#include "Forwards.hpp"

#include "Lib/Exception.hpp"
#include "Lib/Int.hpp"

#include <cmath>

namespace Kernel{

namespace __Aux_Number{

unsigned long long GCD(long long n1, long long n2);


bool additionOverflow(long long n1, long long n2);
bool subtractionOverflow(long long n1, long long n2);
bool multiplicationOverflow(long long n1, long long n2);
bool divisionOverflow(long long numerator, long long denominator);
bool moduloOverflow(long long numerator, long long denominator);

double safeConversionToDouble(long long number);
double safeConversionToDouble(double number);
float safeConversionToFloat(long long number);

long long safeAdd(long long n1, long long n2);

long long safeSub(long long n1, long long n2);

long long safeMul(long long n1, long long n2);

long long safeDiv(long long n1, long long n2);

long long safeModulo(long long n1, long long n2);

class Rational{

public:
	class NumberImprecisionException {
		public:
		NumberImprecisionException() {}
	};
	
	Rational(): _num(1), _den(1){}
	
	Rational(long long value):_num(value),_den(1){}
	
	Rational(long long num, long long den);
	
	Rational(vstring value);
	
	Rational(double value);
	Rational(long double value);
	Rational(int value);

	~Rational(){}
	Rational& operator=(const Rational& o){
		(*this)._den = o._den;
		(*this)._num = o._num;
		return static_cast<Rational&>(*this);
	}
	Rational& operator=(const long double val){
		Rational r(val);
		(*this)._den = r._den;
		(*this)._num = r._num;
		return static_cast<Rational&>(*this);
	}
	
	Rational& assign(double num, double den){
		_den=den;
		_num=num;
		return static_cast<Rational&>(*this);
	}

	Rational operator+(const Rational& o) const;
	
	Rational operator-() const;
	Rational operator-(const Rational& o) const;

	Rational operator*(const Rational& o) const;
	Rational operator/(const Rational& o) const;

	Rational& operator+=(const Rational& o);
	Rational& operator-=(const Rational& o);
	Rational& operator*=(const Rational& o);
	Rational& operator/=(const Rational& o);

	
	Rational& operator++();
	Rational& operator--();
	
	Rational operator++(int);
	Rational operator--(int);


	
	bool operator==(const Rational& o) const {
		
		return ((*this)._num == o._num && (*this)._den == o._den);

	}

	
	
	bool operator>(const Rational& o) const;
	bool operator<(const Rational& o) const;
	bool operator>=(const Rational& o) const;
	bool operator<=(const Rational& o) const;


	double toDouble() const{
		double res = (double)_num/_den;
		return res;
	}

	vstring toString() const;

	bool isPositive() const{ return this->_num >= 0;}
	bool isPositiveNonZero() const{return this->_num > 0;}

	bool isNegative() const{ return this->_num <= 0;}
	bool isNegativeNonZero() const{ return this->_num < 0;}

	bool isZero() const{ return this->_num == 0; }

	Rational abs() const{
		if ((*this).isNegative()){
			return Rational( -(*this)._num, (*this)._den);
		}
		return static_cast<Rational>(*this);
	}
	Rational abs(Rational val){
		if(val.isNegative()){
			return -val;
		}
		else{
			return val;
		}


	}
	long long Numerator() const {return _num;}
	long long Denomination() const {return _den;}

	
	
	operator double() const {return safeConversionToDouble(_num) / safeConversionToDouble(_den);}
	operator float() const {return safeConversionToFloat(_num) / safeConversionToFloat(_den);}
	operator long double() const {return safeConversionToDouble(_num) / safeConversionToDouble(_den);}

	friend ostream& operator<< (ostream &out, Rational &val){
		out << val.toString();
		return out;
	}

protected:
	bool sameDenominator(const Rational& a , const Rational& b) const{
		return (a._den == b._den);
	}

	Rational inverse() const{
		if (isZero()){
			return Rational(0,1);
		}
		Rational result(_den, _num);
		return result;
	}

	Rational canonical();

private:
	
	long long _num;
	
	
	
	
	long long _den;
};

} 
} 
#endif 
#endif

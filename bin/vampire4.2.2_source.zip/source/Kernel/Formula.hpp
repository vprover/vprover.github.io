
/*
 * File Formula.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Formula__
#define __Formula__

#include <utility>

#include "Forwards.hpp"

#include "Lib/Environment.hpp"
#include "Lib/List.hpp"
#include "Lib/XML.hpp"

#include "Kernel/Signature.hpp"

#include "Connective.hpp"
#include "Term.hpp"


namespace Kernel {

using namespace Lib;

class Formula
{
public:
  typedef List<int> VarList;
  typedef List<unsigned> SortList;
 
  explicit Formula (bool value)
    : _connective(value ? TRUE : FALSE)
  {
  } 

  
 
  Connective connective () const { return _connective; }

  const FormulaList* args() const;
  FormulaList* args();
  FormulaList** argsPtr();
  const Formula* left() const;
  Formula* left();
  const Formula* right() const;
  Formula* right();
  const Formula* qarg() const;
  Formula* qarg();
  const VarList* vars() const;
  VarList* vars();
  const SortList* sorts() const;
  SortList* sorts();
  const Formula* uarg() const;
  Formula* uarg();
  const Literal* literal() const;
  Literal* literal();
  const TermList getBooleanTerm() const;
  TermList getBooleanTerm();
  VarList* freeVariables () const;
  VarList* boundVariables () const;

  
  bool equals(const Formula*) const;
  void collectAtoms(Stack<Literal*>& acc);
  void collectPredicates(Stack<unsigned>& acc);
  void collectPredicatesWithPolarity(Stack<pair<unsigned,int> >& acc, int polarity=1);

  XMLElement toXML() const;

  
  vstring toString() const;
  vstring toStringInScopeOf(Connective con) const;
  static vstring toString(Connective con);
  bool parenthesesRequired(Connective outer) const;
  
  void destroy();

  unsigned weight() const;

  Color getColor();
  bool getSkip();

  static Formula* fromClause(Clause* cl);

  static Formula* quantify(Formula* f);

  static Formula* trueFormula();
  static Formula* falseFormula();

  static Formula* createITE(Formula* condition, Formula* thenArg, Formula* elseArg);
  static Formula* createLet(unsigned functor, Formula::VarList* variables, TermList body, Formula* contents);
  static Formula* createLet(unsigned predicate, Formula::VarList* variables, Formula* body, Formula* contents);

  
  CLASS_NAME(Formula);
  USE_ALLOCATOR(Formula);
protected:
  static vstring toString(const Formula* f);

 
  explicit Formula(Connective con)
    : _connective(con)
  {}

 
  Connective _connective;
  
  static vstring _connectiveNames[];
}; 

class NamedFormula
  : public Formula
{
public:
  explicit NamedFormula(vstring name) : Formula(NAME), _name(name) {}

  CLASS_NAME(NamedFormula);
  USE_ALLOCATOR(NamedFormula);

  vstring name(){ return _name; }
  const vstring name() const { return _name;}

protected:
  vstring _name;

}; 

class AtomicFormula
  : public Formula
{
public:
 
  explicit AtomicFormula (Literal* lit)
    : Formula(LITERAL),
      _literal(lit)
  {}
 
  const Literal* getLiteral() const { return _literal; }
 
  Literal* getLiteral() { return _literal; }

  
  CLASS_NAME(AtomicFormula);
  USE_ALLOCATOR(AtomicFormula);
protected:
 
  Literal* _literal;
}; 


class QuantifiedFormula
  : public Formula
{
 public:
 
  QuantifiedFormula(Connective con, VarList* vs, SortList* ss, Formula* arg)
    : Formula(con),
      _vars(vs),
      _sorts(ss),
      _arg(arg)
  {
    ASS(con == FORALL || con == EXISTS);
    ASS(vs);
    ASS(!ss || VarList::length(vs) == SortList::length(ss));
  }

 
  const Formula* subformula () const { return _arg; }
 
  Formula* subformula () { return _arg; }
 
  const VarList* varList() const { return _vars; }
 
  VarList* varList() { return _vars; }
 
  const SortList* sortList() const { return _sorts; }
 
  SortList* sortList() { return _sorts; }

  
  CLASS_NAME(QuantifiedFormula);
  USE_ALLOCATOR(QuantifiedFormula);
 protected:
 
  VarList* _vars;
 
  SortList* _sorts;
 
  Formula* _arg;
}; 

class NegatedFormula
  : public Formula
{
public:
 
  explicit NegatedFormula (Formula* f)
    : Formula(NOT),
      _arg(f)
  {}

 
  const Formula* subformula() const { return _arg; }
 
  Formula* subformula() { return _arg; }

  
  CLASS_NAME(NegatedFormula);
  USE_ALLOCATOR(NegatedFormula);
protected:
 
  Formula* _arg;
}; 


class BinaryFormula
  : public Formula
{
public:
 
  explicit BinaryFormula (Connective con,Formula* lhs,Formula* rhs)
    : Formula(con),
      _left(lhs),
      _right(rhs)
  {
    ASS(con == IFF || con == XOR || con == IMP);
  }

 
  const Formula* lhs() const { return _left; }
 
  Formula* lhs() { return _left; }
 
  const Formula* rhs() const { return _right; }
 
  Formula* rhs() { return _right; }

  
  CLASS_NAME(BinaryFormula);
  USE_ALLOCATOR(BinaryFormula);
protected:
 
  Formula* _left;
 
  Formula* _right;
}; 


class JunctionFormula
  : public Formula
{
 public:
  JunctionFormula (Connective con, FormulaList* args)
    : Formula(con),
      _args(args)
  {
    ASS(con == AND || con == OR);
    ASS_GE(FormulaList::length(args),2);
  }

 
  void setArgs(FormulaList* args) { _args = args; }

 
  const FormulaList* getArgs() const { return _args; }
 
  FormulaList* getArgs() { return _args; }
 
  FormulaList** getArgsPtr() { return &_args; }

  static Formula* generalJunction(Connective c, FormulaList* args);

  
  CLASS_NAME(JunctionFormula);
  USE_ALLOCATOR(JunctionFormula);
 protected:
 
  FormulaList* _args;
}; 


class BoolTermFormula
  : public Formula
{
 public:
  BoolTermFormula (TermList ts)
    : Formula(BOOL_TERM),
      _ts(ts)
  {
    
    ASS_REP(ts.isVar() || ts.term()->isITE() || ts.term()->isLet() || ts.term()->isTupleLet(), ts.toString());
  }

  static Formula* create(TermList ts) {
    if (ts.isVar()) {
      return new BoolTermFormula(ts);
    }

    Term* term = ts.term();
    if (term->isSpecial()) {
      Term::SpecialTermData *sd = term->getSpecialData();
      switch (sd->getType()) {
        case Term::SF_FORMULA:
          return sd->getFormula();
        default:
          return new BoolTermFormula(ts);
      }
    } else {
      unsigned functor = term->functor();
      if (env.signature->isFoolConstantSymbol(true, functor)) {
        return new Formula(true);
      } else {
        ASS(env.signature->isFoolConstantSymbol(false, functor));
        return new Formula(false);
      }
    }
  }

 
  const TermList getTerm() const { return _ts; }
  TermList getTerm() { return _ts; }

  
  CLASS_NAME(BoolTermFormula);
  USE_ALLOCATOR(BoolTermFormula);
 protected:
 
  TermList _ts;
}; 



inline
const Formula::VarList* Formula::vars() const
{
  ASS(_connective == FORALL || _connective == EXISTS);
  return static_cast<const QuantifiedFormula*>(this)->varList();
}
inline
Formula::VarList* Formula::vars()
{
  ASS(_connective == FORALL || _connective == EXISTS);
  return static_cast<QuantifiedFormula*>(this)->varList();
}

inline
const Formula::SortList* Formula::sorts() const
{
  ASS(_connective == FORALL || _connective == EXISTS);
  return static_cast<const QuantifiedFormula*>(this)->sortList();
}
inline
Formula::SortList* Formula::sorts()
{
  ASS(_connective == FORALL || _connective == EXISTS);
  return static_cast<QuantifiedFormula*>(this)->sortList();
}

inline
const Formula* Formula::qarg() const
{
  ASS(_connective == FORALL || _connective == EXISTS);
  return static_cast<const QuantifiedFormula*>(this)->subformula();
}
inline
Formula* Formula::qarg()
{
  ASS(_connective == FORALL || _connective == EXISTS);
  return static_cast<QuantifiedFormula*>(this)->subformula();
}

inline
const Formula* Formula::uarg() const
{
  ASS(_connective == NOT);
  return static_cast<const NegatedFormula*>(this)->subformula();
}

inline
Formula* Formula::uarg()
{
  ASS(_connective == NOT);
  return static_cast<NegatedFormula*>(this)->subformula();
}

inline
const FormulaList* Formula::args() const
{
  ASS(_connective == AND || _connective == OR);
  return static_cast<const JunctionFormula*>(this)->getArgs();
}

inline
FormulaList* Formula::args()
{
  ASS(_connective == AND || _connective == OR);
  return static_cast<JunctionFormula*>(this)->getArgs();
}

inline
FormulaList** Formula::argsPtr()
{
  ASS(_connective == AND || _connective == OR);
  return static_cast<JunctionFormula*>(this)->getArgsPtr();
}

inline
const Literal* Formula::literal() const
{
  ASS(_connective == LITERAL);
  return static_cast<const AtomicFormula*>(this)->getLiteral();
}

inline
Literal* Formula::literal()
{
  ASS(_connective == LITERAL);
  return static_cast<AtomicFormula*>(this)->getLiteral();
}

inline
const Formula* Formula::left() const
{
  ASS(_connective == IFF || _connective == XOR || _connective == IMP);
  return static_cast<const BinaryFormula*>(this)->lhs();
}
inline
Formula* Formula::left()
{
  ASS(_connective == IFF || _connective == XOR || _connective == IMP);
  return static_cast<BinaryFormula*>(this)->lhs();
}

inline
const Formula* Formula::right() const
{
  ASS(_connective == IFF || _connective == XOR || _connective == IMP);
  return static_cast<const BinaryFormula*>(this)->rhs();
}
inline
Formula* Formula::right()
{
  ASS(_connective == IFF || _connective == XOR || _connective == IMP);
  return static_cast<BinaryFormula*>(this)->rhs();
}

inline
const TermList Formula::getBooleanTerm() const
{
  ASS(_connective == BOOL_TERM);
  return static_cast<const BoolTermFormula*>(this)->getTerm();
}
inline
TermList Formula::getBooleanTerm()
{
  ASS(_connective == BOOL_TERM);
  return static_cast<BoolTermFormula*>(this)->getTerm();
}



std::ostream& operator<< (ostream& out, const Formula& f);
std::ostream& operator<< (ostream& out, const Formula* f);

}

#endif 

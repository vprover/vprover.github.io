
/*
 * File Formula.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Forwards.hpp"

#include "Debug/Tracer.hpp"

#include "Lib/Environment.hpp"
#include "Lib/Exception.hpp"
#include "Lib/Environment.hpp"
#include "Lib/MultiCounter.hpp"
#include "Lib/VString.hpp"
#include "Lib/Set.hpp"

#include "Kernel/Signature.hpp"
#include "Kernel/SortHelper.hpp"

#include "Shell/Options.hpp"

#include "Clause.hpp"
#include "Term.hpp"
#include "Formula.hpp"
#include "SubformulaIterator.hpp"
#include "FormulaVarIterator.hpp"

using namespace Lib;

namespace Kernel {


































void Formula::destroy ()
{
  CALL ("Formula::Data::destroy");
  

  switch ( connective() ) {
  case LITERAL:
    delete static_cast<AtomicFormula*>(this);
    return;

  case AND:
  case OR:
    delete static_cast<JunctionFormula*>(this);
    return;

  case IMP:
  case IFF:
  case XOR:
    delete static_cast<BinaryFormula*>(this);
    return;

  case NOT:
    delete static_cast<NegatedFormula*>(this);
    return;

  case FORALL:
  case EXISTS:
    delete static_cast<QuantifiedFormula*>(this);
    return;

  case BOOL_TERM:
    delete static_cast<BoolTermFormula*>(this);

  case TRUE:
  case FALSE:
    delete this;
    return;

  case NAME:
    delete static_cast<NamedFormula*>(this);
    return;

#if VDEBUG
  default:
    ASSERTION_VIOLATION;
    return;
#endif
  }
} 































































































vstring Formula::toString (Connective c)
{
  static vstring names [] =
    { "", "&", "|", "=>", "<=>", "<~>", "~", "!", "?", "$var", "$false", "$true", "",""};
  ASS_EQ(sizeof(names)/sizeof(vstring), NOCONN+1);

  return names[(int)c];
} 

vstring Formula::toString(const Formula* formula)
{
  CALL("Formula::toString(const Formula*)");

  vstring res;

  
  typedef struct {
    bool wrapInParenthesis;
    Connective renderConnective; 
    const Formula* theFormula;   
  } Todo;

  Stack<Todo> stack;
  stack.push({false,NOCONN,formula});

  while (stack.isNonEmpty()) {
    Todo todo = stack.pop();

    
    {
      vstring con = toString(todo.renderConnective);
      if (con != "") {
        res += " "+con+" ";
      }
    }

    const Formula* f = todo.theFormula;

    if (!f) {
      res += ")";
      continue;
    }

    if (todo.wrapInParenthesis) {
      res += "(";
      stack.push({false,NOCONN,nullptr}); 
    }

    Connective c = f->connective();
    switch (c) {
    case NAME:
      res += static_cast<const NamedFormula*>(f)->name();
      continue;
    case LITERAL:
      res += f->literal()->toString();
      continue;

    case AND:
    case OR:
      {
        
        

        const FormulaList* fs = f->args();
        ASS (FormulaList::length(fs) >= 2);

        while (FormulaList::isNonEmpty(fs)) {
          const Formula* arg = fs->head();
          fs = fs->tail();
          
          stack.push({arg->parenthesesRequired(c),FormulaList::isNonEmpty(fs) ? c : NOCONN,arg});
        }

        continue;
      }

    case IMP:
    case IFF:
    case XOR:
      

      stack.push({f->right()->parenthesesRequired(c),c,f->right()});      
      stack.push({f->left()->parenthesesRequired(c),NOCONN,f->left()}); 

      continue;

    case NOT:
      {
        res += toString(c);

        const Formula* arg = f->uarg();
        stack.push({arg->parenthesesRequired(c),NOCONN,arg});

        continue;
      }
    case FORALL:
    case EXISTS:
      {
        res += toString(c) + " [";
        VarList::Iterator vs(f->vars());
        SortList::Iterator ss(f->sorts());
        bool hasSorts = f->sorts();
        bool first=true;
        while (vs.hasNext()) {
          int var = vs.next();
          if (!first) {
            res += ",";
          }
          res += Term::variableToString(var);
          unsigned t;
          if (hasSorts) {
            ASS(ss.hasNext());
            t = ss.next();
            if (t != Sorts::SRT_DEFAULT) {
              res += " : " + env.sorts->sortName(t);
            }
          } else if (SortHelper::tryGetVariableSort(var, const_cast<Formula*>(f),t) && t != Sorts::SRT_DEFAULT) {
            res += " : " + env.sorts->sortName(t);
          }
          first = false;
        }
        res += "] : ";

        const Formula* arg = f->qarg();
        stack.push({arg->parenthesesRequired(c),NOCONN,arg});

        continue;
      }

    case BOOL_TERM: {
      vstring term = f->getBooleanTerm().toString();
      res += env.options->showFOOL() ? "$formula{" + term + "}" : term;

      continue;
    }

    case TRUE:
    case FALSE:
      res += toString(c);

      continue;
  #if VDEBUG
    default:
      ASSERTION_VIOLATION;
  #endif
  }
  }

  return res;
}

vstring Formula::toString () const
{
  CALL("Formula::toString");

  return toString(this);
} 

bool Formula::parenthesesRequired (Connective outer) const
{
  CALL("Formula::parenthesesRequired");

  switch (connective())
    {
    case LITERAL:
    case NOT:
    case FORALL:
    case EXISTS:
    case BOOL_TERM:
    case TRUE:
    case FALSE:
    case NAME:
      return false;

    case OR:
    case AND:
    case IMP:
    case IFF:
    case XOR:
      return true;

#if VDEBUG
    default:
      ASSERTION_VIOLATION;
      return false;
#endif
    }
} 


vstring Formula::toStringInScopeOf (Connective outer) const
{
  return parenthesesRequired(outer) ?
         vstring("(") + toString() + ")" :
         toString();
} 









































































Formula::VarList* Formula::freeVariables () const
{
  CALL("Formula::freeVariables");

  FormulaVarIterator fvi(this);
  VarList* result = VarList::empty();
  VarList::FIFO stack(result);
  while (fvi.hasNext()) {
    stack.push(fvi.next());
  }
  return result;
} 

Formula::VarList* Formula::boundVariables () const
{
  CALL("Formula::boundVariables");

  VarList* res = 0;
  SubformulaIterator sfit(const_cast<Formula*>(this));
  while(sfit.hasNext()) {
    Formula* sf = sfit.next();
    if(sf->connective() == FORALL || sf->connective() == EXISTS) {
      VarList* qvars = sf->vars();
      VarList* qvCopy = VarList::copy(qvars);
      res = VarList::concat(qvCopy, res);
    }
  }
  return res;
}

void Formula::collectAtoms(Stack<Literal*>& acc)
{
  CALL("Formula::collectPredicates");

  SubformulaIterator sfit(this);
  while(sfit.hasNext()) {
    Formula* sf = sfit.next();
    if(sf->connective()==LITERAL) {
      Literal* l = sf->literal();
      acc.push(Literal::positiveLiteral(l));
    }
  }
}

void Formula::collectPredicates(Stack<unsigned>& acc)
{
  CALL("Formula::collectPredicates");

  SubformulaIterator sfit(this);
  while(sfit.hasNext()) {
    Formula* sf = sfit.next();
    if(sf->connective()==LITERAL) {
      acc.push(sf->literal()->functor());
    }
  }
}

void Formula::collectPredicatesWithPolarity(Stack<pair<unsigned,int> >& acc, int polarity)
{
  CALL("Formula::collectPredicatesWithPolarity");

  switch (connective()) {
    case LITERAL:
    {
      Literal* l=literal();
      int pred = l->functor();
      acc.push(make_pair(pred, l->isPositive() ? polarity : -polarity));
      return;
    }

    case AND:
    case OR: {
      FormulaList::Iterator fs(args());
      while (fs.hasNext()) {
	fs.next()->collectPredicatesWithPolarity(acc,polarity);
      }
      return;
    }

    case IMP:
      left()->collectPredicatesWithPolarity(acc,-polarity);
      right()->collectPredicatesWithPolarity(acc,polarity);
      return;

    case NOT:
      uarg()->collectPredicatesWithPolarity(acc,-polarity);
      return;

    case IFF:
    case XOR:
      left()->collectPredicatesWithPolarity(acc,0);
      right()->collectPredicatesWithPolarity(acc,0);
      return;

    case FORALL:
    case EXISTS:
      qarg()->collectPredicatesWithPolarity(acc,polarity);
      return;

    case BOOL_TERM:
      ASSERTION_VIOLATION;

    case TRUE:
    case FALSE:
      return;

#if VDEBUG
    default:
      ASSERTION_VIOLATION;
      return;
#endif
  }
}


unsigned Formula::weight() const
{
  CALL("Formula::weight");

  unsigned result=0;

  SubformulaIterator fs(const_cast<Formula*>(this));
  while (fs.hasNext()) {
    const Formula* f = fs.next();
    switch (f->connective()) {
    case LITERAL:
      result += f->literal()->weight();
      break;
    default:
      result++;
      break;
    }
  }
  return result;
} 

Formula* JunctionFormula::generalJunction(Connective c, FormulaList* args)
{
  if(!args) {
    if(c==AND) {
      return new Formula(true);
    }
    else {
      ASS_EQ(c,OR);
      return new Formula(false);
    }
  }
  if(!args->tail()) {
    return FormulaList::pop(args);
  }
  return new JunctionFormula(c, args);
}

Color Formula::getColor()
{
  CALL("Formula::getColor");

  SubformulaIterator si(this);
  while(si.hasNext()) {
    Formula* f=si.next();
    if(f->connective()!=LITERAL) {
      continue;
    }

    if(f->literal()->color()!=COLOR_TRANSPARENT) {
      return f->literal()->color();
    }
  }
  return COLOR_TRANSPARENT;
}

bool Formula::getSkip()
{
  CALL("Formula::getColor");

  SubformulaIterator si(this);
  while(si.hasNext()) {
    Formula* f=si.next();
    if(f->connective()!=LITERAL) {
      continue;
    }

    if(!f->literal()->skip()) {
      return false;
    }
  }
  return true;
}

Formula* Formula::trueFormula()
{
  CALL("Formula::trueFormula");

  static Formula* res = new Formula(true);
  return res;
}

Formula* Formula::falseFormula()
{
  CALL("Formula::falseFormula");

  static Formula* res = new Formula(false);
  return res;
}

Formula* Formula::createITE(Formula* condition, Formula* thenArg, Formula* elseArg)
{
  CALL("Formula::createITE");
  TermList thenTerm(Term::createFormula(thenArg));
  TermList elseTerm(Term::createFormula(elseArg));
  TermList iteTerm(Term::createITE(condition, thenTerm, elseTerm, Sorts::SRT_BOOL));
  return new BoolTermFormula(iteTerm);
}

Formula* Formula::createLet(unsigned functor, Formula::VarList* variables, TermList body, Formula* contents)
{
  CALL("Formula::createLet(TermList)");
  TermList contentsTerm(Term::createFormula(contents));
  TermList letTerm(Term::createLet(functor, variables, body, contentsTerm, Sorts::SRT_BOOL));
  return new BoolTermFormula(letTerm);
}

Formula* Formula::createLet(unsigned predicate, Formula::VarList* variables, Formula* body, Formula* contents)
{
  CALL("Formula::createLet(Formula*)");
  TermList bodyTerm(Term::createFormula(body));
  TermList contentsTerm(Term::createFormula(contents));
  TermList letTerm(Term::createLet(predicate, variables, bodyTerm, contentsTerm, Sorts::SRT_BOOL));
  return new BoolTermFormula(letTerm);
}

Formula* Formula::quantify(Formula* f)
{
  Set<unsigned> vars;
  FormulaVarIterator fvit( f );
  while(fvit.hasNext()) {
    vars.insert(fvit.next());
  }

  
  VarList* varLst=0;
  Set<unsigned>::Iterator vit(vars);
  while(vit.hasNext()) {
    VarList::push(vit.next(), varLst);
  }
  if(varLst) {
    
    f=new QuantifiedFormula(FORALL, varLst, 0, f);
  }
  return f;
}


Formula* Formula::fromClause(Clause* cl)
{
  CALL("Formula::fromClause");
  
  FormulaList* resLst=0;
  unsigned clen=cl->length();
  for(unsigned i=0;i<clen;i++) {
    Formula* lf=new AtomicFormula((*cl)[i]);
    FormulaList::push(lf, resLst);
  }

  Formula* res=JunctionFormula::generalJunction(OR, resLst);
  
  Set<unsigned> vars;
  FormulaVarIterator fvit( res );
  while(fvit.hasNext()) {
    vars.insert(fvit.next());
  }

  
  VarList* varLst=0;
  Set<unsigned>::Iterator vit(vars);
  while(vit.hasNext()) {
    VarList::push(vit.next(), varLst);
  }
  if(varLst) {
    
    res=new QuantifiedFormula(FORALL, varLst, 0, res);
  }

  return res;
}


std::ostream& operator<< (ostream& out, const Formula& f)
{
  CALL("operator <<(ostream&, const Formula&)");
  return out << f.toString();
}

std::ostream& operator<< (ostream& out, const Formula* f)
{
  CALL("operator <<(ostream&, const Formula&)");
  return out << f->toString();
}

}

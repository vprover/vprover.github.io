
/*
 * File Clause.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include <ostream>

#include "Debug/RuntimeStatistics.hpp"

#include "Lib/Allocator.hpp"
#include "Lib/DArray.hpp"
#include "Lib/Environment.hpp"
#include "Lib/Int.hpp"
#include "Lib/SharedSet.hpp"
#include "Lib/Stack.hpp"
#include "Lib/BitUtils.hpp"

#include "Saturation/ClauseContainer.hpp"

#include "SAT/SATClause.hpp"

#include "Shell/Options.hpp"

#include "Inference.hpp"
#include "Signature.hpp"
#include "Term.hpp"
#include "TermIterators.hpp"

#include "Clause.hpp"

#undef RSTAT_COLLECTION
#define RSTAT_COLLECTION 1

namespace Kernel
{

using namespace Lib;
using namespace Saturation;
using namespace Shell;

size_t Clause::_auxCurrTimestamp = 0;
#if VDEBUG
bool Clause::_auxInUse = false;
#endif


Clause::Clause(unsigned length,InputType it,Inference* inf)
  : Unit(Unit::CLAUSE,inf,it),
    _length(length),
    _color(COLOR_INVALID),
    _input(0),
    _extensionality(false),
    _extensionalityTag(false),
    _component(false),
    _theoryDescendant(false),
    _numSelected(0),
    _age(0),
    _weight(0),
    _store(NONE),
    _in_active(0),
    _refCnt(0),
    _reductionTimestamp(0),
    _literalPositions(0),
    _splits(0),
    _numActiveSplits(0),
    _auxTimestamp(0)
{

  if(it == Unit::EXTENSIONALITY_AXIOM){
    
    _extensionalityTag = true;
    setInputType(Unit::AXIOM);
  }
  static bool hasTheoryAxioms = env.options->theoryAxioms() != Options::TheoryAxiomLevel::OFF;
  if(hasTheoryAxioms){
    Inference::Iterator it = inf->iterator();
    bool td = inf->hasNext(it); 
    while(inf->hasNext(it) && td){
      Unit* parent = inf->next(it);
      if(parent->isClause()){
        td &= static_cast<Clause*>(parent)->isTheoryDescendant();
        if(!td){break;}
      }
      else{
        
        
        td = false;
      }
    }
    _theoryDescendant=td;
  }


_freeze_count=0;

}

void* Clause::operator new(size_t sz, unsigned lits)
{
  CALL("Clause::operator new");
  ASS_EQ(sz,sizeof(Clause));

  RSTAT_CTR_INC("clauses created");

  
  
  
  size_t size = sizeof(Clause) + lits * sizeof(Literal*);
  size -= sizeof(Literal*);

  return ALLOC_KNOWN(size,"Clause");
}

void Clause::operator delete(void* ptr,unsigned length)
{
  CALL("Clause::operator delete");

  RSTAT_CTR_INC("clauses deleted by delete operator");

  
  
  
  size_t size = sizeof(Clause) + length * sizeof(Literal*);
  size -= sizeof(Literal*);

  DEALLOC_KNOWN(ptr, size,"Clause");
}

void Clause::destroyExceptInferenceObject()
{
  if (_literalPositions) {
    delete _literalPositions;
  }

  RSTAT_CTR_INC("clauses deleted");

  
  
  
  size_t size = sizeof(Clause) + _length * sizeof(Literal*);
  size -= sizeof(Literal*);

  DEALLOC_KNOWN(this, size,"Clause");
}


Clause* Clause::fromStack(const Stack<Literal*>& lits, InputType it, Inference* inf)
{
  CALL("Clause::fromStack");

  unsigned clen = lits.size();
  Clause* res = new (clen) Clause(clen, it, inf);

  for(unsigned i = 0; i < clen; i++) {
    (*res)[i] = lits[i];
  }

  return res;
}

Clause* Clause::fromClause(Clause* c)
{
  CALL("Clause::fromClause");

  Inference* inf = new Inference1(Inference::REORDER_LITERALS, c);
  Clause* res = fromIterator(Clause::Iterator(*c), c->inputType(), inf);

  res->setAge(c->age());
  
  res->setSplits(c->splits());

  return res;
}

bool Clause::shouldBeDestroyed()
{
  return (_store == NONE) && _refCnt == 0 &&
    !isFromPreprocessing();
}

void Clause::destroyIfUnnecessary()
{
  if (shouldBeDestroyed()) {
    destroy();
  }
}

void Clause::destroy()
{
  CALL("Clause::destroy");

  static Stack<Clause*> toDestroy(32);
  Clause* cl = this;
  for(;;) {
    Inference::Iterator it = cl->_inference->iterator();
    while (cl->_inference->hasNext(it)) {
      Unit* refU = cl->_inference->next(it);
      if (!refU->isClause()) {
	continue;
      }
      Clause* refCl = static_cast<Clause*> (refU);
      refCl->_refCnt--;
      if (refCl->shouldBeDestroyed()) {
	toDestroy.push(refCl);
      }
    }
    delete cl->_inference;
    cl->destroyExceptInferenceObject();
    if (toDestroy.isEmpty()) {
      break;
    }
    cl = toDestroy.pop();
  }
} 

void Clause::setStore(Store s)
{
  CALL("Clause::setStore");

#if VDEBUG
  
  static Clause* selected=0;
  if (_store==SELECTED) {
    ASS_EQ(selected, this);
    selected=0;
  }
  if (s==SELECTED) {
    ASS_EQ(selected, 0);
    selected=this;
  }
#endif
  _store = s;
  destroyIfUnnecessary();
}

bool Clause::isGround()
{
  CALL("Clause::isGround");

  Iterator it(*this);
  while (it.hasNext()) {
    if (!it.next()->ground()) {
      return false;
    }
  }
  return true;
}

bool Clause::isPropositional()
{
  CALL("Clause::isPropositional");

  Iterator it(*this);
  while (it.hasNext()) {
    if (it.next()->arity() > 0) {
      return false;
    }
  }
  return true;
}

bool Clause::isHorn()
{
  CALL("Clause::isHorn");

  bool posFound=false;
  Iterator it(*this);
  while (it.hasNext()) {
    if (it.next()->isPositive()) {
      if (posFound) {
        return false;
      }
      else {
        posFound=true;
      }
    }
  }
  return true;
}

VirtualIterator<unsigned> Clause::getVariableIterator()
{
  CALL("Clause::getVariableIterator");

  return pvi( getUniquePersistentIterator(
      getMappingIterator(
	  getMapAndFlattenIterator(
	      Iterator(*this),
	      VariableIteratorFn()),
	  OrdVarNumberExtractorFn())));
}

bool Clause::noSplits() const
{
  CALL("Clause::noSplits");

  return !this->splits() || this->splits()->isEmpty();
}

vstring Clause::literalsOnlyToString() const
{
  CALL("Clause::literalsOnlyToString");

  if (_length == 0) {
    return "$false";
  } else {
    vstring result;
    result += _literals[0]->toString();
    for(unsigned i = 1; i < _length; i++) {
      result += " | ";
      result += _literals[i]->toString();
    }
    return result;
  }
}

vstring Clause::toTPTPString() const
{
  CALL("Clause::toTPTPString()");

  vstring result = literalsOnlyToString();

  return result;
}

vstring Clause::toNiceString() const
{
  CALL("Clause::toNiceString()");

  vstring result = literalsOnlyToString();

  if (splits() && !splits()->isEmpty()) {
    result += vstring(" {") + splits()->toString() + "}";
  }

  return result;
}

vstring Clause::toString() const
{
  CALL("Clause::toString()");

  vstring result = Int::toString(_number) + ". " + literalsOnlyToString();

  if (splits() && !splits()->isEmpty()) {
    result += vstring(" {") + splits()->toString() + "}";
  }

  if (env.colorUsed) {
    result += " C" + Int::toString(color()) + " ";
  }

  result += vstring(" (") + Int::toString(_age) + ':' + Int::toString(weight());
  float ew = const_cast<Clause*>(this)->getEffectiveWeight(const_cast<Shell::Options&>(*(env.options)));
  unsigned effective = static_cast<int>(ceil(ew));
  if(effective!=weight()){
    result += "["+Int::toString(effective)+"]";
  }
  if (numSelected()>0) {
    result += ':' + Int::toString(numSelected());
  }
  result += ") ";
  if(isTheoryDescendant()){
    result += "T ";
  }
  result +=  inferenceAsString();
  return result;
}


VirtualIterator<vstring> Clause::toSimpleClauseStrings()
{
  CALL("toSimpleClauseStrings");
    return pvi(getSingletonIterator(literalsOnlyToString()));

}

bool Clause::skip() const
{
  unsigned clen = length();
  for(unsigned i = 0; i < clen; i++) {
    const Literal* lit = (*this)[i];
    if (!lit->skip()) {
      return false;
    }
  }
  return true;
}

void Clause::computeColor() const
{
  CALL("Clause::computeColor");
  ASS_EQ(_color, COLOR_INVALID);

  Color color = COLOR_TRANSPARENT;

  if (env.colorUsed) {
    unsigned clen=length();
    for(unsigned i=0;i<clen;i++) {
      color = static_cast<Color>(color | (*this)[i]->color());
    }
    ASS_L(color, COLOR_INVALID);
  }

  _color=color;
}

void Clause::computeWeight() const
{
  CALL("Clause::computeWeight");

  _weight = 0;
  for (int i = _length-1; i >= 0; i--) {
    ASS(_literals[i]->shared());
    _weight += _literals[i]->weight();
  }

  
  
  
  
  if (env.options->nonliteralsInClauseWeight()) {
    _weight+=splitWeight(); 
  }

  
  if(_weight){
    unsigned priority = getPriority();
    _weight *= priority;
  }

} 


unsigned Clause::splitWeight() const
{
  return splits() ? splits()->size() : 0;
}

unsigned Clause::getNumeralWeight() 
{
  CALL("Clause::getNumeralWeight");

  unsigned res=0;
  Iterator litIt(*this);
  while (litIt.hasNext()) {
    Literal* lit=litIt.next();
    if (!lit->hasInterpretedConstants()) {
      continue;
    }
    NonVariableIterator nvi(lit);
    while (nvi.hasNext()) {
      const Term* t = nvi.next().term();
      if (t->arity() != 0) {
	continue;
      }
      IntegerConstantType intVal;
      if (theory->tryInterpretConstant(t,intVal)) {
	int w = BitUtils::log2(abs(intVal.toInner()))-1;
	if (w > 0) {
	  res += w;
	}
	continue;
      }
      RationalConstantType ratVal;
      RealConstantType realVal;
      bool haveRat = false;
      if (theory->tryInterpretConstant(t,ratVal)) {
	haveRat = true;
      }
      else if (theory->tryInterpretConstant(t,realVal)) {
	ratVal = RationalConstantType(realVal);
	haveRat = true;
      }
      if (!haveRat) {
	continue;
      }
      int wN = BitUtils::log2(abs(ratVal.numerator().toInner()))-1;
      int wD = BitUtils::log2(abs(ratVal.denominator().toInner()))-1;
      int v = wN + wD;
      if (v > 0) {
	res += v;
      }
    }
  }
  return res;
} 

float Clause::getEffectiveWeight(const Options& opt) 
{
  CALL("Clause::getEffectiveWeight");

  static float nongoalWeightCoef=opt.nongoalWeightCoefficient();

  unsigned w=weight();
  
  
  
  
  if (opt.increasedNumeralWeight()) {
    return (2*w+getNumeralWeight()) * ( (inputType()==0) ? nongoalWeightCoef : 1.0f);
  }
  else {
    return w * ( (inputType()==0) ? nongoalWeightCoef : 1.0f);
  }
}

void Clause::collectVars(DHSet<unsigned>& acc)
{
  CALL("Clause::collectVars");

  Iterator it(*this);
  while (it.hasNext()) {
    Literal* lit = it.next();
    VariableIterator vit(lit);
    while (vit.hasNext()) {
      TermList var = vit.next();
      ASS(var.isOrdinaryVar());
      acc.insert(var.var());
    }
  }
}

unsigned Clause::varCnt()
{
  CALL("Clause::varCnt");

  static DHSet<unsigned> vars;
  vars.reset();
  collectVars(vars);
  return vars.size();
}

unsigned Clause::maxVar()
{
  CALL("Clause::maxVar()");
  
  unsigned max = 0;
  VirtualIterator<unsigned> it = getVariableIterator();

  while (it.hasNext()) {
    unsigned n = it.next();
    max = n > max ? n : max;
  }
  return max;
}

unsigned Clause::getLiteralPosition(Literal* lit)
{
  switch(length()) {
  case 1:
    ASS_EQ(lit,(*this)[0]);
    return 0;
  case 2:
    if (lit==(*this)[0]) {
      return 0;
    } else {
      ASS_EQ(lit,(*this)[1]);
      return 1;
    }
  case 3:
    if (lit==(*this)[0]) {
      return 0;
    } else if (lit==(*this)[1]) {
      return 1;
    } else {
      ASS_EQ(lit,(*this)[2]);
      return 2;
    }
#if VDEBUG
  case 0:
    ASSERTION_VIOLATION;
#endif
  default:
    if (!_literalPositions) {
      _literalPositions=new InverseLookup<Literal>(_literals,length());
    }
    return static_cast<unsigned>(_literalPositions->get(lit));
  }
}

void Clause::notifyLiteralReorder()
{
  CALL("Clause::notifyLiteralReorder");
  if (_literalPositions) {
    _literalPositions->update(_literals);
  }
}

#if VDEBUG

void Clause::assertValid()
{
  ASS_ALLOC_TYPE(this, "Clause");
  if (_literalPositions) {
    unsigned clen=length();
    for (unsigned i = 0; i<clen; i++) {
      ASS_EQ(getLiteralPosition((*this)[i]),i);
    }
  }
}

bool Clause::contains(Literal* lit)
{
  for (int i = _length-1; i >= 0; i--) {
    if (_literals[i]==lit) {
      return true;
    }
  }
  return false;
}

#endif

}

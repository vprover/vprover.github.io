
/*
 * File FormulaVarIterator.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __FormulaVarIterator__
#define __FormulaVarIterator__

#include "Lib/MultiCounter.hpp"
#include "Lib/Stack.hpp"

#include "Kernel/Term.hpp"
#include "Kernel/Formula.hpp"

using namespace Lib;

namespace Kernel {

class FormulaVarIterator
{
public:
  explicit FormulaVarIterator(const Formula*);
  explicit FormulaVarIterator(const Term*);
  explicit FormulaVarIterator(const TermList*);

  bool hasNext();
  int next();

private:
 
  enum Instruction {
   
    FVI_FORMULA,
   
    FVI_TERM,
   
    FVI_TERM_LIST,
   
    FVI_BIND,
   
    FVI_UNBIND,
  };

 
  bool _found;
 
  unsigned _nextVar;

 
  MultiCounter _bound;
 
  MultiCounter _free;
 
  Stack<const Formula*> _formulas;
 
  Stack<const Term*> _terms;
 
  Stack<TermList> _termLists;
 
  Stack<Instruction> _instructions;
 
  Stack<const Formula::VarList*> _vars;
}; 

}

#endif 

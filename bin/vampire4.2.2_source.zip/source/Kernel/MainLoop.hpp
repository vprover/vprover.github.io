
/*
 * File MainLoop.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __MainLoop__
#define __MainLoop__

#include "Forwards.hpp"

#include "Lib/Environment.hpp"
#include "Lib/Exception.hpp"

#include "Shell/Statistics.hpp"

#include "Lib/Allocator.hpp"

namespace Shell {
  class Property;
};

namespace Kernel {

using namespace Lib;
using namespace Inferences;
using namespace Shell;

struct MainLoopResult
{
  typedef Statistics::TerminationReason TerminationReason;

  MainLoopResult(TerminationReason reason)
  : terminationReason(reason), saturatedSet(0) {}
  MainLoopResult(TerminationReason reason, Clause* ref)
  : terminationReason(reason), refutation(ref), saturatedSet(0) {}

  void updateStatistics();

  TerminationReason terminationReason;
  Clause* refutation;
  UnitList* saturatedSet;
};



class MainLoop {
public:  
  CLASS_NAME(MainLoop);
  USE_ALLOCATOR(MainLoop);

  MainLoop(Problem& prb, const Options& opt) : _prb(prb), _opt(opt) {}
  virtual ~MainLoop() {}


  MainLoopResult run();
  static MainLoop* createFromOptions(Problem& prb, const Options& opt);

 
  struct RefutationFoundException : public ThrowableBase
  {
    RefutationFoundException(Clause* ref) : refutation(ref)
    {
      CALL("MainLoop::RefutationFoundException::RefutationFoundException");
      ASS(isRefutation(ref));
    }

    Clause* refutation;
  };

 
  struct MainLoopFinishedException : public ThrowableBase
  {
    MainLoopFinishedException(const MainLoopResult& res) : result(res)
    {
    }

    MainLoopResult result;
  };

 
  const Problem& getProblem() const { return _prb; }
  Problem& getProblem() { return _prb; }

 
  const Options& getOptions() const { return _opt; }

  static bool isRefutation(Clause* cl);
protected:
  static ImmediateSimplificationEngine* createISE(Problem& prb, const Options& opt);

 
  virtual void init() = 0;

 
  virtual MainLoopResult runImpl() = 0;

  Problem& _prb;

 
  const Options& _opt;
};

}

#endif 

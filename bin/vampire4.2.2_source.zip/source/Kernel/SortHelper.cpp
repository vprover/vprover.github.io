
/*
 * File SortHelper.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Lib/Environment.hpp"

#include "Clause.hpp"
#include "FormulaUnit.hpp"
#include "Signature.hpp"
#include "Sorts.hpp"
#include "SubformulaIterator.hpp"
#include "Term.hpp"
#include "TermIterators.hpp"

#include "SortHelper.hpp"

using namespace Kernel;

BaseType& SortHelper::getType(Term* t)
{
  CALL("SortHelper::getType(Term*)");

  if (t->isLiteral()) {
    return *(env.signature->getPredicate(t->functor())->predType());
  }
  return *env.signature->getFunction(t->functor())->fnType();
} 

unsigned SortHelper::getResultSort(const Term* t)
{
  CALL("SortHelper::getResultSort(Term*)");
  ASS(!t->isSpecial());
  ASS(!t->isLiteral());

  Signature::Symbol* sym = env.signature->getFunction(t->functor());
  return sym->fnType()->result();
}

bool SortHelper::tryGetResultSort(const Term* t, unsigned& result)
{
  CALL("tryGetResultSort(Term*,unsigned&)");
  ASS(!t->isLiteral());

  TermList masterVar;
  return getResultSortOrMasterVariable(t, result, masterVar);
}

bool SortHelper::tryGetResultSort(const TermList t, unsigned& result)
{
  CALL("tryGetResultSort(TermList,unsigned&)");
  if (t.isVar()) {
    return false;
  }
  return tryGetResultSort(t.term(), result);
}

unsigned SortHelper::getResultSort(TermList t, DHMap<unsigned,unsigned>& varSorts)
{
  CALL("SortHelper::getResultSort");

  unsigned res;
  TermList masterVar;
  if (!getResultSortOrMasterVariable(t, res, masterVar)) {
    ASS(masterVar.isOrdinaryVar());
    res = varSorts.get(masterVar.var());
  }
  return res;
}

bool SortHelper::getResultSortOrMasterVariable(const Term* t, unsigned& resultSort, TermList& resultVar)
{
  CALL("SortHelper::getResultSortOrMasterVariable");

  switch(t->functor()) {
    case Term::SF_LET:
    case Term::SF_LET_TUPLE:
    case Term::SF_ITE:
      resultSort = t->getSpecialData()->getSort();
      return true;
    case Term::SF_FORMULA:
      resultSort = Sorts::SRT_BOOL;
      return true;
    case Term::SF_TUPLE: {
      resultSort = getResultSort(t->getSpecialData()->getTupleTerm());
      return true;
    }
    default:
      ASS(!t->isSpecial());
      resultSort = getResultSort(t);
      return true;
  }
} 

bool SortHelper::getResultSortOrMasterVariable(const TermList t, unsigned& resultSort, TermList& resultVar)
{
  CALL("SortHelper::getResultSortOrMasterVariable");

  if (t.isVar()) {
    resultVar = t;
    return false;
  }
  return getResultSortOrMasterVariable(t.term(), resultSort, resultVar);
}

unsigned SortHelper::getArgSort(Term* t, unsigned argIndex)
{
  CALL("SortHelper::getArgSort(Term*,unsigned)");
  ASS_L(argIndex, t->arity());

  if (t->isLiteral() && static_cast<Literal*>(t)->isEquality()) {
    return getEqualityArgumentSort(static_cast<Literal*>(t));
  }

  return getType(t).arg(argIndex);
} 

unsigned SortHelper::getEqualityArgumentSort(const Literal* lit)
{
  CALL("SortHelper::getEqualityArgumentSort");
  ASS(lit->isEquality());

  if (lit->isTwoVarEquality()) {
    return lit->twoVarEqSort();
  }

  TermList arg1 = *lit->nthArgument(0);
  unsigned srt1;
  if (tryGetResultSort(arg1, srt1)) {
    return srt1;
  }

  TermList arg2 = *lit->nthArgument(1);
  unsigned srt2;
  ALWAYS(tryGetResultSort(arg2, srt2));
  return srt2;
} 

unsigned SortHelper::getTermSort(TermList trm, Literal* lit)
{
  CALL("SortHelper::getTermSort");

  if (trm.isTerm()) {
    return getResultSort(trm.term());
  }
  ASS(trm.isVar());
  return getVariableSort(trm, lit);
}

unsigned SortHelper::getVariableSort(TermList var, Term* t)
{
  CALL("SortHelper::getVariableSort(TermList,Term*)");

  unsigned res;
  ALWAYS(tryGetVariableSort(var, t, res));
  return res;
}

bool SortHelper::tryGetVariableSort(unsigned var, Formula* f, unsigned& res)
{
  CALL("SortHelper::tryGetVariableSort(unsigned,Formula*,unsigned&)");

  TermList varTerm(var, false);

  SubformulaIterator sfit(f);
  while (sfit.hasNext()) {
    Formula* sf = sfit.next();
    if (sf->connective() == LITERAL){

      Literal* lit = sf->literal();

      
      if(lit->isEquality()){
         TermList* left = lit->nthArgument(0);
         TermList* right = lit->nthArgument(1);
         if((left->isVar() && left->var()==var) ||
            (right->isVar() && right->var()==var)){

           res = getEqualityArgumentSort(lit); 
           return true;
         }
      }
      if(tryGetVariableSort(varTerm, lit, res)){
        return true;
      }
    }
    if(sf->connective() == BOOL_TERM){
      TermList stt = sf->getBooleanTerm();
      if(stt.isVar() && stt.var()==var){
        res = Sorts::SRT_BOOL;
        return true;
      }
      if(stt.isTerm()){
        Term* st = stt.term();
        if(tryGetVariableSort(varTerm,st,res)){
          return true;
        } 
      }
    } 
  }
  return false;
}


void SortHelper::collectVariableSortsIter(CollectTask task, DHMap<unsigned,unsigned>& map)
{
  CALL("SortHelper::collectVariableSortsIter");

  Stack<CollectTask> todo;

  todo.push(task);
  while (todo.isNonEmpty()) {
    CollectTask task = todo.pop();

    switch(task.fncTag) {
      case COLLECT_TERM: {
        Term* term = task.t;

        unsigned position = 0;
        for (TermList* ts = term->args(); ts->isNonEmpty(); ts = ts->next()) {
          CollectTask newTask;
          newTask.fncTag = COLLECT_TERMLIST;
          newTask.ts = *ts;
          newTask.contextSort = getArgSort(term, position++);
          todo.push(newTask);
        }

      } break;

      case COLLECT_TERMLIST: {
        TermList ts = task.ts;

        if (ts.isTerm()) {
          Term* term = ts.term();

          CollectTask newTask;
          newTask.t = term;
          newTask.contextSort = task.contextSort;

          if (term->isSpecial()) {
            newTask.fncTag = COLLECT_SPECIALTERM;
            todo.push(newTask);
          } else {
            newTask.fncTag = COLLECT_TERM;
            todo.push(newTask);
          }
        } else if (ts.isOrdinaryVar()) {
          unsigned var = ts.var();
          if (!map.insert(var, task.contextSort)) {
            ASS_EQ(task.contextSort, map.get(var));
          }
        }

      } break;

      case COLLECT_SPECIALTERM: {
        Term* term = task.t;

        ASS(term->isSpecial());

        Term::SpecialTermData* sd = term->getSpecialData();

        switch (term->functor()) {
          case Term::SF_ITE: {
            CollectTask newTask;

            newTask.fncTag = COLLECT_TERMLIST;
            newTask.contextSort = task.contextSort;

            newTask.ts = *term->nthArgument(0);
            todo.push(newTask);

            newTask.ts = *term->nthArgument(1);
            todo.push(newTask);

            newTask.fncTag = COLLECT_FORMULA;
            newTask.f = sd->getCondition();
            todo.push(newTask);

            break;
          }

          case Term::SF_LET: {
            TermList binding = sd->getBinding();
            bool isPredicate = binding.isTerm() && binding.term()->isBoolean();
            Signature::Symbol* symbol = isPredicate ? env.signature->getPredicate(sd->getFunctor())
                                                    : env.signature->getFunction(sd->getFunctor());
            unsigned position = 0;
            Formula::VarList::Iterator vit(sd->getVariables());
            while (vit.hasNext()) {
              unsigned var = (unsigned)vit.next();
              unsigned sort = isPredicate ? symbol->predType()->arg(position) : symbol->fnType()->arg(position);
              if (!map.insert(var, sort)) {
                ASS_EQ(sort, map.get(var));
              }
              position++;
            }

            CollectTask newTask;

            newTask.fncTag = COLLECT_TERMLIST;
            newTask.contextSort = task.contextSort;

            newTask.ts = *term->nthArgument(0);
            todo.push(newTask);

            newTask.ts = binding;
            if (!isPredicate) {
              newTask.contextSort = symbol->fnType()->result();
            }
            todo.push(newTask);

            break;
          }

          case Term::SF_LET_TUPLE: {
            TermList binding = sd->getBinding();
            Signature::Symbol* symbol = env.signature->getFunction(sd->getFunctor());

            CollectTask newTask;
            newTask.fncTag = COLLECT_TERMLIST;
            newTask.contextSort = task.contextSort;
            newTask.ts = *term->nthArgument(0);
            todo.push(newTask);

            newTask.contextSort = symbol->fnType()->result();
            newTask.ts = binding;
            todo.push(newTask);

            break;
          }

          case Term::SF_FORMULA: {
            CollectTask newTask;
            newTask.fncTag = COLLECT_FORMULA;
            newTask.f = sd->getFormula();
            todo.push(newTask);
          } break;

          case Term::SF_TUPLE: {
            CollectTask newTask;
            newTask.fncTag = COLLECT_TERM;
            newTask.t = sd->getTupleTerm();
            todo.push(newTask);
          } break;

      #if VDEBUG
          default:
            ASSERTION_VIOLATION;
      #endif
        }
      } break;

      case COLLECT_FORMULA: {
        Formula* f = task.f;

        SubformulaIterator sfit(f);
        while (sfit.hasNext()) {
          Formula* sf = sfit.next();
          switch (sf->connective()) {
            case LITERAL: {
              CollectTask newTask;
              newTask.fncTag = COLLECT_TERM;
              newTask.t = sf->literal();

              todo.push(newTask);
            } break;

            case BOOL_TERM: {
              TermList ts = sf->getBooleanTerm();
              if (ts.isVar()) {
                if (!map.insert(ts.var(), Sorts::SRT_BOOL)) {
                  ASS_EQ(Sorts::SRT_BOOL, map.get(ts.var()));
                }
              } else {
                ASS(ts.isTerm() && ts.term()->isSpecial());

                CollectTask newTask;
                newTask.fncTag = COLLECT_SPECIALTERM;
                newTask.t = ts.term();
                newTask.contextSort = Sorts::SRT_BOOL;

                todo.push(newTask);
              }
              break;
            }

            default:
              continue;
          }
        }

      } break;
    }
  }
}

void SortHelper::collectVariableSorts(Term* term, DHMap<unsigned,unsigned>& map)
{
  CALL("SortHelper::collectVariableSorts(Term*,...)");

  CollectTask t;
  t.fncTag = COLLECT_TERM;
  t.t = term;

  collectVariableSortsIter(t,map);

 

} 

void SortHelper::collectVariableSorts(TermList ts, unsigned contextSort, DHMap<unsigned,unsigned>& map)
{
  CALL("SortHelper::collectVariableSorts(TermList,...)");

  CollectTask t;
  t.fncTag = COLLECT_TERMLIST;
  t.ts = ts;
  t.contextSort = contextSort;

  collectVariableSortsIter(t,map);

 
} 

void SortHelper::collectVariableSortsSpecialTerm(Term* term, unsigned contextSort, DHMap<unsigned,unsigned>& map) {
  CALL("SortHelper::collectVariableSortsSpecialTerm(Term*,...)");

  CollectTask task;
  task.fncTag = COLLECT_SPECIALTERM;
  task.t = term;
  task.contextSort = contextSort;

  collectVariableSortsIter(task,map);

 
} 

void SortHelper::collectVariableSorts(Formula* f, DHMap<unsigned,unsigned>& map)
{
  CALL("SortHelper::collectVariableSorts(Formula*,...)");

  CollectTask task;
  task.fncTag = COLLECT_FORMULA;
  task.f = f;

  collectVariableSortsIter(task,map);

 
}

void SortHelper::collectVariableSorts(Unit* u, DHMap<unsigned,unsigned>& map)
{
  CALL("SortHelper::collectVariableSorts(Unit*,...)");

  if (!u->isClause()) {
    FormulaUnit* fu = static_cast<FormulaUnit*>(u);

    CollectTask task;
    task.fncTag = COLLECT_FORMULA;
    task.f = fu->formula();

    collectVariableSortsIter(task,map);

    return;
  }

  Clause* cl = static_cast<Clause*>(u);
  Clause::Iterator cit(*cl);
  while (cit.hasNext()) {
    Literal* l = cit.next();

    CollectTask task;
    task.fncTag = COLLECT_TERM;
    task.t = l;

    collectVariableSortsIter(task,map);
  }
}

bool SortHelper::tryGetVariableSort(TermList var, Term* t0, unsigned& result)
{
  CALL("SortHelper::tryGetVariableSort");
  ASS(var.isVar());

  NonVariableIterator sit(t0,true);
  while (sit.hasNext()) {
    Term* t = sit.next().term();
    if(t->isLet()){
      TermList binding = t->getSpecialData()->getBinding();
      if(binding.isVar()) {
        if ( binding == var) {
          
          unsigned f = t->getSpecialData()->getFunctor();
          Signature::Symbol* sym = env.signature->getFunction(f);
          return sym->fnType()->result();
        }
      } else if(tryGetVariableSort(var,binding.term(),result)){
        return true;
      }

      ASS_EQ(t->arity(),1);
      if (*t->nthArgument(0) == var) {
        result = t->getSpecialData()->getSort();
        return true;
      }

      continue;
    }
    if (t->isITE()) {
      
      ASS_EQ(t->arity(),2);
      if (*t->nthArgument(0) == var || *t->nthArgument(1) == var) {
        result = t->getSpecialData()->getSort();
        return true;
      }
      continue;
    }
    if (t->shared() && t->ground()) {
      sit.right();
      continue;
    }
    int idx = 0;
    TermList* args = t->args();
    while (!args->isEmpty()) {
      if (*args==var) {
        result = getArgSort(t, idx);
        return true;
      }
      idx++;
      args=args->next();
    }
  }
  return false;
} 

bool SortHelper::areImmediateSortsValid(Term* t)
{
  CALL("SortHelper::areImmediateSortsValid");

  if (t->isLiteral() && static_cast<Literal*>(t)->isEquality()) {
    Literal* lit = static_cast<Literal*>(t);
    unsigned eqSrt = getEqualityArgumentSort(lit);
    for (unsigned i=0; i<2; i++) {
      TermList arg = *t->nthArgument(i);
      if (!arg.isTerm()) { continue; }
      Term* ta = arg.term();
      unsigned argSort = getResultSort(ta);
      if (eqSrt != argSort) {
        return false;
      }
    }
    return true;
  }

  BaseType& type = getType(t);
  unsigned arity = t->arity();
  for (unsigned i=0; i<arity; i++) {
    TermList arg = *t->nthArgument(i);
    if (!arg.isTerm()) { continue; }
    Term* ta = arg.term();
    unsigned argSort = getResultSort(ta);
    if (type.arg(i) != argSort) {
      
      return false;
    }
  }
  return true;
}

bool SortHelper::areSortsValid(Clause* cl)
{
  CALL("SortHelper::areSortsValid");

  static DHMap<unsigned,unsigned> varSorts;
  varSorts.reset();

  unsigned clen = cl->length();
  for (unsigned i=0; i<clen; i++) {
    if (!areSortsValid((*cl)[i], varSorts)) {
      return false;
    }
  }
  return true;
}

bool SortHelper::areSortsValid(Term* t0, DHMap<unsigned,unsigned>& varSorts)
{
  CALL("SortHelper::areSortsValid");

  NonVariableIterator sit(t0,true);
  while (sit.hasNext()) {
    Term* t = sit.next().term();
    int idx = 0;
    TermList* args = t->args();
    while (!args->isEmpty()) {
      unsigned argSrt = getArgSort(t,idx);
      TermList arg = *args;
      if (arg.isVar()) {
	unsigned varSrt;
	if (!varSorts.findOrInsert(arg.var(), varSrt, argSrt)) {
	  
	  if (varSrt != argSrt) {
	    return false;
	  }
	}
      }
      else {
	if (argSrt != getResultSort(arg.term())) {
	  return false;
	}
      }
      idx++;
      args=args->next();
    }
  }
  return true;
} 

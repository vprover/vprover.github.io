
/*
 * File KBO.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Debug/Tracer.hpp"


#include "Lib/Environment.hpp"
#include "Lib/Comparison.hpp"
#include "Lib/DArray.hpp"
#include "Lib/DHMap.hpp"
#include "Lib/Int.hpp"
#include "Lib/Metaiterators.hpp"
#include "Lib/Random.hpp"

#include "Indexing/TermSharing.hpp"

#include "Shell/Options.hpp"

#include "Term.hpp"
#include "KBO.hpp"
#include "Signature.hpp"

#include <fstream>


#define NONINTERPRETED_PRECEDENCE_BOOST 0x1000

#define NONINTERPRETED_LEVEL_BOOST 0x1000
#define COLORED_WEIGHT_BOOST 0x10000
#define COLORED_LEVEL_BOOST 0x10000

#include <sstream>

namespace Kernel {

using namespace Lib;
using namespace Shell;


class KBO::State
{
public:
 
  State(KBO* kbo)
    : _kbo(*kbo)
  {}

  void init()
  {
    _weightDiff=0;
    _posNum=0;
    _negNum=0;
    _lexResult=EQUAL;
    _varDiffs.reset();
  }

  CLASS_NAME(KBO::State);
  USE_ALLOCATOR(State);

  void traverse(Term* t1, Term* t2);
  void traverse(TermList tl,int coefficient);
  Result result(Term* t1, Term* t2);
private:
  void recordVariable(unsigned var, int coef);
  Result innerResult(TermList t1, TermList t2);
  Result applyVariableCondition(Result res)
  {
    if(_posNum>0 && (res==LESS || res==LESS_EQ || res==EQUAL)) {
      res=INCOMPARABLE;
    } else if(_negNum>0 && (res==GREATER || res==GREATER_EQ || res==EQUAL)) {
      res=INCOMPARABLE;
    }
    return res;
  }

  int _weightDiff;
  DHMap<unsigned, int, IdentityHash> _varDiffs;
 
  int _posNum;
 
  int _negNum;
 
  Result _lexResult;
 
  KBO& _kbo;
 
}; 

Ordering::Result KBO::State::result(Term* t1, Term* t2)
{
  Result res;
  if(_weightDiff) {
    res=_weightDiff>0 ? GREATER : LESS;
  } else if(t1->functor()!=t2->functor()) {
    if(t1->isLiteral()) {
      int prec1, prec2;
      prec1=_kbo.predicatePrecedence(t1->functor());
      prec2=_kbo.predicatePrecedence(t2->functor());
      ASS_NEQ(prec1,prec2);
      res=(prec1>prec2)?GREATER:LESS;
    } else {
      res=_kbo.compareFunctionPrecedences(t1->functor(), t2->functor());
      ASS_REP(res==GREATER || res==LESS, res); 
    }
  } else {
    res=_lexResult;
  }
  res=applyVariableCondition(res);
  ASS( !t1->ground() || !t2->ground() || res!=INCOMPARABLE);

  
  
  
  
  
  
  
  ASS_NEQ(res, EQUAL);
  return res;
}

Ordering::Result KBO::State::innerResult(TermList tl1, TermList tl2)
{
  CALL("KBO::State::innerResult");

  ASS_NEQ(tl1, tl2);
  ASS(!TermList::sameTopFunctor(tl1,tl2));

  if(_posNum>0 && _negNum>0) {
    return INCOMPARABLE;
  }

  Result res;
  if(_weightDiff) {
    res=_weightDiff>0 ? GREATER : LESS;
  } else {
    if(tl1.isVar()) {
      ASS_EQ(_negNum,0);
      res=LESS;
    } else if(tl2.isVar()) {
      ASS_EQ(_posNum,0);
      res=GREATER;
    } else {
      res=_kbo.compareFunctionPrecedences(tl1.term()->functor(), tl2.term()->functor());
      ASS_REP(res==GREATER || res==LESS, res);
    }
  }
  return applyVariableCondition(res);
}

void KBO::State::recordVariable(unsigned var, int coef)
{
  CALL("KBO::State::recordVariable");
  ASS(coef==1 || coef==-1);

  int* pnum;
  _varDiffs.getValuePtr(var,pnum,0);
  (*pnum)+=coef;
  if(coef==1) {
    if(*pnum==0) {
      _negNum--;
    } else if(*pnum==1) {
      _posNum++;
    }
  } else {
    if(*pnum==0) {
      _posNum--;
    } else if(*pnum==-1) {
      _negNum++;
    }
  }
}

void KBO::State::traverse(TermList tl,int coef)
{
  CALL("KBO::State::traverse(TermList...)");

  if(tl.isOrdinaryVar()) {
    _weightDiff+=_kbo._variableWeight*coef;
    recordVariable(tl.var(), coef);
    return;
  }
  ASS(tl.isTerm());

  Term* t=tl.term();
  ASSERT_VALID(*t);

  _weightDiff+=_kbo.functionSymbolWeight(t->functor())*coef;

  if(!t->arity()) {
    return;
  }

  TermList* ts=t->args();
  static Stack<TermList*> stack(4);
  for(;;) {
    if(!ts->next()->isEmpty()) {
      stack.push(ts->next());
    }
    if(ts->isTerm()) {
      _weightDiff+=_kbo.functionSymbolWeight(ts->term()->functor())*coef;
      if(ts->term()->arity()) {
	stack.push(ts->term()->args());
      }
    } else {
      ASS_METHOD(*ts,isOrdinaryVar());
      _weightDiff+=_kbo._variableWeight*coef;
      recordVariable(ts->var(), coef);
    }
    if(stack.isEmpty()) {
      break;
    }
    ts=stack.pop();
  }
}

void KBO::State::traverse(Term* t1, Term* t2)
{
  CALL("KBO::State::traverse");
  ASS(t1->functor()==t2->functor());
  ASS(t1->arity());
  ASS_EQ(_lexResult, EQUAL);

  unsigned depth=1;
  unsigned lexValidDepth=0;

  static Stack<TermList*> stack(32);
  stack.push(t1->args());
  stack.push(t2->args());
  TermList* ss; 
  TermList* tt; 
  while(!stack.isEmpty()) {
    tt=stack.pop();
    ss=stack.pop();
    if(ss->isEmpty()) {
      ASS(tt->isEmpty());
      depth--;
      ASS_NEQ(_lexResult,EQUAL);
      if(_lexResult!=EQUAL && depth<lexValidDepth) {
	lexValidDepth=depth;
	if(_weightDiff!=0) {
	  _lexResult=_weightDiff>0 ? GREATER : LESS;
	}
	_lexResult=applyVariableCondition(_lexResult);
      }
      continue;
    }

    stack.push(ss->next());
    stack.push(tt->next());
    if(ss->sameContent(tt)) {
      
      continue;
    }
    if(TermList::sameTopFunctor(*ss,*tt)) {
      ASS(ss->isTerm());
      ASS(tt->isTerm());
      ASS(ss->term()->arity());
      stack.push(ss->term()->args());
      stack.push(tt->term()->args());
      depth++;
    } else {
      traverse(*ss,1);
      traverse(*tt,-1);
      if(_lexResult==EQUAL) {
	_lexResult=innerResult(*ss, *tt);
	lexValidDepth=depth;
	ASS(_lexResult!=EQUAL);
	ASS(_lexResult!=GREATER_EQ);
	ASS(_lexResult!=LESS_EQ);
      }
    }
  }
  ASS_EQ(depth,0);
}


KBO::KBO(Problem& prb, const Options& opt)
 : KBOBase(prb, opt)
{
  CALL("KBO::KBO");

  _variableWeight = 1;
  _defaultSymbolWeight = 1;

  _state=new State(this);
}

KBO::~KBO()
{
  CALL("KBO::~KBO");

  delete _state;
}

Ordering::Result KBO::compare(Literal* l1, Literal* l2) const
{
  CALL("KBO::compare(Literal*...)");
  ASS(l1->shared());
  ASS(l2->shared());

  if (l1 == l2) {
    return EQUAL;
  }

  unsigned p1 = l1->functor();
  unsigned p2 = l2->functor();

  if( (l1->isNegative() ^ l2->isNegative()) && (p1==p2) &&
	  l1->weight()==l2->weight() && l1->vars()==l2->vars() &&  
	  l1==env.sharing->tryGetOpposite(l2)) {
    return l1->isNegative() ? LESS : GREATER;
  }

  Result res;

  if (p1 != p2) {
    int lev1 = predicateLevel(p1);
    int lev2 = predicateLevel(p2);
    if (lev1 > lev2) {
      res=GREATER;
      goto fin;
    }
    if (lev2 > lev1) {
      res=LESS;
      goto fin;
    }
  }

  if(l1->isEquality()) {
    ASS(l2->isEquality());
    return compareEqualities(l1, l2);
  }
  ASS(!l1->isEquality());

  {
    ASS(_state);
    State* state=_state;
#if VDEBUG
    
    _state=0;
#endif
    state->init();
    if(p1!=p2) {
      TermList* ts;
      ts=l1->args();
      while(!ts->isEmpty()) {
	state->traverse(*ts,1);
	ts=ts->next();
      }
      ts=l2->args();
      while(!ts->isEmpty()) {
	state->traverse(*ts,-1);
	ts=ts->next();
      }
    } else {
      state->traverse(l1,l2);
    }

    res=state->result(l1,l2);
#if VDEBUG
    _state=state;
#endif
  }

fin:
  if(_reverseLCM && (l1->isNegative() || l2->isNegative()) ) {
    if(l1->isNegative() && l2->isNegative()) {
      res = reverse(res);
    }
    else {
      res = l1->isNegative() ? LESS : GREATER;
    }
  }
  return res;
} 

Ordering::Result KBO::compare(TermList tl1, TermList tl2) const
{
  CALL("KBO::compare(TermList)");

  if(tl1==tl2) {
    return EQUAL;
  }
  if(tl1.isOrdinaryVar()) {
    if(existsZeroWeightUnaryFunction()) {
      NOT_IMPLEMENTED;
    } else {
      return tl2.containsSubterm(tl1) ? LESS : INCOMPARABLE;
    }
  }
  if(tl2.isOrdinaryVar()) {
    if(existsZeroWeightUnaryFunction()) {
      NOT_IMPLEMENTED;
    } else {
      return tl1.containsSubterm(tl2) ? GREATER : INCOMPARABLE;
    }
  }

  ASS(tl1.isTerm());
  ASS(tl2.isTerm());

  Term* t1=tl1.term();
  Term* t2=tl2.term();

  ASS(_state);
  State* state=_state;
#if VDEBUG
  
  _state=0;
#endif

  state->init();
  if(t1->functor()==t2->functor()) {
    state->traverse(t1,t2);
  } else {
    state->traverse(tl1,1);
    state->traverse(tl2,-1);
  }
  Result res=state->result(t1,t2);
#if VDEBUG
  _state=state;
#endif
  return res;
}

int KBO::functionSymbolWeight(unsigned fun) const
{
  int weight = _defaultSymbolWeight;

  if(env.signature->functionColored(fun)) {
    weight *= COLORED_WEIGHT_BOOST;
  }

  return weight;
}





int KBOBase::predicateLevel (unsigned pred) const
{
  int basic=pred >= _predicates ? 1 : _predicateLevels[pred];
  if(NONINTERPRETED_LEVEL_BOOST && !env.signature->getPredicate(pred)->interpreted()) {
    ASS_NEQ(pred,0); 
    basic+=NONINTERPRETED_LEVEL_BOOST;
  }
  if(env.signature->predicateColored(pred)) {
    ASS_NEQ(pred,0); 
    return COLORED_LEVEL_BOOST*basic;
  } else {
    return basic;
  }
} 


int KBOBase::predicatePrecedence (unsigned pred) const
{
  int res=pred >= _predicates ? (int)pred : _predicatePrecedences[pred];
  if(NONINTERPRETED_PRECEDENCE_BOOST) {
    ASS_EQ(NONINTERPRETED_PRECEDENCE_BOOST & 1, 0); 

    bool intp = env.signature->getPredicate(pred)->interpreted();
    res *= 2;
    return intp ? res+1 : res+NONINTERPRETED_PRECEDENCE_BOOST;
  }
  return res;
} 

Comparison KBOBase::compareFunctors(unsigned fun1, unsigned fun2) const
{
  CALL("KBOBase::compareFunctors");

  if(fun1==fun2) {
    return Lib::EQUAL;
  }
  switch(compareFunctionPrecedences(fun1, fun2)) {
  case GREATER: return Lib::GREATER;
  case LESS: return Lib::LESS;
  default:
    ASSERTION_VIOLATION;
  }
}

Ordering::Result KBOBase::compareFunctionPrecedences(unsigned fun1, unsigned fun2) const
{
  CALL("KBOBase::compareFunctionPrecedences");
  ASS_NEQ(fun1, fun2);

  
  if (env.signature->isFoolConstantSymbol(false,fun1)) {
    return LESS;
  }
  if (env.signature->isFoolConstantSymbol(false,fun2)) {
    return GREATER;
  }

  
  if (env.signature->isFoolConstantSymbol(true,fun1)) {
    return LESS;
  }

  if (env.signature->isFoolConstantSymbol(true,fun2)) {
    return GREATER;
  }

  Signature::Symbol* s1=env.signature->getFunction(fun1);
  Signature::Symbol* s2=env.signature->getFunction(fun2);
  
  if(!s1->interpreted()) {
    if(s2->interpreted()) {
      return GREATER;
    }
    
    return fromComparison(Int::compare(
        fun1 >= _functions ? (int)fun1 : _functionPrecedences[fun1],
        fun2 >= _functions ? (int)fun2 : _functionPrecedences[fun2] ));
  }
  if(!s2->interpreted()) {
    return LESS;
  }
  if(s1->arity()) {
    if(!s2->arity()) {
      return GREATER;
    }
    
    return fromComparison(Int::compare(fun1, fun2));
  }
  if(s2->arity()) {
    return LESS;
  }
  

  if (!s1->numericConstant() || !s2->numericConstant()) {
    return fromComparison(Int::compare(fun1, fun2));
  }

  Comparison cmpRes;
  if(s1->integerConstant() && s2->integerConstant()) {
    cmpRes = IntegerConstantType::comparePrecedence(s1->integerValue(), s2->integerValue());
  }
  else if(s1->rationalConstant() && s2->rationalConstant()) {
    cmpRes = RationalConstantType::comparePrecedence(s1->rationalValue(), s2->rationalValue());
  }
  else if(s1->realConstant() && s2->realConstant()) {
    cmpRes = RealConstantType::comparePrecedence(s1->realValue(), s2->realValue());
  }
  else if(s1->integerConstant()) {
    ASS_REP(s2->rationalConstant() || s2->realConstant(), s2->name());
    cmpRes = Lib::LESS;
  }
  else if(s2->integerConstant()) {
    ASS_REP(s1->rationalConstant() || s1->realConstant(), s1->name());
    cmpRes = Lib::GREATER;
  }
  else if(s1->rationalConstant()) {
    ASS_REP(s2->realConstant(), s2->name());
    cmpRes = Lib::LESS;
  }
  else if(s2->rationalConstant()) {
    ASS_REP(s1->realConstant(), s1->name());
    cmpRes = Lib::GREATER;
  }
  else {
    ASSERTION_VIOLATION;
    cmpRes = Int::compare(fun1, fun2);
  }
  return fromComparison(cmpRes);
}

template<typename Comparator>
struct FnBoostWrapper
{
  FnBoostWrapper(Comparator comp) : _comp(comp) {}
  Comparator _comp;

  Comparison compare(unsigned f1, unsigned f2)
  {
    static Options::SymbolPrecedenceBoost boost = env.options->symbolPrecedenceBoost();
    Comparison res = EQUAL;
    bool u1 = env.signature->getFunction(f1)->inUnit(); 
    bool u2 = env.signature->getFunction(f2)->inUnit(); 
    bool g1 = env.signature->getFunction(f1)->inGoal();
    bool g2 = env.signature->getFunction(f2)->inGoal();
    switch(boost){
      case Options::SymbolPrecedenceBoost::NONE:
        break;
      case Options::SymbolPrecedenceBoost::GOAL:
        if(g1 && !g2){ res = GREATER; }
        else if(!g1 && g2){ res = LESS; }
        break;
      case Options::SymbolPrecedenceBoost::UNIT:
        if(u1 && !u2){ res = GREATER; }
        else if(!u1 && u2){ res = LESS; }
        break;
      case Options::SymbolPrecedenceBoost::GOAL_UNIT:
        if(g1 && !g2){ res = GREATER; }
        else if(!g1 && g2){ res = LESS; }
        else if(u1 && !u2){ res = GREATER; }
        else if(!u1 && u2){ res = LESS; }
        break;
    }
    if(res==EQUAL){
      res = _comp.compare(f1,f2);
    }
    return res;
  }

};
template<typename Comparator>
struct PredBoostWrapper
{
  PredBoostWrapper(Comparator comp) : _comp(comp) {}
  Comparator _comp;

  Comparison compare(unsigned p1, unsigned p2)
  {
    static Options::SymbolPrecedenceBoost boost = env.options->symbolPrecedenceBoost();
    Comparison res = EQUAL;
    bool u1 = env.signature->getPredicate(p1)->inUnit();
    bool u2 = env.signature->getPredicate(p2)->inUnit();
    bool g1 = env.signature->getPredicate(p1)->inGoal();
    bool g2 = env.signature->getPredicate(p2)->inGoal();
    switch(boost){
      case Options::SymbolPrecedenceBoost::NONE:
        break;
      case Options::SymbolPrecedenceBoost::GOAL:
        if(g1 && !g2){ res = GREATER; }
        else if(!g1 && g2){ res = LESS; }
        break;
      case Options::SymbolPrecedenceBoost::UNIT:
        if(u1 && !u2){ res = GREATER; }
        else if(!u1 && u2){ res = LESS; }
        break;
      case Options::SymbolPrecedenceBoost::GOAL_UNIT:
        if(g1 && !g2){ res = GREATER; }
        else if(!g1 && g2){ res = LESS; }
        else if(u1 && !u2){ res = GREATER; }
        else if(!u1 && u2){ res = LESS; }
        break;
    }
    if(res==EQUAL){
      res = _comp.compare(p1,p2);
    }
    return res;
  }
};

struct FnFreqComparator
{
  Comparison compare(unsigned f1, unsigned f2)
  {
    unsigned c1 = env.signature->getFunction(f1)->usageCnt();
    unsigned c2 = env.signature->getFunction(f2)->usageCnt();
    Comparison res = Int::compare(c2,c1);
    if(res==EQUAL){
      res = Int::compare(f1,f2);
    }
    return res;
  }
};
struct PredFreqComparator
{
  Comparison compare(unsigned p1, unsigned p2)
  {
    unsigned c1 = env.signature->getPredicate(p1)->usageCnt();
    unsigned c2 = env.signature->getPredicate(p2)->usageCnt();
    Comparison res = Int::compare(c2,c1);
    if(res==EQUAL){
      res = Int::compare(p1,p2);
    }
    return res;
  }
};
struct FnRevFreqComparator
{
  Comparison compare(unsigned f1, unsigned f2)
  {
    unsigned c1 = env.signature->getFunction(f1)->usageCnt();
    unsigned c2 = env.signature->getFunction(f2)->usageCnt();
    Comparison res = Int::compare(c1,c2);
    if(res==EQUAL){
      res = Int::compare(f1,f2);
    }
    return res;
  }
};
struct PredRevFreqComparator
{
  Comparison compare(unsigned p1, unsigned p2)
  {
    unsigned c1 = env.signature->getPredicate(p1)->usageCnt();
    unsigned c2 = env.signature->getPredicate(p2)->usageCnt();
    Comparison res = Int::compare(c1,c2);
    if(res==EQUAL){
      res = Int::compare(p1,p2);
    }
    return res;
  }
};

struct FnArityComparator
{
  Comparison compare(unsigned u1, unsigned u2)
  {
    Comparison res=Int::compare(env.signature->functionArity(u1),
	    env.signature->functionArity(u2));
    if(res==EQUAL) {
      res=Int::compare(u1,u2);
    }
    return res;
  }
};
struct PredArityComparator
{
  Comparison compare(unsigned u1, unsigned u2)
  {
    Comparison res=Int::compare(env.signature->predicateArity(u1),
	    env.signature->predicateArity(u2));
    if(res==EQUAL) {
      res=Int::compare(u1,u2);
    }
    return res;
  }
};

struct FnRevArityComparator
{
  Comparison compare(unsigned u1, unsigned u2)
  {
    Comparison res=Int::compare(env.signature->functionArity(u2),
	    env.signature->functionArity(u1));
    if(res==EQUAL) {
      res=Int::compare(u1,u2);
    }
    return res;
  }
};
struct PredRevArityComparator
{
  Comparison compare(unsigned u1, unsigned u2)
  {
    Comparison res=Int::compare(env.signature->predicateArity(u2),
	    env.signature->predicateArity(u1));
    if(res==EQUAL) {
      res=Int::compare(u1,u2);
    }
    return res;
  }
};

static void loadPermutationFromString(DArray<unsigned>& p, const vstring& str) {
  CALL("loadPermutationFromString");

  std::stringstream ss(str.c_str());
  unsigned i = 0;
  unsigned val;
  while (ss >> val)
  {
      if (i >= p.size()) {
        break;
      }

      if (val >= p.size()) {
        break;
      }

      p[i++] = val;

      if (ss.peek() == ',')
          ss.ignore();
  }
}

KBOBase::KBOBase(Problem& prb, const Options& opt)
  : _predicates(env.signature->predicates()),
    _functions(env.signature->functions()),
    _predicateLevels(_predicates),
    _predicatePrecedences(_predicates),
    _functionPrecedences(_functions)
{
  CALL("KBOBase::KBOBase");
  ASS_G(_predicates, 0);

  DArray<unsigned> aux(32);
  if(_functions) {
    aux.initFromIterator(getRangeIterator(0u, _functions), _functions);

    if (!opt.functionPrecedence().empty()) {
      BYPASSING_ALLOCATOR;

      vstring precedence;
      ifstream precedence_file (opt.functionPrecedence().c_str());
      if (precedence_file.is_open() && getline(precedence_file, precedence)) {
        loadPermutationFromString(aux,precedence);
        precedence_file.close();
      }
    } else {
      switch(opt.symbolPrecedence()) {
      case Shell::Options::SymbolPrecedence::ARITY:
        aux.sort(FnBoostWrapper<FnArityComparator>(FnArityComparator()));
        break;
      case Shell::Options::SymbolPrecedence::REVERSE_ARITY:
        aux.sort(FnBoostWrapper<FnRevArityComparator>(FnRevArityComparator()));
        break;
      case Shell::Options::SymbolPrecedence::FREQUENCY:
      case Shell::Options::SymbolPrecedence::WEIGHTED_FREQUENCY:
        aux.sort(FnBoostWrapper<FnFreqComparator>(FnFreqComparator()));
        break;
      case Shell::Options::SymbolPrecedence::REVERSE_FREQUENCY:
      case Shell::Options::SymbolPrecedence::REVERSE_WEIGHTED_FREQUENCY:
        aux.sort(FnBoostWrapper<FnRevFreqComparator>(FnRevFreqComparator()));
        break;
      case Shell::Options::SymbolPrecedence::OCCURRENCE:
        break;
      case Shell::Options::SymbolPrecedence::SCRAMBLE:
        for(unsigned i=0;i<_functions;i++){
          unsigned j = Random::getInteger(_functions-i)+i;
          unsigned tmp = aux[j];
          aux[j]=aux[i];
          aux[i]=tmp;
        }
        break;
      }
    }

   

   

    for(unsigned i=0;i<_functions;i++) {
      _functionPrecedences[aux[i]]=i;
    }
  }

  aux.initFromIterator(getRangeIterator(0u, _predicates), _predicates);

  if (!opt.predicatePrecedence().empty()) {
    BYPASSING_ALLOCATOR;

    vstring precedence;
    ifstream precedence_file (opt.predicatePrecedence().c_str());
    if (precedence_file.is_open() && getline(precedence_file, precedence)) {
      loadPermutationFromString(aux,precedence);
      precedence_file.close();
    }
  } else {
    switch(opt.symbolPrecedence()) {
    case Shell::Options::SymbolPrecedence::ARITY:
      aux.sort(PredBoostWrapper<PredArityComparator>(PredArityComparator()));
      break;
    case Shell::Options::SymbolPrecedence::REVERSE_ARITY:
      aux.sort(PredBoostWrapper<PredRevArityComparator>(PredRevArityComparator()));
      break;
    case Shell::Options::SymbolPrecedence::FREQUENCY:
    case Shell::Options::SymbolPrecedence::WEIGHTED_FREQUENCY:
      aux.sort(PredBoostWrapper<PredFreqComparator>(PredFreqComparator()));
      break;
    case Shell::Options::SymbolPrecedence::REVERSE_FREQUENCY:
    case Shell::Options::SymbolPrecedence::REVERSE_WEIGHTED_FREQUENCY:
     aux.sort(PredBoostWrapper<PredRevFreqComparator>(PredRevFreqComparator()));
     break;
    case Shell::Options::SymbolPrecedence::OCCURRENCE:
      break;
      case Shell::Options::SymbolPrecedence::SCRAMBLE:
        for(unsigned i=0;i<_predicates;i++){
          unsigned j = Random::getInteger(_predicates-i)+i;
          unsigned tmp = aux[j];
          aux[j]=aux[i];
          aux[i]=tmp;
        }
        break;
    }
  }
 
 

  for(unsigned i=0;i<_predicates;i++) {
    _predicatePrecedences[aux[i]]=i;
  }

  switch(opt.literalComparisonMode()) {
  case Shell::Options::LiteralComparisonMode::STANDARD:
    _predicateLevels.init(_predicates, 1);
    break;
  case Shell::Options::LiteralComparisonMode::PREDICATE:
  case Shell::Options::LiteralComparisonMode::REVERSE:
    for(unsigned i=1;i<_predicates;i++) {
      _predicateLevels[i]=_predicatePrecedences[i]+1;
    }
    break;
  }
  
  _predicateLevels[0]=0;

  _reverseLCM = opt.literalComparisonMode()==Shell::Options::LiteralComparisonMode::REVERSE;

  for(unsigned i=1;i<_predicates;i++) {
    Signature::Symbol* predSym = env.signature->getPredicate(i);
    
    if(predSym->label()) {
      _predicateLevels[i]=-1;
    }
    else if(predSym->equalityProxy()) {
      
      _predicateLevels[i]=_predicates+2;
    }

  }
}


}


/*
 * File Substitution.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Substitution__
#define __Substitution__

#include "Lib/DHMap.hpp"
#include "Lib/Environment.hpp"
#include "Lib/VString.hpp"

#include "Lib/Allocator.hpp"

#include "Term.hpp"

namespace Kernel {

using namespace std;
using namespace Lib;

class Substitution
{
public:
  CLASS_NAME(Substitution);
  USE_ALLOCATOR(Substitution);
  DECLARE_PLACEMENT_NEW;

  Substitution() {}

  void bind(int v,Term* t);
  void bind(int v,TermList t);
  void rebind(int v, Term* t);
  void rebind(int v, TermList t);
  bool findBinding(int var, TermList& res) const;
  TermList apply(unsigned var);
  void unbind(int var);
  void reset();
  bool isEmpty() const { return _map.isEmpty(); }
#if VDEBUG
  vstring toString() const;
#endif
private:
  DHMap<unsigned,TermList> _map;
}; 


}

#endif 



/*
 * File Term.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Term__
#define __Term__

#include <cstdlib>
#include <iosfwd>
#include <utility>

#include "Forwards.hpp"
#include "Debug/Assertion.hpp"
#include "Debug/Tracer.hpp"

#include "Lib/Allocator.hpp"
#include "Lib/Portability.hpp"
#include "Lib/XML.hpp"
#include "Lib/Comparison.hpp"
#include "Lib/Stack.hpp"
#include "Lib/Metaiterators.hpp"
#include "Lib/VString.hpp"


#define USE_MATCH_TAG 0

#include "Sorts.hpp"

#define TERM_DIST_VAR_UNKNOWN 0x7FFFFF

namespace Kernel {

using namespace std;
using namespace Lib;

enum TermTag {
 
  REF = 0u,
 
  ORD_VAR = 1u,
 
  FUN = 2u,
 
  SPEC_VAR = 3u,
};

class TermList {
public:
 
  TermList() {}
 
  explicit TermList(size_t data) : _content(data) {}
 
  explicit TermList(Term* t) : _term(t) {}
 
  TermList(unsigned var, bool special)
  {
    if (special) {
      makeSpecialVar(var);
    }
    else {
      makeVar(var);
    }
  }

 
  inline TermTag tag() const { return (TermTag)(_content & 0x0003); }
 
  inline bool isEmpty() const
  { return tag() == FUN; }
 
  inline bool isNonEmpty() const
  { return tag() != FUN; }
 
  inline TermList* next()
  { return this-1; }
 
  inline const TermList* next() const
  { return this-1; }
 
  inline bool isVar() const { return (_content & 0x0001) == 1; }
 
  inline bool isOrdinaryVar() const { return tag() == ORD_VAR; }
 
  inline bool isSpecialVar() const { return tag() == SPEC_VAR; }
 
  inline unsigned var() const
  { ASS(isVar()); return _content / 4; }
 
  inline bool isTerm() const
  { return tag() == REF; }
  inline const Term* term() const
  { ASS(isTerm()); return _term; }
  inline Term* term()
  { ASS(isTerm()); return _term; }
 
  inline bool sameContent(const TermList* t) const
  { return _content == t->_content ; }
 
  inline size_t content() const { return _content; }
  vstring toString() const;
 
  inline void makeVar(unsigned vnumber)
  { _content = vnumber * 4 + ORD_VAR; }
 
  inline void makeSpecialVar(unsigned vnumber)
  { _content = vnumber * 4 + SPEC_VAR; }
 
  inline void makeEmpty()
  { _content = FUN; }
 
  inline void setTerm(Term* t)
  { _term = t; }
  static bool sameTop(TermList ss, TermList tt);
  static bool sameTopFunctor(TermList ss, TermList tt);
  static bool equals(TermList t1, TermList t2);
  static bool allShared(TermList* args);
 
  unsigned weight() const;
  bool containsSubterm(TermList v);
  bool containsAllVariablesOf(TermList t);

  bool isSafe() const;

  IntList* freeVariables() const;

#if VDEBUG
  void assertValid() const;
#endif

  inline bool operator==(const TermList& t) const
  { return _content==t._content; }
  inline bool operator!=(const TermList& t) const
  { return _content!=t._content; }
  inline bool operator<(const TermList& t) const
  { return _content<t._content; }
  inline bool operator>(const TermList& t) const
  { return _content>t._content; }

private:
  vstring asArgsToString() const;

  union {
   
    Term* _term;
   
    size_t _content;
   
    struct {
     
      unsigned tag : 2;
     
      unsigned polarity : 1;
     
      unsigned commutative : 1;
     
      unsigned shared : 1;
     
      unsigned literal : 1;
     
      unsigned order : 3;
     
      mutable unsigned distinctVars : 23;
     
#if ARCH_X64
# if USE_MATCH_TAG
      MatchTag matchTag; 
# else
      unsigned reserved : 32;
# endif
#else

#endif
    } _info;
  };
  friend class Indexing::TermSharing;
  friend class Term;
  friend class Literal;
}; 

ASS_STATIC(sizeof(TermList)==sizeof(size_t));

class Term
{
public:
  
  static const unsigned SF_ITE = 0xFFFFFFFF;
  static const unsigned SF_LET = 0xFFFFFFFE;
  static const unsigned SF_FORMULA = 0xFFFFFFFD;
  static const unsigned SF_TUPLE = 0xFFFFFFFC;
  static const unsigned SF_LET_TUPLE = 0xFFFFFFFB;
  static const unsigned SPECIAL_FUNCTOR_LOWER_BOUND = 0xFFFFFFFB;

  class SpecialTermData
  {
    friend class Term;
  private:
    union {
      struct {
        Formula * condition;
        unsigned sort;
      } _iteData;
      struct {
        unsigned functor;
        IntList* variables;
	
	
        size_t binding;
        unsigned sort;
      } _letData;
      struct {
        Formula * formula;
      } _formulaData;
      struct {
        Term* term;
      } _tupleData;
      struct {
        unsigned functor;
        IntList* symbols;
        size_t binding;
        unsigned sort;
      } _letTupleData;
    };
   
    const Term* getTerm() const { return reinterpret_cast<const Term*>(this+1); }
  public:
    unsigned getType() const {
      unsigned res = getTerm()->functor();
      ASS_GE(res,SPECIAL_FUNCTOR_LOWER_BOUND);
      return res;
    }
    Formula* getCondition() const { ASS_EQ(getType(), SF_ITE); return _iteData.condition; }
    unsigned getFunctor() const {
      ASS_REP(getType() == SF_LET || getType() == SF_LET_TUPLE, getType());
      return getType() == SF_LET ? _letData.functor : _letTupleData.functor;
    }
    IntList* getVariables() const { ASS_EQ(getType(), SF_LET); return _letData.variables; }
    IntList* getTupleSymbols() const { return _letTupleData.symbols; }
    TermList getBinding() const {
      ASS_REP(getType() == SF_LET || getType() == SF_LET_TUPLE, getType());
      return TermList(getType() == SF_LET ? _letData.binding : _letTupleData.binding);
    }
    unsigned getSort() const {
      switch (getType()) {
        case SF_ITE:
          return _iteData.sort;
        case SF_LET:
          return _letData.sort;
        case SF_LET_TUPLE:
          return _letTupleData.sort;
        default:
          ASSERTION_VIOLATION_REP(getType());
      }
    }
    Formula* getFormula() const { ASS_EQ(getType(), SF_FORMULA); return _formulaData.formula; }
    Term* getTupleTerm() const { return _tupleData.term; }
  };


  Term() throw();
  explicit Term(const Term& t) throw();
  static Term* create(unsigned function, unsigned arity, TermList* args);
  static Term* create(Term* t,TermList* args);
  static Term* createNonShared(Term* t,TermList* args);
  static Term* createNonShared(Term* t);
  static Term* cloneNonShared(Term* t);

  static Term* createConstant(const vstring& name);
 
  static Term* createConstant(unsigned symbolNumber) { return create(symbolNumber,0,0); }
  static Term* createITE(Formula * condition, TermList thenBranch, TermList elseBranch, unsigned branchSort);
  static Term* createLet(unsigned functor, IntList* variables, TermList binding, TermList body, unsigned bodySort);
  static Term* createTupleLet(unsigned functor, IntList* symbols, TermList binding, TermList body, unsigned bodySort);
  static Term* createFormula(Formula* formula);
  static Term* createTuple(unsigned arity, unsigned* sorts, TermList* elements);
  static Term* createTuple(Term* tupleTerm);
  static Term* create1(unsigned fn, TermList arg);
  static Term* create2(unsigned fn, TermList arg1, TermList arg2);

  
  static Term* foolTrue(); 
  static Term* foolFalse(); 

  IntList* freeVariables() const;

 
  size_t getPreDataSize() { return isSpecial() ? sizeof(SpecialTermData) : 0; }

 
  const unsigned functor() const { return _functor; }

  static XMLElement variableToXML(unsigned var);
  vstring toString() const;
  static vstring variableToString(unsigned var);
  static vstring variableToString(TermList var);
 
  const TermList* args() const
  { return _args + _arity; }
 
  const TermList* nthArgument(int n) const
  {
    ASS(n >= 0);
    ASS((unsigned)n < _arity);

    return _args + (_arity - n);
  }
 
  TermList* nthArgument(int n)
  {
    ASS(n >= 0);
    ASS((unsigned)n < _arity);

    return _args + (_arity - n);
  }
 
  TermList* args()
  { return _args + _arity; }
  unsigned hash() const;
 
  unsigned arity() const
  { return _arity; }
  static void* operator new(size_t,unsigned arity,size_t preData=0);
 
  void makeSymbol(unsigned number,unsigned arity)
  {
    _functor = number;
    _arity = arity;
  }
  void destroy();
  void destroyNonShared();
  Term* apply(Substitution& subst);

 
  bool ground() const
  {
    ASS(_args[0]._info.shared);
    return ! vars();
  } 

 
  bool shared() const
  { return _args[0]._info.shared; } 

 
  bool commutative() const
  {
    return _args[0]._info.commutative;
  } 

 
  unsigned weight() const
  {
    ASS(shared());
    return _weight;
  }

 
  void markShared()
  {
    ASS(! shared());
    _args[0]._info.shared = 1u;
  } 

 
  void setWeight(unsigned w)
  {
    _weight = w;
  } 

 
  void setVars(unsigned v)
  {
    CALL("Term::setVars");

    if(_isTwoVarEquality) {
      ASS_EQ(v,2);
      return;
    }
    _vars = v;
  } 

 
  unsigned vars() const
  {
    ASS(shared());
    if(_isTwoVarEquality) {
      return 2;
    }
    return _vars;
  } 

 
  bool isTwoVarEquality() const
  {
    return _isTwoVarEquality;
  }

  const vstring& functionName() const;

 
  bool isLiteral() const { return _args[0]._info.literal; }

 
  unsigned getArgumentIndex(TermList* arg)
  {
    CALL("Term::getArgumentIndex");

    unsigned res=arity()-(arg-_args);
    ASS_L(res,arity());
    return res;
  }

#if VDEBUG
  vstring headerToString() const;
  void assertValid() const;
#endif


  static TermIterator getVariableIterator(TermList tl);




 
  bool askDistinctVars(unsigned& res) const
  {
    if(_args[0]._info.distinctVars==TERM_DIST_VAR_UNKNOWN) {
      return false;
    }
    res=_args[0]._info.distinctVars;
    return true;
  }
  unsigned getDistinctVars() const
  {
    if(_args[0]._info.distinctVars==TERM_DIST_VAR_UNKNOWN) {
      unsigned res=computeDistinctVars();
      if(res<TERM_DIST_VAR_UNKNOWN) {
	_args[0]._info.distinctVars=res;
      }
      return res;
    } else {
      ASS_L(_args[0]._info.distinctVars,0x100000);
      return _args[0]._info.distinctVars;
    }
  }

  bool couldBeInstanceOf(Term* t)
  {
    ASS(shared());
    ASS(t->shared());
    if(t->functor()!=functor()) {
      return false;
    }
    ASS(!commutative());
    return couldArgsBeInstanceOf(t);
  }
  inline bool couldArgsBeInstanceOf(Term* t)
  {
#if USE_MATCH_TAG
    ensureMatchTag();
    t->ensureMatchTag();
    return matchTag().couldBeInstanceOf(t->matchTag());
#else
    return true;
#endif
  }

  bool containsSubterm(TermList v);
  bool containsAllVariablesOf(Term* t);
 
  bool isShallow() const;

 
  void setColor(Color color)
  {
    ASS(_color == static_cast<unsigned>(COLOR_TRANSPARENT) || _color == static_cast<unsigned>(color));
    _color = color;
  } 
 
  Color color() const { return static_cast<Color>(_color); }

  bool skip() const;

 
  bool hasInterpretedConstants() const { return _hasInterpretedConstants; }
 
  void setInterpretedConstantsPresence(bool value) { _hasInterpretedConstants=value; }

 
  bool isSpecial() const { return functor()>=SPECIAL_FUNCTOR_LOWER_BOUND; }
  bool isITE() const { return functor() == SF_ITE; }
  bool isLet() const { return functor() == SF_LET; }
  bool isTupleLet() const { return functor() == SF_LET_TUPLE; }
  bool isTuple() const { return functor() == SF_TUPLE; }
  bool isFormula() const { return functor() == SF_FORMULA; }
  bool isBoolean() const;
 
  const SpecialTermData* getSpecialData() const { return const_cast<Term*>(this)->getSpecialData(); }
 
  SpecialTermData* getSpecialData() {
    CALL("Term::getSpecialData");
    ASS(isSpecial());
    return reinterpret_cast<SpecialTermData*>(this)-1;
  }
protected:
  vstring headToString() const;

  unsigned computeDistinctVars() const;

 
  int getArgumentOrderValue() const
  {
    return _args[0]._info.order;
  }

 
  void setArgumentOrderValue(int val)
  {
    CALL("Term::setArgumentOrderValue");
    ASS_GE(val,0);
    ASS_L(val,8);

    _args[0]._info.order = val;
  }

#if USE_MATCH_TAG
  inline void ensureMatchTag()
  {
    matchTag().ensureInit(this);
  }

  inline MatchTag& matchTag()
  {
#if ARCH_X64
    return _args[0]._info.matchTag;
#else
    return _matchTag;
#endif
  }

#endif

 
  unsigned _functor;
 
  unsigned _arity : 27;
 
  unsigned _color : 2;
 
  unsigned _hasInterpretedConstants : 1;
 
  unsigned _isTwoVarEquality : 1;
 
  unsigned _weight;
  union {
   
    unsigned _vars;
   
    unsigned _sort;
  };

#if USE_MATCH_TAG && !ARCH_X64
  MatchTag _matchTag;
#endif

 
  TermList _args[1];













  friend class TermList;
  friend class MatchTag;
  friend class Indexing::TermSharing;
  friend class Ordering;

public:
 
  class Iterator
  {
  public:
    DECL_ELEMENT_TYPE(TermList);
    Iterator(Term* t) : _next(t->args()) {}
    bool hasNext() const { return _next->isNonEmpty(); }
    TermList next()
    {
      CALL("Term::Iterator::next");
      ASS(hasNext());
      TermList res = *_next;
      _next = _next->next();
      return res;
    }
  private:
    TermList* _next;
  }; 
}; 

class Literal
  : public Term
{
public:
 
  bool isEquality() const
  { return functor() == 0; }

  Literal();
  explicit Literal(const Literal& l) throw();

 
  Literal(unsigned functor,unsigned arity,bool polarity,bool commutative) throw()
  {
    _functor = functor;
    _arity = arity;
    _args[0]._info.polarity = polarity;
    _args[0]._info.commutative = commutative;
    _args[0]._info.literal = 1u;
  }

 
  unsigned header() const
  { return 2*_functor + polarity(); }
 
  unsigned complementaryHeader() const
  { return 2*_functor + 1 - polarity(); }

 
  static unsigned int headerToPredicateNumber(unsigned header)
  {
    return header/2;
  }
 
  static unsigned int headerToPolarity(unsigned header)
  {
    return header % 2;
  }
  static bool headersMatch(Literal* l1, Literal* l2, bool complementary);
 
  void negate()
  {
    ASS(! shared());
    _args[0]._info.polarity = 1 - _args[0]._info.polarity;
  }
 
  void setPolarity(bool positive)
  { _args[0]._info.polarity = positive ? 1 : 0; }
  static Literal* create(unsigned predicate, unsigned arity, bool polarity,
	  bool commutative, TermList* args);
  static Literal* create(Literal* l,bool polarity);
  static Literal* create(Literal* l,TermList* args);
  static Literal* createEquality(bool polarity, TermList arg1, TermList arg2, unsigned sort);
  static Literal* create1(unsigned predicate, bool polarity, TermList arg);
  static Literal* create2(unsigned predicate, bool polarity, TermList arg1, TermList arg2);

  static Literal* flattenOnArgument(const Literal*,int argumentNumber);

  unsigned hash() const;
  unsigned oppositeHash() const;
  static Literal* complementaryLiteral(Literal* l);
 
  static Literal* positiveLiteral(Literal* l) {
    return l->isPositive() ? l : complementaryLiteral(l);
  }
 
  static Literal* negativeLiteral(Literal* l) {
    return l->isNegative() ? l : complementaryLiteral(l);
  }

 
  bool isPositive() const
  {
    return _args[0]._info.polarity;
  } 

 
  bool isNegative() const
  {
    return ! _args[0]._info.polarity;
  } 

 
  int polarity() const
  {
    return _args[0]._info.polarity;
  } 

 
  void markTwoVarEquality()
  {
    CALL("Literal::markTwoVarEquality");
    ASS(!shared());
    ASS(isEquality());
    ASS(nthArgument(0)->isVar() || !nthArgument(0)->term()->shared());
    ASS(nthArgument(1)->isVar() || !nthArgument(1)->term()->shared());

    _isTwoVarEquality = true;
  }


 
  unsigned twoVarEqSort() const
  {
    CALL("Literal::twoVarEqSort");
    ASS(isTwoVarEquality());

    return _sort;
  }

 
  void setTwoVarEqSort(unsigned sort)
  {
    CALL("Literal::setTwoVarEqSort");
    ASS(isTwoVarEquality());

    _sort = sort;
  }


 
  static inline Literal* equality (bool polarity)
  {
     CALL("Literal::equality/1");
     return new(2) Literal(0,2,polarity,true);
  }


  Literal* apply(Substitution& subst);


  inline bool couldBeInstanceOf(Literal* lit, bool complementary)
  {
    ASS(shared());
    ASS(lit->shared());
    if(!headersMatch(this, lit, complementary)) {
      return false;
    }
    return couldArgsBeInstanceOf(lit);
  }
  bool couldArgsBeInstanceOf(Literal* lit)
  {
#if USE_MATCH_TAG
    ensureMatchTag();
    lit->ensureMatchTag();
    if(commutative()) {
      return matchTag().couldBeInstanceOf(lit->matchTag()) ||
	  matchTag().couldBeInstanceOfReversed(lit->matchTag());
    } else {
      return matchTag().couldBeInstanceOf(lit->matchTag());
    }
#else
    return true;
#endif
  }




  vstring toString() const;
  const vstring& predicateName() const;

private:
  static Literal* createVariableEquality(bool polarity, TermList arg1, TermList arg2, unsigned variableSort);

}; 

struct TermListHash {
  static unsigned hash(TermList t) {
    return static_cast<unsigned>(t.content());
  }
};

std::ostream& operator<< (ostream& out, TermList tl );
std::ostream& operator<< (ostream& out, const Term& tl );
std::ostream& operator<< (ostream& out, const Literal& tl );

};

namespace Lib
{

template<>
struct FirstHashTypeInfo<Kernel::TermList> {
  typedef Kernel::TermListHash Type;
};

}

#endif

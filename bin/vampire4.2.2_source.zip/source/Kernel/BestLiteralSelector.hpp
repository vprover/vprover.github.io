
/*
 * File BestLiteralSelector.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#ifndef __BestLiteralSelector__
#define __BestLiteralSelector__

#include <algorithm>

#include "Forwards.hpp"

#include "Lib/Comparison.hpp"
#include "Lib/DArray.hpp"
#include "Lib/List.hpp"
#include "Lib/Metaiterators.hpp"
#include "Lib/Set.hpp"
#include "Lib/Stack.hpp"

#include "Term.hpp"
#include "Clause.hpp"
#include "Ordering.hpp"

#include "LiteralSelector.hpp"
#include "LiteralComparators.hpp"

namespace Kernel {

using namespace Lib;

template<class QComparator>
class BestLiteralSelector
    : public LiteralSelector
      {
      public:
  CLASS_NAME(BestLiteralSelector);
  USE_ALLOCATOR(BestLiteralSelector);

  BestLiteralSelector(const Ordering& ordering, const Options& options) : LiteralSelector(ordering, options)
  {
    CALL("BestLiteralSelector::BestLiteralSelector");

    _comp.attachSelector(this);
  }

  bool isBGComplete() const override { return false; }
protected:
  void doSelection(Clause* c, unsigned eligible) override
  {
    CALL("BestLiteralSelector::doSelection");

    unsigned besti=0;
    Literal* best=(*c)[0];
    for(unsigned i=1;i<eligible;i++) {
      Literal* lit=(*c)[i];
      if(_comp.compare(best, lit)==LESS) {
        besti=i;
        best=lit;
      }
    }
    if(besti>0) {
      std::swap((*c)[0], (*c)[besti]);
    }
    c->setSelected(1);

#if VDEBUG
    ensureSomeColoredSelected(c, eligible);
    ASS_EQ(c->numSelected(), 1); 
#endif
  }

      private:
  QComparator _comp;
      };


template<class QComparator>
class CompleteBestLiteralSelector
    : public LiteralSelector
{
public:
  CLASS_NAME(CompleteBestLiteralSelector);
  USE_ALLOCATOR(CompleteBestLiteralSelector);

  CompleteBestLiteralSelector(const Ordering& ordering, const Options& options) : LiteralSelector(ordering, options)
  {
    CALL("CompleteBestLiteralSelector::CompleteBestLiteralSelector");

    _comp.attachSelector(this);
  }

  bool isBGComplete() const override { return true; }
protected:
  void doSelection(Clause* c, unsigned eligible) override
  {
    CALL("CompleteBestLiteralSelector::doSelection");
    ASS_G(eligible, 1); 

    static DArray<Literal*> litArr(64);
    litArr.initFromArray(eligible,*c);
    litArr.sortInversed(_comp);

    LiteralList* maximals=0;
    Literal* singleSelected=0; 
    
    bool allSelected=false;

    if(isNegativeForSelection(litArr[0])) {
      singleSelected=litArr[0];
    } else {
      DArray<Literal*>::ReversedIterator rlit(litArr);
      while(rlit.hasNext()) {
        Literal* lit=rlit.next();
        LiteralList::push(lit,maximals);
      }
      _ord.removeNonMaximal(maximals);
      unsigned besti=0;
      LiteralList* nextMax=maximals;
      while(true) {
        if(nextMax->head()==litArr[besti]) {
          nextMax=nextMax->tail();
          if(nextMax==0) {
            break;
          }
        }
        besti++;
        ASS_L(besti,eligible);
        if(isNegativeForSelection(litArr[besti])) {
          singleSelected=litArr[besti];
          break;
        }
      }
    }
    if(!singleSelected && !maximals->tail()) {
      
      singleSelected=maximals->head();
    }
    if(!singleSelected) {
      unsigned selCnt=0;
      for(LiteralList* mit=maximals; mit; mit=mit->tail()) {
        ASS(isPositiveForSelection(mit->head()));
        selCnt++;
      }
      if(selCnt==eligible) {
        allSelected=true;
      }
    }
    if(allSelected) {
      c->setSelected(eligible);
    } else if(!singleSelected) {
      
      static Stack<Literal*> replaced(16);
      Set<Literal*> maxSet;
      unsigned selCnt=0;

      for(LiteralList* mit=maximals; mit; mit=mit->tail()) {
        maxSet.insert(mit->head());
      }

      while(maximals) {
        if(!maxSet.contains((*c)[selCnt])) {
          replaced.push((*c)[selCnt]);
        }
        (*c)[selCnt]=LiteralList::pop(maximals);
        selCnt++;
      }
      ASS_G(selCnt,1);
      ASS_LE(selCnt,eligible);

      
      unsigned i=selCnt;
      while(replaced.isNonEmpty()) {
        while(!maxSet.contains((*c)[i])) {
          i++;
          ASS_L(i,eligible);
        }
        (*c)[i++]=replaced.pop();
      }

      c->setSelected(selCnt);
    } else {
      unsigned besti=c->getLiteralPosition(singleSelected);
      if(besti!=0) {
        std::swap((*c)[0],(*c)[besti]);
      }
      c->setSelected(1);
    }
    LiteralList::destroy(maximals);

    ensureSomeColoredSelected(c, eligible);
  }

private:
  QComparator _comp;
};

};

#endif

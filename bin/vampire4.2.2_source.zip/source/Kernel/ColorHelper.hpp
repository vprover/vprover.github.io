
/*
 * File ColorHelper.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __ColorHelper__
#define __ColorHelper__

#include "Forwards.hpp"

#include "Debug/Assertion.hpp"

#include "Lib/DHMap.hpp"
#include "Lib/Environment.hpp"

namespace Kernel {

using namespace Lib;
using namespace Saturation;

class ColorHelper {
public:

 
  static Color combine(Color c1, Color c2)
  {
    CALL("ColorHelper::combine");
    ASS(env.colorUsed || (c1|c2)!=COLOR_INVALID);
    return static_cast<Color>(c1|c2);
  }

 
  static bool compatible(Color c1, Color c2) {
    CALL("ColorHelper::compatible");
    return combine(c1,c2)!=COLOR_INVALID;
  }

  static bool isTransparent(bool predicate, unsigned functor);
  static bool hasColoredPredicates(Clause* c);
  static Clause* skolemizeColoredConstants(Clause* c);
  static Clause* skolemizeColoredTerms(Clause* c);

  static void tryUnblock(Clause* c, SaturationAlgorithm* salg);

private:
  typedef DHMap<Term*, Term*> TermMap;

  static void ensureSkolemReplacement(Term* t, TermMap& map);
  static void collectSkolemReplacements(Clause* c, TermMap& map);

  static Term* applyReplacement(Term* t, TermMap& map);
  static void collectColoredConstants(Clause* c, Stack<Term*>& acc);
};

}

#endif 

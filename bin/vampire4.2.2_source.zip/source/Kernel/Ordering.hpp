
/*
 * File Ordering.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Ordering__
#define __Ordering__

#include "Forwards.hpp"

#include "Debug/Assertion.hpp"

#include "Lib/Comparison.hpp"
#include "Lib/SmartPtr.hpp"

#include "Lib/Allocator.hpp"

namespace Kernel {

using namespace Shell;

class Ordering
{
public:
  CLASS_NAME(Ordering);
  USE_ALLOCATOR(Ordering);

 
  enum Result {
    GREATER=1,
    LESS=2,
    GREATER_EQ=3,
    LESS_EQ=4,
    EQUAL=5,
    INCOMPARABLE=6
  };

  Ordering();
  virtual ~Ordering();

 
  virtual Result compare(Literal* l1,Literal* l2) const = 0;
 
  virtual Result compare(TermList t1,TermList t2) const = 0;

  static bool isGorGEorE(Result r) { return (r == GREATER || r == GREATER_EQ || r == EQUAL); }

  virtual Comparison compareFunctors(unsigned fun1, unsigned fun2) const = 0;

  void removeNonMaximal(LiteralList*& lits) const;

  static Result fromComparison(Comparison c);

  static Result reverse(Result r)
  {
    CALL("Ordering::reverse");
    
    switch(r) {
    case GREATER:
      return LESS;
    case GREATER_EQ:
      return LESS_EQ;
    case LESS:
      return GREATER;
    case LESS_EQ:
      return GREATER_EQ;
    case EQUAL:
    case INCOMPARABLE:
      return r;
    default:
      ASSERTION_VIOLATION;
    }
  }
  static const char* resultToString(Result r);

  static Ordering* create(Problem& prb, const Options& opt);

  static bool trySetGlobalOrdering(OrderingSP ordering);
  static Ordering* tryGetGlobalOrdering();

  Result getEqualityArgumentOrder(Literal* eq) const;
protected:

  Result compareEqualities(Literal* eq1, Literal* eq2) const;

private:

  enum ArgumentOrderVals {
   
    AO_UNKNOWN=0,
    AO_GREATER=1,
    AO_LESS=2,
    AO_GREATER_EQ=3,
    AO_LESS_EQ=4,
    AO_EQUAL=5,
    AO_INCOMPARABLE=6
  };


  void createEqualityComparator();
  void destroyEqualityComparator();

  class EqCmp;
 
  EqCmp* _eqCmp;

 
  static OrderingSP s_globalOrdering;
}; 

}

#endif

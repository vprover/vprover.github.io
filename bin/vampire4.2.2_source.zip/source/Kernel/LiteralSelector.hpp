
/*
 * File LiteralSelector.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __LiteralSelector__
#define __LiteralSelector__

#include "Forwards.hpp"

#include "Lib/Array.hpp"

#include "Lib/Allocator.hpp"

#include "Term.hpp"

namespace Kernel {

using namespace Lib;
using namespace Shell;

class LiteralSelector
{
public:
  CLASS_NAME(LiteralSelector);
  USE_ALLOCATOR(LiteralSelector);

  LiteralSelector(const Ordering& ordering, const Options& options)
  : _ord(ordering), _opt(options), _reversePolarity(false)
  {
  }
  virtual ~LiteralSelector()
  {
  }
 
  void select(Clause* c, unsigned eligible=0);

  static LiteralSelector* getSelector(const Ordering& ordering, const Options& options, int selectorNumber);

  static void ensureSomeColoredSelected(Clause* c, unsigned eligible);

 
  bool isPositiveForSelection(Literal* l) const;

  static void reversePredicatePolarity(unsigned pred, bool reverse);

 
  bool isNegativeForSelection(Literal* l) const
  {
    return !isPositiveForSelection(l);
  }

  int getSelectionPriority(Literal* l) const;

 
  virtual bool isBGComplete() const = 0;

protected:
 
  virtual void doSelection(Clause* c, unsigned eligible) = 0;

  const Ordering& _ord;
  const Options& _opt;
private:
 
  bool _reversePolarity;

  static ZIArray<bool> _reversePredicate;
};

class TotalLiteralSelector
: public LiteralSelector
{
public:
  CLASS_NAME(TotalLiteralSelector);
  USE_ALLOCATOR(TotalLiteralSelector);

  TotalLiteralSelector(const Ordering& ordering, const Options& options)
  : LiteralSelector(ordering, options) {}

  bool isBGComplete() const override {
    
    return false;
  }
protected:
  void doSelection(Clause* c, unsigned eligible) override;
};



}

#endif

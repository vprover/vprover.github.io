
/*
 * File Grounder.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include <algorithm>

#include "Lib/Environment.hpp"
#include "Lib/SharedSet.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/InferenceStore.hpp"
#include "Kernel/Renaming.hpp"
#include "Kernel/Signature.hpp"
#include "Kernel/SortHelper.hpp"
#include "Kernel/SubstHelper.hpp"
#include "Kernel/Term.hpp"
#include "Kernel/TermIterators.hpp"

#include "SAT/SATClause.hpp"
#include "SAT/SATInference.hpp"
#include "SAT/SATLiteral.hpp"
#include "SAT/SATSolver.hpp"

#include "Grounder.hpp"

using namespace Kernel;

SATClause* Grounder::ground(Clause* cl,bool use_n)
{
  CALL("Grounder::ground(Clause*)");

  if(!cl->noSplits()) {
    NOT_IMPLEMENTED;
  }

  SATClause* gndNonProp = groundNonProp(cl,use_n);


  SATInference* inf = new FOConversionInference(cl);
  gndNonProp->setInference(inf);

  return gndNonProp;
}

void Grounder::groundNonProp(Clause* cl, SATLiteralStack& acc, bool use_n, Literal** normLits)
{
  CALL("Grounder::groundNonProp/2");

  static DArray<Literal*> lits;

  unsigned clen = cl->length();

  if(normLits) {
    std::copy(cl->literals(), cl->literals()+clen, normLits);
  }
  else {
    lits.initFromArray(clen, *cl);
    normLits = lits.array();
  }

  normalize(clen, normLits);

  for(unsigned i=0; i<clen; i++) {
    SATLiteral lit = groundNormalized(normLits[i]);
    
    if(use_n){
      
      ASS(_satSolver);
      _satSolver->recordSource(lit.var(),(*cl)[i]);
    }
    acc.push(lit);
  }
}

SATClause* Grounder::groundNonProp(Clause* cl, bool use_n, Literal** normLits)
{
  CALL("Grounder::groundNonProp(Clause*,Literal**)");

  static SATLiteralStack gndLits;
  gndLits.reset();

  groundNonProp(cl, gndLits, use_n, normLits);

  SATClause* res = SATClause::fromStack(gndLits);
  return res;
}

SATLiteral Grounder::groundLiteral(Literal* lit,bool use_n)
{
  CALL("Grounder::ground(Literal*)");

  Literal* norm = lit;
  normalize(1, &norm);
  SATLiteral slit = groundNormalized(norm);
  
  if(use_n){
     ASS(_satSolver);
     _satSolver->recordSource(slit.var(),lit);
  }
  return slit;
}

SATLiteral Grounder::groundNormalized(Literal* lit)
{
  CALL("Grounder::groundNormalized");

  bool isPos = lit->isPositive();
  Literal* posLit = Literal::positiveLiteral(lit);

  unsigned* pvar;
  if(_asgn.getValuePtr(posLit, pvar)) {    
    *pvar = _satSolver->newVar();
  }
  return SATLiteral(*pvar, isPos);
}

LiteralIterator Grounder::groundedLits()
{
  CALL("Grounder::groundedLits");

  return _asgn.domain();
}






struct GlobalSubsumptionGrounder::OrderNormalizingComparator
{
  Literal** _lits;
  OrderNormalizingComparator(Literal** lits) : _lits(lits) {}

  bool operator()(unsigned a, unsigned b) {
    Literal* la = _lits[a];
    Literal* lb = _lits[b];
    if(la==lb) { return false; }
    if(la->vars()!=lb->vars()) {
      
      
      return la->vars()<lb->vars();
    }
    if(la->weight()!=lb->weight()) {
      return la->weight()<lb->weight();
    }
    if(la->header()!=lb->header()) {
      return la->header()<lb->header();
    }
    
    static DisagreementSetIterator dsit;
    dsit.reset(la, lb, false);
    ALWAYS(dsit.hasNext());
    pair<TermList,TermList> da = dsit.next();
    if(da.first.isVar()!=da.second.isVar()) {
      return da.first.isVar();
    }
    if(da.first.isVar()) {
      ASS_NEQ(da.first.var(),da.second.var());
      return da.first.var()<da.second.var();
    }
    else {
      ASS_NEQ(da.first.term()->functor(),da.second.term()->functor());
      return da.first.term()->functor()<da.second.term()->functor();
    }
    return a<b; 
  }
};

void GlobalSubsumptionGrounder::normalize(unsigned cnt, Literal** lits)
{
  CALL("GlobalSubsumptionGrounder::normalize");

  if(!_doNormalization) { return; }

  if(cnt==0) { return; }
  if(cnt==1) {
    lits[0] = Renaming::normalize(lits[0]);
  }

  static Stack<unsigned> litOrder;
  litOrder.reset();
  litOrder.loadFromIterator(getRangeIterator(0u,cnt));

  std::sort(litOrder.begin(), litOrder.end(), OrderNormalizingComparator(lits));

  static Renaming normalizer;
  normalizer.reset();

  for(unsigned i=0; i<cnt; i++) {
    unsigned li = litOrder[i];
    normalizer.normalizeVariables(lits[li]);
    lits[li] = normalizer.apply(lits[li]);
  }
}






IGGrounder::IGGrounder(SATSolver* satSolver) : Grounder(satSolver)
{
  _tgtTerm = TermList(0, false);
  
}

class IGGrounder::CollapsingApplicator
{
  TermList _tgtTerm;
public:
  CollapsingApplicator(TermList tgtTerm) : _tgtTerm(tgtTerm) {}
  TermList apply(unsigned var)
  {

    return _tgtTerm;
  }
};

Literal* IGGrounder::collapseVars(Literal* lit)
{
  CALL("IGGrounder::collapseVars");

  CollapsingApplicator apl(_tgtTerm);
  return SubstHelper::apply(lit, apl);
}

void IGGrounder::normalize(unsigned cnt, Literal** lits)
{
  CALL("IGGrounder::normalize");

  for(unsigned i=0; i<cnt; i++) {
    lits[i] = collapseVars(lits[i]);
  }
}


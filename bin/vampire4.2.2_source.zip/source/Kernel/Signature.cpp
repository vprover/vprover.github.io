
/*
 * File Signature.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Lib/Environment.hpp"
#include "Lib/Int.hpp"
#include "Shell/Options.hpp"

#include "Signature.hpp"

using namespace std;
using namespace Kernel;
using namespace Shell;

const unsigned Signature::STRING_DISTINCT_GROUP = 0;
const unsigned Signature::INTEGER_DISTINCT_GROUP = 1;
const unsigned Signature::RATIONAL_DISTINCT_GROUP = 2;
const unsigned Signature::REAL_DISTINCT_GROUP = 3;
const unsigned Signature::LAST_BUILT_IN_DISTINCT_GROUP = 3;

Signature::Symbol::Symbol(const vstring& nm,unsigned arity, bool interpreted, bool stringConstant,bool numericConstant, bool overflownConstant)
  : _name(nm),
    _arity(arity),
    _interpreted(interpreted ? 1 : 0),
    _introduced(0),
    _protected(0),
    _skip(0),
    _label(0),
    _equalityProxy(0),
    _color(COLOR_TRANSPARENT),
    _stringConstant(stringConstant ? 1: 0),
    _numericConstant(numericConstant ? 1: 0),
    _answerPredicate(0),
    _overflownConstant(overflownConstant ? 1 : 0),
    _termAlgebraCons(0),
    _type(0),
    _distinctGroups(0),
    _usageCount(0)
{
  CALL("Signature::Symbol::Symbol");
  ASS(!stringConstant || arity==0);

  if (!stringConstant && !numericConstant && !overflownConstant && symbolNeedsQuoting(_name, interpreted,arity)) {
    _name="'"+_name+"'";
  }
  if (_interpreted || isProtectedName(nm)) {
    markProtected();
  }
} 

Signature::Symbol::~Symbol()
{
  CALL("Signature::Symbol::~Symbol");

  if (_type) {
    delete _type;
  }
}

void Signature::Symbol::destroyFnSymbol()
{
  CALL("Signature::Symbol::destroyFnSymbol");

  if (integerConstant()) {
    delete static_cast<IntegerSymbol*>(this);
  }
  else if (rationalConstant()) {
    delete static_cast<RationalSymbol*>(this);
  }
  else if (realConstant()) {
    delete static_cast<RealSymbol*>(this);
  }
  else if (interpreted()) {
    delete static_cast<InterpretedSymbol*>(this);
  }
  else {
    delete this;
  }
}

void Signature::Symbol::destroyPredSymbol()
{
  CALL("Signature::Symbol::destroyPredSymbol");

  if (interpreted()) {
    delete static_cast<InterpretedSymbol*>(this);
  }
  else {
    delete this;
  }
}

void Signature::Symbol::addToDistinctGroup(unsigned group,unsigned this_number)
{
  CALL("Signature::Symbol::addToDistinctGroup");

  ASS_EQ(arity(), 0);
  ASS(!List<unsigned>::member(group, _distinctGroups))

  List<unsigned>::push(group, _distinctGroups);

  env.signature->_distinctGroupsAddedTo=true;

  Stack<unsigned>* members = env.signature->_distinctGroupMembers[group];
  
  if(members->size()<141 || env.options->bfnt()
                       || env.options->saturationAlgorithm()==Options::SaturationAlgorithm::FINITE_MODEL_BUILDING){ 
    members->push(this_number);
  }

} 

void Signature::Symbol::setType(BaseType* type)
{
  CALL("Signature::Symbol::setType");
  ASS(!_type);

  _type = type;
}

void Signature::Symbol::forceType(BaseType* type)
{
  CALL("Signature::Symbol::forceType");
  if(_type){ delete _type; }
  _type = type;
}

FunctionType* Signature::Symbol::fnType() const
{
  CALL("Signature::Symbol::fnType");

  if (!_type) {
    _type = new FunctionType(arity(), (unsigned*)0, Sorts::SRT_DEFAULT);
  }
  return static_cast<FunctionType*>(_type);
}

PredicateType* Signature::Symbol::predType() const
{
  CALL("Signature::Symbol::predType");

  if (!_type) {
    _type = new PredicateType(arity(), (unsigned*)0);
  }
  return static_cast<PredicateType*>(_type);
}


Signature::Signature ():
    _foolConstantsDefined(false), _foolTrue(0), _foolFalse(0),
    _funs(32),
    _preds(32),
    _nextFreshSymbolNumber(0),
    _skolemFunctionCount(0),
    _distinctGroupsAddedTo(false),
    _strings(0),
    _integers(0),
    _rationals(0),
    _reals(0),
    _termAlgebras()
{
  CALL("Signature::Signature");

  
  addInterpretedPredicate(Theory::EQUAL, "=");
  ASS_EQ(predicateName(0), "="); 
  getPredicate(0)->markSkip();

  unsigned aux;
  
  
  aux = createDistinctGroup();
  ASS_EQ(STRING_DISTINCT_GROUP, aux);
  aux = createDistinctGroup();
  ASS_EQ(INTEGER_DISTINCT_GROUP, aux);
  aux = createDistinctGroup();
  ASS_EQ(RATIONAL_DISTINCT_GROUP, aux);
  aux = createDistinctGroup();
  ASS_EQ(REAL_DISTINCT_GROUP, aux);

} 

Signature::~Signature ()
{
  for (int i = _funs.length()-1;i >= 0;i--) {
    _funs[i]->destroyFnSymbol();
  }
  for (int i = _preds.length()-1;i >= 0;i--) {
    _preds[i]->destroyPredSymbol();
  }
  for (int i = _vars.length()-1; i>= 0 ; i--){
    delete _vars[i];
  }
} 

unsigned Signature::addInterpretedFunction(Interpretation interpretation, const vstring& name)
{
  CALL("Signature::addInterpretedFunction");
  ASS(Theory::isFunction(interpretation));

  unsigned res;
  if (_iSymbols.find(interpretation,res)) { 
    if (name!=functionName(res)) {
      USER_ERROR("Interpreted function '"+functionName(res)+"' has the same interpretation as '"+name+"' should have");
    }
    return res;
  }

  vstring symbolKey = name+"_i"+Int::toString(interpretation);
  ASS(!_funNames.find(symbolKey));

  unsigned fnNum = _funs.length();
  InterpretedSymbol* sym = new InterpretedSymbol(name, interpretation);
  _funs.push(sym);
  _funNames.insert(symbolKey, fnNum);
  ALWAYS(_iSymbols.insert(interpretation, fnNum));
  BaseType* fnType = Theory::getOperationType(interpretation);
  ASS(fnType->isFunctionType());
  sym->setType(fnType);
  return fnNum;
} 

unsigned Signature::addInterpretedPredicate(Interpretation interpretation, const vstring& name)
{
  CALL("Signature::addInterpretedPredicate");
  ASS(!Theory::isFunction(interpretation));

  unsigned res;
  if (_iSymbols.find(interpretation,res)) { 
    if (name!=predicateName(res)) {
      USER_ERROR("Interpreted predicate '"+predicateName(res)+"' has the same interpretation as '"+name+"' should have");
    }
    return res;
  }

  vstring symbolKey = name+"_i"+Int::toString(interpretation);

  ASS(!_predNames.find(symbolKey));

  unsigned predNum = _preds.length();
  InterpretedSymbol* sym = new InterpretedSymbol(name, interpretation);
  _preds.push(sym);
  _predNames.insert(symbolKey,predNum);
  ALWAYS(_iSymbols.insert(interpretation, predNum));
  if (predNum!=0) {
    BaseType* predType = Theory::getOperationType(interpretation);
    ASS_REP(!predType->isFunctionType(), predType->toString());
    sym->setType(predType);
  }
  return predNum;
} 

unsigned Signature::addIntegerConstant(const vstring& number,bool defaultSort)
{
  CALL("Signature::addIntegerConstant(vstring)");

  IntegerConstantType value(number);
  if (!defaultSort) {
    return addIntegerConstant(value);
  }

  
  vstring name = value.toString();
  vstring symbolKey = name + "_n";
  unsigned result;
  if (_funNames.find(symbolKey,result)) {
    return result;
  }

  result = _funs.length();
  Symbol* sym = new Symbol(name,0,false,false,true);
  sym->addToDistinctGroup(INTEGER_DISTINCT_GROUP,result);
  if(defaultSort){ 
     sym->addToDistinctGroup(STRING_DISTINCT_GROUP,result); 
  }
  _funs.push(sym);
  _funNames.insert(symbolKey,result);
  return result;
} 

unsigned Signature::addIntegerConstant(const IntegerConstantType& value)
{
  CALL("Signature::addIntegerConstant");

  vstring key = value.toString() + "_n";
  unsigned result;
  if (_funNames.find(key, result)) {
    return result;
  }
  _integers++;
  result = _funs.length();
  Symbol* sym = new IntegerSymbol(value);
  _funs.push(sym);
  _funNames.insert(key,result);
  sym->addToDistinctGroup(INTEGER_DISTINCT_GROUP,result);
  
  return result;
} 

unsigned Signature::addRationalConstant(const vstring& numerator, const vstring& denominator,bool defaultSort)
{
  CALL("Signature::addRationalConstant(vstring,vstring)");

  RationalConstantType value(numerator, denominator);
  if (!defaultSort) {
    return addRationalConstant(value);
  }

  vstring name = value.toString();
  vstring key = name + "_q";
  unsigned result;
  if (_funNames.find(key,result)) {
    return result;
  }
  result = _funs.length();
  Symbol* sym = new Symbol(name,0,false,false,true);
  if(defaultSort){ 
    sym->addToDistinctGroup(STRING_DISTINCT_GROUP,result); 
  }
  sym->addToDistinctGroup(RATIONAL_DISTINCT_GROUP,result);
  _funs.push(sym);
  _funNames.insert(key,result);
  return result;
} 

unsigned Signature::addRationalConstant(const RationalConstantType& value)
{
  CALL("Signature::addRationalConstant");

  vstring key = value.toString() + "_q";
  unsigned result;
  if (_funNames.find(key, result)) {
    return result;
  }
  _rationals++;
  result = _funs.length();
  _funs.push(new RationalSymbol(value));
  _funNames.insert(key, result);
  return result;
} 

unsigned Signature::addRealConstant(const vstring& number,bool defaultSort)
{
  CALL("Signature::addRealConstant(vstring)");

  RealConstantType value(number);
  if (!defaultSort) {
    return addRealConstant(value);
  }
  vstring key = value.toString() + "_r";
  unsigned result;
  if (_funNames.find(key,result)) {
    return result;
  }
  result = _funs.length();
  Symbol* sym = new Symbol(value.toNiceString(),0,false,false,true);
  if(defaultSort){ 
    sym->addToDistinctGroup(STRING_DISTINCT_GROUP,result); 
  }
  sym->addToDistinctGroup(REAL_DISTINCT_GROUP,result);
  _funs.push(sym);
  _funNames.insert(key,result);
  return result;
} 

unsigned Signature::addRealConstant(const RealConstantType& value)
{
  CALL("Signature::addRealConstant");

  vstring key = value.toString() + "_r";
  unsigned result;
  if (_funNames.find(key, result)) {
    return result;
  }
  _reals++;
  result = _funs.length();
  _funs.push(new RealSymbol(value));
  _funNames.insert(key, result);
  return result;
}

unsigned Signature::getInterpretingSymbol(Interpretation interp)
{
  CALL("Signature::getInterpretingSymbol");
  
  ASS(Theory::instance()->isValidInterpretation(interp));
    
  unsigned res;
  if (_iSymbols.find(interp, res)) {
    return res;
  }

  vstring name = theory->getInterpretationName(interp);
  unsigned arity = Theory::getArity(interp);
  
  if (Theory::isFunction(interp)) {
    if (functionExists(name, arity)) {
      int i=0;
      while(functionExists(name+Int::toString(i), arity)) {
        i++;
      }
      name=name+Int::toString(i);
    }
    addInterpretedFunction(interp, name);
  }
  else {
    if (predicateExists(name, arity)) {
      int i=0;
      while(predicateExists(name+Int::toString(i), arity)) {
        i++;
      }
      name=name+Int::toString(i);
    }
    addInterpretedPredicate(interp, name);
  }

  
  return _iSymbols.get(interp);
}

unsigned Signature::getStructureInterpretationFunctor(unsigned theorySort, Theory::StructuredSortInterpretation ssi) {
  CALL("Signature::getStructureInterpretationFunctor");
  Interpretation i = Theory::instance()->getInterpretation(theorySort, ssi);
  return env.signature->getInterpretingSymbol(i);
}

const vstring& Signature::functionName(int number)
{
  CALL("Signature::functionName");

  
  
  
  
  if (!env.options->showFOOL() && isFoolConstantSymbol(false,number)) {
    static vstring fols("$false");
    return fols;
  }
  if (!env.options->showFOOL() && isFoolConstantSymbol(true,number)) { 
    static vstring troo("$true");
    return troo;
  }
  return _funs[number]->name();
}

bool Signature::functionExists(const vstring& name,unsigned arity) const
{
  CALL("Signature::functionExists");

  return _funNames.find(key(name, arity));
}

bool Signature::predicateExists(const vstring& name,unsigned arity) const
{
  CALL("Signature::predicateExists");

  return _predNames.find(key(name, arity));
}

unsigned Signature::getFunctionNumber(const vstring& name, unsigned arity) const
{
  CALL("Signature::getFunctionNumber");

  ASS(_funNames.find(key(name, arity)));
  return _funNames.get(key(name, arity));
}

unsigned Signature::getPredicateNumber(const vstring& name, unsigned arity) const
{
  CALL("Signature::getPredicateNumber");

  ASS(_predNames.find(key(name, arity)));
  return _predNames.get(key(name, arity));
}

unsigned Signature::addFunction (const vstring& name,
				 unsigned arity,
				 bool& added,
				 bool overflowConstant)
{
  CALL("Signature::addFunction");

  vstring symbolKey = key(name,arity);
  unsigned result;
  if (_funNames.find(symbolKey,result)) {
    added = false;
    getFunction(result)->unmarkIntroduced();
    return result;
  }
  if (env.options->arityCheck()) {
    unsigned prev;
    if (_arityCheck.find(name,prev)) {
      unsigned prevArity = prev/2;
      bool isFun = prev % 2;
      USER_ERROR((vstring)"Symbol " + name +
		 " is used both as a function of arity " + Int::toString(arity) +
		 " and a " + (isFun ? "function" : "predicate") +
		 " of arity " + Int::toString(prevArity));
    }
    _arityCheck.insert(name,2*arity+1);
  }

  result = _funs.length();
  _funs.push(new Symbol(name, arity, false, false, false, overflowConstant));
  _funNames.insert(symbolKey, result);
  added = true;
  return result;
} 

unsigned Signature::addStringConstant(const vstring& name)
{
  CALL("Signature::addStringConstant");

  vstring symbolKey = name + "_c";
  unsigned result;
  if (_funNames.find(symbolKey,result)) {
    return result;
  }

  _strings++;
  vstring quotedName = "\"" + name + "\"";
  result = _funs.length();
  Symbol* sym = new Symbol(quotedName,0,false,true);
  sym->addToDistinctGroup(STRING_DISTINCT_GROUP,result);
  _funs.push(sym);
  _funNames.insert(symbolKey,result);
  return result;
} 

unsigned Signature::addPredicate (const vstring& name,
				  unsigned arity,
				  bool& added)
{
  CALL("Signature::addPredicate");

  vstring symbolKey = key(name,arity);
  unsigned result;
  if (_predNames.find(symbolKey,result)) {
    added = false;
    getPredicate(result)->unmarkIntroduced();
    return result;
  }
  if (env.options->arityCheck()) {
    unsigned prev;
    if (_arityCheck.find(name,prev)) {
      unsigned prevArity = prev/2;
      bool isFun = prev % 2;
      USER_ERROR((vstring)"Symbol " + name +
		 " is used both as a predicate of arity " + Int::toString(arity) +
		 " and a " + (isFun ? "function" : "predicate") +
		 " of arity " + Int::toString(prevArity));
    }
    _arityCheck.insert(name,2*arity);
  }

  result = _preds.length();
  _preds.push(new Symbol(name,arity));
  _predNames.insert(symbolKey,result);
  added = true;
  return result;
} 

unsigned Signature::addNamePredicate(unsigned arity)
{
  CALL("Signature::addNamePredicate");
  return addFreshPredicate(arity,"sP");
} 

unsigned Signature::addFreshFunction(unsigned arity, const char* prefix, const char* suffix)
{
  CALL("Signature::addFreshFunction");

  vstring pref(prefix);
  vstring suf(suffix ? vstring("_")+suffix : "");
  bool added;
  unsigned result;
  
  
  


    do {
      result = addFunction(pref+Int::toString(_nextFreshSymbolNumber++)+suf,arity,added);
    }
    while (!added);

  Symbol* sym = getFunction(result);
  sym->markIntroduced();
  sym->markSkip();
  return result;
} 

unsigned Signature::addFreshPredicate(unsigned arity, const char* prefix, const char* suffix)
{
  CALL("Signature::addFreshPredicate");

  vstring pref(prefix);
  vstring suf(suffix ? vstring("_")+suffix : "");
  bool added = false;
  unsigned result;
  
  
  




    do {
      result = addPredicate(pref+Int::toString(_nextFreshSymbolNumber++)+suf,arity,added);
    }
    while (!added);

  Symbol* sym = getPredicate(result);
  sym->markIntroduced();
  sym->markSkip();
  return result;
} 

unsigned Signature::addSkolemFunction (unsigned arity, const char* suffix)
{
  CALL("Signature::addSkolemFunction");

  unsigned f = addFreshFunction(arity, "sK", suffix);

  
  theory->registerLaTeXFuncName(f,"\\sigma_{"+Int::toString(_skolemFunctionCount)+"}(a0)");
  _skolemFunctionCount++;

  return f;
} 

unsigned Signature::addSkolemPredicate(unsigned arity, const char* suffix)
{
  CALL("Signature::addSkolemPredicate");

  unsigned f = addFreshPredicate(arity, "sK", suffix);

  
  theory->registerLaTeXFuncName(f,"\\sigma_{"+Int::toString(_skolemFunctionCount)+"}(a0)");
  _skolemFunctionCount++;

  return f;
} 

vstring Signature::key(const vstring& name,int arity)
{
  return name + '_' + Int::toString(arity);
} 


void Signature::Symbol::addColor(Color color)
{
  ASS_L(color,3);
  ASS_G(color,0);
  ASS(env.colorUsed);

  if (_color && color != static_cast<Color>(_color)) {
    USER_ERROR("A symbol cannot have two colors");
  }
  _color = color;
} 

unsigned Signature::createDistinctGroup(Unit* premise)
{
  CALL("Signature::createDistinctGroup");

  unsigned res = _distinctGroupPremises.size();
  _distinctGroupPremises.push(premise);
  Stack<unsigned>* stack = new Stack<unsigned>;
  _distinctGroupMembers.push(stack);
  return res;
}

Unit* Signature::getDistinctGroupPremise(unsigned group)
{
  CALL("Signature::getDistinctGroupPremise");

  return _distinctGroupPremises[group];
}

void Signature::addToDistinctGroup(unsigned constantSymbol, unsigned groupId)
{
  CALL("Signature::addToDistinctGroup");

  Symbol* sym = getFunction(constantSymbol);
  sym->addToDistinctGroup(groupId,constantSymbol);
}

bool Signature::isProtectedName(vstring name)
{
  CALL("Signature::isProtectedName");

  if (name=="$distinct") {
    
    return true;
  }

  vstring protectedPrefix = env.options->protectedPrefix();
  if (protectedPrefix.size()==0) {
    return false;
  }
  if (name.substr(0, protectedPrefix.size())==protectedPrefix) {
    return true;
  }
  return false;
}

bool Signature::symbolNeedsQuoting(vstring name, bool interpreted, unsigned arity)
{
  CALL("Signature::symbolNeedsQuoting");
  ASS_G(name.length(),0);

  if (interpreted && (name=="=" || arity==0)) {
    return false;
  }

  const char* c = name.c_str();
  bool quote = false;
  bool first = true;
  if (*c=='$') {
    if (*(c+1)=='$') {
      c+=2; 
      first = false;
    }
    else if (interpreted) {
      c++; 
      first = false;
    }
  }
  while(!quote && *c) {
    quote |= charNeedsQuoting(*c, first);
    first = false;
    c++;
  }
  if (!quote) { return false; }
  if (name=="$distinct") {
    
    return false;
  }
  if (name.find("$array") == 0) {
    
    return false;
  }
  return true;
} 

Signature::VarSymbol::VarSymbol(const vstring& nm)
  : _name(nm)
{

  
  const char* c=_name.c_str();
  bool quote=charNeedsQuoting(*c, true);
  c++;
  while(*c) {
    if(charNeedsQuoting(*c, false)) {
      quote=true;
      break;
    }
    c++;
  }
  if(quote) {
    _name="'"+_name+"'";
  }
}

unsigned Signature::addVar (const vstring& name,
				 bool& added)
{
  CALL("Signature::addFunction - tkv");

#if VDEBUG
  unsigned result = 0;
#else
  unsigned result;
#endif
  if (_varNames.find(name,result)) {
    added = false;
    return result;
  }

  result = _vars.length();
  _vars.push(new VarSymbol(name));
  _varNames.insert(name,result);
  added = true;
  return result;
} 

TermAlgebraConstructor* Signature::getTermAlgebraConstructor(unsigned functor)
{
  CALL("Signature::getTermAlgebraConstructor");

  if (getFunction(functor)->termAlgebraCons()) {
    TermAlgebra *ta = _termAlgebras.get(getFunction(functor)->fnType()->result());
    if (ta) {
      for (unsigned i = 0; i < ta->nConstructors(); i++) {
        TermAlgebraConstructor *c = ta->constructor(i);
        if (c->functor() == functor)
          return c;
      }
    }
  }

  return nullptr;
}

bool Signature::charNeedsQuoting(char c, bool first)
{
  switch (c) {
  case 'a':
  case 'b':
  case 'c':
  case 'd':
  case 'e':
  case 'f':
  case 'g':
  case 'h':
  case 'i':
  case 'j':
  case 'k':
  case 'l':
  case 'm':
  case 'n':
  case 'o':
  case 'p':
  case 'q':
  case 'r':
  case 's':
  case 't':
  case 'u':
  case 'v':
  case 'w':
  case 'x':
  case 'y':
  case 'z':

    return false;
  case 'A':
  case 'B':
  case 'C':
  case 'D':
  case 'E':
  case 'F':
  case 'G':
  case 'H':
  case 'I':
  case 'J':
  case 'K':
  case 'L':
  case 'M':
  case 'N':
  case 'O':
  case 'P':
  case 'Q':
  case 'R':
  case 'S':
  case 'T':
  case 'U':
  case 'V':
  case 'W':
  case 'X':
  case 'Y':
  case 'Z':
  case '_':
  case '0':
  case '1':
  case '2':
  case '3':
  case '4':
  case '5':
  case '6':
  case '7':
  case '8':
  case '9':
    return first;
  default:
    return true;
  }
}

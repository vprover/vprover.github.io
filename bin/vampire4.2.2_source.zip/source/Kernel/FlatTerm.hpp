
/*
 * File FlatTerm.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __FlatTerm__
#define __FlatTerm__

#include "Forwards.hpp"

namespace Kernel {

class FlatTerm
{
public:
  static FlatTerm* create(Term* t);
  static FlatTerm* create(TermList t);
  void destroy();

  static FlatTerm* copy(const FlatTerm* ft);

  static const size_t functionEntryCount=3;

  enum EntryTag {
    FUN_TERM_PTR = 0,
    FUN = 1,
    VAR = 2,
   
    FUN_RIGHT_OFS = 3
  };

  struct Entry
  {
    Entry() {}
    Entry(EntryTag tag, unsigned num) { _info.tag=tag; _info.number=num; }
    Entry(Term* ptr) : _ptr(ptr) { ASS_EQ(tag(), FUN_TERM_PTR); }

    inline EntryTag tag() const { return static_cast<EntryTag>(_info.tag); }
    inline unsigned number() const { return _info.number; }
    inline Term* ptr() const { return _ptr; }
    inline bool isVar() const { return tag()==VAR; }
    inline bool isVar(unsigned num) const { return isVar() && number()==num; }
    inline bool isFun() const { return tag()==FUN; }
    inline bool isFun(unsigned num) const { return isFun() && number()==num; }

    union {
      Term* _ptr;
      struct {
	unsigned tag : 2;
	unsigned number : 30;
      } _info;
    };
  };

  inline Entry& operator[](size_t i) { ASS_L(i,_length); return _data[i]; }
  inline const Entry& operator[](size_t i) const { ASS_L(i,_length); return _data[i]; }

  void swapCommutativePredicateArguments();
  void changeLiteralPolarity()
  { _data[0]._info.number^=1; }

private:
  static size_t getEntryCount(Term* t);

  FlatTerm(size_t length);
  void* operator new(size_t,unsigned length);

 
  void operator delete(void*);

  size_t _length;
  Entry _data[1];
};

};

#endif


/*
 * File FormulaUnit.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Lib/Int.hpp"

#include "Formula.hpp"
#include "FormulaUnit.hpp"
#include "Inference.hpp"
#include "SubformulaIterator.hpp"
#include "Term.hpp"

using namespace std;
using namespace Lib;

using namespace Kernel;

void FormulaUnit::destroy()
{
  _inference->destroy();
  delete this;
} 


vstring FormulaUnit::toString() const
{
  return Int::toString(_number) + ". " + _formula->toString() +
         ' ' + inferenceAsString();
} 

unsigned FormulaUnit::varCnt()
{
  CALL("FormulaUnit::varCnt");

  Formula* frm = formula();
  Formula::VarList* fv = frm->freeVariables();
  Formula::VarList* bv = frm->boundVariables();

  unsigned res = Formula::VarList::length(fv) + Formula::VarList::length(bv);
  Formula::VarList::destroy(fv);
  Formula::VarList::destroy(bv);
  return res;
}

Color FormulaUnit::getColor()
{
  CALL("FormulaUnit::getColor");
  ASS_ALLOC_TYPE(this, "FormulaUnit");

  if (_cachedColor == COLOR_INVALID) {
    _cachedColor = this->formula()->getColor();
  }
  return _cachedColor;
}

unsigned FormulaUnit::weight()
{
  CALL("FormulaUnit::weight");
  ASS_ALLOC_TYPE(this, "FormulaUnit");

  if (!_cachedWeight) {
    _cachedWeight = this->formula()->weight();
  }
  return _cachedWeight;
}

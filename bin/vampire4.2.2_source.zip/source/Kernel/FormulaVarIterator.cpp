
/*
 * File FormulaVarIterator.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Debug/Tracer.hpp"

#include "FormulaVarIterator.hpp"

using namespace Lib;
using namespace Kernel;

FormulaVarIterator::FormulaVarIterator(const Formula* f)
  : _found(false)
{
  _instructions.push(FVI_FORMULA);
  _formulas.push(f);
} 

FormulaVarIterator::FormulaVarIterator(const Term* t)
  : _found(false)
{
  CALL("FormulaVarIterator::FormulaVarIterator(Term*)");
  _instructions.push(FVI_TERM);
  _terms.push(t);
} 

FormulaVarIterator::FormulaVarIterator(const TermList* ts)
  : _found(false)
{
  CALL("FormulaVarIterator::FormulaVarIterator(TermList)");
  _instructions.push(FVI_TERM_LIST);
  _termLists.push(*ts);
} 

int FormulaVarIterator::next()
{
  CALL("FormulaVarIterator::next");

  ASS(_found);
  _found = false;
  return _nextVar;
} 

bool FormulaVarIterator::hasNext()
{
  CALL("FormulaVarIterator::hasNext");

  if (_found) return true;

  while (_instructions.isNonEmpty()) {
    switch (_instructions.pop()) {
      case FVI_FORMULA: {
        const Formula* f = _formulas.pop();
        switch (f->connective()) {
          case LITERAL:
            _instructions.push(FVI_TERM);
            _terms.push(f->literal());
            break;

          case AND:
          case OR: {
            FormulaList::Iterator fs(f->args());
            while (fs.hasNext()) {
              _instructions.push(FVI_FORMULA);
              _formulas.push(fs.next());
            }
            break;
          }

          case IMP:
          case IFF:
          case XOR:
            _instructions.push(FVI_FORMULA);
            _formulas.push(f->left());
            _instructions.push(FVI_FORMULA);
            _formulas.push(f->right());
            break;

          case NOT:
            _instructions.push(FVI_FORMULA);
            _formulas.push(f->uarg());
            break;

          case FORALL:
          case EXISTS:
            _instructions.push(FVI_UNBIND);
            _instructions.push(FVI_FORMULA);
            _formulas.push(f->qarg());
            _instructions.push(FVI_BIND);
            _vars.push(f->vars());
            break;

          case BOOL_TERM:
            _instructions.push(FVI_TERM_LIST);
            _termLists.push(f->getBooleanTerm());
            break;

          case TRUE:
          case FALSE:
          case NAME:
            break;
          default:
            ASSERTION_VIOLATION;
        }
        break;
      }

      case FVI_TERM: {
        const Term* t = _terms.pop();

        
        Term::Iterator ts(const_cast<Term*>(t));
        while (ts.hasNext()) {
          _instructions.push(FVI_TERM_LIST);
          _termLists.push(ts.next());
        }

        if (t->isSpecial()) {
          const Term::SpecialTermData* sd = t->getSpecialData();
          switch (t->functor()) {
            case Term::SF_ITE:
              _instructions.push(FVI_FORMULA);
              _formulas.push(sd->getCondition());
              break;

            case Term::SF_FORMULA:
              _instructions.push(FVI_FORMULA);
              _formulas.push(sd->getFormula());
              break;

            case Term::SF_LET: {
              _instructions.push(FVI_UNBIND);

              _instructions.push(FVI_TERM_LIST);
              _termLists.push(sd->getBinding());

              _instructions.push(FVI_BIND);
              _vars.push(sd->getVariables());

              break;
            }

            case Term::SF_LET_TUPLE: {
              _instructions.push(FVI_TERM_LIST);
              _termLists.push(sd->getBinding());
              break;
            }

            case Term::SF_TUPLE: {
              Term* tt = sd->getTupleTerm();
              Term::Iterator tts(tt);
              while (tts.hasNext()) {
                _instructions.push(FVI_TERM_LIST);
                _termLists.push(tts.next());
              }
              break;
            }

#if VDEBUG
            default:
              ASSERTION_VIOLATION;
#endif
          }
        }

        break;
      }

      case FVI_TERM_LIST: {
        TermList ts = _termLists.pop();
        if (ts.isVar()) {
          unsigned var = ts.var();
          if (!_free.get(var) && !_bound.get(var)) {
            _nextVar = var;
            _found = true;
            _free.inc(var);
            return true;
          }
        } else {
          _instructions.push(FVI_TERM);
          _terms.push(ts.term());
        }
        break;
      }

      case FVI_BIND: {
        Formula::VarList::Iterator vs(_vars.top());
        while (vs.hasNext()) {
          _bound.inc(vs.next());
        }
        break;
      }

      case FVI_UNBIND: {
        Formula::VarList::Iterator vs(_vars.pop());
        while (vs.hasNext()) {
          _bound.dec(vs.next());
        }
        break;
      }
    }
  }

  return false;
} 

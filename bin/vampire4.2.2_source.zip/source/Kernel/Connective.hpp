
/*
 * File Connective.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#ifndef __Connective__
#define __Connective__

namespace Kernel {

enum Connective 
{
 
  LITERAL = 0u,
 
  AND = 1u,
 
  OR = 2u,
 
  IMP = 3u,
 
  IFF = 4u,
 
  XOR = 5u,
 
  NOT = 6u,
 
  FORALL = 7u,
 
  EXISTS = 8u,
 
  BOOL_TERM = 9u,
 
  FALSE = 10u,
 
  TRUE = 11u,
 
  NAME = 12u,
 
  NOCONN = 13u
}; 

}

#endif 

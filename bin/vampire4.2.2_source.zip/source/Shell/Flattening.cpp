
/*
 * File Flattening.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Debug/RuntimeStatistics.hpp"
#include "Debug/Tracer.hpp"

#include "Kernel/Inference.hpp"
#include "Kernel/FormulaUnit.hpp"
#include "Kernel/Problem.hpp"
#include "Kernel/Unit.hpp"

#include "Lib/Environment.hpp"
#include "Shell/Options.hpp"

#include "Flattening.hpp"

namespace Shell
{

Formula* Flattening::getFlattennedNegation(Formula* f)
{
  CALL("Flattening::getFlattennedNegation");

  switch(f->connective()) {
  case NOT:
    return f->uarg();
  case TRUE:
    return Formula::falseFormula();
  case FALSE:
    return Formula::trueFormula();
  default:
    return new NegatedFormula(f);
  }

}

FormulaUnit* Flattening::flatten (FormulaUnit* unit)
{
  CALL("Flattening::flatten (Unit*)");
  ASS(! unit->isClause());

  Formula* f = unit->formula();
  Formula* g = flatten(f);
  if (f == g) { 
    return unit;
  }

  FormulaUnit* res = new FormulaUnit(g,
			 new Inference1(Inference::FLATTEN,unit),
			 unit->inputType());
  if(unit->included()) {
    res->markIncluded();
  }
  if (env.options->showPreprocessing()) {
    env.beginOutput();
    env.out() << "[PP] flatten in: " << unit->toString() << std::endl;
    env.out() << "[PP] flatten out: " << res->toString() << std::endl;
    env.endOutput();
  }
  return res;
} 

Formula* Flattening::flatten (Formula* f)
{
  CALL("Flattening::flatten(Formula*)");

  Connective con = f->connective();
  switch (con) {
  case TRUE:
  case FALSE:
    return f;

  case LITERAL:
    {
      Literal* lit = f->literal();

      if (env.options->newCNF()) {
        
        if (lit->isEquality()) {
          TermList lhs = *lit->nthArgument(0);
          TermList rhs = *lit->nthArgument(1);

          bool lhsBoolean = lhs.isTerm() && lhs.term()->isBoolean();
          bool rhsBoolean = rhs.isTerm() && rhs.term()->isBoolean();
          bool varEquality = lit->isTwoVarEquality() && lit->twoVarEqSort() == Sorts::SRT_BOOL;

          if (lhsBoolean || rhsBoolean || varEquality) {
            Formula* lhsFormula = BoolTermFormula::create(lhs);
            Formula* rhsFormula = BoolTermFormula::create(rhs);
            return flatten(new BinaryFormula(lit->polarity() ? IFF : XOR, lhsFormula, rhsFormula));
          }
        }
      }

      Literal* flattenedLit = flatten(lit);
      if (lit == flattenedLit) {
        return f;
      } else {
        return new AtomicFormula(flattenedLit);
      }
    }

  case BOOL_TERM:
    {
      TermList ts = f->getBooleanTerm();
      TermList flattenedTs = flatten(ts);
      if (ts == flattenedTs) {
        return f;
      } else {
        return new BoolTermFormula(flattenedTs);
      }
    }

  case AND:
  case OR: 
    {
      FormulaList* args = flatten(f->args(),con);
      if (args == f->args()) { 
	return f;
      }
      return new JunctionFormula(con,args);
    }

  case IMP:
  case IFF:
  case XOR: 
    {
      Formula* left = flatten(f->left());
      Formula* right = flatten(f->right());
      if (left == f->left() && right == f->right()) {
	return f;
      }
      return new BinaryFormula(con,left,right);
    }
    
  case NOT: 
    {
      Formula* arg = flatten(f->uarg());

      if(arg->connective()==NOT) {
	
	return arg->uarg();
      }
      if(arg->connective()==LITERAL) {
	return new AtomicFormula(Literal::complementaryLiteral(arg->literal()));
      }
      if (arg == f->uarg()) {
	return f;
      }
      return new NegatedFormula(arg);
    }
    
  case FORALL:
  case EXISTS: 
    {
      Formula* arg = flatten(f->qarg());
      if (arg->connective() != con) {
	if (arg == f->qarg()) {
	  return f;
	}
	return new QuantifiedFormula(con,f->vars(),f->sorts(),arg);
      }

      
      
      Formula::SortList* sl = 0;
      if(f->sorts() && arg->sorts()){
        sl = Formula::SortList::append(f->sorts(), arg->sorts());
      }
      return new QuantifiedFormula(con,
				   Formula::VarList::append(f->vars(), arg->vars()),
                                   sl, 
				   arg->qarg());
    }

#if VDEBUG
  default:
    ASSERTION_VIOLATION;
#endif
  }

} 

Literal* Flattening::flatten(Literal* l)
{
  CALL("Flattening::flatten(Literal*)");

  if (l->shared()) {
    return l;
  }

  bool flattened = false;
  Stack<TermList> args;
  Term::Iterator terms(l);
  while (terms.hasNext()) {
    TermList argument = terms.next();
    TermList flattenedArgument = flatten(argument);
    if (argument != flattenedArgument) {
      flattened = true;
    }
    args.push(flattenedArgument);
  }

  if (!flattened) {
    return l;
  }

  return Literal::create(l, args.begin());
} 

TermList Flattening::flatten (TermList ts)
{
  CALL("Flattening::flatten(TermList)");

  if (ts.isVar()) {
    return ts;
  }

  Term* term = ts.term();

  if (term->shared()) {
    return ts;
  }

  if (term->isSpecial()) {
    Term::SpecialTermData* sd = term->getSpecialData();
    switch (sd->getType()) {
      case Term::SF_FORMULA: {
        Formula* f = sd->getFormula();
        Formula* flattenedF = flatten(f);
        if (f == flattenedF) {
          return ts;
        } else {
          return TermList(Term::createFormula(flattenedF));
        }
      }

      case Term::SF_ITE: {
        TermList thenBranch = *term->nthArgument(0);
        TermList elseBranch = *term->nthArgument(1);
        Formula* condition  = sd->getCondition();

        TermList flattenedThenBranch = flatten(thenBranch);
        TermList flattenedElseBranch = flatten(elseBranch);
        Formula* flattenedCondition  = flatten(condition);

        if ((thenBranch == flattenedThenBranch) &&
            (elseBranch == flattenedElseBranch) &&
            (condition == flattenedCondition)) {
          return ts;
        } else {
          return TermList(Term::createITE(flattenedCondition, flattenedThenBranch, flattenedElseBranch, sd->getSort()));
        }
      }

      case Term::SF_LET: {
        TermList binding = sd->getBinding();
        TermList body = *term->nthArgument(0);

        TermList flattenedBinding = flatten(binding);
        TermList flattenedBody = flatten(body);

        if ((binding == flattenedBinding) && (body == flattenedBody)) {
          return ts;
        } else {
          return TermList(Term::createLet(sd->getFunctor(), sd->getVariables(), flattenedBinding, flattenedBody, sd->getSort()));
        }
      }

      case Term::SF_LET_TUPLE: {
        TermList binding = sd->getBinding();
        TermList body = *term->nthArgument(0);

        TermList flattenedBinding = flatten(binding);
        TermList flattenedBody = flatten(body);

        if ((binding == flattenedBinding) && (body == flattenedBody)) {
          return ts;
        } else {
          return TermList(Term::createTupleLet(sd->getFunctor(), sd->getTupleSymbols(), flattenedBinding, flattenedBody, sd->getSort()));
        }
      }

      case Term::SF_TUPLE: {
        TermList tupleTerm = TermList(sd->getTupleTerm());
        TermList flattenedTupleTerm = flatten(tupleTerm);

        if (tupleTerm == flattenedTupleTerm) {
          return ts;
        } else {
          ASS_REP(flattenedTupleTerm.isTerm(), flattenedTupleTerm.toString())
          return TermList(Term::createTuple(flattenedTupleTerm.term()));
        }
      }

      default:
        ASSERTION_VIOLATION;
    }
  }

  bool flattened = false;
  Stack<TermList> args;
  Term::Iterator terms(term);
  while (terms.hasNext()) {
    TermList argument = terms.next();
    TermList flattenedArgument = flatten(argument);
    if (argument != flattenedArgument) {
      flattened = true;
    }
    args.push(flattenedArgument);
  }

  if (!flattened) {
    return ts;
  }

  return TermList(Term::create(term, args.begin()));
} 

FormulaList* Flattening::flatten (FormulaList* fs, 
				  Connective con)
{
  CALL("Flattening::flatten (FormulaList*...)");
  ASS(con == OR || con == AND);

#if 1
  if(!fs) {
    return 0;
  }

  FormulaList* fs0 = fs;

  bool modified = false;
  Stack<Formula*> res(8);
  Stack<FormulaList*> toDo(8);
  for(;;) {
    if(fs->head()->connective()==con) {
      modified = true;
      if(fs->tail()) {
	toDo.push(fs->tail());
      }
      fs = fs->head()->args();
      continue;
    }
    Formula* hdRes = flatten(fs->head());
    if(hdRes!=fs->head()) {
      modified = true;
    }
    res.push(hdRes);
    fs = fs->tail();
    if(!fs) {
      if(toDo.isEmpty()) {
	break;
      }
      fs = toDo.pop();
    }
  }
  if(!modified) {
    return fs0;
  }
  FormulaList* resLst = 0;
  FormulaList::pushFromIterator(Stack<Formula*>::TopFirstIterator(res), resLst);
  return resLst;
#else
  if (fs->isEmpty()) {
    return fs;
  }
  Formula* head = flatten(fs->head());
  FormulaList* tail = flatten(fs->tail(),con);

  if (head->connective() == con) {
    return FormulaList::append(head->args(), tail);
  }

  if (head == fs->head() && tail == fs->tail()) {
    return fs;
  }
  return new FormulaList(head,tail);
#endif
} 


}

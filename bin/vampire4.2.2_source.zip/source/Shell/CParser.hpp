
/*
 * File CParser.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __CParser__
#define __CParser__

#include <vector>

#include "Lib/Exception.hpp"
#include "Lib/VString.hpp"

using namespace std;

namespace Shell {

class CParser 
{
public:
 
  class LexerException 
    : public Lib::Exception
  {
  public:                                
    LexerException(const CParser&,unsigned pos,Lib::vstring message);
    void cry(ostream&);
    ~LexerException() {}
  protected:
    Lib::vstring _message;
    unsigned _pos;
  }; 

 
  class ParserException 
    : public Lib::Exception
  {
  public:                                
    ParserException(const CParser&,unsigned pos,Lib::vstring message);
    void cry(ostream&);
    ~ParserException() {}
  protected:
    Lib::vstring _message;
    unsigned _pos;
  }; 

 
  enum LTType {
   
    LT_IDENTIFIER,

   
    LT_AUTO,
   
    LT_BREAK,
   
    LT_CASE,
   
    LT_CHAR,
   
    LT_CONST,
   
    LT_CONTINUE,
   
    LT_DEFAULT,
   
    LT_DO,
   
    LT_DOUBLE,
   
    LT_ELSE,
   
    LT_ENUM,
   
    LT_EXTERN,
   
    LT_FLOAT,
   
    LT_FOR,
   
    LT_GOTO,
   
    LT_IF,
   
    LT_INLINE,
   
    LT_INT,
   
    LT_LONG,
   
    LT_REGISTER,
   
    LT_RESTRICT,
   
    LT_RETURN,
   
    LT_SHORT,
   
    LT_SIGNED,
   
    LT_SIZEOF,
   
    LT_STRUCT,
   
    LT_SWITCH,
   
    LT_TYPEDEF,
   
    LT_UNION,
   
    LT_UNSIGNED,
   
    LT_VOID,
   
    LT_VOLATILE,
   
    LT_WHILE,

   
    LT_LBRACE,
   
    LT_RBRACE,
   
    LT_LPAR,
   
    LT_RPAR,
   
    LT_SEMICOLON,
   
    LT_EQ_OP,
   
    LT_ASSIGN,
   
    LT_ADD_ASSIGN,
   
    LT_INC_OP,
   
    LT_ADD,
   
    LT_MULT_ASSIGN,
   
    LT_MULT,
   
    LT_ELLIPSIS,
   
    LT_DOT,
   
    LT_GE_OP,
   
    LT_GREATER,
   
    LT_RIGHT_ASSIGN,
   
    LT_RIGHT_OP,
   
    LT_LE_OP,
   
    LT_LBRACKET,
   
    LT_LESS,
   
    LT_LEFT_ASSIGN,
   
    LT_LEFT_OP,
   
    LT_SUB_ASSIGN,
   
    LT_DEC_OP,
   
    LT_PTR_OP,
   
    LT_MINUS,
   
    LT_DIV_ASSIGN,
   
    LT_DIV,
   
    LT_MOD_ASSIGN,
   
    LT_MOD,
   
    LT_AND_ASSIGN,
   
    LT_AND_OP,
   
    LT_AMP,
   
    LT_OR_ASSIGN,
   
    LT_OR_OP,
   
    LT_BAR,
   
    LT_XOR_ASSIGN,
   
    LT_XOR,
   
    LT_NE_OP,
   
    LT_EXCLAMATION,
   
    LT_COLON,
   
    LT_RBRACKET,
   
    LT_COMMA,
   
    LT_TILDE,
   
    LT_QUESTION,

   
    LT_INT_CONST,
   
    LT_LONG_CONST,
   
    LT_UINT_CONST,
   
    LT_ULONG_CONST,
   
    LT_FLOAT_CONST,
   
    LT_DOUBLE_CONST,
   
    LT_STRING_CONST,
   
    LT_CHAR_CONST,
   
    LT_EOF,
  };

  struct Token {
    LTType type;
    unsigned start;
    unsigned end;
  };

 
  enum PTType {
   
    PT_CONSTANT_EXPRESSION,
   
    PT_ARRAY_APPLICATION,
   
    PT_IDENTIFIER,
  };

 
  class Unit {
  public:
   
    PTType type() const { return _type; }
   
    Unit(PTType tp,unsigned start,unsigned end)
      : _type(tp), _start(start), _end(end)
    {}
   
    unsigned start() const { return _start; }
   
    unsigned end() const { return _end; }
  protected:
   
    PTType _type;
   
    unsigned _start;
   
    unsigned _end;
  };

 
  class ConstantExpression
    : public Unit
  {
  public:
   
    ConstantExpression(unsigned start,unsigned end);
  };

 
  class Identifier
    : public Unit
  {
  public:
   
    Identifier(unsigned start,unsigned end);
  };

 
  class ArrayApplication
    : public Unit
  {
  public:
   
    ArrayApplication(unsigned start,unsigned end,Unit* lhs,Unit* rhs):
      Unit(PT_ARRAY_APPLICATION,start,end)
    {}
  };

  CParser(const char* input);
  ~CParser();
  void tokenize();
 
  const char* input() const { return _input; }

  #if VDEBUG
  void output(ostream& str);
  static const char* toString(LTType);
  #endif

private:
  
  unsigned skipWhiteSpacesAndComments(unsigned pos);
  unsigned skipToEndOfLine(unsigned pos);
  unsigned skipToEndOfComment(unsigned pos);

  LTType keyword(unsigned pos,unsigned end);
  static bool keyword(const char* txt,const char* word,int chars);

  unsigned integerTypeSuffix(unsigned start,LTType&);
  unsigned decimalLiteral(unsigned start,LTType&);
  unsigned octalLiteral(unsigned start,LTType&);
  unsigned hexLiteral(unsigned start,LTType&);
  unsigned floatingPointLiteral(unsigned start,LTType&);
  unsigned exponent(unsigned start);
  unsigned identifier(unsigned start);
  unsigned numericConstant(unsigned start,LTType&);
  unsigned stringConstant(unsigned start);
  unsigned charConstant(unsigned start);

 
  static bool digit(char c) { return c >= '0' && c <= '9'; }
  static bool letter(char c);
  static bool floatTypeSuffix(char c,LTType&);
  static bool hexDigit(char c);

  
  unsigned primaryExpression(unsigned pos,bool backtrack);
  unsigned postfixExpression(unsigned pos,bool backtrack);
  unsigned unaryExpression(unsigned pos,bool backtrack);
  unsigned multiplicativeExpression(unsigned pos,bool backtrack);
  unsigned additiveExpression(unsigned pos,bool backtrack);
  unsigned shiftExpression(unsigned pos,bool backtrack);
  unsigned relationalExpression(unsigned pos,bool backtrack);
  unsigned equalityExpression(unsigned pos,bool backtrack);
  unsigned andExpression(unsigned pos,bool backtrack);
  unsigned xorExpression(unsigned pos,bool backtrack);
  unsigned orExpression(unsigned pos,bool backtrack);
  unsigned logicalAndExpression(unsigned pos,bool backtrack);
  unsigned logicalOrExpression(unsigned pos,bool backtrack);
  unsigned conditionalExpression(unsigned pos,bool backtrack);
  unsigned assignmentExpression(unsigned pos,bool backtrack);
  unsigned expression(unsigned pos,bool backtrack);
  bool consumeToken(LTType t,unsigned pos,bool backtrack);
  unsigned argumentExpressionList(unsigned pos,bool backtrack);

 
  const char* _input;
 
  vector<Token> _tokens;
 
  vector<Unit*> _units;
}; 

}

#endif



/*
 * File FOOLElimination.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Indexing/TermSharing.hpp"

#include "Lib/Environment.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/FormulaUnit.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/Problem.hpp"
#include "Kernel/Signature.hpp"
#include "Kernel/SortHelper.hpp"
#include "Kernel/SubformulaIterator.hpp"

#include "Shell/Options.hpp"
#include "Shell/SymbolOccurrenceReplacement.hpp"

#include "Rectify.hpp"

#include "FOOLElimination.hpp"

using namespace Lib;
using namespace Kernel;
using namespace Shell;


const char* FOOLElimination::ITE_PREFIX  = "iG";
const char* FOOLElimination::LET_PREFIX  = "lG";
const char* FOOLElimination::BOOL_PREFIX = "bG";


const Unit::InputType FOOLElimination::DEFINITION_INPUT_TYPE = Unit::AXIOM;

FOOLElimination::FOOLElimination() : _defs(0) {}

bool FOOLElimination::needsElimination(FormulaUnit* unit) {
  CALL("FOOLElimination::needsElimination");

 

  SubformulaIterator sfi(unit->formula());
  while(sfi.hasNext()) {
    Formula* formula = sfi.next();
    switch (formula->connective()) {
      case LITERAL:
        if (!formula->literal()->shared()) {
          return true;
        }
        break;
      case BOOL_TERM:
        return true;
      default:
        break;
    }
  }
  return false;
}

void FOOLElimination::apply(Problem& prb)  {
  CALL("FOOLElimination::apply(Problem*)");

  apply(prb.units());
  prb.reportFOOLEliminated();
  prb.invalidateProperty();
}

void FOOLElimination::apply(UnitList*& units) {
  CALL("FOOLElimination::apply(UnitList*&)");

  UnitList::DelIterator us(units);
  while(us.hasNext()) {
    Unit* unit = us.next();
    if(unit->isClause()) {
      Clause* clause = static_cast<Clause*>(unit);
      for (unsigned i = 0; i < clause->length(); i++) {
        
        
        if(!(*clause)[i]->shared()){ 
          USER_ERROR("Input clauses (cnf) cannot use $ite, $let or $o terms. Error in "+clause->literalsOnlyToString());
        }
      }
      continue;
    }
    Unit* processedUnit = apply(static_cast<FormulaUnit*>(unit));
    if (processedUnit != unit) {
      us.replace(processedUnit);
    }
  }

  
  

  units = UnitList::concat(_defs, units);
  _defs = 0;
}

FormulaUnit* FOOLElimination::apply(FormulaUnit* unit) {
  CALL("FOOLElimination::apply(FormulaUnit*)");

  if (!needsElimination(unit)) {
    return unit;
  }

  FormulaUnit* rectifiedUnit = Rectify::rectify(unit);

  Formula* formula = rectifiedUnit->formula();

  _unit = rectifiedUnit;
  _varSorts.reset();

  SortHelper::collectVariableSorts(formula, _varSorts);

  Formula* processedFormula = process(formula);
  if (formula == processedFormula) {
    return rectifiedUnit;
  }

  Inference* inference = new Inference1(Inference::FOOL_ELIMINATION, rectifiedUnit);
  FormulaUnit* processedUnit = new FormulaUnit(processedFormula, inference, rectifiedUnit->inputType());

  if (unit->included()) {
    processedUnit->markIncluded();
  }

  if (env.options->showPreprocessing()) {
    env.beginOutput();
    env.out() << "[PP] " << unit->toString() << endl;
    env.out() << "[PP] " << processedUnit->toString()  << endl;
    env.endOutput();
  }

  return processedUnit;
}

Formula* FOOLElimination::process(Formula* formula) {
  CALL("FOOLElimination::process(Formula*)");

  switch (formula->connective()) {
    case LITERAL: {
      Literal* literal = formula->literal();

     

      if (literal->isEquality()) {
        ASS_EQ(literal->arity(), 2); 
        TermList lhs = *literal->nthArgument(0);
        TermList rhs = *literal->nthArgument(1);

        bool lhsIsFormula = lhs.isTerm() && lhs.term()->isBoolean();
        bool rhsIsFormula = rhs.isTerm() && rhs.term()->isBoolean();

        if (rhsIsFormula || lhsIsFormula) {
          Formula* lhsFormula = processAsFormula(lhs);
          Formula* rhsFormula = processAsFormula(rhs);

          Connective connective = literal->polarity() ? IFF : XOR;
          Formula* processedFormula = new BinaryFormula(connective, lhsFormula, rhsFormula);

          if (env.options->showPreprocessing()) {
            reportProcessed(formula->toString(), processedFormula->toString());
          }

          return processedFormula;
        }
      }

      Stack<TermList> arguments;
      Term::Iterator lit(literal);
      while (lit.hasNext()) {
        arguments.push(process(lit.next()));
      }

      Formula* processedFormula = new AtomicFormula(Literal::create(literal, arguments.begin()));

      if (env.options->showPreprocessing()) {
        reportProcessed(formula->toString(), processedFormula->toString());
      }

      return processedFormula;
    }

    case IFF:
    case XOR: {
     
      Formula* lhs = formula->left();
      Formula* rhs = formula->right();
      if (lhs->connective() == BOOL_TERM && rhs->connective() == BOOL_TERM) {
        TermList lhsTerm = lhs->getBooleanTerm();
        TermList rhsTerm = rhs->getBooleanTerm();

        bool polarity = formula->connective() == IFF;

        Literal* equality = Literal::createEquality(polarity, process(lhsTerm), process(rhsTerm), Sorts::SRT_BOOL);
        Formula* processedFormula = new AtomicFormula(equality);

        if (env.options->showPreprocessing()) {
          reportProcessed(formula->toString(), processedFormula->toString());
        }

        return processedFormula;
      }
      
    }

    case IMP:
      return new BinaryFormula(formula->connective(), process(formula->left()), process(formula->right()));

    case AND:
    case OR:
      return new JunctionFormula(formula->connective(), process(formula->args()));

    case NOT:
      return new NegatedFormula(process(formula->uarg()));

    case FORALL:
    case EXISTS:
      return new QuantifiedFormula(formula->connective(), formula->vars(),formula->sorts(), process(formula->qarg()));

    case BOOL_TERM: {
      Formula* processedFormula = processAsFormula(formula->getBooleanTerm());

      if (env.options->showPreprocessing()) {
        reportProcessed(formula->toString(), processedFormula->toString());
      }

      return processedFormula;
    }

    case TRUE:
    case FALSE:
      return formula;

#if VDEBUG
    default:
      ASSERTION_VIOLATION;
#endif
  }
}

FormulaList* FOOLElimination::process(FormulaList* formulas) {
  CALL ("FOOLElimination::process(FormulaList*)");

  FormulaList*  res = FormulaList::empty();
  FormulaList** ipt = &res;

  while (!FormulaList::isEmpty(formulas)) {
    Formula* processed = process(formulas->head());
    *ipt = new FormulaList(processed,FormulaList::empty());
    ipt = (*ipt)->tailPtr();
    formulas = formulas->tail();
  }

  return res;

  
}

void FOOLElimination::process(TermList ts, Context context, TermList& termResult, Formula*& formulaResult) {
  CALL("FOOLElimination::process(TermList ts, Context context, ...)");

#if VDEBUG
  
  
  unsigned sort = SortHelper::getResultSort(ts, _varSorts);
  if (context == FORMULA_CONTEXT) {
    ASS_REP(sort == Sorts::SRT_BOOL, ts.toString());
  }
#endif

  if (!ts.isTerm()) {
    if (context == TERM_CONTEXT) {
      termResult = ts;
    } else {
      formulaResult = toEquality(ts);
    }
    return;
  }

  process(ts.term(), context, termResult, formulaResult);

  if (context == FORMULA_CONTEXT) {
    return;
  }

  
  ASS_EQ(sort, SortHelper::getResultSort(termResult, _varSorts));
}

TermList FOOLElimination::process(TermList terms) {
  CALL("FOOLElimination::process(TermList terms)");
  TermList ts;
  Formula* dummy;
  process(terms, TERM_CONTEXT, ts, dummy);
  return ts;
}

Formula* FOOLElimination::processAsFormula(TermList terms) {
  CALL("FOOLElimination::processAsFormula(TermList terms)");
  Formula* formula;
  TermList dummy;
  process(terms, FORMULA_CONTEXT, dummy, formula);
  return formula;
}

void FOOLElimination::process(Term* term, Context context, TermList& termResult, Formula*& formulaResult) {
  CALL("FOOLElimination::process(Term* term, Context context, ...)");

  
  Formula::VarList* freeVars = term->freeVariables();
  Stack<unsigned> freeVarsSorts = collectSorts(freeVars);

 

  if (!term->isSpecial()) {
   

    Stack<TermList> arguments;
    Term::Iterator ait(term);
    while (ait.hasNext()) {
      arguments.push(process(ait.next()));
    }

    TermList processedTerm = TermList(Term::create(term, arguments.begin()));

    if (context == FORMULA_CONTEXT) {
      formulaResult = toEquality(processedTerm);
    } else {
      termResult = processedTerm;
    }
  } else {
   

    Term::SpecialTermData* sd = term->getSpecialData();

    switch (term->functor()) {
      case Term::SF_ITE: {
       

        Formula* condition = process(sd->getCondition());

        TermList thenBranch;
        Formula* thenBranchFormula;
        process(*term->nthArgument(0), context, thenBranch, thenBranchFormula);

        TermList elseBranch;
        Formula* elseBranchFormula;
        process(*term->nthArgument(1), context, elseBranch, elseBranchFormula);

        
        unsigned resultSort = 0;
        if (context == TERM_CONTEXT) {
          resultSort = SortHelper::getResultSort(thenBranch, _varSorts);
          ASS_EQ(resultSort, SortHelper::getResultSort(elseBranch, _varSorts));
        }

        
        unsigned freshSymbol = introduceFreshSymbol(context, ITE_PREFIX, freeVarsSorts, resultSort);

        
        TermList freshFunctionApplication;
        Formula* freshPredicateApplication;
        buildApplication(freshSymbol, freeVars, context, freshFunctionApplication, freshPredicateApplication);

        
        Formula* thenEq = buildEq(context, freshPredicateApplication, thenBranchFormula,
                                           freshFunctionApplication, thenBranch, resultSort);

        
        Formula* thenImplication = new BinaryFormula(IMP, condition, thenEq);

        
        if (Formula::VarList::length(freeVars) > 0) {
          
          thenImplication = new QuantifiedFormula(FORALL, freeVars,0, thenImplication);
        }

        
        Formula* elseEq = buildEq(context, freshPredicateApplication, elseBranchFormula,
                                           freshFunctionApplication, elseBranch, resultSort);

        
        Formula* elseImplication = new BinaryFormula(IMP, new NegatedFormula(condition), elseEq);

        
        if (Formula::VarList::length(freeVars) > 0) {
          
          elseImplication = new QuantifiedFormula(FORALL, freeVars, 0, elseImplication);
        }

        
        Inference* iteInference = new Inference1(Inference::FOOL_ITE_ELIMINATION, _unit);
        addDefinition(new FormulaUnit(thenImplication, iteInference, DEFINITION_INPUT_TYPE));
        addDefinition(new FormulaUnit(elseImplication, iteInference, DEFINITION_INPUT_TYPE));

        if (context == FORMULA_CONTEXT) {
          formulaResult = freshPredicateApplication;
        } else {
          termResult = freshFunctionApplication;
        }
        break;
      }

      case Term::SF_LET: {
       

        TermList binding = sd->getBinding(); 

       
        Context bindingContext = binding.isTerm() && binding.term()->isBoolean() ? FORMULA_CONTEXT : TERM_CONTEXT;

        
        Formula::VarList* argumentVars = sd->getVariables();

        
        Formula::VarList* bodyFreeVars(0);
        Formula::VarList::Iterator bfvi(binding.freeVariables());
        while (bfvi.hasNext()) {
          int var = bfvi.next();
          if (!Formula::VarList::member(var, argumentVars)) {
            bodyFreeVars = new Formula::VarList(var, bodyFreeVars);
          }
        }

        
        Formula::VarList* vars = Formula::VarList::append(bodyFreeVars, argumentVars);
        Stack<unsigned> sorts = collectSorts(vars);

        
        unsigned symbol = sd->getFunctor();
        unsigned bindingSort = SortHelper::getResultSort(binding, _varSorts);

       
        bool renameSymbol = Formula::VarList::isNonEmpty(bodyFreeVars);
        
       
        if(bindingContext == TERM_CONTEXT && !env.signature->getFunction(symbol)->introduced()) renameSymbol = true;
        if(bindingContext == FORMULA_CONTEXT && !env.signature->getPredicate(symbol)->introduced()) renameSymbol = true;

        
        unsigned freshSymbol = renameSymbol ? introduceFreshSymbol(bindingContext, LET_PREFIX, sorts, bindingSort) : symbol;

        
        TermList processedBody;
        Formula* processedBodyFormula;
        process(binding, bindingContext, processedBody, processedBodyFormula);

        
        TermList freshFunctionApplication;
        Formula* freshPredicateApplication;
        buildApplication(freshSymbol, vars, bindingContext, freshFunctionApplication, freshPredicateApplication);

        
        Formula* freshSymbolDefinition = buildEq(bindingContext, freshPredicateApplication, processedBodyFormula,
                                                                 freshFunctionApplication, processedBody, bindingSort);

        
        if (Formula::VarList::length(vars) > 0) {
        
          freshSymbolDefinition = new QuantifiedFormula(FORALL, vars, 0, freshSymbolDefinition);
        }

        
        Inference* letInference = new Inference1(Inference::FOOL_LET_ELIMINATION, _unit);
        addDefinition(new FormulaUnit(freshSymbolDefinition, letInference, DEFINITION_INPUT_TYPE));

        TermList contents = *term->nthArgument(0); 

        
        if (renameSymbol) {
          if (env.options->showPreprocessing()) {
            env.beginOutput();
            env.out() << "[PP] FOOL replace in:  " << contents.toString() << endl;
            env.endOutput();
          }

          SymbolOccurrenceReplacement replacement(bindingContext == FORMULA_CONTEXT, symbol, freshSymbol, bodyFreeVars);
          contents = replacement.process(contents);

          if (env.options->showPreprocessing()) {
            env.beginOutput();
            env.out() << "[PP] FOOL replace out: " << contents.toString() << endl;
            env.endOutput();
          }
        }

        process(contents, context, termResult, formulaResult);

        break;
      }

      case Term::SF_FORMULA: {
        if (context == FORMULA_CONTEXT) {
          formulaResult = process(sd->getFormula());
          break;
        }

        Connective connective = sd->getFormula()->connective();

        if (connective == TRUE) {
          termResult = TermList(Term::foolTrue());
          break;
        }

        if (connective == FALSE) {
          termResult = TermList(Term::foolFalse());
          break;
        }

       

        Formula *formula = process(sd->getFormula());

        
        unsigned freshSymbol = introduceFreshSymbol(context, BOOL_PREFIX, freeVarsSorts, Sorts::SRT_BOOL);
        TermList freshSymbolApplication = buildFunctionApplication(freshSymbol, freeVars);

        
        Formula* freshSymbolDefinition = new BinaryFormula(IFF, formula, toEquality(freshSymbolApplication));

        
        if (Formula::VarList::length(freeVars) > 0) {
          
          freshSymbolDefinition = new QuantifiedFormula(FORALL, freeVars,0, freshSymbolDefinition);
        }

        
        Inference* inference = new Inference1(Inference::FOOL_ELIMINATION, _unit);
        addDefinition(new FormulaUnit(freshSymbolDefinition, inference, DEFINITION_INPUT_TYPE));

        termResult = freshSymbolApplication;
        break;
      }

#if VDEBUG
      default:
        ASSERTION_VIOLATION;
#endif
    }

    if (env.options->showPreprocessing()) {
      reportProcessed(term->toString(), context == FORMULA_CONTEXT ? formulaResult->toString() : termResult.toString());
    }
  }

#if VDEBUG
  
  Formula::VarList* resultFreeVars;
  if (context == TERM_CONTEXT) {
    resultFreeVars = termResult.isVar() ? new List<int>(termResult.var()) : termResult.term()->freeVariables();
  } else {
    resultFreeVars = formulaResult->freeVariables();
  }

  Formula::VarList::Iterator ufv(freeVars);
  while (ufv.hasNext()) {
    unsigned var = (unsigned)ufv.next();
    ASS_REP(Formula::VarList::member(var, resultFreeVars), var);
  }
  Formula::VarList::Iterator pfv(resultFreeVars);
  while (pfv.hasNext()) {
    unsigned var = (unsigned)pfv.next();
    ASS_REP(Formula::VarList::member(var, freeVars), var);
  }

  
  if (context == TERM_CONTEXT) {
    ASS_REP(termResult.isSafe(), termResult);
  }
#endif
}

TermList FOOLElimination::process(Term* term) {
  CALL("FOOLElimination::process(Term* term)");

  TermList termList;
  Formula* dummy;

  process(term, TERM_CONTEXT, termList, dummy);

  return termList;
}

Formula* FOOLElimination::processAsFormula(Term* term) {
  CALL("FOOLElimination::processAsFormula(Term* term)");

  Formula* formula;
  TermList dummy;

  process(term, FORMULA_CONTEXT, dummy, formula);

  return formula;
}

void FOOLElimination::buildApplication(unsigned symbol, Formula::VarList* vars, Context context,
                                       TermList& functionApplication, Formula*& predicateApplication) {
  CALL("FOOLElimination::buildApplication");

  unsigned arity = Formula::VarList::length(vars);
  if (context == FORMULA_CONTEXT) {
    ASS_EQ(env.signature->predicateArity(symbol), arity);
  } else {
    ASS_EQ(env.signature->functionArity(symbol), arity);
  }

  Stack<TermList> arguments;
  Formula::VarList::Iterator vit(vars);
  while (vit.hasNext()) {
    unsigned var = (unsigned)vit.next();
    arguments.push(TermList(var, false));
  }

  if (context == FORMULA_CONTEXT) {
    predicateApplication = new AtomicFormula(Literal::create(symbol, arity, true, false, arguments.begin()));
  } else {
    functionApplication = TermList(Term::create(symbol, arity, arguments.begin()));
  }
}

TermList FOOLElimination::buildFunctionApplication(unsigned function, Formula::VarList* vars) {
  CALL("FOOLElimination::buildFunctionApplication");

  TermList functionApplication;
  Formula* dummy;

  buildApplication(function, vars, TERM_CONTEXT, functionApplication, dummy);

  return functionApplication;
}

Formula* FOOLElimination::buildPredicateApplication(unsigned predicate, Formula::VarList* vars) {
  CALL("FOOLElimination::buildPredicateApplication");

  TermList dummy;
  Formula* predicateApplication;

  buildApplication(predicate, vars, FORMULA_CONTEXT, dummy, predicateApplication);

  return predicateApplication;
}

Formula* FOOLElimination::buildEq(Context context, Formula* lhsFormula, Formula* rhsFormula,
                                                   TermList lhsTerm, TermList rhsTerm, unsigned termSort) {
  CALL("FOOLElimination::buildEq");

  if (context == FORMULA_CONTEXT) {
    
    return new BinaryFormula(IFF, lhsFormula, rhsFormula);
  } else {
    
    return new AtomicFormula(Literal::createEquality(true, lhsTerm, rhsTerm, termSort));
  }
}

Stack<unsigned> FOOLElimination::collectSorts(Formula::VarList* vars) {
  CALL("FOOLElimination::collectSorts");

  Stack<unsigned> sorts;
  Formula::VarList::Iterator fvi(vars);
  while (fvi.hasNext()) {
    unsigned var = (unsigned)fvi.next();
    ASS_REP(_varSorts.find(var), var);
    sorts.push(_varSorts.get(var));
  }
  return sorts;
}

void FOOLElimination::addDefinition(FormulaUnit* def) {
  CALL("FOOLElimination::addDefinition");

  ASS_REP(!needsElimination(def), def->toString());

  _defs = new UnitList(def, _defs);

  if (env.options->showPreprocessing()) {
    env.beginOutput();
    env.out() << "[PP] FOOL added definition: " << def->toString() << endl;
    env.endOutput();
  }
}

Formula* FOOLElimination::toEquality(TermList booleanTerm) {
  TermList truth(Term::foolTrue());
  Literal* equality = Literal::createEquality(true, booleanTerm, truth, Sorts::SRT_BOOL);
  return new AtomicFormula(equality);
}

unsigned FOOLElimination::introduceFreshSymbol(Context context, const char* prefix,
                                               Stack<unsigned> sorts, unsigned resultSort) {
  CALL("FOOLElimination::introduceFreshSymbol");

  unsigned arity = (unsigned)sorts.size();
  BaseType* type;
  if (context == FORMULA_CONTEXT) {
    type = new PredicateType(arity, sorts.begin());
  } else {
    type = new FunctionType(arity, sorts.begin(), resultSort);
  }

  unsigned symbol;
  if (context == FORMULA_CONTEXT) {
    symbol = env.signature->addFreshPredicate(arity, prefix);
    env.signature->getPredicate(symbol)->setType(type);
  } else {
    symbol = env.signature->addFreshFunction(arity, prefix);
    env.signature->getFunction(symbol)->setType(type);
  }

  if (env.options->showPreprocessing()) {
    env.beginOutput();
    env.out() << "[PP] FOOL: introduced fresh ";
    if (context == FORMULA_CONTEXT) {
      env.out() << "predicate symbol " << env.signature->predicateName(symbol);
    } else {
      env.out() << "function symbol " << env.signature->functionName(symbol);
    }
    env.out() << " of the sort " << type->toString() << endl;
    env.endOutput();
  }

  return symbol;
}

void FOOLElimination::reportProcessed(vstring inputRepr, vstring outputRepr) {
  CALL("FOOLElimination::reportProcessed");

  if (inputRepr != outputRepr) {
   
    env.beginOutput();
    env.out() << "[PP] FOOL in:  " << inputRepr  << endl;
    env.out() << "[PP] FOOL out: " << outputRepr << endl;
    env.endOutput();
  }
}

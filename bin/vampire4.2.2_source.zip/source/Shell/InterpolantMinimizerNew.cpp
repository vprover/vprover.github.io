
/*
 * File InterpolantMinimizerNew.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#if VZ3

#include "InterpolantMinimizerNew.hpp"

#include "Kernel/Unit.hpp"
#include "Kernel/InferenceStore.hpp"

#include <memory>
#include <unordered_set> 
#include "z3++.h"

namespace Shell
{
    using namespace Kernel;

    std::unordered_map<Kernel::Unit*, Kernel::Color> InterpolantMinimizerNew::computeSplittingFunction(Kernel::Unit* refutation,  UnitWeight weightFunction)
    {
        CALL("InterpolantMinimizerNew::computeSplittingFunction");
        BYPASSING_ALLOCATOR;
        
        using namespace z3;
        context c;
        optimize solver(c);
        
        std::unordered_map<Unit*, std::unique_ptr<expr>> unitsToExpressions; 
        std::unordered_map<Unit*, std::unique_ptr<expr>> unitsToPenalties;
        int i = 0; 
        
        
        ProofIteratorPostOrder it(refutation);
        while (it.hasNext()) 
        {
            Unit* current = it.next();
            
            
            
            std::unique_ptr<expr> x_i_ptr (new expr(c));
            *x_i_ptr = c.bool_const(("x_" + std::to_string(i)).c_str()); 
            unitsToExpressions.emplace(std::make_pair(current, std::move(x_i_ptr)));
            
            
            std::unique_ptr<expr> p_i_ptr (new expr(c));
            *p_i_ptr = c.bool_const(("p_" + std::to_string(i)).c_str()); 
            unitsToPenalties.emplace(std::make_pair(current, std::move(p_i_ptr)));
            
            
            i++;
            
            expr& x_i = *unitsToExpressions.at(current);
            
            if (current->inheritedColor() == COLOR_LEFT)
            {
                solver.add(x_i);
            }
            else if (current->inheritedColor() == COLOR_RIGHT)
            {
                solver.add(!x_i);
            }
            
            
            if (current->getColor() == COLOR_LEFT)
            {
                solver.add(x_i);
            }
            else if (current->getColor() == COLOR_RIGHT)
            {
                solver.add(!x_i);
            }
            
            
            VirtualIterator<Unit*> parents = InferenceStore::instance()->getParents(current);
            while (parents.hasNext())
            {
                Unit* premise= parents.next();
                if (premise->getColor() == COLOR_LEFT)
                {
                    solver.add(x_i);
                }
                else if (premise->getColor() == COLOR_RIGHT)
                {
                    solver.add(!x_i);
                }
            }
            
            

            
            
            parents = InferenceStore::instance()->getParents(current);
            while (parents.hasNext())
            {
                Unit* premise= parents.next();
                
                expr& x_j = *unitsToExpressions.at(premise);
                expr& p_j = *unitsToPenalties.at(premise);
                
                solver.add(!(x_i != x_j) || p_j);
            }
        }
        
        
       
        expr penaltyFunction = c.real_val(0);

        for (const auto& keyValuePair : unitsToPenalties)
        {
            expr& p_i = *keyValuePair.second;
            double weight = weightForUnit(keyValuePair.first, weightFunction) + 1;
            expr weightExpression = c.real_val(std::to_string(weight).c_str());
            
            penaltyFunction = penaltyFunction + ite(p_i, weightExpression, c.real_val(0));
        }
        solver.minimize(penaltyFunction);

        
       
        
        
        check_result result = solver.check();
        
        
        
        if (result == check_result::sat)
        {
            bool containsLeftInference = false; 
            bool containsRightInference = false; 
            
            
            model m = solver.get_model();
            
            std::unordered_map<Kernel::Unit*, Kernel::Color> splittingFunction;
            for (const auto& keyValuePair : unitsToExpressions)
            {
                Unit* current = keyValuePair.first;
                expr evaluation = m.eval(*unitsToExpressions[current]);
                
                if (Z3_get_bool_value(c,evaluation) == Z3_L_TRUE)
                {
                    splittingFunction[current] = COLOR_LEFT;
                    containsLeftInference = true;
                }
                else
                {
                    splittingFunction[current] = COLOR_RIGHT;
                    containsRightInference = true;
                }
            }
            
            
            if (containsLeftInference && containsRightInference)
            {
                cout << "expecting interpolant weight " << m.eval(penaltyFunction - c.real_val(1)) << endl;
            }
            else
            {
                cout << "expecting interpolant weight " << m.eval(penaltyFunction) << endl;
            }
            
            return splittingFunction;
        }
        
        else
        {
            return InterpolantsNew::computeSplittingFunction(refutation, weightFunction);
        }
    }
    
    void InterpolantMinimizerNew::analyzeLocalProof(Kernel::Unit *refutation)
    {
        BYPASSING_ALLOCATOR;
        CALL("InterpolantMinimizerNew::analyzeLocalProof");

        
        analyzeGreyAreas(refutation);
        
        
        const std::unordered_map<Unit*, Color> splittingFunction = computeSplittingFunction(refutation, UnitWeight::VAMPIRE);
        const std::unordered_map<Unit*, Unit*> unitsToRepresentative = computeSubproofs(refutation, splittingFunction);
        
        std::unordered_set<Unit*> representatives;
        for (const auto& keyValuePair : unitsToRepresentative)
        {
            representatives.insert(keyValuePair.second);
        }
        cout << "Number of red subproofs: " << representatives.size() << endl;
        
        
       
        std::unordered_map<Unit*, int> alternations;
        
        ProofIteratorPostOrder it(refutation);
        while (it.hasNext()) 
        {
            Unit* current = it.next();
            
            
            if (!InferenceStore::instance()->getParents(current).hasNext())
            {
                alternations[current] = 0;
            }
            else
            {
                int alternations_max = 0;
                
                VirtualIterator<Unit*> parents = InferenceStore::instance()->getParents(current);
                while (parents.hasNext())
                {
                    Unit* premise= parents.next();
                    
                    if (splittingFunction.at(premise) != splittingFunction.at(current))
                    {
                        alternations_max = std::max(alternations.at(premise) + 1, alternations_max);
                    }
                    else
                    {
                        alternations_max = std::max(alternations.at(premise), alternations_max);
                    }
                }
                alternations[current] = alternations_max;
            }
        }
        
        cout << "Number of alternations: " << alternations.at(refutation) << endl;
    }
    
   
    void InterpolantMinimizerNew::analyzeGreyAreas(Kernel::Unit* refutation)
    {
        CALL("InterpolantMinimizerNew::analyzeGreyArea");
        
        int number_red = 0;
        int number_blue = 0;
        int number_grey = 0;
        
       
        ProofIteratorPostOrder it(refutation);
        while (it.hasNext()) 
        {
            Unit* current = it.next();
            ASS((!InferenceStore::instance()->getParents(current).hasNext() && (current->inheritedColor() == COLOR_LEFT || current->inheritedColor() == COLOR_RIGHT)) || (InferenceStore::instance()->getParents(current).hasNext() &&  current->inheritedColor() == COLOR_INVALID));
            
            
            if (!InferenceStore::instance()->getParents(current).hasNext())
            {
                if (current->inheritedColor() == COLOR_LEFT)
                {
                    number_red++;
                }
                else
                {
                    number_blue++;
                }
                continue;
            }
            
            
            
            
            if (current->getColor() == COLOR_LEFT)
            {
                number_red++;
                continue;
            }
            else if (current->getColor() == COLOR_RIGHT)
            {
                number_blue++;
                continue;
            }
            
            
            Color containedColor = COLOR_TRANSPARENT;
            VirtualIterator<Unit*> parents = InferenceStore::instance()->getParents(current);
            while (parents.hasNext())
            {
                Unit* premise= parents.next();
                
                if (premise->getColor() == COLOR_LEFT || premise->getColor() == COLOR_RIGHT)
                {
                    containedColor = premise->getColor();
                    break;
                }
            }
            if (containedColor == COLOR_LEFT)
            {
                number_red++;
                continue;
            }
            else if (containedColor == COLOR_RIGHT)
            {
                number_blue++;
                continue;
            }
            
            number_grey++;
        }
        
        cout << "Proof contains " << number_red << " / " << number_blue << " / " << number_grey << " inferences (red/blue/grey)" << endl;
        cout << "Percentage of grey inferences: " << static_cast<double>(number_grey) / (number_red + number_blue + number_grey) << endl;
    }

}

#endif 


/*
 * File FunctionDefinition.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Debug/Tracer.hpp"

#include "Lib/Allocator.hpp"
#include "Lib/BitUtils.hpp"
#include "Lib/DHMultiset.hpp"
#include "Lib/Environment.hpp"
#include "Lib/Int.hpp"
#include "Lib/ScopedLet.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/Formula.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/FormulaUnit.hpp"
#include "Kernel/Problem.hpp"
#include "Kernel/Signature.hpp"
#include "Kernel/SubstHelper.hpp"
#include "Kernel/Term.hpp"
#include "Kernel/TermIterators.hpp"

#include "Shell/Options.hpp"

#include "Statistics.hpp"

#include "FunctionDefinition.hpp"

#if VDEBUG
#include <iostream>
#endif

namespace Shell {

using namespace Lib;
using namespace Kernel;

struct FunctionDefinition::Def
{
  enum Mark {
    UNTOUCHED,
    SAFE,
    LOOP,
    BLOCKED,
    UNFOLDED,
    REMOVED
  };
 
  Clause* defCl;
 
  int fun;
 
  Term* lhs;
 
  Term* rhs;

  Mark mark;
 
  bool linear;
 
  bool strict;
 
  int containedFn;

  int examinedArg;

  IntList* dependentFns;

 
  bool* argOccurs;

  Def(Term* l, Term* r, bool lin, bool str)
    : fun(l->functor()),
      lhs(l),
      rhs(r),
      mark(UNTOUCHED),
      linear(lin),
      strict(str),
      containedFn(-1),
      dependentFns(0),
      argOccurs(0)
  {
  }

  ~Def()
  {
    if(argOccurs) {
      DEALLOC_KNOWN(argOccurs, lhs->arity()*sizeof(bool), "FunctionDefinition::Def::argOccurs");
    }
  }

  CLASS_NAME(FunctionDefinition::Def);
  USE_ALLOCATOR(Def);
}; 


FunctionDefinition::FunctionDefinition ()
  :

    _found(0),
    _removed(0),
    _processedProblem(0)
{
  CALL("FunctionDefinition::FunctionDefinition");
} 

void FunctionDefinition::removeUnusedDefinitions(Problem& prb)
{
  CALL("FunctionDefinition::removeUnusedDefinitions");

  if(removeUnusedDefinitions(prb.units(), &prb)) {
    prb.invalidateByRemoval();
  }
}

bool FunctionDefinition::removeUnusedDefinitions(UnitList*& units, Problem* prb)
{
  CALL("FunctionDefinition::removeUnusedDefinitions");

  unsigned funs=env.signature->functions();

  Stack<Def*> defStack;
  DArray<Def*> def;
  DArray<unsigned> occCounter;
  def.init(funs, 0);
  occCounter.init(funs, 0);

  UnitList::DelIterator scanIterator(units);
  while(scanIterator.hasNext()) {
    Clause* cl=static_cast<Clause*>(scanIterator.next());
    unsigned clen=cl->length();
    ASS(cl->isClause());
    Def* d=isFunctionDefinition(cl);
    if(d) {
      d->defCl=cl;
      if(!def[d->fun]) {
	defStack.push(d);
	def[d->fun]=d;
	scanIterator.del();
      } else {
	delete d;
      }
    }
    for(unsigned i=0;i<clen;i++) {
      NonVariableIterator nvit((*cl)[i]);
      while(nvit.hasNext()) {
	unsigned fn=nvit.next().term()->functor();
	occCounter[fn]++;
      }
    }
  }

  Stack<Def*> toDo;
  Stack<Def*>::Iterator dit(defStack);
  while(dit.hasNext()) {
    Def* d=dit.next();
    unsigned fn=d->fun;
    ASS_GE(occCounter[fn],1);
    if(occCounter[fn]==1) {
      toDo.push(d);
    }
  }

  while(toDo.isNonEmpty()) {
    Def* d=toDo.pop();
    d->mark=Def::REMOVED;
    ASS_EQ(d->defCl->length(), 1);
    ASS_EQ(occCounter[d->fun], 1);
    NonVariableIterator nvit((*d->defCl)[0]);
    while(nvit.hasNext()) {
      unsigned fn=nvit.next().term()->functor();
      occCounter[fn]--;
      if(occCounter[fn]==1 && def[fn]) {
	toDo.push(def[fn]);
      }
    }
    ASS_EQ(occCounter[d->fun], 0);
  }

  bool modified = false;
  while(defStack.isNonEmpty()) {
    Def* d=defStack.pop();
    if(d->mark==Def::REMOVED) {
      modified = true;
      if(prb) {
	ASS_EQ(d->defCl->length(), 1);
	prb->addEliminatedFunction(d->fun, (*d->defCl)[0]);
      }
    }
    else {
      ASS_EQ(d->mark, Def::UNTOUCHED);
      UnitList::push(d->defCl, units);
    }
    delete d;
  }
  return modified;
}

void FunctionDefinition::removeAllDefinitions(Problem& prb)
{
  CALL("FunctionDefinition::removeAllDefinitions(Problem&)");

  ScopedLet<Problem*> prbLet(_processedProblem, &prb);
  if(removeAllDefinitions(prb.units())) {
    prb.invalidateByRemoval();
  }
}

bool FunctionDefinition::removeAllDefinitions(UnitList*& units)
{
  CALL("FunctionDefinition::removeAllDefinitions");

  UnitList::DelIterator scanIterator(units);
  while(scanIterator.hasNext()) {
    Clause* cl=static_cast<Clause*>(scanIterator.next());
    ASS(cl->isClause());
    Def* d=isFunctionDefinition(cl);
    if(d) {
      d->defCl=cl;
      if(_defs.insert(d->fun, d)) {

	scanIterator.del();
      } else {
	delete d;
      }
    }
  }

  if(!_defs.size()) {
    return false;
  }

  Fn2DefMap::Iterator dit(_defs);
  while(dit.hasNext()) {
    Def* d=dit.next();

    if(d->mark==Def::SAFE || d->mark==Def::BLOCKED) {
      continue;
    }
    ASS(d->mark==Def::UNTOUCHED);
    checkDefinitions(d);
  }

  while(_blockedDefs.isNonEmpty()) {
    Def* d=_blockedDefs.pop();
    ASS_EQ(d->mark, Def::BLOCKED);


    UnitList::push(d->defCl, units);
    _defs.remove(d->fun);
    delete d;
  }

  if(_defs.isEmpty()) {
    return false;
  }

  ASS_EQ(_defs.size(), _safeDefs.size());
  
  
  
  for(unsigned i=0;i<_safeDefs.size(); i++) {
    Def* d=_safeDefs[i];
    ASS_EQ(d->mark, Def::SAFE);


    
    
    d->mark=Def::BLOCKED;

    d->defCl=applyDefinitions(d->defCl);


    
    Literal* defEq=(*d->defCl)[0];
    if( defEq->nthArgument(0)->term()==d->lhs ) {
      d->rhs=defEq->nthArgument(1)->term();
    } else {
      ASS_EQ(defEq->nthArgument(1)->term(),d->lhs);
      d->rhs=defEq->nthArgument(0)->term();
    }

    d->mark=Def::UNFOLDED;
    if(_processedProblem) {
      ASS_EQ(d->defCl->length(), 1);
      _processedProblem->addEliminatedFunction(d->fun, (*d->defCl)[0]);
    }

    if (env.options->showPreprocessing()) {
      env.beginOutput();
      env.out() << "[PP] fn def discovered: "<<(*d->defCl)<<"\n  unfolded: "<<(*d->rhs) << std::endl;
      env.endOutput();
    }
    env.statistics->functionDefinitions++;
  }

  UnitList::DelIterator unfoldIterator(units);
  while(unfoldIterator.hasNext()) {
    Clause* cl=static_cast<Clause*>(unfoldIterator.next());
    ASS(cl->isClause());
    Clause* newCl=applyDefinitions(cl);
    if(cl!=newCl) {


      unfoldIterator.replace(newCl);
    }
  }

  _safeDefs.reset();
  return true;
}

void FunctionDefinition::checkDefinitions(Def* def0)
{
  CALL("FunctionDefinition::unfoldDefinition");

  TermList t=TermList(def0->lhs);

  
  
  static Stack<TermList*> stack(4);
  
  static Stack<Def*> defCheckingStack(4);
  
  static Stack<Def*> defArgStack(4);
  
  static Stack<Term*> termArgStack(4);

  
  for(;;) {
    Def* d;
    if(t.isEmpty()) {
      d=defCheckingStack.pop();
      defArgStack.pop();
      termArgStack.pop();
      ASS(!d || d->mark==Def::LOOP);
      if(d && d->mark==Def::LOOP) {
	
	assignArgOccursData(d);
	_safeDefs.push(d);
	d->mark=Def::SAFE;
      }
    } else if(t.isTerm()) {
      Term* trm=t.term();
      Def* checkedDef=0;
    toplevel_def:
      if(!_defs.find(trm->functor(), d) || d->mark==Def::BLOCKED) {
	d=0;
      }
      if(trm->arity() || checkedDef) {
	stack.push(trm->args());
	defCheckingStack.push(checkedDef);
	defArgStack.push(d);
	termArgStack.push(trm);
      }
      if(d) {
	if(d->mark==Def::UNTOUCHED) {
	  
	  d->mark=Def::LOOP;
	  trm=d->rhs;
	  checkedDef=d;
	  goto toplevel_def;
	} else if(d->mark==Def::LOOP) {
	  
	  
	  do{
	    stack.pop();

	    defArgStack.pop();
	    termArgStack.pop();
	    d=defCheckingStack.pop();
	  } while(!d);
	  ASS_EQ(d->mark, Def::LOOP);
	  d->mark=Def::BLOCKED;
	  defArgStack.setTop(0);
	  _blockedDefs.push(d);
	} else {
	  ASS_EQ(d->mark, Def::SAFE);
	}
      }
    }
    if(stack.isEmpty()) {
      break;
    }
    TermList* ts=stack.pop();
    if(ts->isNonEmpty()) {
      Def* argDef=defArgStack.top();
      if(argDef) {
	ASS_EQ(argDef->mark,Def::SAFE);
	Term* parentTerm=termArgStack.top();
	while(ts->isNonEmpty() && !argDef->argOccurs[parentTerm->getArgumentIndex(ts)]) {
	  ts=ts->next();
	}
	if(ts->isNonEmpty()) {
	  stack.push(ts->next());
	}
      } else {
	stack.push(ts->next());
      }
    }
    t=*ts;
  }
  ASS(defCheckingStack.isEmpty());
  ASS(defArgStack.isEmpty());
}

void FunctionDefinition::assignArgOccursData(Def* updDef)
{
  CALL("FunctionDefinition::assignArgOccursData");
  ASS(!updDef->argOccurs);

  if(!updDef->lhs->arity()) {
    return;
  }

  updDef->argOccurs=reinterpret_cast<bool*>(ALLOC_KNOWN(updDef->lhs->arity()*sizeof(bool),
	    "FunctionDefinition::Def::argOccurs"));
  BitUtils::zeroMemory(updDef->argOccurs, updDef->lhs->arity()*sizeof(bool));

  static DHMap<unsigned, unsigned, IdentityHash> var2argIndex;
  var2argIndex.reset();
  int argIndex=0;
  for (TermList* ts = updDef->lhs->args(); ts->isNonEmpty(); ts=ts->next()) {
    int w = ts->var();
    var2argIndex.insert(w, argIndex);
    argIndex++;
  }

  TermList t=TermList(updDef->rhs);
  static Stack<TermList*> stack(4);
  static Stack<Def*> defArgStack(4);
  static Stack<Term*> termArgStack(4);
  for(;;) {
    Def* d;
    if(t.isEmpty()) {
      defArgStack.pop();
      termArgStack.pop();
    } else if(t.isTerm()) {
      Term* trm=t.term();
      if(trm->arity()) {
	if(!_defs.find(trm->functor(), d) || d->mark==Def::BLOCKED) {
	  d=0;
	}
	ASS(!d || d->mark==Def::SAFE);
	stack.push(trm->args());
	defArgStack.push(d);
	termArgStack.push(trm);
      }
    } else {
      ASS(t.isOrdinaryVar());
      updDef->argOccurs[var2argIndex.get(t.var())]=true;
    }
    if(stack.isEmpty()) {
      break;
    }
    TermList* ts=stack.pop();
    if(!ts->isEmpty()) {
      Def* argDef=defArgStack.top();
      if(argDef) {
	Term* parentTerm=termArgStack.top();
	while(ts->isNonEmpty() && !argDef->argOccurs[parentTerm->getArgumentIndex(ts)]) {
	  ts=ts->next();
	}
	if(ts->isNonEmpty()) {
	  stack.push(ts->next());
	}
      } else {
	stack.push(ts->next());
      }
    }
    t=*ts;
  }
}



typedef pair<unsigned,unsigned> BindingSpec;
typedef DHMap<BindingSpec, TermList, IntPairSimpleHash> BindingMap;
typedef DHMap<BindingSpec, bool, IntPairSimpleHash> UnfoldedSet;

Term* FunctionDefinition::applyDefinitions(Literal* lit, Stack<Def*>* usedDefs)
{
  CALL("FunctionDefinition::applyDefinitions");

  if (env.options->showPreprocessing()) {
    env.beginOutput();
    env.out() << "[PP] applying function definitions to literal "<<(*lit) << std::endl;
    env.endOutput();
  }
  BindingMap bindings;
  UnfoldedSet unfolded;
  unsigned nextDefIndex=1;
  Stack<BindingSpec> bindingsBeingUnfolded;
  Stack<unsigned> defIndexes;
  
  
  Stack<TermList*> toDo;
  Stack<Term*> terms;
  Stack<bool> modified;
  Stack<TermList> args;

  bindings.reset();
  unfolded.reset();

  defIndexes.reset();
  toDo.reset();
  terms.reset();
  modified.reset();
  args.reset();

  defIndexes.push(0);
  modified.push(false);
  toDo.push(lit->args());

  for(;;) {
    TermList* tt=toDo.pop();
    if(!tt) {
      BindingSpec spec=bindingsBeingUnfolded.pop();
      bindings.set(spec, args.top());
      unfolded.insert(spec, true);
      continue;
    }
    if(tt->isEmpty()) {
      if(terms.isEmpty()) {
	
	
	ASS(toDo.isEmpty());
	break;
      }
      defIndexes.pop();
      Term* orig=terms.pop();
      if(!modified.pop()) {
	args.truncate(args.length() - orig->arity());
	args.push(TermList(orig));
	continue;
      }
      
      
      
      TermList* argLst=&args.top() - (orig->arity()-1);

      Term* newTrm=Term::create(orig,argLst);
      args.truncate(args.length() - orig->arity());
      args.push(TermList(newTrm));

      modified.setTop(true);
      continue;
    }
    toDo.push(tt->next());

    TermList tl=*tt;
    unsigned defIndex=defIndexes.top();
    Term* t;

    if(tl.isVar()) {
      ASS(tl.isOrdinaryVar());

      if(defIndexes.top()) {
        modified.setTop(true);
        BindingSpec spec=make_pair(defIndexes.top(), tl.var());
        TermList bound=bindings.get(spec);
        if(bound.isVar() || unfolded.find(spec)) {
          args.push(bound);
          continue;
        } else {
          bindingsBeingUnfolded.push(spec);
          toDo.push(0);

          defIndex=0;
          t=bound.term();
        }
      } else {
        args.push(tl);
        continue;
      }

    } else {
      ASS(tl.isTerm());
      t=tl.term();
    }

    Def* d;
    if( !defIndex && _defs.find(t->functor(), d) && d->mark!=Def::BLOCKED) {
      ASS_EQ(d->mark, Def::UNFOLDED);
      usedDefs->push(d);
      if (env.options->showPreprocessing()) {
        env.beginOutput();
        env.out() << "[PP] definition of "<<(*t)<<"\n  expanded to "<<(*d->rhs) << std::endl;
        env.endOutput();
      }

      defIndex=nextDefIndex++;

      
      TermList* dargs=d->lhs->args();
      TermList* targs=t->args();
      while(dargs->isNonEmpty()) {
        ASS(targs->isNonEmpty());
        ALWAYS(bindings.insert(make_pair(defIndex, dargs->var()), *targs));
        dargs=dargs->next();
        targs=targs->next();
      }

      
      t=d->rhs;
      modified.setTop(true);
    }
    defIndexes.push(defIndex);
    terms.push(t);
    modified.push(false);
    toDo.push(t->args());
  }
  ASS(toDo.isEmpty());
  ASS(terms.isEmpty());
  ASS_EQ(modified.length(),1);
  ASS_EQ(args.length(),lit->arity());

  if(!modified.pop()) {
    return lit;
  }

  
  
  
  TermList* argLst=&args.top() - (lit->arity()-1);
  return Literal::create(static_cast<Literal*>(lit),argLst);
}


Clause* FunctionDefinition::applyDefinitions(Clause* cl)
{
  CALL("FunctionDefinition::applyDefinitions(Clause*)")

  unsigned clen=cl->length();

  static Stack<Def*> usedDefs(8);
  static Stack<Literal*> resLits(8);
  ASS(usedDefs.isEmpty());
  resLits.reset();

  bool modified=false;
  for(unsigned i=0;i<clen;i++) {
    Literal* lit=(*cl)[i];
    Literal* rlit=static_cast<Literal*>(applyDefinitions(lit, &usedDefs));
    resLits.push(rlit);
    modified|= rlit!=lit;
  }
  if(!modified) {
    ASS(usedDefs.isEmpty());
    return cl;
  }

  UnitList* premises=0;
  Unit::InputType inpType = cl->inputType();
  while(usedDefs.isNonEmpty()) {
    Clause* defCl=usedDefs.pop()->defCl;
    UnitList::push(defCl, premises);
    inpType = (Unit::InputType)	Int::max(inpType, defCl->inputType());
  }
  UnitList::push(cl, premises);
  Inference* inf = new InferenceMany(Inference::DEFINITION_UNFOLDING, premises);

  Clause* res = new(clen) Clause(clen, inpType, inf);
  res->setAge(cl->age());

  for(unsigned i=0;i<clen;i++) {
    (*res)[i] = resLits[i];
  }

  return res;
}


FunctionDefinition::~FunctionDefinition ()
{
  CALL("FunctionDefinition::~FunctionDefinition");

  Fn2DefMap::Iterator dit(_defs);
  while(dit.hasNext()) {
    delete dit.next();
  }
} 

FunctionDefinition::Def*
FunctionDefinition::isFunctionDefinition (Unit& unit)
{
  CALL("FunctionDefinition::isFunctionDefinition(const Unit&)");
  if (unit.isClause()) {
    return isFunctionDefinition(static_cast<Clause*>(&unit));
  }
  return isFunctionDefinition(static_cast<FormulaUnit&>(unit));
} 


FunctionDefinition::Def*
FunctionDefinition::isFunctionDefinition (Clause* clause)
{
  CALL("FunctionDefinition::isFunctionDefinition(Clause*)");

  if (clause->length() != 1) {
    return 0;
  }
  return isFunctionDefinition((*clause)[0]);
} 

FunctionDefinition::Def*
FunctionDefinition::isFunctionDefinition (Literal* lit)
{
  CALL("FunctionDefinition::isFunctionDefinition(const Literal*)");

  if (! lit->isPositive() ||
      ! lit->isEquality() ||
      ! lit->shared()) {
    return 0;
  }

  
  TermList* args = lit->args();
  if (args->isVar()) {
    return 0;
  }
  Term* l = args->term();
  args = args->next();
  if (args->isVar()) {
    return 0;
  }
  Term* r = args->term();
  Def* def = defines(l,r);
  if (def) {
    return def;
  }
  def = defines(r,l);
  if (def) {
    return def;
  }

  return 0;
} 


FunctionDefinition::Def*
FunctionDefinition::defines (Term* lhs, Term* rhs)
{
  CALL("FunctionDefinition::defines");

  if(!lhs->shared() || !rhs->shared()) {
    return 0;
  }
  unsigned f = lhs->functor();
  if(env.signature->getFunction(f)->protectedSymbol()) {
    return 0;
  }
  if(env.signature->getFunction(f)->distinctGroups()!=0) {
    return 0;
  }
  if(lhs->color()==COLOR_TRANSPARENT && rhs->color()!=COLOR_TRANSPARENT) {
    return 0;
  }

  if (occurs(f,*rhs)) {
    return 0;
  }
  if (lhs->arity() == 0) {
    if (rhs->arity() != 0) { 
      return 0;
    }
    if (rhs->functor() == f) {
      return 0;
    }
    return new Def(lhs,rhs,true,true);
  }

  int vars = 0; 

  
  
  
  MultiCounter counter;
  for (const TermList* ts = lhs->args(); ts->isNonEmpty(); ts=ts->next()) {
    if (! ts->isVar()) {
      return 0;
    }
    int w = ts->var();
    if (counter.get(w) != 0) { 
      return 0;
    }
    counter.inc(w);
    vars++;
  }

  bool linear = true;
  
  
  
  
  
  TermVarIterator vs(rhs->args());
  while (vs.hasNext()) {
    int v = vs.next();
    switch (counter.get(v)) {
    case 0: 
      return 0;

    case 1: 
      counter.inc(v);
      vars--;
      break;

    default: 
      linear = false;
      break;
    }
  }

  Def* res=new Def(lhs,rhs,linear,!vars);
  return res;
} 


bool FunctionDefinition::occurs (unsigned f, Term& t)
{
  CALL ("FunctionDefinition::occurs");

  TermFunIterator funs(&t);
  while (funs.hasNext()) {
    if (f == funs.next()) {
      return true;
    }
  }
  return false;
} 


FunctionDefinition::Def*
FunctionDefinition::isFunctionDefinition (FormulaUnit& unit)
{
  CALL ("Definition::isFunctionDefinition(FormulaUnit&)" );

  Formula* f = unit.formula();
  
  while (f->connective() == FORALL) {
    f = f->qarg();
  }

  if (f->connective() != LITERAL) {
    return 0;
  }
  return isFunctionDefinition(f->literal());
} 

void FunctionDefinition::deleteDef (Def* def)
{
  delete def;
} 


}


/*
 * File DistinctGroupExpansion.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Lib/Environment.hpp"
#include "Lib/Stack.hpp"
#include "Lib/List.hpp"

#include "Kernel/Signature.hpp"
#include "Kernel/Problem.hpp"
#include "Kernel/Unit.hpp"
#include "Kernel/Term.hpp"
#include "Kernel/Formula.hpp"
#include "Kernel/FormulaUnit.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/SortHelper.hpp"
#include "Kernel/Connective.hpp"

#include "Options.hpp"
#include "DistinctGroupExpansion.hpp"

using namespace Shell;

void DistinctGroupExpansion::apply(Problem& prb)
{
  CALL("DistinctGroupExpansion::apply(Problem&)");

  if(apply(prb.units())){
    prb.invalidateProperty();
    prb.reportFormulasAdded();
    prb.reportEqualityAdded(false); 
  }

}

bool DistinctGroupExpansion::apply(UnitList*& units)
{
  CALL("DistinctGroupExpansion::apply(UnitList*&)");

  bool added=false;

  Stack<Stack<unsigned>*> group_members = env.signature->getDistinctGroupMembers();

  
  
  bool expandEverything = 
    env.options->saturationAlgorithm()==Options::SaturationAlgorithm::FINITE_MODEL_BUILDING ||
    env.options->bfnt();

  bool someLeft = false;

  for(unsigned i=0;i<group_members.size();i++){
    Stack<unsigned>* members = group_members[i];
    if(i==Signature::STRING_DISTINCT_GROUP && !env.signature->strings()){ continue;} 
    if(members->size() > 0){
      
      
      

      Signature::Symbol* sym = env.signature->getFunction(members->top());
      unsigned grp_sort = sym->fnType()->result();

      if(grp_sort==Sorts::SRT_INTEGER || grp_sort==Sorts::SRT_RATIONAL || grp_sort==Sorts::SRT_REAL){ someLeft=true; }

      
      
      if( members->size()>1 && (members->size() < 140 || expandEverything)){
        added=true;
        Formula* expansion = expand(*members);
        if(env.options->showPreprocessing()){
          env.out() << "  expansion adding " << expansion->toString() << endl;
        }
        
        UnitList::push(new FormulaUnit(expansion, new Inference(Inference::INPUT),Unit::AXIOM),units);
      }
      else someLeft=true;
    }
  } 

  if(!someLeft){
    env.signature->noDistinctGroupsLeft();
  }

  return added;
}

Formula* DistinctGroupExpansion::expand(Stack<unsigned>& constants)
{
  CALL("DistinctGroupExpansion::expand");

  ASS(constants.size()>=2);
  
  if(constants.size()==2){
    TermList a = TermList(Term::createConstant(constants[0]));
    TermList b = TermList(Term::createConstant(constants[1]));
    unsigned sort = SortHelper::getResultSort(a.term());
    return new AtomicFormula(Literal::createEquality(false,a,b,sort));
  }

  
  FormulaList* diseqs = 0; 

  for(unsigned i=0;i<constants.size();i++){
    TermList a = TermList(Term::createConstant(constants[i]));
    ASS(a.isSafe());
    unsigned sort = SortHelper::getResultSort(a.term());

    for(unsigned j=0;j<i;j++){
      TermList b = TermList(Term::createConstant(constants[j]));
      ASS(b.isSafe());
      
      Formula* new_dis = new AtomicFormula(Literal::createEquality(false,a,b,sort));
      if(diseqs) FormulaList::push(new_dis,diseqs);
      else diseqs = new FormulaList(new_dis);

    }
  }

  
  return new JunctionFormula(Connective::AND, diseqs);

}


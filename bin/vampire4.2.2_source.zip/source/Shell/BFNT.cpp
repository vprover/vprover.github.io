
/*
 * File BFNT.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Lib/Environment.hpp"
#include "Lib/Int.hpp"
#include "Lib/Array.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/Problem.hpp"
#include "Kernel/Signature.hpp"
#include "Kernel/SortHelper.hpp"
#include "Kernel/SubstHelper.hpp"
#include "Kernel/Substitution.hpp"

#include "Property.hpp"
#include "BFNT.hpp"

#define BNFT_SHOW_TRANSFORMED 1

#define BNFT_TPTP_TRANSFORMED 0

#if BNFT_TPTP_TRANSFORMED
#include "Shell/TPTP.hpp"
#endif

using namespace Shell;
using namespace std;
using namespace Lib;
using namespace Kernel;

BFNT::BFNT(Property* prop)
 
{
  _proxy = env.signature->addFreshPredicate(2,"equalish");
}

void BFNT::apply(UnitList* units)
{
  CALL("BFNT::apply(UnitList*&)");

  
  UnitList::Iterator uit(units);
  while (uit.hasNext()) {
    Clause* cl=static_cast<Clause*>(uit.next());
    ASS(cl->isClause());
    _flat.push(apply(cl));
#if BNFT_SHOW_TRANSFORMED
    cout << "Flat: " << _flat.top()->toString() << "\n";
#endif
#if BNFT_TPTP_TRANSFORMED
    cout << "%\n% " << cl->toString() << "\n%\n";
    cout << TPTP::toString(_flat.top()) << "\n";
#endif   
  }
} 

Clause* BFNT::apply(Clause* cl)
{
  CALL("BFNT::apply(Clause*)");

  
  cl = resolveNegativeVariableEqualities(cl);

  
  int maxVar = -1;
  VirtualIterator<unsigned> varIt = cl->getVariableIterator();
  while (varIt.hasNext()) {
    int var = varIt.next();
    if (var > maxVar) {
      maxVar = var;
    }
  }
  
  Map<Term*,Literal*> _literalMap;
  Map<Term*,unsigned> _variableMap;
  
  Stack<Literal*> lits;
  for (int i = cl->length()-1; i>=0; i--) {
    lits.push((*cl)[i]);
  }
  
  Stack<Literal*> result;
  bool updated = false; 
  while (!lits.isEmpty()) {
    Literal* lit = lits.pop();
    if (!lit->isEquality()) {
      bool modified = false;
      Stack<TermList> args;
      for (TermList* ts = lit->args();ts->isNonEmpty();ts = ts->next()) {
	if (ts->isVar()) {
	  args.push(*ts);
	  continue;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	modified = true;
	TermList newVar;
	newVar.makeVar(++maxVar);
	args.push(newVar);
	
	lits.push(Literal::createEquality(false,*ts,newVar, SortHelper::getResultSort(ts->term())));
      }
      if (!modified) { 
	result.push(lit);
	continue;
      }
      updated = true;
      
      result.push(Literal::create(lit,args.begin()));
      continue;
    }
    
    unsigned litArgSort = SortHelper::getEqualityArgumentSort(lit);
    updated = true;
    TermList* lhs = lit->nthArgument(0);
    TermList* rhs = lit->nthArgument(1);
    if (!lit->polarity()) { 
      if (lhs->isVar()) { 
	ASS(!rhs->isVar());
	TermList* tmp = lhs;
	lhs = rhs;
	rhs = tmp;
      }
      else if (!rhs->isVar()) { 
	
	TermList v1;
	v1.makeVar(++maxVar);
	
	lits.push(Literal::createEquality(false, *lhs, v1, litArgSort));
	
	lits.push(Literal::createEquality(false, *rhs, v1, litArgSort));
	continue;
      }
      
      
      Term* l = lhs->term();
      Stack<TermList> args;
      for (TermList* ts = l->args();ts->isNonEmpty();ts = ts->next()) {
	if (ts->isVar()) {
	  args.push(*ts);
	  continue;
	}
	
	TermList newVar;
	newVar.makeVar(++maxVar);
	args.push(newVar);
	
	lits.push(Literal::createEquality(false,*ts,newVar, SortHelper::getResultSort(ts->term())));
	continue;
      }
      
      args.push(*rhs);
      unsigned f = l->functor();
      
      unsigned p; 
      if (!_preds.find(f,p)) { 
	vstring pname = env.signature->getFunction(f)->name();
	p = env.signature->addFreshPredicate(args.length(),pname.c_str());
	_preds.insert(f,p);
      }
      
      result.push(Literal::create(p,args.length(),false,false,args.begin()));
      continue;
    }
    
    TermList v1;
    TermList v2;
    if (lhs->isVar()) {
      v1 = *lhs;
    }
    else {
      
      v1.makeVar(++maxVar);
      lits.push(Literal::createEquality(false,*lhs,v1,litArgSort));
    }
    if (rhs->isVar()) {
      v2 = *rhs;
    }
    else {
      
      v2.makeVar(++maxVar);
      lits.push(Literal::createEquality(false,*rhs,v2,litArgSort));
    }
    
    result.push(Literal::create2(_proxy,true,v1,v2));
  }
  return updated ? Clause::fromStack(result,cl->inputType(),
				     new Inference1(Inference::BFNT_FLATTENING,cl))
                  : cl;
} 

Clause* BFNT::resolveNegativeVariableEqualities(Clause* cl)
{
  CALL("BFNT::resolveNegativeVariableEqualities");

  Array<Literal*> lits;
  Stack<Literal*> inequalities;
  int n = 0;
  for (unsigned i = 0;i < cl->length();i++) {
    Literal* lit = (*cl)[i];
    if (lit->isEquality() &&
	lit->isNegative() &&
	lit->nthArgument(0)->isVar() &&
	lit->nthArgument(1)->isVar()) {
      inequalities.push(lit);
    }
    else {
      lits[n++] = lit;
    }
  }
  if (inequalities.isEmpty()) {
    return cl;
  }
  bool diffVar = false;
  while (!inequalities.isEmpty()) {
    Literal* ineq = inequalities.pop();
    unsigned v1 = ineq->nthArgument(0)->var();
    TermList* v2 = ineq->nthArgument(1);
    if (v1 == v2->var()) { 
      continue;
    }
    diffVar = true;
    Substitution subst;
    subst.bind(v1,*v2);
    cl = new(n) Clause(n,cl->inputType(),
		       new Inference1(Inference::EQUALITY_RESOLUTION,cl));
    for (int i = n-1;i >= 0;i--) {
      Literal* lit = SubstHelper::apply<Substitution>(lits[i],subst);
      (*cl)[i] = lit;
      lits[i] = lit;
    }
  }
  if (!diffVar) { 
    cl = new(n) Clause(n,cl->inputType(),
		       new Inference1(Inference::EQUALITY_RESOLUTION,cl));
    for (int i = n-1;i >= 0;i--) {
      (*cl)[i] = lits[i];
    }
  }
#if BNFT_SHOW_TRANSFORMED
  cout << "EqRes: " << cl->toString() << "\n";
#endif
  return cl;
} 

Problem* BFNT::createProblem(unsigned modelSize)
{
  CALL("BFNT::createProblem");

  UnitList* units = create(modelSize);
  Problem* res = new Problem(units);
  return res;
}

UnitList* BFNT::create(unsigned modelSize)
{
  CALL("BFNT::create");
  ASS(modelSize > 0);

  unsigned len = _constants.length();
  while (len < modelSize) {
    _constants.push(Term::createConstant(Int::toString(++len)));
  }
  UnitList* result = 0;

  
  Term** cs = _constants.begin();
  for (unsigned i = 0;i < len;i++) {
    TermList c1(cs[i]);
    for (unsigned j = 0;j < len;j++) {
      if (i == j) continue;
      TermList c2(cs[j]);
      
      Clause* cls = new(1) Clause(1,Unit::AXIOM,new Inference(Inference::BFNT_DISTINCT));
      (*cls)[0] = Literal::create2(_proxy,false,c1,c2);
#if BNFT_SHOW_TRANSFORMED
      cout << "EqProxy: " << cls->toString() << "\n";
#endif
#if BNFT_TPTP_TRANSFORMED
      cout << TPTP::toString(cls) << "\n";
#endif
      result = new UnitList(cls,result);
    }
  }

  
  Map<unsigned,unsigned>::Iterator preds(_preds);
  unsigned fun;
  unsigned pred;
  unsigned constantsFound=0; 
  while (preds.hasNext()) {
    preds.next(fun,pred);
    int arity = env.signature->getPredicate(pred)->arity();
    Stack<TermList> args;
    for (int i = 0;i < arity;i++) {
      TermList v;
      v.makeVar(i);
      args.push(v);
    }
    Stack<Literal*> lits;
    unsigned elements = modelSize;
    if (arity == 1) {
      constantsFound++;
      if (constantsFound < modelSize) {
	elements = constantsFound;
      }
    }
    for (unsigned i = 0;i < elements;i++) {
      TermList con(cs[i]);
      args.pop();
      args.push(con);
      lits.push(Literal::create(pred,arity,true,false,args.begin()));
    }
    result = new UnitList(Clause::fromStack(lits,Unit::AXIOM,
					    new Inference(Inference::BFNT_TOTALITY)),
			  result);
#if BNFT_TPTP_TRANSFORMED
    cout << TPTP::toString(result->head()) << "\n";
#endif
#if BNFT_SHOW_TRANSFORMED
    cout << "Tot: " << result->head()->toString() << "\n";
#endif
  }
  Stack<Clause*>::Iterator sit(_flat);
  while (sit.hasNext()) {
    result = new UnitList(sit.next(),result);
  }
  return result;
} 

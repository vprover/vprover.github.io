
/*
 * File FOOLElimination.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __FOOLElimination__
#define __FOOLElimination__

#include "Forwards.hpp"

using namespace Kernel;
using namespace Shell;

class FOOLElimination {
public:
  FOOLElimination();

  void apply(Problem& prb);
  void apply(UnitList*& units);

 
  static bool needsElimination(FormulaUnit* unit);

private:
  FormulaUnit* apply(FormulaUnit* fu);

 
  Unit* _unit;

 
  UnitList* _defs;

 
  void addDefinition(FormulaUnit* unit);

 
  DHMap<unsigned,unsigned> _varSorts;

 
  FormulaList* process(FormulaList* fs);
  Formula* process(Formula* f);

  
  typedef bool Context;
  static const Context TERM_CONTEXT = true;
  static const Context FORMULA_CONTEXT = false;

  
  
  void process(TermList ts, Context context, TermList& termResult, Formula*& formulaResult);
  void process(Term* term,  Context context, TermList& termResult, Formula*& formulaResult);

  
  TermList process(TermList terms);
  Formula* processAsFormula(TermList terms);

  
  TermList process(Term* term);
  Formula* processAsFormula(Term* term);

 
  static void buildApplication(unsigned function, Formula::VarList* vars, Context context,
                               TermList& functionApplication, Formula*& predicateApplication);
  
  static TermList buildFunctionApplication(unsigned function, Formula::VarList* vars);
  static Formula* buildPredicateApplication(unsigned predicate, Formula::VarList* vars);

  
  
  static Formula* buildEq(Context context, Formula* lhsFormula, Formula* rhsFormula,
                                           TermList lhsTerm, TermList rhsTerm, unsigned termSort);

  
  
  Stack<unsigned> collectSorts(Formula::VarList* vars);

  
  static Formula* toEquality(TermList booleanTerm);

  
  
  static unsigned introduceFreshSymbol(Context context, const char* prefix,
                                       Stack<unsigned> sorts, unsigned resultSort);

  
  
  static const char* ITE_PREFIX;
  static const char* LET_PREFIX;
  static const char* BOOL_PREFIX;

  
  static const Unit::InputType DEFINITION_INPUT_TYPE;

  
  
  static void reportProcessed(vstring inputRepr, vstring outputRepr);
};

#endif 

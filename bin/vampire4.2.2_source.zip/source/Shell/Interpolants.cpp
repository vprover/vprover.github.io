
/*
 * File Interpolants.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Lib/DHMap.hpp"
#include "Lib/Stack.hpp"
#include "Lib/SharedSet.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/ColorHelper.hpp"
#include "Kernel/Formula.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/InferenceStore.hpp"
#include "Kernel/SubstHelper.hpp"
#include "Kernel/Term.hpp"
#include "Kernel/Unit.hpp"
#include "Kernel/FormulaUnit.hpp"

#include "Flattening.hpp"
#include "SimplifyFalseTrue.hpp"
#include "NNF.hpp"

#include "Interpolants.hpp"

#define TRACE(x)

#define ALLOW_SURPRISING_COLORS 1

namespace Shell
{

using namespace Lib;
using namespace Kernel;

typedef pair<Formula*, Formula*> UIPair; 
typedef List<UIPair> UIPairList;

VirtualIterator<Unit*> Interpolants::getParents(Unit* u)
{
  CALL("Interpolants::getParents");

  if(!_slicedOff) {
    return InferenceStore::instance()->getParents(u);
  }

  static Stack<Unit*> toDo;
  static Stack<Unit*> parents;

  toDo.reset();
  parents.reset();

  for(;;) {
    UnitIterator pit = InferenceStore::instance()->getParents(u);
    while(pit.hasNext()) {
      Unit* par = pit.next();
      if(_slicedOff->find(par)) {
	toDo.push(par);
      }
      else {
	parents.push(par);
      }
    }
    if(toDo.isEmpty()) {
      break;
    }
    u = toDo.pop();
  }

  return getPersistentIterator(Stack<Unit*>::BottomFirstIterator(parents));
}

struct Interpolants::ItemState
{
  ItemState() {}

  ItemState(Unit* us) : parCnt(0), inheritedColor(COLOR_TRANSPARENT), interpolant(0),
      leftInts(0), rightInts(0), processed(false), _us(us)
  {
    CALL("ItemState::ItemState");
    _usColor = us->getColor();
  }

  void destroy()
  {
    CALL("ItemState::destroy");

    List<UIPair>::destroy(leftInts);
    List<UIPair>::destroy(rightInts);
  }

  Unit* us() const { return _us; }
  Color usColor() const { return _usColor; }
 
  VirtualIterator<Unit*> pars;
 
  int parCnt;
 
  Color inheritedColor;
 
  Formula* interpolant;
 
  List<UIPair>* leftInts;
 
  List<UIPair>* rightInts;
 
  bool processed;
private:
 
  Unit* _us;
  Color _usColor;
};

Comparison compareUIP(const UIPair& a, const UIPair& b)
{
  CALL("compareUIP");

  Comparison res = Int::compare(a.first, b.first);
  if(res==EQUAL) {
    res = Int::compare(a.second, b.second);
  }
  return res;
}

void mergeCopy(UIPairList*& tgt, UIPairList* src)
{
  CALL("mergeCopy");
  if(!tgt) {
    tgt = UIPairList::copy(src);
    return;
  }

  UIPairList** curr = &tgt;
  UIPairList::Iterator sit(src);
  while(sit.hasNext()) {
    UIPair spl = sit.next();
  retry_curr:
    if(*curr) {
      Comparison cmp = compareUIP((*curr)->head(), spl);
      if(cmp!=GREATER) {
	curr = (*curr)->tailPtr();
	if(cmp==EQUAL) {
	  continue;
	}
	else {
	  goto retry_curr;
	}
      }
    }
    *curr = new UIPairList(spl, *curr);
    curr = (*curr)->tailPtr();
  }
}

void Interpolants::removeConjectureNodesFromRefutation(Unit* refutation)
{
  CALL("Interpolants::removeConjectureNodesFromRefutation");

  Stack<Unit*> todo;
  DHSet<Unit*> seen;

  todo.push(refutation);
  while (todo.isNonEmpty()) {
    Unit* cur = todo.pop();
    if (!seen.insert(cur)) {
      continue;
    }

    if (cur->inference()->rule() == Inference::NEGATED_CONJECTURE) {
      VirtualIterator<Unit*> pars = InferenceStore::instance()->getParents(cur);

      
      

      ASS(pars.hasNext()); 
      Unit* par = pars.next();

      
      cur->setInheritedColor(par->inheritedColor());

      

      ASS(!pars.hasNext()); 

      cur->inference()->destroy();
      cur->setInference(new Inference(Inference::NEGATED_CONJECTURE)); 
    }

    todo.loadFromIterator(InferenceStore::instance()->getParents(cur));
  }
}

void Interpolants::fakeNodesFromRightButGrayInputsRefutation(Unit* refutation)
{
  CALL("Interpolants::fakeNodesFromRightButGrayInputsRefutation");

  Stack<Unit*> todo;
  DHSet<Unit*> seen;

  todo.push(refutation);
  while (todo.isNonEmpty()) {
    Unit* cur = todo.pop();
    if (!seen.insert(cur)) {
      continue;
    }

    {
      VirtualIterator<Unit*> pars = InferenceStore::instance()->getParents(cur);

      if (!pars.hasNext() && 
          cur->inheritedColor() != COLOR_INVALID && cur->inheritedColor() != COLOR_TRANSPARENT && 
          cur->getColor() == COLOR_TRANSPARENT) {  

          Clause* fakeParent = Clause::fromIterator(LiteralIterator::getEmpty(), cur->inputType(), new Inference(Inference::INPUT));
          fakeParent->setInheritedColor(cur->inheritedColor());
          fakeParent->updateColor(cur->inheritedColor());

          cur->inference()->destroy();
          cur->setInference(new Inference1(Inference::INPUT,fakeParent)); 
          cur->invalidateInheritedColor();
      }
    }

    todo.loadFromIterator(InferenceStore::instance()->getParents(cur));
  }
}


Unit* Interpolants::formulifyRefutation(Unit* refutation)
{
  CALL("Interpolants::formulifyRefutation");

  Stack<Unit*> todo;
  DHMap<Unit*,Unit*> translate; 

  todo.push(refutation);
  while (todo.isNonEmpty()) {
    Unit* cur = todo.top();

    if (translate.find(cur)) {  
      todo.pop();

      continue;
    }

    if (!cur->isClause()) {     
      todo.pop();

      translate.insert(cur,cur);
      continue;
    }

    
    bool allDone = true;
    Inference* inf = cur->inference();
    Inference::Iterator iit = inf->iterator();
    while (inf->hasNext(iit)) {
      Unit* premUnit=inf->next(iit);
      if (!translate.find(premUnit)) {
        allDone = false;
        break;
      }
    }

    if (allDone) { 
      todo.pop();

      List<Unit*>* prems = 0;

      Inference::Iterator iit = inf->iterator();
      while (inf->hasNext(iit)) {
        Unit* premUnit=inf->next(iit);

        List<Unit*>::push(translate.get(premUnit), prems);
      }

      Inference::Rule rule=inf->rule();
      prems = List<Unit*>::reverse(prems);  

      Formula* f = Formula::fromClause(cur->asClause());
      FormulaUnit* fu = new FormulaUnit(f,new InferenceMany(rule,prems),cur->inputType());

      if (cur->inheritedColor() != COLOR_INVALID) {
        fu->setInheritedColor(cur->inheritedColor());
      }

      translate.insert(cur,fu);
    } else { 

      Inference::Iterator iit = inf->iterator();
      while (inf->hasNext(iit)) {
        Unit* premUnit=inf->next(iit);
        todo.push(premUnit);
      }
    }
  }

  return translate.get(refutation);
}

Formula* Interpolants::getInterpolant(Unit* unit)
{
  CALL("Interpolants::getInterpolant");

  typedef DHMap<Unit*,ItemState> ProcMap;
  ProcMap processed;

  TRACE(cout << "===== getInterpolant for " << unit->toString() << endl);

  Stack<ItemState> sts;

  Unit* curr= unit;

  Formula* resultInterpolant = 0;

  int ctr=0;

  for(;;) {
    ItemState st;

    if(processed.find(curr)) {
      st = processed.get(curr);
      ASS(st.us()==curr);
      ASS(st.processed);
      ASS(!st.pars.hasNext());
    }
    else {
      st = ItemState(curr);
      st.pars = getParents(curr);
    }

    TRACE(cout << "curr  " << curr->toString() << endl);
    TRACE(cout << "cu_ic " << curr->inheritedColor() << endl);
    TRACE(cout << "st_co " << st.usColor() << endl);

    if(curr->inheritedColor()!=COLOR_INVALID) {
      
      st.inheritedColor=ColorHelper::combine(curr->inheritedColor(), st.usColor());
      ASS_NEQ(st.inheritedColor, COLOR_INVALID);
    }
#if ALLOW_SURPRISING_COLORS
    else {
      
      
      
      
      
      
      
      st.inheritedColor=st.usColor();
    }
#else
    else if(!st.processed && !st.pars.hasNext()) {
      
      
      
      st.inheritedColor=st.usColor();
    }
#endif

    TRACE(cout << "st_ic " << st.inheritedColor << endl);

    if(sts.isNonEmpty()) {
      
      ItemState& pst=sts.top(); 
      pst.parCnt++;
      if(pst.inheritedColor==COLOR_TRANSPARENT) {
        pst.inheritedColor=st.usColor();

        TRACE(cout << "updated parent's inh col to " << pst.inheritedColor << endl);
        TRACE(cout << "parent " << pst.us()->toString() << endl);

      }
#if VDEBUG
      else {
        Color clr=st.usColor();
        ASS_REP2(pst.inheritedColor==clr || clr==COLOR_TRANSPARENT, pst.us()->toString(), curr->toString());
      }
      ASS_EQ(curr->getColor(),st.usColor());
#endif
    }

    
    if (curr->isClause()) {
      Clause* cl = curr->asClause();

      if (cl->isComponent()) {
        SplitSet* splits = cl->splits();
        ASS_EQ(splits->size(),1);
        _splittingComponents.insert(splits->sval(),cl);
      }
    }

    sts.push(st);

    for(;;) {
      if(sts.top().pars.hasNext()) {
        curr=sts.top().pars.next();
        break;
      }
      
      st=sts.pop();
      ctr++;
      Color color = st.usColor();
      if(!st.processed) {
	if(st.inheritedColor!=color || sts.isEmpty()) {
	  

	    TRACE(cout<<"generate interpolant of transparent clause: "<<st.us()->toString()<<"\n");
	  ASS_REP2(color==COLOR_TRANSPARENT, st.us()->toString(), st.inheritedColor);
	  generateInterpolant(st);
	}
	st.processed = true;
	processed.insert(st.us(), st);
      }
      
      if(sts.isNonEmpty()) {
	
        if(color!=COLOR_LEFT) {
          mergeCopy(sts.top().leftInts, st.leftInts);
        } 
        if(color!=COLOR_RIGHT) {
          mergeCopy(sts.top().rightInts, st.rightInts);
        }
      } 
      else {
	
	
	
        resultInterpolant = st.interpolant;
        goto fin;
      }
    }
  }

fin:

  
  ProcMap::Iterator destrIt(processed);
  while(destrIt.hasNext()) {
    destrIt.next().destroy();
  }

  TRACE(cout << "result interpolant (before false/true - simplification) " << resultInterpolant->toString() << endl);

  cout << "Before simplification: " << resultInterpolant->toString() << endl;
  cout << "Weight before simplification: " << resultInterpolant->weight() << endl;

  
  return Flattening::flatten(NNF::ennf(Flattening::flatten(SimplifyFalseTrue::simplify(resultInterpolant)),true));

}

void Interpolants::generateInterpolant(ItemState& st)
{
  CALL("Interpolants::generateInterpolant");

  Unit* u=st.us();

  TRACE(cout << "GenerateInterpolant for " << u->toString() << endl);

  Color color=st.usColor();
  ASS_EQ(color, COLOR_TRANSPARENT);

  Formula* interpolant;
  Formula* unitFormula=u->getFormula();

  
  if (u->isClause()) {
    Clause* cl = u->asClause();

    if (cl->splits()) {
      FormulaList* disjuncts = FormulaList::empty();
      SplitSet::Iterator it(*cl->splits());
      while(it.hasNext()) {
        SplitLevel lv=it.next();
        Clause* ass = _splittingComponents.get(lv);
        FormulaList::push(new NegatedFormula(Formula::fromClause(ass)),disjuncts);
      }
      if (FormulaList::isNonEmpty(disjuncts)) {
        FormulaList::push(unitFormula,disjuncts);

        unitFormula = JunctionFormula::generalJunction(OR, disjuncts);
      }
    }
  }

  TRACE(cout	<<"unitFormula: "<<unitFormula->toString()<<endl);

  if(st.parCnt) {
    
    FormulaList* conj=0;
    List<UIPair>* src= (st.inheritedColor==COLOR_LEFT) 
        ? st.rightInts
        : st.leftInts;
    
    List<UIPair>::Iterator sit(src);
    while(sit.hasNext()) {
      UIPair uip=sit.next();
      FormulaList* disj=0;
      FormulaList::push(uip.first, disj);
      FormulaList::push(uip.second, disj);
      FormulaList::push(JunctionFormula::generalJunction(OR, disj), conj);
    }

    if(st.inheritedColor==COLOR_LEFT) {
      
      FormulaList* innerConj=0;
      List<UIPair>::Iterator sit2(src);
      while(sit2.hasNext()) {
        UIPair uip=sit2.next();
        FormulaList::push(uip.first, innerConj);
      }
      FormulaList::push(new NegatedFormula(JunctionFormula::generalJunction(AND, innerConj)), conj);
    }
    else {
      
    }
    interpolant=JunctionFormula::generalJunction(AND, conj);
  }
  else {
    
    if(st.inheritedColor==COLOR_RIGHT) {
      interpolant=new NegatedFormula(unitFormula); 
    }
    else {
      
      interpolant=unitFormula; 
    }
  }
  st.interpolant=interpolant;
  TRACE(cout<<"Unit "<<u->toString()
	<<"\nto Formula "<<unitFormula->toString()
	<<"\ninterpolant "<<interpolant->toString()<<endl<<endl);
  UIPair uip=make_pair(unitFormula, interpolant);
  if(st.inheritedColor==COLOR_LEFT) {
    List<UIPair>::destroy(st.leftInts);
    st.leftInts=0;
    List<UIPair>::push(uip,st.leftInts);
  }
  else if(st.inheritedColor==COLOR_RIGHT) {
    List<UIPair>::destroy(st.rightInts);
    st.rightInts=0;
    List<UIPair>::push(uip,st.rightInts);
  }
}

}

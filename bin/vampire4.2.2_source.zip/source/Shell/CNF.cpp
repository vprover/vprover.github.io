
/*
 * File CNF.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Debug/Tracer.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/Formula.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/FormulaUnit.hpp"
#include "CNF.hpp"

using namespace Kernel;
using namespace Shell;

CNF::CNF()
  : _literals(16),
    _formulas(16)
{
} 

void CNF::clausify (Unit* unit,Stack<Clause*>& stack)
{
  CALL("CNF::clausify/2");
  ASS(! unit->isClause());

  _unit = static_cast<FormulaUnit*>(unit);
  _result = &stack;
  _literals.reset();
  _formulas.reset();

  Formula* f = _unit->formula();
  switch (f->connective()) {
  case TRUE:
    return;
  case FALSE:
    {
      
      Clause* clause = new(0) Clause(0,
				     unit->inputType(),
				     new Inference1(Inference::CLAUSIFY,unit));
      stack.push(clause);
    }
    return;
  default:
    clausify(f);
  }
} 


void CNF::clausify (Formula* f)
{
  CALL("CNF::clausify/1");

  switch (f->connective()) {
  case LITERAL:
    _literals.push(f->literal());
    if (_formulas.isEmpty()) {
      
      int length = _literals.length();
      Clause* clause = new(length) Clause(length,
					  _unit->inputType(),
					  new Inference1(Inference::CLAUSIFY,
							 _unit));;
      for (int i = length-1;i >= 0;i--) {
	(*clause)[i] = _literals[i];
      }
      _result->push(clause);
    }
    else {
      f = _formulas.pop();
      clausify(f);
      _formulas.push(f);
    }
    _literals.pop();
    return;

  case AND:
    {
      FormulaList::Iterator fs(f->args());
      while (fs.hasNext()) {
	clausify(fs.next());
      }
    }
    return;

  case OR:
    {
      int ln = _formulas.length();

      FormulaList::Iterator fs(f->args());
      while (fs.hasNext()) {
	_formulas.push(fs.next());
      }
      clausify(_formulas.pop());
      _formulas.truncate(ln);
    }
    return;

  case FORALL:
    clausify(f->qarg());
    return;

#if VDEBUG
  default:
    ASSERTION_VIOLATION;
#endif
  }
} 


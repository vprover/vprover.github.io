
/*
 * File FunctionDefinition.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __FunctionDefinition__
#define __FunctionDefinition__

#include "Forwards.hpp"

#include "Lib/DHMap.hpp"
#include "Lib/MultiCounter.hpp"
#include "Lib/Stack.hpp"
#include "Kernel/Unit.hpp"

namespace Shell {

using namespace Lib;
using namespace Kernel;

class FunctionDefinition
{
public:
  struct Def;
  FunctionDefinition();
  ~FunctionDefinition();

  void removeAllDefinitions(Problem& prb);
  bool removeAllDefinitions(UnitList*& units);

  static void removeUnusedDefinitions(Problem& prb);
  static bool removeUnusedDefinitions(UnitList*& units, Problem* prb=0);


  static Def* isFunctionDefinition (Unit&);
  static void deleteDef(Def* def);






private:
  static Def* isFunctionDefinition (Clause*);
  static Def* isFunctionDefinition (FormulaUnit&);
  static Def* isFunctionDefinition (Literal*);
  static Def* defines (Term* lhs, Term* rhs);
  static bool occurs (unsigned function, Term&);


  bool isDefined(Term* t);

  Term* applyDefinitions(Literal* t, Stack<Def*>* usedDefs);
  Clause* applyDefinitions(Clause* cl);

  void checkDefinitions(Def* t);
  void assignArgOccursData(Def* d);












  typedef DHMap<int, Def*, IdentityHash> Fn2DefMap;
  Fn2DefMap _defs;

 
  Stack<Def*> _blockedDefs;

  Stack<Def*> _safeDefs;
 
  MultiCounter _counter;
 
  int _found;
 
  int _removed;

  Problem* _processedProblem;
}; 


}

#endif

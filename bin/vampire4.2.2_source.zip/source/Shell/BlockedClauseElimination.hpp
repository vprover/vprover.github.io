
/*
 * File BlockedClauseElimination.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#ifndef __BlockedClauseElimination__
#define __BlockedClauseElimination__

#include "Forwards.hpp"

#include "Kernel/Problem.hpp"

#include "Lib/Environment.hpp"
#include "Lib/Comparison.hpp"
#include "Lib/Stack.hpp"

namespace Shell {

using namespace Kernel;

class BlockedClauseElimination
{
public:
  void apply(Kernel::Problem& prb);

private:
  struct ClWrapper;

  struct Candidate {
    CLASS_NAME(BlockedClauseElimination::Candidate);
    USE_ALLOCATOR(Candidate);

    ClWrapper* clw;
    unsigned litIdx;    
    unsigned contFrom;  
    unsigned weight;    
  };

  struct CandidateComparator {
    static Comparison compare(Candidate* c1, Candidate* c2) {
      return Int::compare(c1->weight,c2->weight);
    }
  };

  struct ClWrapper {
    CLASS_NAME(BlockedClauseElimination::ClWrapper);
    USE_ALLOCATOR(ClWrapper);

    Clause* cl;            
    bool blocked;          
    Stack<Candidate*> toResurrect; 

    ClWrapper(Clause* cl) : cl(cl), blocked(false) {}
  };

  bool resolvesToTautology(bool equationally, Clause* cl, Literal* lit, Clause* pcl, Literal* plit);

  bool resolvesToTautologyUn(Clause* cl, Literal* lit, Clause* pcl, Literal* plit);

  bool resolvesToTautologyEq(Clause* cl, Literal* lit, Clause* pcl, Literal* plit);
};

};

#endif

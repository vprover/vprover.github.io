
/*
 * File InterpolantMinimizer.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include <fstream>
#include <sstream>

#include "Lib/Environment.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/Formula.hpp"
#include "Kernel/FormulaUnit.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/Renaming.hpp"
#include "Kernel/Term.hpp"
#include "Kernel/Problem.hpp"
#include "Kernel/Signature.hpp"
#include "Kernel/Connective.hpp"
#include "Kernel/MainLoop.hpp"

#include "Indexing/ClauseVariantIndex.hpp"

#include "Interpolants.hpp"
#include "Options.hpp"

#include "Saturation/Splitter.hpp"

#include "InterpolantMinimizer.hpp"


using namespace Shell;
using namespace Indexing;

#define TRACE(x)

Formula* InterpolantMinimizer::getInterpolant(Unit* refutation)
{
  CALL("InterpolantMinimizer::getInterpolant");
  
  traverse(refutation);
  addAllFormulas();

  SMTSolverResult res;
  YicesSolver solver;
  YicesSolver::MinimizationResult mres = solver.minimize(_resBenchmark, costFunction(), res);


  DHSet<Unit*> slicedOff;

  if(mres==SMTSolver::FAIL) {
    cerr << "Minimization timed failed to find a satisfiable assignment, generating basic interpolant" << endl;
    goto just_generate_interpolant;
  }
  if(mres==SMTSolver::APPROXIMATE) {
    cerr << "Minimization gave approximate result" << endl;
  }

  if(_showStats) {
    env.beginOutput();
    env.out() << _statsPrefix << " cost: " <<res.assignment.get(costFunction()) << endl;
    env.endOutput();
  }

  collectSlicedOffNodes(res, slicedOff);

just_generate_interpolant:
  Formula* interpolant = Interpolants(&slicedOff).getInterpolant(refutation);
    
  return interpolant;
}

    
void InterpolantMinimizer::prettyPrint(Formula* formula, ostream& out)
{
  CALL("SMTLibPrinter::prettyPrint");
        
  Signature *sig = env.signature;
  unsigned symbNum;
  Symbol* symb;
  TermList* args;
  FormulaList* fs;
  switch (formula->connective()) {
    case LITERAL:
        symbNum = formula->literal()->functor();
        symb = sig->getPredicate(symbNum);
        
        if(formula->literal()->args()->isNonEmpty())
             out << "(";
                
        prettyPrint(symb, out);
                
        args = formula->literal()->args();
        while(args->isNonEmpty()) {
                out << " ";
                if(args->isVar())
                    out << "x" << args->var();
                else
                    prettyPrint(args->term(), out);
                args = args->next();
            }
                
        if(formula->literal()->args()->isNonEmpty())
                out << ")";
                
        return;
    case AND:
    case OR:
        if(formula->connective() == AND)
            out << "(and ";
        else
            out << "(or ";
                
        for(fs = formula->args(); FormulaList::isNonEmpty(fs); fs = fs->tail()) {
            prettyPrint(fs->head(), out);
            out << " ";
        }
                
        out << ")";
        return;
    case IMP:
    case IFF:
    case XOR:
        if(formula->connective() == IMP)
                out << "(implies ";
        else if(formula->connective() == IFF)
            out << "(= ";
        else
            ASS(false);
                
        prettyPrint(formula->left(), out);
        out << " ";
        prettyPrint(formula->right(), out);
        out << ")";
        return;
    case NOT:
        out << "(not ";
        prettyPrint(formula->uarg(), out);
        out << ")";
        return;
    case FORALL:
        return;
    case EXISTS:
        return;
    case BOOL_TERM:
        out << formula->getBooleanTerm().toString();
        return;
    case TRUE:
        out << "true";
        return;
    case FALSE:
        out << "false";
        return;
    default:
        out << "WARNING!!! This is not a literal\n";
        ASS(false);
        return;
    }
}
    

        
void InterpolantMinimizer::prettyPrint(Term* term, ostream& out)
{
    Signature *sig = env.signature;
    unsigned int symbNum = term->functor();
    Symbol* symb = sig->getFunction(symbNum);
        
    if(term->args()->isNonEmpty())
        out << "(";
        
    prettyPrint(symb, out);
        
    TermList* args = term->args();
    while(args->isNonEmpty()) {
        out << " ";
        if(args->isVar())
            out << "x" << args->var();
        else
            prettyPrint(args->term(), out);
        args = args->next();
    }
        
    if(term->args()->isNonEmpty())
            out << ")";
}
    


void InterpolantMinimizer::prettyPrint(Symbol* symb, ostream& out)
{
    vstring name = symb->name();
    if(symb->interpreted()) {
        if(name == "$less")
        {out << "<";}
        else if(name == "$lesseq")
        {out << "<=";}
        else if(name == "$greater")
        {out << ">";}
        else if(name == "$greatereq")
        {out << ">=";}
        else if(name == "=")
        {out << "=";}
        else if(name == "$plus")
        {out << "+";}
        else if(name == "$sum")
        {out << "+";}
        else if(name == "$times")
        {out << "*";}
        else if(name == "$product")
        {out << "*";}
        else if(name == "$uminus")
        {out << "-";}
        else 
        {out << name;} 
    }
    else{out<<name;}
}

    
    
    

void InterpolantMinimizer::collectSlicedOffNodes(SMTSolverResult& solverResult, DHSet<Unit*>& acc)
{
  CALL("InterpolantMinimizer::collectSlicedOffNodes");

    
  InfoMap::Iterator uit(_infos);
  while(uit.hasNext()) {
    Unit* unit;
    UnitInfo info;
    uit.next(unit, info);

    if(info.color!=COLOR_TRANSPARENT || !info.leadsToColor) {
      continue;
    }

    vstring uid = getUnitId(unit);
    
    SMTConstant sU = pred(S, uid);
    vstring val = solverResult.assignment.get(sU);
    if(val=="false") {
      continue;
    }
    ASS_EQ(val,"true");
    acc.insert(unit);
  }

  TRACE(
  WeightMap::Iterator wit(_atomWeights);
  while(wit.hasNext()) {
    vstring atom;
    unsigned weight;
    wit.next(atom, weight);

    Unit* unit = _unitsById.get(atom);

    SMTConstant vU = pred(V, atom);

    cout << "because " << solverResult.assignment.get(vU) << " for " << unit->toString() << endl;
  })
}

void InterpolantMinimizer::addAllFormulas()
{
  CALL("InterpolantMinimizer::addAllFormulas");

  InfoMap::Iterator uit(_infos);
  while(uit.hasNext()) {
    Unit* unit;
    UnitInfo info;
    uit.next(unit, info);

    if(info.color==COLOR_TRANSPARENT && info.leadsToColor) {
      addNodeFormulas(unit); 
    }
  }

  addCostFormula();
}

void InterpolantMinimizer::addNodeFormulas(Unit* u)
{
  CALL("InterpolantMinimizer::addNodeFormulas");

  static ParentSummary psum;
  psum.reset();

  UnitIterator pit = InferenceStore::instance()->getParents(u);
  while(pit.hasNext()) {
    Unit* par = pit.next();
    UnitInfo& info = _infos.get(par);
    if(!info.leadsToColor) {
      continue;
    }
    vstring parId = getUnitId(par);
    switch(info.color) {
    case COLOR_LEFT: psum.rParents.push(parId); break;
    case COLOR_RIGHT: psum.bParents.push(parId); break;
    case COLOR_TRANSPARENT: psum.gParents.push(parId); break;
    default: ASSERTION_VIOLATION;
    }
  }

  UnitInfo& uinfo = _infos.get(u);
  ASS_EQ(uinfo.color, COLOR_TRANSPARENT);

  vstring uId = getUnitId(u);

  if(uinfo.inputInheritedColor!=COLOR_TRANSPARENT) {
    
    
    ASS(psum.rParents.isEmpty());
    ASS(psum.bParents.isEmpty());
    ASS(psum.gParents.isEmpty());
    addLeafNodePropertiesFormula(uId);
  }
  else {
    addNodeFormulas(uId, psum);
    addFringeFormulas(u);
  }



  if(_noSlicing || uinfo.isRefutation) {
    vstring comment;
    if(uinfo.isRefutation) {
      comment += "refutation";
    }
    _resBenchmark.addFormula(!pred(S,uId), comment);
  }

  
  
  if(uinfo.isParentOfLeft) {
    _resBenchmark.addFormula(!pred(B,uId), "parent_of_left");
  }
  if(uinfo.isParentOfRight) {
    _resBenchmark.addFormula(!pred(R,uId), "parent_of_right");
  }

  addAtomImplicationFormula(u);
}

void InterpolantMinimizer::addFringeFormulas(Unit* u)
{
  CALL("InterpolantMinimizer::addFringeFormulas");

  vstring n = getUnitId(u);

  SMTFormula rcN = pred(RC, n);
  SMTFormula bcN = pred(BC, n);
  SMTFormula rfN = pred(RF, n);
  SMTFormula bfN = pred(BF, n);
  SMTFormula dN = pred(D, n);

  _resBenchmark.addFormula(dN -=- ((rcN & !rfN) | (bcN & !bfN)));

  UnitInfo& uinfo = _infos.get(u);

  if(uinfo.isRefutation) {
    _resBenchmark.addFormula(!rfN);
    _resBenchmark.addFormula(bfN);
    return;
  }

  SMTFormula rfRhs = SMTFormula::getTrue();
  SMTFormula bfRhs = SMTFormula::getTrue();
  UList::Iterator gsit(uinfo.transparentSuccessors);
  while(gsit.hasNext()) {
    Unit* succ = gsit.next();
    vstring succId = getUnitId(succ);

    SMTFormula rcS = pred(RC, succId);
    SMTFormula bcS = pred(BC, succId);
    SMTFormula rfS = pred(RF, succId);
    SMTFormula bfS = pred(BF, succId);

    rfRhs = rfRhs & ( rfS | rcS ) & !bcS;
    bfRhs = bfRhs & ( bfS | bcS ) & !rcS;
  }


  if(uinfo.rightSuccessors) {
    _resBenchmark.addFormula(!rfN);
  }
  else {
    _resBenchmark.addFormula(rfN -=- rfRhs);
  }

  if(uinfo.leftSuccessors) {
    _resBenchmark.addFormula(!bfN);
  }
  else {
    _resBenchmark.addFormula(bfN -=- bfRhs);
  }

}





class InterpolantMinimizer::ClauseSplitter {
public:
  CLASS_NAME(InterpolantMinimizer::ClauseSplitter);
  USE_ALLOCATOR(InterpolantMinimizer::ClauseSplitter);

  ClauseSplitter() : _index(new SubstitutionTreeClauseVariantIndex()), _acc(0) {}
  
 
  void getComponents(Clause* cl, ClauseStack& acc)
  {
    CALL("InterpolantMinimizer::ClauseSplitter::getComponents");
    ASS(!_acc);

    _acc = &acc;

    if(cl->length()==0) {
      handleNoSplit(cl);
    }
    else {
      doSplitting(cl);
    }

    _acc = 0;
  }
protected:

  void doSplitting(Clause* cl) {

    static Stack<LiteralStack> comps;
    comps.reset();
    
    if(!Saturation::Splitter::getComponents(cl, comps)) {
      handleNoSplit(cl);
    } else {
      buildAndInsertComponents(comps.begin(),comps.size());
    }
  }

  void buildAndInsertComponents(const LiteralStack* comps, unsigned compCnt)
  {
    CALL("InterpolantMinimizer::ClauseSplitter::buildAndInsertComponents");

    for(unsigned i=0; i<compCnt; i++) {
      Clause* compCl = getComponent(comps[i].begin(), comps[i].size());
      _acc->push(compCl);
    }
  }  

  void handleNoSplit(Clause* cl)
  {
    CALL("InterpolantMinimizer::ClauseSplitter::handleNoSplit");

    _acc->push(getComponent(cl));
  }

private:

  Clause* getComponent(Literal* const * lits, unsigned len)
  {
    CALL("InterpolantMinimizer::ClauseSplitter::getComponent/2");

    if(len==1) {
      return getAtomComponent(lits[0], 0);
    }
    ClauseIterator cit = _index->retrieveVariants(lits, len);
    if(cit.hasNext()) {
      Clause* res = cit.next();
      ASS(!cit.hasNext());
      return res;
    }
    
    Clause* res = Clause::fromIterator(getArrayishObjectIterator(lits, len),
	Unit::AXIOM, new Inference(Inference::INPUT));
    res->incRefCnt();
    _index->insert(res);
    return res;
  }

  Clause* getComponent(Clause* cl)
  {
    CALL("InterpolantMinimizer::ClauseSplitter::getComponent/1");

    if(cl->length()==1) {
      return getAtomComponent((*cl)[0], cl);
    }

    ClauseIterator cit = _index->retrieveVariants(cl);
    if(cit.hasNext()) {
      Clause* res = cit.next();
      ASS(!cit.hasNext());
      return res;
    }
    _index->insert(cl);
    return cl;
  }

 
  Clause* getAtomComponent(Literal* lit, Clause* cl)
  {
    CALL("InterpolantMinimizer::ClauseSplitter::getAtomComponent");

    Literal* norm = Literal::positiveLiteral(lit);
    norm = Renaming::normalize(norm);

    Clause* res;
    if(_atomIndex.find(norm, res)) {
      return res;
    }
    res = cl;
    if(!res) {
      res = Clause::fromIterator(getSingletonIterator(norm),
  	Unit::AXIOM, new Inference(Inference::INPUT));
    }
    ALWAYS(_atomIndex.insert(norm, res));
    return res;
  }

  ScopedPtr<ClauseVariantIndex> _index;
  DHMap<Literal*,Clause*> _atomIndex;

  ClauseStack* _acc;
};

void InterpolantMinimizer::collectAtoms(FormulaUnit* f, Stack<vstring>& atoms)
{
  CALL("InterpolantMinimizer::collectAtoms(FormulaUnit*...)");
  
  vstring key = f->formula()->toString();

  vstring id;
  if(!_formulaAtomIds.find(key, id)) {
    id = "f" + Int::toString(_formulaAtomIds.size());
    _formulaAtomIds.insert(key, id);
    unsigned weight = f->formula()->weight();
    _atomWeights.insert(id, weight);
    _unitsById.insert(id, f);
  }
  
  atoms.push(id);
}

vstring InterpolantMinimizer::getComponentId(Clause* cl)
{
  CALL("InterpolantMinimizer::getComponentId");
  vstring id;
  if(!_atomIds.find(cl, id)) {
    id = "c" + Int::toString(_atomIds.size());
    _atomIds.insert(cl, id);
    unsigned weight = cl->weight();
    _atomWeights.insert(id, weight);
    _unitsById.insert(id, cl);
  }
  return id;
}

void InterpolantMinimizer::collectAtoms(Unit* u, Stack<vstring>& atoms)
{
  CALL("InterpolantMinimizer::collectAtoms(Unit*...)");

  if(!u->isClause()) {
    collectAtoms(static_cast<FormulaUnit*>(u), atoms);
    return;
  }
  
  Clause* cl = u->asClause();
    
  static ClauseStack components;
  components.reset();
  _splitter->getComponents(cl, components);
  ASS(components.isNonEmpty());
  ClauseStack::Iterator cit(components);

  TRACE(cout << "collecting for " << u->toString() << endl);

  while(cit.hasNext()) {
    Clause* comp = cit.next();

    TRACE(cout << "comp " << comp->toString() << endl);

    atoms.push(getComponentId(comp));
  }
}

void InterpolantMinimizer::addAtomImplicationFormula(Unit* u)
{
  CALL("InterpolantMinimizer::getAtomImplicationFormula");
  
  
  static Stack<vstring> atoms;
  atoms.reset();
  
  collectAtoms(u, atoms);

  vstring uId = getUnitId(u);

  SMTFormula cConj = SMTFormula::getTrue();
  Stack<vstring>::Iterator ait(atoms);
  while(ait.hasNext()) {
    
    vstring atom = ait.next();
    cConj = cConj & pred(V, atom);
  }

  vstring comment = "atom implications for " + u->toString();
  _resBenchmark.addFormula(pred(D, uId) --> cConj, comment);
}

void InterpolantMinimizer::addCostFormula()
{
  CALL("InterpolantMinimizer::getCostFormula");

  TRACE(cout << "adding cost fla" << endl);

  SMTFormula costSum = SMTFormula::unsignedValue(0);

  WeightMap::Iterator wit(_atomWeights);
  while(wit.hasNext()) {
    vstring atom;
    unsigned weight;
    wit.next(atom, weight);

    Unit* unit = _unitsById.get(atom);
    unsigned varCnt = unit->varCnt();

    if(_optTarget==OT_COUNT && weight>0) {
      weight = 1;
    }
    
    if(_optTarget==OT_QUANTIFIERS){
      weight = varCnt;
    }

    TRACE(cout << "cost " << weight << " for unit " << unit->toString() << endl);

    SMTFormula atomExpr = SMTFormula::condNumber(pred(V, atom), weight);
    costSum = SMTFormula::add(costSum, atomExpr);
  }
  _resBenchmark.addFormula(SMTFormula::equals(costFunction(), costSum));
}





SMTConstant InterpolantMinimizer::pred(PredType t, vstring node)
{
  CALL("InterpolantMinimizer::pred");
  
  
  ASS_NEQ(node, "fake_node");

  vstring n1;
  switch(t) {
  case R: n1 = "r"; break;
  case B: n1 = "b"; break;
  case G: n1 = "g"; break;
  case S: n1 = "s"; break;
  case RC: n1 = "rc"; break;
  case BC: n1 = "bc"; break;
  case RF: n1 = "rf"; break;
  case BF: n1 = "bf"; break;
  case D: n1 = "d"; break;
  case V: n1 = "v"; break;
  default: ASSERTION_VIOLATION;
  }
  SMTConstant res = SMTFormula::name(n1, node);
  _resBenchmark.declarePropositionalConstant(res);
  return res;
}

SMTConstant InterpolantMinimizer::costFunction()
{
  SMTConstant res = SMTFormula::name("cost");
  _resBenchmark.declareRealConstant(res);
  return res;
}

vstring InterpolantMinimizer::getUnitId(Unit* u)
{
  CALL("InterpolantMinimizer::getUnitId");

  vstring id = InferenceStore::instance()->getUnitIdStr(u);

  return id;
}

void InterpolantMinimizer::addDistinctColorsFormula(vstring n)
{
  CALL("InterpolantMinimizer::distinctColorsFormula");

  SMTFormula rN = pred(R, n);
  SMTFormula bN = pred(B, n);
  SMTFormula gN = pred(G, n);

  SMTFormula res = bN | rN | gN;
  res = res & ( rN --> ((!bN) & (!gN)) );
  res = res & ( bN --> ((!rN) & (!gN)) );
  res = res & ( gN --> ((!rN) & (!bN)) );

  _resBenchmark.addFormula(res);
}

void InterpolantMinimizer::addGreyNodePropertiesFormula(vstring n, ParentSummary& parents)
{
  CALL("InterpolantMinimizer::gNodePropertiesFormula");
  ASS(parents.rParents.isEmpty());
  ASS(parents.bParents.isEmpty());

  SMTFormula rParDisj = SMTFormula::getFalse();
  SMTFormula bParDisj = SMTFormula::getFalse();
  SMTFormula gParConj = SMTFormula::getTrue();

  Stack<vstring>::Iterator pit(parents.gParents);
  while(pit.hasNext()) {
    vstring par = pit.next();
    rParDisj = rParDisj | pred(R, par);
    bParDisj = bParDisj | pred(B, par);
    gParConj = gParConj & pred(G, par);
  }

  SMTFormula rN = pred(R, n);
  SMTFormula bN = pred(B, n);
  SMTFormula gN = pred(G, n);
  SMTFormula sN = pred(S, n);
  SMTFormula rcN = pred(RC, n);
  SMTFormula bcN = pred(BC, n);



  _resBenchmark.addFormula(rcN -=- ((!sN) & rParDisj));
  _resBenchmark.addFormula(bcN -=- ((!sN) & bParDisj));

  _resBenchmark.addFormula(rParDisj-->!bParDisj);
  _resBenchmark.addFormula(bParDisj-->!rParDisj);
  _resBenchmark.addFormula((sN & rParDisj)-->rN);
  _resBenchmark.addFormula((sN & bParDisj)-->bN);
  _resBenchmark.addFormula((sN & gParConj)-->gN);
  _resBenchmark.addFormula( (!sN)-->gN );

}

void InterpolantMinimizer::addLeafNodePropertiesFormula(vstring n)
{
  CALL("InterpolantMinimizer::addLeafNodePropertiesFormula");
 
    
  SMTFormula gN = pred(G, n);
  SMTFormula sN = pred(S, n);
  SMTFormula dN = pred(D, n);

  _resBenchmark.addFormula(!sN);
  _resBenchmark.addFormula(gN);
  _resBenchmark.addFormula(dN);
}

void InterpolantMinimizer::addColoredParentPropertiesFormulas(vstring n, ParentSummary& parents)
{
  CALL("InterpolantMinimizer::coloredParentPropertiesFormula");
  ASS_NEQ(parents.rParents.isNonEmpty(),parents.bParents.isNonEmpty());

  PredType parentType = parents.rParents.isNonEmpty() ? R : B;
  PredType oppositeType = (parentType==R) ? B : R;

  Stack<vstring>::Iterator gParIt(parents.gParents);

  SMTFormula gParNegConj = SMTFormula::getTrue();
  while(gParIt.hasNext()) {
    vstring par = gParIt.next();
    gParNegConj = gParNegConj & !pred(oppositeType, par);
  }

  SMTFormula parN = pred(parentType, n);
  SMTFormula gN = pred(G, n);
  SMTFormula sN = pred(S, n);
  SMTFormula rcN = pred(RC, n);
  SMTFormula bcN = pred(BC, n);


  if(parentType==R) {
    _resBenchmark.addFormula(rcN -=- !sN);
    _resBenchmark.addFormula(!bcN);
  }
  else {
    ASS_EQ(parentType,B);
    _resBenchmark.addFormula(bcN -=- !sN);
    _resBenchmark.addFormula(!rcN);
  }

  _resBenchmark.addFormula(gParNegConj);
  _resBenchmark.addFormula(sN --> parN);
  _resBenchmark.addFormula((!sN) --> gN);

}

void InterpolantMinimizer::addNodeFormulas(vstring n, ParentSummary& parents)
{
  CALL("InterpolantMinimizer::propertiesFormula");

  addDistinctColorsFormula(n);

  if(parents.rParents.isEmpty() && parents.bParents.isEmpty()) {
    addGreyNodePropertiesFormula(n, parents);
  }
  else {
    addColoredParentPropertiesFormulas(n, parents);
  }
}





struct InterpolantMinimizer::TraverseStackEntry
{
  TraverseStackEntry(InterpolantMinimizer& im, Unit* u) : unit(u), _im(im)
  {
    CALL("InterpolantMinimizer::TraverseStackEntry::TraverseStackEntry");

    parentIterator = InferenceStore::instance()->getParents(u);

    
    
    ALWAYS(im._infos.insert(unit, UnitInfo()));
    UnitInfo& info = getInfo();

    info.color = u->getColor();
    info.inputInheritedColor = u->inheritedColor();
    if(info.inputInheritedColor==COLOR_INVALID) {
      if(!parentIterator.hasNext()) {
	
	info.inputInheritedColor = info.color;
      }
      else {
	info.inputInheritedColor = COLOR_TRANSPARENT;
      }
    }

    info.leadsToColor = info.color!=COLOR_TRANSPARENT || info.inputInheritedColor!=COLOR_TRANSPARENT;
  }

 
  void processParent(Unit* parent)
  {
    CALL("InterpolantMinimizer::TraverseStackEntry::processParent");

    UnitInfo& info = getInfo();

    UnitInfo& parInfo = _im._infos.get(parent);

    Color pcol = parInfo.color;
    if(pcol==COLOR_LEFT) {
      ASS_NEQ(info.state, HAS_RIGHT_PARENT);
      info.state = HAS_LEFT_PARENT;
    }
    if(pcol==COLOR_RIGHT) {
      ASS_REP2(info.state!=HAS_LEFT_PARENT, unit->toString(), parent->toString());
      info.state = HAS_RIGHT_PARENT;
    }

    info.leadsToColor |= parInfo.leadsToColor;

    if(info.color==COLOR_LEFT) {
      parInfo.isParentOfLeft = true;
      UList::push(unit, parInfo.leftSuccessors);
    }
    else if(info.color==COLOR_RIGHT) {
      parInfo.isParentOfRight = true;
      UList::push(unit, parInfo.rightSuccessors);
    }
    else {
      ASS_EQ(info.color, COLOR_TRANSPARENT);
      UList::push(unit, parInfo.transparentSuccessors);
    }
  }

 
  UnitInfo& getInfo()
  {
    return _im._infos.get(unit);
  }

  Unit* unit;
 
  UnitIterator parentIterator;

  InterpolantMinimizer& _im;
};

void InterpolantMinimizer::traverse(Unit* refutationUnit)
{
  CALL("InterpolantMinimizer::traverse");

  Unit* refutation = refutationUnit;

  static Stack<TraverseStackEntry> stack;
  stack.reset();

  stack.push(TraverseStackEntry(*this, refutation));
  stack.top().getInfo().isRefutation = true;
  while(stack.isNonEmpty()) {
    TraverseStackEntry& top = stack.top();
    if(top.parentIterator.hasNext()) {
      Unit* parent = top.parentIterator.next();

      if(!_infos.find(parent)) {
	stack.push(TraverseStackEntry(*this, parent));
      }
      else {
	top.processParent(parent);
      }
    }
    else {
      if(stack.size()>1){
	TraverseStackEntry& child = stack[stack.size()-2];
	child.processParent(stack.top().unit);
      }
      stack.pop();
    }
  }

}

InterpolantMinimizer::InterpolantMinimizer(OptimizationTarget target, bool noSlicing,
					   bool showStats, vstring statsPrefix)
  : _optTarget(target),
    _noSlicing(noSlicing),
    _showStats(showStats),
    _statsPrefix(statsPrefix)
{
  CALL("InterpolantMinimizer::InterpolantMinimizer");

  _splitter = new ClauseSplitter();
}

InterpolantMinimizer::~InterpolantMinimizer()
{
  CALL("InterpolantMinimizer::~InterpolantMinimizer");

  delete _splitter;
}

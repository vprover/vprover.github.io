
/*
 * File Reflection.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#ifndef __Reflection__
#define __Reflection__












#define DECL_ELEMENT_TYPE(...) typedef __VA_ARGS__ _ElementType

#define ELEMENT_TYPE(Cl) typename Lib::ElementTypeInfo<Cl>::Type

#define OWN_ELEMENT_TYPE _ElementType

#define DECL_RETURN_TYPE(...) typedef __VA_ARGS__ _ReturnType

#define RETURN_TYPE(Cl) typename Cl::_ReturnType

#define OWN_RETURN_TYPE _ReturnType


#define DECL_ITERATOR_TYPE(...) typedef __VA_ARGS__ _IteratorType

#define ITERATOR_TYPE(Cl) typename Lib::IteratorTypeInfo<Cl>::Type

#define OWN_ITERATOR_TYPE _IteratorType

namespace Lib {

template<typename T>
struct ElementTypeInfo
{
  typedef typename T::_ElementType Type;
};

template<typename T>
struct ElementTypeInfo<T[]>
{
  typedef T Type;
};

template<typename T>
struct ElementTypeInfo<T*>
{
  typedef T Type;
};

template<typename T>
struct IteratorTypeInfo
{
  typedef typename T::_IteratorType Type;
};

template<typename T>
struct IteratorTypeInfo<T const>
{
  typedef typename IteratorTypeInfo<T>::Type Type;
};


};



#endif

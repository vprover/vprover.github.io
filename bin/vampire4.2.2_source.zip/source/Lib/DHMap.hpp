
/*
 * File DHMap.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __DHMap__
#define __DHMap__

#include <cstdlib>
#include <utility>

#if VDEBUG
#include <typeinfo>
#endif

#include "Debug/Assertion.hpp"
#include "Allocator.hpp"
#include "Exception.hpp"
#include "Hash.hpp"
#include "VirtualIterator.hpp"

namespace Lib {

#define DHMAP_MAX_CAPACITY_INDEX 29


template<typename Hash>
struct HashTraits
{
  enum {SINGLE_PARAM_HASH=1};
};

template<int I, class Hash, typename Key>
class HashCompClass {
};

template<class Hash, typename Key>
struct HashCompClass<1,Hash,Key> {
  static inline unsigned compute(Key& key, int capacity)
  {
    return Hash::hash(key);
  }
};

template<class Hash, typename Key>
struct HashCompClass<0,Hash,Key> {
  static inline unsigned compute(Key& key, int capacity)
  {
    return Hash::hash(key, capacity);
  }
};

template<class Hash, typename Key>
inline
unsigned computeHash(Key& key, int capacity)
{
  return HashCompClass<HashTraits<Hash>::SINGLE_PARAM_HASH,Hash,Key>::compute(key, capacity);
};

extern const unsigned DHMapTableCapacities[];
extern const unsigned DHMapTableNextExpansions[];

template <typename Key, typename Val, class Hash1, class Hash2>
class DHMap
{
public:
  CLASS_NAME(DHMap);
  USE_ALLOCATOR(DHMap);
  
 
  DHMap()
  : _timestamp(1), _size(0), _deleted(0), _capacityIndex(0), _capacity(0),
  _nextExpansionOccupancy(0), _entries(0), _afterLast(0)
  {
    ensureExpanded();
  }

  DHMap(const DHMap& obj)
  : _timestamp(1), _size(0), _deleted(0), _capacityIndex(0), _capacity(0),
  _nextExpansionOccupancy(0), _entries(0), _afterLast(0)
  {
    ensureExpanded();

    typename DHMap::Iterator iit(obj);
    while(iit.hasNext()) {
      Key k;
      Val v;
      iit.next(k, v);
      ALWAYS(insert(k,v));
    }
  }

 
  ~DHMap()
  {
    if(_entries) {
      ASS_EQ(_afterLast-_entries,_capacity);
      array_delete(_entries, _capacity);
      DEALLOC_KNOWN(_entries,_capacity*sizeof(Entry),"DHMap::Entry");

    }
  }

 
  void reset()
  {
    CALL("DHMap::reset");
    unsigned oldTS=_timestamp;
    _timestamp++;
    _size=0;
    _deleted=0;

    if(oldTS>(_timestamp&0x3FFFFFFF)) {
      
      
      _timestamp=1;
      Entry* pe=_afterLast;
      while(pe--!=_entries) {
	pe->_info.timestamp=0;
      }
    }
  }

 
  inline
  bool find(Key key, Val& val) const
  {
    CALL("DHMap::find/2");
    const Entry* e=findEntry(key);
    if(!e) {
      return false;
    }
    val=e->_val;
    return true;
  }

 
  Val* findPtr(Key key)
  {
    CALL("DHMap::findPtr");
    Entry* e=findEntry(key);
    if(!e) {
      return nullptr;
    }
    return &e->_val;
  }

 
  inline
  bool find(Key key) const
  {
    CALL("DHMap::find/1");
    return findEntry(key);
  }

 
  inline
  const Val& get(Key key) const
  {
    const Entry* e=findEntry(key);
    ASS(e);
    return e->_val;
  }

 
  inline
  Val& get(Key key)
  {
    Entry* e=findEntry(key);
    ASS(e);
    return e->_val;
  }

 
  inline
  Val get(Key key, Val def) const
  {
    const Entry* e=findEntry(key);
    if(!e) {
      return def;
    }
    return e->_val;
  }


 
  void loadFromMap(const DHMap& map)
  {
    Iterator iit(map);
    while(iit.hasNext()) {
      Key k;
      Val v;
      iit.next(k, v);
      ALWAYS(insert(k,v));
    }
  }

 
  template<class HashX1, class HashX2>
  void loadFromInverted(const DHMap<Val, Key, HashX1, HashX2>& inverted)
  {
    typename DHMap<Val, Key, HashX1, HashX2>::Iterator iit(inverted);
    while(iit.hasNext()) {
      Key k;
      Val v;
      iit.next(v, k);
      ALWAYS(insert(k,v));
    }
  }

 
  bool insert(Key key, const Val& val)
  {
    CALL("DHMap::insert");
    ensureExpanded();
    Entry* e=findEntryToInsert(key);
    bool exists = e->_info.timestamp==_timestamp && !e->_info.deleted;
    if(!exists) {
      if(e->_info.timestamp!=_timestamp) {
	e->_info.timestamp=_timestamp;
	
	e->_info.collision=0;
      } else {
	ASS(e->_info.deleted);
	_deleted--;
      }
      e->_info.deleted=0;
      e->_key=key;
      e->_val=val;
      _size++;
    }
    return !exists;
  }

 
  Val findOrInsert(Key key, const Val& val)
  {
    CALL("DHMap::insert");
    ensureExpanded();
    Entry* e=findEntryToInsert(key);
    bool exists = e->_info.timestamp==_timestamp && !e->_info.deleted;
    if(!exists) {
      if(e->_info.timestamp!=_timestamp) {
	e->_info.timestamp=_timestamp;
	
	e->_info.collision=0;
      } else {
	ASS(e->_info.deleted);
	_deleted--;
      }
      e->_info.deleted=0;
      e->_key=key;
      e->_val=val;
      _size++;
    }
    return e->_val;
  }

 
  bool findOrInsert(Key key, Val& val, const Val& initial)
  {
    CALL("DHMap::insert");
    ensureExpanded();
    Entry* e=findEntryToInsert(key);
    bool exists = e->_info.timestamp==_timestamp && !e->_info.deleted;
    if(!exists) {
      if(e->_info.timestamp!=_timestamp) {
	e->_info.timestamp=_timestamp;
	
	e->_info.collision=0;
      } else {
	ASS(e->_info.deleted);
	_deleted--;
      }
      e->_info.deleted=0;
      e->_key=key;
      e->_val=initial;
      _size++;
    }
    val=e->_val;
    return !exists;
  }

 
  bool getValuePtr(Key key, Val*& pval, const Val& initial)
  {
    CALL("DHMap::getValuePtr/3");
    ensureExpanded();
    Entry* e=findEntryToInsert(key);
    bool exists = e->_info.timestamp==_timestamp && !e->_info.deleted;
    if(!exists) {
      if(e->_info.timestamp!=_timestamp) {
	e->_info.timestamp=_timestamp;
	
	e->_info.collision=0;
      } else {
	ASS(e->_info.deleted);
	_deleted--;
      }
      e->_info.deleted=0;
      e->_key=key;
      e->_val=initial;
      _size++;
    }
    pval=&e->_val;
    return !exists;
  }

 
  bool getValuePtr(Key key, Val*& pval)
  {
    CALL("DHMap::getValuePtr/2");
    ensureExpanded();
    Entry* e=findEntryToInsert(key);
    bool exists = e->_info.timestamp==_timestamp && !e->_info.deleted;
    if(!exists) {
      if(e->_info.timestamp!=_timestamp) {
	e->_info.timestamp=_timestamp;
	
	e->_info.collision=0;
      } else {
	ASS(e->_info.deleted);
	_deleted--;
      }
      e->_info.deleted=0;
      e->_key=key;
      e->_val.~Val();
      new(&e->_val) Val();
      _size++;
    }
    pval=&e->_val;
    return !exists;
  }

 
  bool set(Key key, const Val& val)
  {
    CALL("DHMap::set");
    ensureExpanded();
    Entry* e=findEntryToInsert(key);
    bool exists = e->_info.timestamp==_timestamp && !e->_info.deleted;
    if(!exists) {
      if(e->_info.timestamp!=_timestamp) {
	e->_info.timestamp=_timestamp;
	
	e->_info.collision=0;
      } else {
	ASS(e->_info.deleted);
	_deleted--;
      }
      e->_info.deleted=0;
      e->_key=key;
      _size++;
    }
    e->_val=val;
    return !exists;
  }


 
  inline
  bool pop(Key key, Val& val)
  {
    CALL("DHMap::pop");
    Entry* e=findEntry(key);
    if(!e) {
      return false;
    }
    val=e->_val;
    e->_info.deleted=1;
    _size--;
    _deleted++;
    return true;
  }


 
  bool remove(Key key)
  {
    CALL("DHMap::remove");
    Entry* e=findEntry(key);
    if(!e) {
      return false;
    }
    e->_info.deleted=1;
    _size--;
    _deleted++;
    return true;
  }


 
  inline
  unsigned size() const
  {
    ASS(_size>=0);
    return _size;
  }

 
  inline
  bool isEmpty() const
  {
    ASS(_size>=0);
    return _size==0;
  }

 
  Key getOneKey()
  {
    Iterator it(*this);
    ALWAYS(it.hasNext());
    return it.nextKey();
  }

private:
  struct Entry
  {
   
    Entry() : _infoData(0) {}
    union {
      struct {
	unsigned deleted : 1;

	unsigned collision : 1;
	unsigned timestamp : 30;
      } _info;
      int _infoData;
    };
    Key _key;
    Val _val;
  };

 
  DHMap& operator=(const DHMap& obj);


 
  inline
  void ensureExpanded()
  {
    if(_size+_deleted>=_nextExpansionOccupancy) {
      
      expand();
    }
  }

 
  void expand()
  {
    CALL("DHMap::expand");

    if(_capacityIndex>=DHMAP_MAX_CAPACITY_INDEX) {
      throw Exception("Lib::DHMap::expand: MaxCapacityIndex reached.");
    }

    int newCapacity=DHMapTableCapacities[_capacityIndex+1];
    void* mem = ALLOC_KNOWN(newCapacity*sizeof(Entry),"DHMap::Entry");


    

    Entry* oldEntries=_entries;
    Entry* oldAfterLast=_afterLast;
    unsigned oldTimestamp=_timestamp;
    int oldCapacity=_capacity;

    _timestamp=1;
    _size=0;
    _deleted=0;
    _capacityIndex++;
    _capacity = newCapacity;
    _nextExpansionOccupancy = DHMapTableNextExpansions[_capacityIndex];

    _entries = array_new<Entry>(mem, _capacity);
    _afterLast = _entries + _capacity;

    Entry* ep=oldEntries;
    while(ep!=oldAfterLast) {
      ASS(ep);
      if(ep->_info.timestamp==oldTimestamp && !ep->_info.deleted) {
	insert(ep->_key, ep->_val);
      }
      (ep++)->~Entry();
    }
    
    if(oldCapacity) {
      DEALLOC_KNOWN(oldEntries,oldCapacity*sizeof(Entry),"DHMap::Entry");

    }
  }

 
  inline
  Entry* findEntry(Key key)
  {
    return const_cast<Entry*>(static_cast<const DHMap*>(this)->findEntry(key));
  }

 
  const Entry* findEntry(Key key) const
  {
    CALL("DHMap::findEntry");
    ASS(_capacity>_size+_deleted);

    unsigned h1=computeHash<Hash1>(key, _capacity);
    int pos=h1%_capacity;
    Entry* res=&_entries[pos];
    if(res->_info.timestamp != _timestamp ) {
      return 0;
    }
    if(res->_key==key) {
      return res->_info.deleted ? 0 : res;
    }

    

    if(!res->_info.collision) {
      
      
      return 0;
    }

    unsigned h2=Hash2::hash(key)%_capacity;
    if(h2==0) {
      h2=1;
    }
    do {
      pos=(pos+h2)%_capacity;
      res=&_entries[pos];
    } while (res->_info.timestamp == _timestamp && res->_key!=key);

    if(res->_info.timestamp != _timestamp ) {
      return 0;
    }

    ASS(res->_key==key);
    return res->_info.deleted ? 0 : res;
  }

 
  Entry* findEntryToInsert(Key key)
  {
    CALL("DHMap::findEntryToInsert");
    ASS(_capacity>_size+_deleted);

    unsigned h1=computeHash<Hash1>(key, _capacity);
    int pos=h1%_capacity;
    Entry* res=&_entries[pos];
    if(res->_info.timestamp != _timestamp || res->_key==key) {
      return res;
    }

    

    
    res->_info.collision=1;

    unsigned h2=Hash2::hash(key)%_capacity;
    if(h2==0) {
      h2=1;
    }
    do {
      pos=(pos+h2)%_capacity;
      res=&_entries[pos];
    } while (res->_info.timestamp == _timestamp && res->_key!=key);
    return res;
  }

 
  unsigned _timestamp;
 
  int _size;
 
  int _deleted;
 
  int _capacityIndex;
 
  int _capacity;
 
  int _nextExpansionOccupancy;

 
  Entry* _entries;
 
  Entry* _afterLast;

private:
  class IteratorBase {
  public:
   
    inline IteratorBase(const DHMap& map)
    : _next(map._entries), _last(map._afterLast),
    _timestamp(map._timestamp) {}

   
    bool hasNext()
    {
      CALL("DHMap::DomainIteratorCore::hasNext");
      while (_next != _last) {
	if (_next->_info.timestamp==_timestamp && !_next->_info.deleted) {
	  return true;
	}
	_next++;
      }
      return false;
    }

   
    inline
    Entry* next()
    {
      CALL("DHMap::DomainIteratorCore::next");
      ASS(_next != _last);
      ASS(_next->_info.timestamp==_timestamp && !_next->_info.deleted);
      return _next++;
    }

  private:
   
    Entry* _next;
   
    Entry* _last;
   
    unsigned _timestamp;
  }; 

  class DomainIteratorCore
  : public IteratorCore<Key> {
  public:
   
    inline DomainIteratorCore(const DHMap& map) : _base(map) {}
   
    inline bool hasNext() { return _base.hasNext(); }

   
    inline Key next() { return _base.next()->_key; }
  private:
    IteratorBase _base;
  }; 
    
    class RangeIteratorCore
    : public IteratorCore<Val> {
    public:
       
        inline RangeIteratorCore(const DHMap& map) : _base(map) {}
       
        inline bool hasNext() { return _base.hasNext(); }
        
       
        inline Val next() { return _base.next()->_val; }
    private:
        IteratorBase _base;
    }; 
    
public:
  VirtualIterator<Key> domain() const
  {
    return VirtualIterator<Key>(new DomainIteratorCore(*this));
  }
  VirtualIterator<Val> range() const
  {
    return VirtualIterator<Val>(new RangeIteratorCore(*this));
  }
    
  typedef std::pair<Key,Val> Item;

private:
  class ItemIteratorCore
  : public IteratorCore<Item> {
  public:
   
    inline ItemIteratorCore(const DHMap& map) : _base(map) {}
   
    inline bool hasNext() { return _base.hasNext(); }

   
    inline Item next()
    {
      Entry* e=_base.next();
      return Item(e->_key, e->_val);
    }
  private:
    IteratorBase _base;
  }; 
public:

  VirtualIterator<Item> items() const
  {
    return VirtualIterator<Item>(new ItemIteratorCore(*this));
  }


 
  class Iterator {
  public:
   
    inline Iterator(const DHMap& map) : _base(map) {}

   
    bool hasNext() { return _base.hasNext(); }

   
    inline
    void next(Key& key, Val& val)
    {
      Entry* e=_base.next();
      key=e->_key;
      val=e->_val;
    }

   
    inline
    Val& nextRef(Key& key)
    {
      Entry* e= _base.next();
      key= e->_key;
      return e->_val;
    }

   
    inline Val next() { return _base.next()->_val; }

   
    inline Key nextKey() { return _base.next()->_key; }

  private:
    IteratorBase _base;
  }; 

 
  class DelIterator {
  public:
   
    inline DelIterator(DHMap& map) : _base(map), _map(map) {}

   
    bool hasNext() { return _base.hasNext(); }

   
    inline
    void next(Key& key, Val& val)
    {
      Entry* e=getNextEntry();
      key=e->_key;
      val=e->_val;
    }

   
    inline Val next() { return getNextEntry()->_val; }

   
    inline Key nextKey() { return getNextEntry()->_key; }

    void del() {
      CALL("DHMap::DelIterator::del");
      _curr->_info.deleted=1;
      _map._size--;
      _map._deleted++;
    }

    void setValue(Val val) {
      CALL("DHMap::DelIterator::setValue");
      _curr->_val = val;
    }

  private:
    Entry* getNextEntry() {
      _curr = _base.next();
      return _curr;
    }

    IteratorBase _base;
    DHMap& _map;
    Entry* _curr;
  }; 



}; 

}

#endif 


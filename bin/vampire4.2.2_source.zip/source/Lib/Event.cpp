
/*
 * File Event.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Event.hpp"

using namespace Lib;

SubscriptionObject::~SubscriptionObject()
{
  if(hs!=0) {
    hs->sObj=0;
  }
}

void SubscriptionObject::unsubscribe()
{
  if(hs!=0) {
    event->unsubscribe(hs);
    ASS(hs==0);
  }
}

bool SubscriptionObject::belongsTo(BaseEvent& evt)
{
  return &evt==event;
}


SubscriptionData BaseEvent::subscribe(HandlerStruct* h)
{
  HandlerList::push(h, _handlers);
  SubscriptionObject* res=new SubscriptionObject(this, h);
  h->sObj=res;
  return SubscriptionData(res);
}

void BaseEvent::unsubscribe(HandlerStruct* h)
{
  ASS(HandlerList::member(h, _handlers));
  _handlers = HandlerList::remove(h, _handlers);
  if(h->sObj) {
    h->sObj->hs=0;
  }
  delete h;
}


/*
 * File Backtrackable.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Backtrackable__
#define __Backtrackable__

#include "List.hpp"
#include "Int.hpp"
#include "VString.hpp"

namespace Lib
{

class BacktrackData;

class BacktrackObject
{
public:
#if VDEBUG
 
  BacktrackObject() : _next(0) {}
#endif
  virtual ~BacktrackObject()  {}

 
  virtual void backtrack() = 0;

#if VDEBUG
  virtual vstring toString() const { return "(backtrack object)"; }
#endif
private:
 
  BacktrackObject* _next;

  friend class BacktrackData;
};

class BacktrackData
{
public:
  BacktrackData() : _boList(0) {}

 
  void backtrack()
  {
    CALL("BacktrackData::backtrack");

    BacktrackObject* curr=_boList;
    BacktrackObject* next;
    while(curr) {
      curr->backtrack();
      next=curr->_next;
      delete curr;
      curr=next;
    }
    _boList=0;
  }

 
  void drop()
  {
    CALL("BacktrackData::drop");

    BacktrackObject* curr=_boList;
    BacktrackObject* next;
    while(curr) {
      next=curr->_next;
      delete curr;
      curr=next;
    }
    _boList=0;
  }

 
  void addBacktrackObject(BacktrackObject* bo)
  {
    CALL("BacktrackData::addBacktrackObject");

    ASS_EQ(bo->_next,0);
    bo->_next=_boList;
    _boList=bo;
  }

 
  void commitTo(BacktrackData& bd)
  {
    CALL("BacktrackData::commitTo");

    if(!_boList) {
      return;
    }
    BacktrackObject* lastOwn=_boList;
    while(lastOwn->_next) {
      lastOwn=lastOwn->_next;
    }
    lastOwn->_next=bd._boList;
    bd._boList=_boList;
    _boList=0;
  }

 
  bool isEmpty() const
  {
    return _boList==0;
  }

 
  template<typename T>
  void backtrackableSet(T* ptr, T val)
  {
    CALL("BacktrackData::backtrackableSet");

    addBacktrackObject(new SetValueBacktrackObject<T>(ptr,*ptr));
    *ptr=val;
  }

#if VDEBUG
  vstring toString()
  {
    CALL("BacktrackData::toString");

    vstring res;
    unsigned cnt=0;
    BacktrackObject* bobj=_boList;
    while(bobj) {
      res+=bobj->toString()+"\n";
      cnt++;
      bobj=bobj->_next;
    }
    res+="object cnt: "+Int::toString(cnt)+"\n";
    return res;
  }
#endif

 
  BacktrackObject* _boList;
private:

 
  template<typename T>
  class SetValueBacktrackObject
  : public BacktrackObject
  {
  public:
    SetValueBacktrackObject(T* addr, T previousVal)
    : addr(addr), previousVal(previousVal) {}
    void backtrack()
    {
      *addr=previousVal;
    }
  private:
    T* addr;
    T previousVal;
  };
};

class Backtrackable
{
public:
#if VDEBUG
 
  ~Backtrackable() { ASS_EQ(_bdStack,0); }
#endif
 
  void bdRecord(BacktrackData& bd)
  {
    _bdStack=new List<BacktrackData*>(&bd, _bdStack);
  }

 
  void bdDoNotRecord()
  {
    _bdStack=new List<BacktrackData*>(0, _bdStack);
  }

 
  void bdDone()
  {
    List<BacktrackData*>::pop(_bdStack);
  }

 
  void bdCommit(BacktrackData& bd)
  {
    CALL("Backtrackable::bdCommit");
    ASS(!bdIsRecording() || &bd!=&bdGet());

    if(bdIsRecording()) {
      bd.commitTo(bdGet());
    }
    else {
      bd.drop();
    }
  }

protected:
 
  Backtrackable() : _bdStack(0) {}

 
  bool bdIsRecording()
  {
    return _bdStack && _bdStack->head();
  }

 
  void bdAdd(BacktrackObject* bo)
  {
    CALL("Backtrackable::bdAdd");
    ASS(bdIsRecording());

    bdGet().addBacktrackObject(bo);
  }

 
  BacktrackData& bdGet()
  {
    CALL("Backtrackable::bdGet");
    ASS(bdIsRecording());

    return *_bdStack->head();
  }
private:
 
  List<BacktrackData*>* _bdStack;
};

};

#endif 


/*
 * File Set.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Set__
#define __Set__

#include <cstdlib>

#include "Forwards.hpp"

#include "Allocator.hpp"
#include "Hash.hpp"
#include "Reflection.hpp"

namespace Lib {

template <typename Val,class Hash>
class Set
{
protected:
  class Cell
  {
  public:
   
    inline Cell ()
      : code(0)
    {
    } 

   
    inline bool empty() const
    {
      return code == 0;
    } 

   
    inline bool deleted() const
    {
      return code == 1;
    } 

   
    inline bool occupied() const
    {
      return code > 1;
    } 

   
    void* operator new (size_t);

   
    unsigned code;
   
    Val value;
  }; 

public:
  
  CLASS_NAME(Set);
  USE_ALLOCATOR(Set);

 
  Set()
    : _capacity(0),
      _nonemptyCells(0),
      _size(0),
      _entries(0)
  {
    CALL("Set::Set");
    expand();
  } 

 
  inline ~Set ()
  {
    CALL("~Set");

    if (_entries) {
      array_delete(_entries,_capacity);
      DEALLOC_KNOWN(_entries,_capacity*sizeof(Cell),"Set::Cell");
    }
  } 

 
  template<typename Key>
  bool find(Key key, Val& result) const
  {
    CALL("Set::find");

    unsigned code = Hash::hash(key);
    if (code < 2) {
      code = 2;
    }
    for (Cell* cell = firstCellForCode(code);
	 ! cell->empty();
	 cell = nextCell(cell)) {
      if (cell->deleted()) {
	continue;
      }
      if (cell->code == code &&
	  Hash::equals(cell->value,key)) {
	result=cell->value;
	return true;
      }
    }
    return false;
  } 

 
  bool contains (Val val) const
  {
    CALL("Set::contains");

    unsigned code = Hash::hash(val);
    if (code < 2) {
      code = 2;
    }
    for (Cell* cell = firstCellForCode(code);
	 ! cell->empty();
	 cell = nextCell(cell)) {
      if (cell->deleted()) {
	continue;
      }
      if (cell->code == code &&
	  Hash::equals(cell->value,val)) {
	return true;
      }
    }
    return false;
  } 

 
  inline Val insert(const Val val)
  {
    CALL("Set::insert");

    if (_nonemptyCells >= _maxEntries) { 
      expand();
    }

    unsigned code;
    code = Hash::hash(val);

    if (code < 2) {
      code = 2;
    }

    return insert(val,code);
  } 

 
  Val insert(const Val val,unsigned code)
  {
    CALL("Set::insert/2");

    Cell* found = 0;
    Cell* cell = firstCellForCode(code);
    while (! cell->empty()) {
      if (cell->deleted()) {
	if (! found) {
	  found = cell;
	}
	cell = nextCell(cell);
	continue;
      }
      if (cell->code == code &&
	  Hash::equals(cell->value,val)) {
	return cell->value;
      }
      cell = nextCell(cell);
    }
    if (found) { 
      cell = found;
    }
    else { 
      _nonemptyCells++;
    }
    _size++;
    cell->value = val;
    cell->code = code;
    return cell->value;
  } 

 
  template<class It>
  void insertFromIterator(It it)
  {
    while(it.hasNext()) {
      insert(it.next());
    }
  }
	
 
  inline unsigned size() const
  {
    return _size;
  }

 
  bool remove(const Val val)
  {
    CALL("Set::remove");

    unsigned code = Hash::hash(val);
    if (code < 2) {
      code = 2;
    }

    Cell* cell = firstCellForCode(code);
    while (! cell->empty()) {
      if (cell->deleted()) {
	cell = nextCell(cell);
	continue;
      }
      if (cell->code == code &&
	  Hash::equals(cell->value,val)) {
	cell->code = 1; 
	_size--;
	return true;
      }
      cell = nextCell(cell);
    }
    return false;
  } 

 
  void reset()
  {
    CALL("Set::reset");
    Cell* ptr = _entries;
    while(ptr!=_afterLast) {
      ptr->code = 0;
      ptr++;
    }
    _size = 0;
    _nonemptyCells = 0;
  }

private:
  Set(const Set&); 

 
  int _capacity;
 
  int _nonemptyCells;
 
  unsigned _size;
 
  Cell* _entries;
 
  Cell* _afterLast; 
 
  int _maxEntries;

 
  void expand()
  {
    CALL("Set::expand");

    size_t newCapacity = _capacity ? _capacity * 2 : 31;
    Cell* oldEntries = _entries;

    void* mem = ALLOC_KNOWN(newCapacity*sizeof(Cell),"Set::Cell");

    _entries = array_new<Cell>(mem, newCapacity);
    _afterLast = _entries + newCapacity;
    _maxEntries = (int)(newCapacity * 0.8);
    size_t oldCapacity = _capacity;
    _capacity = newCapacity;

    
    
    
    
    
    
    
    
    Cell* current = oldEntries;
    int remaining = _size;
    _nonemptyCells = 0;
    _size = 0;
    while (remaining != 0) {
      
      while (! current->occupied()) {
	current++;
      }
      
      insert(current->value,current->code);
      current ++;
      remaining --;
    }

    if (oldEntries) {
      array_delete(oldEntries,oldCapacity);
      DEALLOC_KNOWN(oldEntries,oldCapacity*sizeof(Cell),"Set::Cell");
    }
  } 

 
  inline Cell* nextCell(Cell* cell) const
  {
    cell ++;
    
    return cell == _afterLast ? _entries : cell;
  } 

 
  inline Cell* firstCellForCode(unsigned code) const
  {
    return _entries + (code % _capacity);
  } 

public:
 
  class Iterator {
  public:
    DECL_ELEMENT_TYPE(Val);

   
    inline Iterator() : _next(0), _last(0) {}

   
    explicit inline Iterator(const Set& set)
      : _next(set._entries),
	_last(set._afterLast)
    {
    } 

   
    bool hasNext()
    {
      while (_next != _last) {
	if (_next->occupied()) {
	  return true;
	}
	_next++;
      }
      return false;
    } 

   
    Val next()
    {
      ASS(_next != _last);
      ASS(_next->occupied());
      Val result = _next->value;
      _next++;
      return result;
    } 

  private:
   
    Cell* _next;
   
    Cell* _last;
  };
  DECL_ITERATOR_TYPE(Iterator);

}; 


}

#endif 



/*
 * File DHSet.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __DHSet__
#define __DHSet__

#include "Forwards.hpp"

#include "DHMap.hpp"

namespace Lib {

template <typename Val, class Hash1, class Hash2>
class DHSet
{
public:
  CLASS_NAME(DHSet);
  USE_ALLOCATOR(DHSet);

  DHSet() {}

 
  void reset()
  {
    CALL("DHSet::reset");

    _map.reset();
  }

 
  inline
  bool find(Val val) const
  {
    CALL("DHSet::find");

    return _map.find(val);
  }

 
  inline
  bool contains(Val val) const
  {
    CALL("DHSet::contains");

    return find(val);
  }

 
  bool insert(Val val)
  {
    CALL("DHSet::insert");

    return _map.insert(val, EmptyStruct());
  }


 
  bool remove(Val val)
  {
    CALL("DHSet::remove");

    return _map.remove(val);
  }

 
  inline
  unsigned size() const
  {
    return _map.size();
  }

 
  inline
  bool isEmpty() const
  {
    return _map.isEmpty();
  }

 
  Val getOneKey()
  {
    return _map.getOneKey();
  }

 
  template<class It>
  void loadFromIterator(It it) {
    CALL("DHSet::loadFromIterator");

    while(it.hasNext()) {
      insert(it.next());
    }
  }

 
  template<class It>
  void removeIteratorElements(It it) {
    CALL("DHSet::removeIteratorElements");

    while(it.hasNext()) {
      ALWAYS(remove(it.next()));
    }
  }

  VirtualIterator<Val> iterator() const
  {
    return _map.domain();
  }
private:
 
  DHSet(const DHSet& obj);
 
  DHSet& operator=(const DHSet& obj);

  typedef DHMap<Val,EmptyStruct,Hash1,Hash2> InnerMap;

  InnerMap _map;

public:
  class Iterator
  {
  public:
    Iterator(const DHSet& parent) : _mit(parent._map) {}

    bool hasNext() { return _mit.hasNext(); }
    Val next() { return _mit.nextKey(); }

  private:
    typename InnerMap::Iterator _mit;
  };
  class DelIterator
  {
  public:
    DelIterator(DHSet& parent) : _mit(parent._map) {}

    bool hasNext() { return _mit.hasNext(); }
    Val next() { return _mit.nextKey(); }
    void del() { _mit.del(); }

  private:
    typename InnerMap::DelIterator _mit;
  };
}; 

}

#endif 


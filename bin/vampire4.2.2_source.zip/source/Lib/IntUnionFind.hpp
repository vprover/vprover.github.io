
/*
 * File IntUnionFind.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __IntUnionFind__
#define __IntUnionFind__

#include "Reflection.hpp"
#include "Stack.hpp"

namespace Lib {

class IntUnionFind {
public:
  IntUnionFind(int cnt);
  ~IntUnionFind();
  bool doUnion(int c1, int c2);
  int root(int c) const;
  void reset();
  void evalComponents();
  int getComponentCount();
private:

  int _cnt;

  bool _modified;

 
  mutable int* _parents;

 
  int* _data;
  Stack<int> _components;

public:
  class ComponentIterator;
  class ElementIterator
  {
  public:
    DECL_ELEMENT_TYPE(int);

    bool hasNext() { return _next!=-1; }
    int next()
    {
      CALL("IntUnionFind::ElementIterator::next");
      ASS_NEQ(_next,-1);

      int res=_next;
      _next=_data[_next];
      return res;
    }
  private:
    ElementIterator(int first, const int* data)
    : _next(first), _data(data) {}

    int _next;
    const int* _data;

    friend class ComponentIterator;
  };

 
  class ComponentIterator
  {
  public:
    DECL_ELEMENT_TYPE(ElementIterator);
   
    ComponentIterator(const IntUnionFind& obj)
    : _cit(obj._components), _data(obj._data)
    {
      CALL("IntUnionFind::ComponentIterator::ComponentIterator");
      ASS(!obj._modified); 
    }

    bool hasNext() { return _cit.hasNext(); }
    ElementIterator next() { return ElementIterator(_cit.next(), _data); }
  private:
    Stack<int>::ConstIterator _cit;
    const int* _data;
  };
};

}

#endif

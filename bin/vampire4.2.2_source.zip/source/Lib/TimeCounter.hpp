
/*
 * File TimeCounter.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#ifndef __TimeCounter__
#define __TimeCounter__

#include <ostream>

namespace Lib {

using namespace std;

enum TimeCounterUnit
{
  TC_RAND_OPT,
  TC_PARSING,
  TC_PROPERTY_EVALUATION,
  TC_PREPROCESSING,
  TC_BCE,
  TC_SINE_SELECTION,
  TC_BDD,
  TC_BDD_CLAUSIFICATION,
  TC_SAT_SOLVER,
  TC_TWLSOLVER_ADD,
  TC_MINIMIZING_SOLVER,
  TC_SAT_PROOF_MINIMIZATION,
  TC_TERM_SHARING,
  TC_SPLITTING_MODEL_UPDATE,
  TC_CONGRUENCE_CLOSURE,
  TC_CCMODEL,
  TC_SIMPLIFYING_UNIT_LITERAL_INDEX_MAINTENANCE,
  TC_NON_UNIT_LITERAL_INDEX_MAINTENANCE,
  TC_FORWARD_SUBSUMPTION_INDEX_MAINTENANCE,
  TC_BINARY_RESOLUTION_INDEX_MAINTENANCE,
  TC_BACKWARD_SUBSUMPTION_INDEX_MAINTENANCE,
  TC_BACKWARD_SUPERPOSITION_INDEX_MAINTENANCE,
  TC_FORWARD_SUPERPOSITION_INDEX_MAINTENANCE,
  TC_BACKWARD_DEMODULATION_INDEX_MAINTENANCE,
  TC_FORWARD_DEMODULATION_INDEX_MAINTENANCE,
  TC_SPLITTING_COMPONENT_INDEX_MAINTENANCE,
  TC_SPLITTING_COMPONENT_INDEX_USAGE,
  TC_LITERAL_REWRITE_RULE_INDEX_MAINTENANCE,
  TC_LRS_LIMIT_MAINTENANCE,
  TC_CONDENSATION,
  TC_INTERPRETED_EVALUATION,
  TC_INTERPRETED_SIMPLIFICATION,
  TC_FORWARD_SUBSUMPTION,
  TC_FORWARD_SUBSUMPTION_RESOLUTION,
  TC_BACKWARD_SUBSUMPTION,
  TC_BACKWARD_SUBSUMPTION_RESOLUTION,
  TC_FORWARD_DEMODULATION,
  TC_BACKWARD_DEMODULATION,
  TC_FORWARD_LITERAL_REWRITING,
  TC_RESOLUTION,
  TC_UR_RESOLUTION,
  TC_SUPERPOSITION,
  TC_LITERAL_ORDER_AFTERCHECK,
  TC_HYPER_SUPERPOSITION,
  TC_BDD_MARKING_SUBSUMPTION,
  TC_GLOBAL_SUBSUMPTION,
  TC_INST_GEN_SIMPLIFICATIONS,
  TC_INST_GEN_VARIANT_DETECTION,
  TC_INST_GEN_SAT_SOLVING,
  TC_INST_GEN_GEN_INST,
  TC_CONSEQUENCE_FINDING,
  TC_TRIVIAL_PREDICATE_REMOVAL,
  TC_SOLVING,
  TC_BOUND_PROPAGATION,
  TC_HANDLING_CONFLICTS,
  TC_VARIABLE_SELECTION,
  TC_DISMATCHING,
  TC_FMB_DEF_INTRO,
  TC_FMB_SORT_INFERENCE,
  TC_FMB_FLATTENING,
  TC_FMB_SPLITTING,
  TC_FMB_SAT_SOLVING,
  TC_FMB_CONSTRAINT_CREATION,
  TC_HCVI_COMPUTE_HASH,
  TC_HCVI_INSERT,
  TC_HCVI_RETRIEVE,
  TC_MINISAT_ELIMINATE_VAR,
  TC_MINISAT_BWD_SUBSUMPTION_CHECK,
  TC_Z3_IN_FMB,
  TC_NAMING,
  TC_LITERAL_SELECTION,
  TC_THEORY_INST_SIMP,
  TC_OTHER,
  __TC_ELEMENT_COUNT,
  __TC_NONE
};

class TimeCounter
{
public:
  inline TimeCounter(TimeCounterUnit tcu)
  {
    if(!s_measuring) return;
    startMeasuring(tcu);
  }
  inline ~TimeCounter()
  {
    if(!s_measuring) return;
    stopMeasuring();
  }

  static void printReport(ostream& out);


 
  void stop()
  {
    if(!s_measuring) return;
    stopMeasuring();
    _tcu=__TC_NONE; 
  }

  static bool isBeingMeasured(TimeCounterUnit tcu)
  {
    return s_measureInitTimes[tcu]!=-1;
  }

  static void reinitialize();

private:
  void startMeasuring(TimeCounterUnit tcu);
  void stopMeasuring();

  static void initialize();
  static void outputSingleStat(TimeCounterUnit tcu, ostream& out);

 
  static void snapShot();

  TimeCounterUnit _tcu;

 
  static TimeCounter* s_currTop;

 
  TimeCounter* previousTop;

 
  static bool s_measuring;
 
  static bool s_initialized;
 
  static int s_measuredTimes[];
 
  static int s_measuredTimesChildren[];
 
  static int s_measureInitTimes[];
};

};

#endif

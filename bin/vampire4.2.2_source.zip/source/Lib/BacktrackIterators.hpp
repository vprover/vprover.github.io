
/*
 * File BacktrackIterators.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#ifndef __BacktrackIterators__
#define __BacktrackIterators__

#include "DArray.hpp"
#include "Stack.hpp"
#include "VirtualIterator.hpp"
#include "Metaiterators.hpp"

namespace Lib {




template<typename State, typename ChoiceArr, class Fn>
class BacktrackingIterator
: public IteratorCore<State>
{
public:
  BacktrackingIterator(State initState, ChoiceArr choices, size_t chLen, Fn functor)
  : _fin(false), _used(true), _choices(choices), _chLen(chLen),
  _chits(32), _states(32), _functor(functor)
  {
    ASS(_chLen>0);
    _states.push(initState);
  }
  bool hasNext()
  {
    if(_fin) {
      return false;
    }
    if(!_used) {
      return true;
    }
    if(depth()) {
      ASS_EQ(depth(), _chLen);
      _states.pop();
    } else {
      _chits.push(_functor(_states.top(), _choices[depth()]));
    }
    for(;;) {
      while( _chits.isNonEmpty() && !_chits.top().hasNext() ) {
	_chits.pop();
	_states.pop();
      }
      if(_chits.isNonEmpty()) {
	ALWAYS(_chits.top().hasNext());
	_states.push(_chits.top().next());
      } else {
	_fin=true;
	return false;
      }
      if(depth()==_chLen) {
	break;
      }
      _chits.push(_functor(_states.top(), _choices[depth()]));
    }
    _used=false;
    return true;
  }
  State next()
  {
    ASS(!_used);
    ASS(!_fin);
    _used=true;
    return _states.top();
  }
private:
  size_t depth() { return _chits.length(); }

  bool _fin;
  bool _used;
  State _initState;
  ChoiceArr _choices;
  size_t _chLen;
  Stack<RETURN_TYPE(Fn) > _chits; 
  Stack<State> _states;
  Fn _functor;
};

template<typename State, typename ChoiceArr, class Fn>
VirtualIterator<State> getBacktrackingIterator(State initState,
	ChoiceArr choices, Fn functor)
{
  size_t chLen=choices.size();
  if(chLen==0) {
    return pvi( getSingletonIterator(initState) );
  }
  return VirtualIterator<State>(new BacktrackingIterator<State,ChoiceArr,Fn>
	  (initState, choices, chLen, functor));
}

template<typename State, class Fn, class ChPntIterable>
class BtrFnForIterable
{
  class FnMapper
  {
  public:
    DECL_RETURN_TYPE(VirtualIterator<State>);
    FnMapper(State s, Fn functor) : _state(s), _functor(functor) {}

    template<typename ChoicePoint>
    OWN_RETURN_TYPE operator() (ChoicePoint cp)
    { return _functor(_state, cp); }
  private:
    State _state;
    Fn _functor;
  };

public:
  DECL_RETURN_TYPE(FlatteningIterator<MappingIterator<ITERATOR_TYPE(ChPntIterable),FnMapper> >);
  BtrFnForIterable(Fn functor) : _functor(functor) {}

  OWN_RETURN_TYPE
  operator() (State curr, ChPntIterable cPItb) 
  {
    return getFlattenedIterator(
	    getMappingIterator(
		    getContentIterator(cPItb),
		    FnMapper(curr, _functor)) );
  }
private:
  Fn _functor;
};

template<typename State, typename ChoiceArr, class IFn>
VirtualIterator<State> getIteratorBacktrackingOnIterable(State initState,
	ChoiceArr choices, IFn innerFunctor)
{
  size_t chLen=choices.size();
  if(chLen==0) {
    return pvi( getSingletonIterator(initState) );
  }

  typedef BtrFnForIterable<State,IFn,ELEMENT_TYPE(ChoiceArr)> Fn;

  return vi( new BacktrackingIterator<State,ChoiceArr,Fn>
	  (initState, choices, chLen,
		  Fn(innerFunctor)
	  ) );
}



};

#endif

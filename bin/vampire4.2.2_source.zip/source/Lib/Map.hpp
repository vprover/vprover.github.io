
/*
 * File Map.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Map__
#define __Map__

#include <cstdlib>

#include "Debug/Assertion.hpp"
#include "Debug/Tracer.hpp"

#include "Allocator.hpp"
#include "VString.hpp"
#include "Hash.hpp"
#include "Exception.hpp"

namespace Lib {

template <typename Key, typename Val,class Hash>
class Map
{
protected:
  class Entry
  {
  public:
   
    inline Entry ()
      : code(0)
    {
    } 

   
    inline bool occupied () const
    {
      return code;
    } 

   
    void* operator new (size_t);

   
    unsigned code;
   
    Key key;
   
    Val value;
  }; 

 public:
 
  Map ()
    : _capacity(0),
      _noOfEntries(0),
      _entries(0)
  {
    expand();
  } 

 
  inline ~Map ()
  {
    CALL("Map::~Map");
    if (_entries) {
      array_delete(_entries, _capacity);
      DEALLOC_KNOWN(_entries,sizeof(Entry)*_capacity,"Map<>");
    }
  } 

 
  inline bool find(Key key) const
  {
    Val val;
    return find(key,val);
  }

 
  bool find(Key key, Val& found) const
  {
    CALL("Map::find/2");

    unsigned code = Hash::hash(key);
    if (code == 0) {
      code = 1;
    }
    Entry* entry;
    for (entry = firstEntryForCode(code);
	 entry->occupied();
	 entry = nextEntry(entry)) {
      if (entry->code == code &&
	  entry->key == key) {
	found = entry->value;
	return true;
      }
    }

    return false;
  } 

 
  Val get(Key key) const
  {
    CALL("Map::get");

    unsigned code = Hash::hash(key);
    if (code == 0) {
      code = 1;
    }
    Entry* entry;
    for (entry = firstEntryForCode(code);
	 entry->key != key;
	 entry = nextEntry(entry)) {
      ASS(entry->occupied());
    }
    ASS(entry->occupied());
    return entry->value;
  } 

 
  inline Entry* firstEntryForCode(unsigned code) const
  {
    return _entries + (code % _capacity);
  } 

 
  inline Entry* nextEntry(Entry* entry) const
  {
    entry ++;
    
    return entry == _afterLast ? _entries : entry;
  } 

 
  inline Val insert(const Key key,Val val)
  {
    CALL("Map::insert");

    if (_noOfEntries >= _maxEntries) { 
      expand();
    }
    unsigned code = Hash::hash(key);
    if (code == 0) {
      code = 1;
    }
    return insert(key,val,code);
  } 

 
  Val insert(const Key key, Val val,unsigned code)
  {
    CALL("Map::insert/2");

    Entry* entry;
    for (entry = firstEntryForCode(code);
	 entry->occupied();
	 entry = nextEntry(entry)) {
      if (entry->code == code &&
	  entry->key == key) {
	return entry->value;
      }
    }
    
    _noOfEntries++;
    entry->key = key;
    entry->value = val;
    entry->code = code;
    return entry->value;
  } 

 
  bool replaceOrInsert(Key key,Val val)
  {
    CALL("Map::insertOrReplace");

    if (_noOfEntries >= _maxEntries) { 
      expand();
    }
    unsigned code = Hash::hash(key);
    if (code == 0) {
      code = 1;
    }
    Entry* entry;
    for (entry = firstEntryForCode(code);
				 entry->occupied();
				 entry = nextEntry(entry)) {
      if (entry->code == code &&
					entry->key == key) {
				entry->value = val;
				return true;
      }
    }
    
    _noOfEntries++;
    entry->key = key;
    entry->value = val;
    entry->code = code;
		return false;
  } 


 
  void replace(const Key key,const Val val)
  {
    CALL("Map::replace");

    if (_noOfEntries >= _maxEntries) { 
      expand();
    }
    unsigned code = Hash::hash(key);
    if (code == 0) {
      code = 1;
    }
    Entry* entry;
    for (entry = firstEntryForCode(code);
	 entry->occupied();
	 entry = nextEntry(entry)) {
      if (entry->code == code &&
	  entry->key == key) {
	entry->value = val;
	return;
      }
    }
#if VDEBUG
    ASSERTION_VIOLATION;
#endif
  } 

  
 
  bool getValuePtr(Key key, Val*& pval, const Val& initial)
  {
    CALL("Map::getValuePtr");

    if (_noOfEntries >= _maxEntries) { 
      expand();
    }
    unsigned code = Hash::hash(key);
    if (code == 0) {
      code = 1;
    }
    Entry* entry;
    for (entry = firstEntryForCode(code);
	 entry->occupied();
	 entry = nextEntry(entry)) {
      if (entry->code == code &&
	  Lib::DefaultEq::equals(entry->key, key)) {
	pval = &entry->value;
	return false;
      }
    }
    
    _noOfEntries++;
    entry->key = key;
    entry->value = initial;
    entry->code = code;
    pval = &entry->value;
    return true;
  }
  
  
 
  void deleteAll()
  {
    CALL("Map::deleteAll");

    for (int i = _capacity-1;i >= 0;i--) {
      Entry& e = _entries[i];
      if (e.occupied()) {
	delete e.value;
      }
    }
  } 

 
  inline int numberOfElements()
  {
    return _noOfEntries;
  }

 
  void destroyAll()
  {
    CALL("Map::destroyAll");

    for (int i = _capacity-1;i >= 0;i--) {
      Entry& e = _entries[i];
      if (e.occupied()) {
	e.value->destroy();
      }
    }
  } 

 
  int _capacity;
 
  int _noOfEntries;
 
  Entry* _entries;
 
  Entry* _afterLast; 
 
  int _maxEntries;

  void expand()
  {
    CALL("Map::expand");

    size_t oldCapacity = _capacity;
    _capacity = _capacity ? _capacity * 2 : 32;

    Entry* oldEntries = _entries;

    void* mem = ALLOC_KNOWN(sizeof(Entry)*_capacity,"Map<>");
    _entries = array_new<Entry>(mem, _capacity);

    _afterLast = _entries + _capacity;
    _maxEntries = (int)(_capacity * 0.8);
    
    
    
    
    
    
    
    
    Entry* current = oldEntries;
    int remaining = _noOfEntries;
    _noOfEntries = 0;
    while (remaining != 0) {
      
      while (! current->occupied()) {
	current ++;
      }
      
      insert(current->key,current->value,current->code);
      current ++;
      remaining --;
    }
    if (oldEntries) {
      array_delete(oldEntries, oldCapacity);
      DEALLOC_KNOWN(oldEntries,sizeof(Entry)*oldCapacity,"Map<>");
    }
  } 

public:
 
  class Iterator {
  public:
   
    inline Iterator(const Map& map)
      : _next(map._entries),
	_last(map._afterLast)
    {
    } 

   
    bool hasNext()
    {
      while (_next != _last) {
	if (_next->occupied()) {
	  return true;
	}
	_next++;
      }
      return false;
    }

   
    Val next()
    {
      ASS(_next != _last);
      ASS(_next->occupied());
      Val result = _next->value;
      _next++;
      return result;
    }

   
    void next(Key& key,Val& val)
    {
      ASS(_next != _last);
      ASS(_next->occupied());
			
      val = _next->value;
      key = _next->key;
      _next++;
    }
  private:
   
    Entry* _next;
   
    Entry* _last;
  };
}; 

} 

#endif 


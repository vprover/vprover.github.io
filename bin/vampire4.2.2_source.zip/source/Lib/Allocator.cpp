
/*
 * File Allocator.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */

#if VDEBUG

#include <sstream>
#include "DHMap.hpp"

#endif

#include <cstring>
#include <cstdlib>
#include "Lib/System.hpp"
#include "Shell/UIHelper.hpp"

#define SAFE_OUT_OF_MEM_SOLUTION 1

#ifndef USE_SYSTEM_ALLOCATION
#define USE_SYSTEM_ALLOCATION 0
#endif

#if USE_SYSTEM_ALLOCATION
# if __APPLE__
#  include <malloc/malloc.h>
# else
#  include <malloc.h>
# endif
#endif

#define TRACE_ALLOCATIONS 0

#define PAGE_PREFIX_SIZE (sizeof(Page)-sizeof(void*))








#define WATCH_FIRST 0
#define WATCH_LAST UINT_MAX

#define WATCH_ADDRESS 0

#if WATCH_ADDRESS
bool watchPage = false;
unsigned watchAddressLastValue = 0;
#endif

#include "Debug/Assertion.hpp"
#include "Debug/Tracer.hpp"

#include "Shell/Statistics.hpp"

#include "Exception.hpp"
#include "Environment.hpp"
#include "Allocator.hpp"

#if CHECK_LEAKS
#include "MemoryLeak.hpp"
#endif

using namespace Lib;
using namespace Shell;

int Allocator::_initialised = 0;
int Allocator::_total = 0;
size_t Allocator::_memoryLimit;
size_t Allocator::_tolerated;
Allocator* Allocator::current;
Allocator::Page* Allocator::_pages[MAX_PAGES];
size_t Allocator::_usedMemory = 0;
Allocator* Allocator::_all[MAX_ALLOCATORS];

#if VDEBUG
unsigned Allocator::Descriptor::globalTimestamp;
size_t Allocator::Descriptor::noOfEntries;
size_t Allocator::Descriptor::maxEntries;
size_t Allocator::Descriptor::capacity;
Allocator::Descriptor* Allocator::Descriptor::map;
Allocator::Descriptor* Allocator::Descriptor::afterLast;
unsigned Allocator::_tolerantZone = 1; 
#endif

#if VDEBUG && USE_PRECISE_CLASS_NAMES && defined(__GNUC__)

string Lib::___prettyFunToClassName(std::string str)
{
  CALLC("___prettyFunToClassName",MAKE_CALLS);

  string noPref = str.substr(19);
  size_t fnNamePos = noPref.find("::className()");
  string className = noPref.substr(0,fnNamePos);
  
  
  string templateInfo = noPref.substr(fnNamePos+13);
  return className+templateInfo;
}

#endif

Allocator::Allocator()
{
  CALLC("Allocator::Allocator",MAKE_CALLS);

#if ! USE_SYSTEM_ALLOCATION
  for (int i = REQUIRES_PAGE/4-1;i >= 0;i--) {
    _freeList[i] = 0;
  }
  _reserveBytesAvailable = 0;
  _nextAvailableReserve = 0;
  _myPages = 0;
#endif
} 

Lib::Allocator::~Allocator ()
{
  CALLC("Allocator::~Allocator",MAKE_CALLS);

  while (_myPages) {
    deallocatePages(_myPages);
  }
} 

void Allocator::initialise()
{
  CALLC("Allocator::initialise",MAKE_CALLS)

#if VDEBUG
  Descriptor::map = 0;
  Descriptor::afterLast = 0;
#endif

  _memoryLimit = 300000000u;
  _tolerated = 330000000u;

#if ! USE_SYSTEM_ALLOCATION
  current = newAllocator();

  for (int i = MAX_PAGES-1;i >= 0;i--) {
    _pages[i] = 0;
  }
#endif
} 

#if VDEBUG
void Allocator::addressStatus(const void* address)
{
  CALLC("Allocator::addressStatus",MAKE_CALLS);

  Descriptor* pg = 0; 
  cout << "Status of address " << address << '\n';

  const char* a = static_cast<const char*>(address);
  for (int i = Descriptor::capacity-1;i >= 0;i--) {
    Descriptor& d = Descriptor::map[i];
    const char* addr = static_cast<const char*>(d.address);
    if (addr < a) {
      continue;
    }
    unsigned diff = a - addr;
    if (diff >= d.size) {
      continue;
    }
    if (d.page) {
      pg = &d;
      continue;
    }
    
    cout << "Descriptor: " << d << '\n'
	 << "Offset: " << diff << '\n'
	 << "End of status\n";
    return;
  }
  if (pg) {
    cout << "Not found but belongs to allocated page: " << *pg << '\n';
  }
  else {
    cout << "Does not belong to an allocated page\n";
  }
  cout << "End of status\n";
} 

void Allocator::reportUsageByClasses()
{
  Lib::DHMap<const char*, size_t> summary;
  Lib::DHMap<const char*, size_t> cntSummary;
  for (int i = Descriptor::capacity-1;i >= 0;i--) {
    Descriptor& d = Descriptor::map[i];
    if (!d.address || !d.size || !d.allocated) {
      continue;
    }
    size_t occupied;
    if(summary.find(d.cls, occupied)) {
      summary.set(d.cls, occupied+d.size);
      size_t cnt;
      ALWAYS(cntSummary.find(d.cls, cnt));
      cntSummary.set(d.cls, cnt+1);
    } else {
      summary.set(d.cls, d.size);
      cntSummary.set(d.cls, 1);
    }
  }

  Lib::DHMap<const char*, size_t>::Iterator sit(summary);
  cout<<"class\tcount\tsize"<<endl;
  while(sit.hasNext()) {
    const char* cls;
    size_t occupied, cnt;
    sit.next(cls,occupied);
    ALWAYS(cntSummary.find(cls,cnt));
    cout<<cls<<":\t"<<cnt<<"\t"<<occupied<<endl;
  }
}

#endif

void Allocator::cleanup()
{
  CALLC("Allocator::cleanup",MAKE_CALLS);
  BYPASSING_ALLOCATOR;

  
  for (int i = _total-1;i >= 0;i--) {
    delete _all[i];
  }
       
#if CHECK_LEAKS
  if (MemoryLeak::report()) {
    int leaks = 0;
    for (int i = Descriptor::capacity-1;i >= 0;i--) {
      Descriptor& d = Descriptor::map[i];
      if (d.allocated) {
	if (! leaks) {
	  cout << "Memory leaks found!\n";
	}
	cout << ++leaks << ": " << d.cls << " (" << d.address << "), timestamp: "
	     << d.timestamp << "\n";
      }
    }
    if (leaks) {
      cout << "End of memory leak report\n";
    }
  }
#endif

  
  for (int i = MAX_PAGES-1;i >= 0;i--) {
#if VDEBUG && TRACE_ALLOCATIONS
    int cnt = 0;
#endif    
    while (_pages[i]) {
      Page* pg = _pages[i];
      _pages[i] = pg->next;
      
      char* mem = reinterpret_cast<char*>(pg);
      ::delete[] mem;
#if VDEBUG && TRACE_ALLOCATIONS
      cnt++;
#endif    
    }
#if VDEBUG && TRACE_ALLOCATIONS    
      if (cnt) {
        cout << "deleted " << cnt << " global page(s) of size " << VPAGE_SIZE*(i+1) << endl;
      }
#endif        
  }
    
#if VDEBUG
  delete[] Descriptor::map;
#endif  
} 


#if VDEBUG
void Allocator::deallocateKnown(void* obj,size_t size,const char* className)
#else
void Allocator::deallocateKnown(void* obj,size_t size)
#endif
{
  CALLC("Allocator::deallocateKnown",MAKE_CALLS);
  ASS(obj);

#if VDEBUG
  Descriptor* desc = Descriptor::find(obj);
  desc->timestamp = ++Descriptor::globalTimestamp;
#if TRACE_ALLOCATIONS
  cout << *desc << ": DK\n" << flush;
#endif
  ASS_EQ(desc->address, obj);
  ASS_STR_EQ(desc->cls,className);
  ASS_EQ(desc->size, size);
  ASS(desc->allocated);
  ASS(desc->known);
  ASS(! desc->page);
#endif

#if USE_SYSTEM_ALLOCATION
#if VDEBUG
  desc->allocated = 0;
#endif
  free(obj);

  return;
#else   
  if (size >= REQUIRES_PAGE) {
    char* mem = reinterpret_cast<char*>(obj)-PAGE_PREFIX_SIZE;
    deallocatePages(reinterpret_cast<Page*>(mem));
  }
  else {
    int index = (size-1)/sizeof(Known);
    Known* mem = reinterpret_cast<Known*>(obj);
    mem->next = _freeList[index];
    _freeList[index] = mem;
  }

#if VDEBUG
  desc->allocated = 0;
#endif

#if WATCH_ADDRESS
  unsigned addr = (unsigned)obj;
  unsigned cp = Debug::Tracer::passedControlPoints();
  if (addr <= WATCH_ADDRESS &&
      WATCH_ADDRESS < addr+size &&
      cp >= WATCH_FIRST &&
      cp <= WATCH_LAST) {
    unsigned currentValue = *((unsigned*)WATCH_ADDRESS);
    cout << "Watch! Known-size piece deallocated!\n"
	 << "  Timestamp: " << cp << '\n'
	 << "  Piece addresses: " << (void*)addr << '-'
	 << (void*)(addr+size-1) << '\n';
    if (currentValue != watchAddressLastValue) {
      watchAddressLastValue = currentValue;
      cout << "  Value: " << (void*)watchAddressLastValue << '\n';
    }
    cout << "  " << *desc << '\n'
	 << "Watch! end\n";
  }
#endif
#endif
} 

#if VDEBUG
void Allocator::deallocateUnknown(void* obj,const char* className)
#else
void Allocator::deallocateUnknown(void* obj)
#endif
{
  CALLC("Allocator::deallocateUnknown",MAKE_CALLS);

#if VDEBUG
  Descriptor* desc = Descriptor::find(obj);
  desc->timestamp = ++Descriptor::globalTimestamp;
#if TRACE_ALLOCATIONS
  cout << *desc << ": DU\n" << flush;
#endif
  ASS_EQ(desc->address, obj);
  ASS_STR_EQ(desc->cls,className);
  ASS(desc->allocated);
  ASS(! desc->known);
  ASS(! desc->page);
  desc->allocated = 0;
#endif

#if USE_SYSTEM_ALLOCATION
  char* memObj = reinterpret_cast<char*>(obj) - sizeof(Known);
  free(memObj);

  return;
#endif

  char* mem = reinterpret_cast<char*>(obj) - sizeof(Known);
  Unknown* unknown = reinterpret_cast<Unknown*>(mem);
  size_t size = unknown->size;
  ASS_EQ(desc->size, size);

  if (size >= REQUIRES_PAGE) {
    mem = mem-PAGE_PREFIX_SIZE;
    deallocatePages(reinterpret_cast<Page*>(mem));
  }
  else {
    Known* known = reinterpret_cast<Known*>(mem);
    int index = (size-1)/sizeof(Known);
    known->next = _freeList[index];
    _freeList[index] = known;
  }

#if WATCH_ADDRESS
  unsigned addr = (unsigned)(void*)mem;
  unsigned cp = Debug::Tracer::passedControlPoints();
  if (addr <= WATCH_ADDRESS &&
      WATCH_ADDRESS < addr+size &&
      cp >= WATCH_FIRST &&
      cp <= WATCH_LAST) {
    unsigned currentValue = *((unsigned*)WATCH_ADDRESS);
    cout << "Watch! Unknown-size piece deallocated!\n"
	 << "  Timestamp: " << cp << '\n'
	 << "  Piece addresses: " << (void*)addr << '-'
	 << (void*)(addr+size-1) << '\n';
    if (currentValue != watchAddressLastValue) {
      watchAddressLastValue = currentValue;
      cout << "  Value: " << (void*)watchAddressLastValue << '\n';
    }
    cout << "  " << *desc << '\n'
	 << "Watch! end\n";
  }
#endif
} 

#if VDEBUG
void* Allocator::reallocateUnknown(void* obj, size_t newsize, const char* className)
#else
void* Allocator::reallocateUnknown(void* obj, size_t newsize)
#endif
{
  CALLC("Allocator::reallocateUnknown",MAKE_CALLS);

  

#if VDEBUG
  void* newobj = allocateUnknown(newsize,className);
#else
  void* newobj = allocateUnknown(newsize);
#endif

  if (obj == NULL) {
    return newobj;
  }

  size_t size = unknownsSize(obj);

  ASS_NEQ(size,newsize); 

  if (newsize < size) {
    size = newsize;
  }

  std::memcpy(newobj,obj,size);

#if VDEBUG
  deallocateUnknown(obj,className);
#else
  deallocateUnknown(obj);
#endif

  return newobj;
} 

Allocator* Allocator::newAllocator()
{
  CALLC("Allocator::newAllocator",MAKE_CALLS);
  BYPASSING_ALLOCATOR;
  
#if VDEBUG && USE_SYSTEM_ALLOCATION
  ASSERTION_VIOLATION;
#else
  Allocator* result = new Allocator();

  if (_total >= MAX_ALLOCATORS) {
    throw Exception("The maximal number of allocators exceeded.");
  }
  _all[_total++] = result;
  return result;
#endif
} 

Allocator::Page* Allocator::allocatePages(size_t size)
{
  CALLC("Allocator::allocatePages",MAKE_CALLS);
  ASS(size >= 0);

#if VDEBUG && USE_SYSTEM_ALLOCATION
  ASSERTION_VIOLATION;
#else
  size += PAGE_PREFIX_SIZE;

  Page* result;
  size_t index = (size-1)/VPAGE_SIZE;
  size_t realSize = VPAGE_SIZE*(index+1);

  
  if(index>=MAX_PAGES) {
#if SAFE_OUT_OF_MEM_SOLUTION
    env.beginOutput();
    reportSpiderStatus('m');
    env.out() << "Unsupported amount of allocated memory: "<<realSize<<"!\n";
    if(env.statistics) {
      env.statistics->print(env.out());
    }
#if VDEBUG
    Debug::Tracer::printStack(env.out());
#endif
    env.endOutput();
    System::terminateImmediately(1);
#else
    throw Lib::MemoryLimitExceededException();
#endif
  }
  
  if (_pages[index]) {
    result = _pages[index];
    _pages[index] = result->next;
  }
  else {
    size_t newSize = _usedMemory+realSize;
    if (_tolerated && newSize > _tolerated) {
      env.statistics->terminationReason = Shell::Statistics::MEMORY_LIMIT;
      
      _tolerated=newSize+1000000;

#if SAFE_OUT_OF_MEM_SOLUTION
      env.beginOutput();
      reportSpiderStatus('m');
      env.out() << "Memory limit exceeded!\n";
# if VDEBUG
	Allocator::reportUsageByClasses();
# endif
      if(env.statistics) {
	env.statistics->print(env.out());
      }
      env.endOutput();
      System::terminateImmediately(1);
#else
      throw Lib::MemoryLimitExceededException();
#endif
    }
    _usedMemory = newSize;

    char* mem;
    try {
      BYPASSING_ALLOCATOR;
      
      mem = new char[realSize];
    } catch(bad_alloc) {
      env.beginOutput();
      reportSpiderStatus('m');
      env.out() << "Memory limit exceeded!\n";
      if(env.statistics) {
        
        
        env.statistics->print(env.out());
      }
      env.endOutput();
      System::terminateImmediately(1);

      
      
    }
    result = reinterpret_cast<Page*>(mem);
  }
  result->size = realSize;

#if VDEBUG
  Descriptor* desc = Descriptor::find(result);
  ASS(! desc->allocated);

  desc->address = result;
  desc->cls = "Allocator::Page";
  desc->timestamp = ++Descriptor::globalTimestamp;
  desc->size = realSize;
  desc->allocated = 1;
  desc->known = 0;
  desc->page = 1;

#if TRACE_ALLOCATIONS
  cout << *desc << ": AP\n" << flush;
#endif 
#endif 

  result->next = _myPages;
  result->previous = 0;
  if (_myPages) {
    _myPages->previous = result;
  }
  _myPages = result;

#if WATCH_ADDRESS
  unsigned addr = (unsigned)(void*)result;
  unsigned cp = Debug::Tracer::passedControlPoints();
  if (addr <= WATCH_ADDRESS &&
      WATCH_ADDRESS < addr+realSize) {
    watchPage = true;
    Debug::Tracer::canWatch = true;
    if (cp >= WATCH_FIRST &&
	cp <= WATCH_LAST) {
      watchAddressLastValue = *((unsigned*)WATCH_ADDRESS);
      cout << "Watch! Page allocated!\n"
	   << "  Timestamp: " << cp << '\n'
	   << "  Page addresses: " << (void*)addr << '-'
	   << (void*)(addr+realSize-1) << '\n'
	   << "  Value: " << (void*)watchAddressLastValue << '\n'
	   << "Watch! end\n";
    }
  }
#endif

  return result;
#endif 
} 

void Allocator::deallocatePages(Page* page)
{
  ASS(page);

#if VDEBUG && USE_SYSTEM_ALLOCATION
  ASSERTION_VIOLATION;
#else
  CALLC("Allocator::deallocatePages",MAKE_CALLS);

#if VDEBUG
  Descriptor* desc = Descriptor::find(page);
  desc->timestamp = ++Descriptor::globalTimestamp;
#if TRACE_ALLOCATIONS
  cout << *desc << ": DP\n" << flush;
#endif
  ASS(desc->address == page);
  ASS_STR_EQ(desc->cls,"Allocator::Page");
  ASS(desc->size == page->size);
  ASS(desc->allocated);
  ASS(! desc->known);
  ASS(desc->page);
  desc->allocated = 0;
#endif

  size_t size = page->size;
  int index = (size-1)/VPAGE_SIZE;

  Page* next = page->next;
  if (next) {
    next->previous = page->previous;
  }
  if (page->previous) {
    page->previous->next = next;
  }

  if (page == _myPages) {
    _myPages = next;
  }

  page->next = _pages[index];
  _pages[index] = page;

#if WATCH_ADDRESS
  unsigned addr = (unsigned)(void*)page;
  unsigned cp = Debug::Tracer::passedControlPoints();
  if (addr <= WATCH_ADDRESS &&
      WATCH_ADDRESS < addr+size &&
      cp >= WATCH_FIRST &&
      cp <= WATCH_LAST) {
    unsigned currentValue = *((unsigned*)WATCH_ADDRESS);
    cout << "Watch! Page deallocated!\n"
	 << "  Timestamp: " << cp << '\n'
	 << "  Page addresses: " << (void*)addr << '-'
	 << (void*)(addr+size-1) << '\n';
    if (currentValue != watchAddressLastValue) {
      watchAddressLastValue = currentValue;
      cout << "  Value: " << (void*)watchAddressLastValue << '\n';
    }
    cout << "Watch! end\n";
  }
#endif

#endif 
} 


#if VDEBUG
void* Allocator::allocateKnown(size_t size,const char* className)
#else
void* Allocator::allocateKnown(size_t size)
#endif
{
  CALLC("Allocator::allocateKnown",MAKE_CALLS);
  ASS(size > 0);

  char* result = allocatePiece(size);

#if VDEBUG
  Descriptor* desc = Descriptor::find(result);
  ASS_REP(! desc->allocated, size);

  desc->address = result;
  desc->cls = className;
  desc->timestamp = ++Descriptor::globalTimestamp;
  desc->size = size;
  desc->allocated = 1;
  desc->known = 1;
  desc->page = 0;
#if TRACE_ALLOCATIONS
  cout << *desc << ": AK\n" << flush;
#endif
#endif

#if WATCH_ADDRESS
  unsigned addr = (unsigned)(void*)result;
  unsigned cp = Debug::Tracer::passedControlPoints();
  if (addr <= WATCH_ADDRESS &&
      WATCH_ADDRESS < addr+size &&
      cp >= WATCH_FIRST &&
      cp <= WATCH_LAST) {
    unsigned currentValue = *((unsigned*)WATCH_ADDRESS);
    cout << "Watch! Known-size piece allocated!\n"
	 << "  Timestamp: " << cp << '\n'
	 << "  Piece addresses: " << (void*)addr << '-'
	 << (void*)(addr+size-1) << '\n';
    if (currentValue != watchAddressLastValue) {
      watchAddressLastValue = currentValue;
      cout << "  Value: " << (void*)watchAddressLastValue << '\n';
    }
    cout << "  " << *desc << '\n'
	 << "Watch! end\n";
  }
#endif
  return result;
} 


char* Allocator::allocatePiece(size_t size)
{
  CALLC("Allocator::allocatePiece",MAKE_CALLS);

  char* result;
#if USE_SYSTEM_ALLOCATION

  result = static_cast<char*>(malloc(size));
#else 
  if (size >= REQUIRES_PAGE) {
    Page* page = allocatePages(size);
    result = reinterpret_cast<char*>(page) + PAGE_PREFIX_SIZE;
  }
  else { 
    int index = (size-1)/sizeof(Known);
    
    size = (index+1) * sizeof(Known);
    Known* mem = _freeList[index];
    if (mem) {
      _freeList[index] = mem->next;
      result = reinterpret_cast<char*>(mem);
    } 
    else if (_reserveBytesAvailable >= size) { 
    use_reserve:
      result = _nextAvailableReserve;
      _nextAvailableReserve += size;
      _reserveBytesAvailable -= size;
    }
    else {
      
      
      if (_reserveBytesAvailable) {
	index = (_reserveBytesAvailable-1)/sizeof(Known);
	Known* save = reinterpret_cast<Known*>(_nextAvailableReserve);
#if VDEBUG
	Descriptor* desc = Descriptor::find(save);
	ASS(! desc->allocated);
	desc->size = _reserveBytesAvailable;
	desc->timestamp = ++Descriptor::globalTimestamp;
#if TRACE_ALLOCATIONS
	cout << *desc << ": RR\n" << flush;
#endif
#endif
	save->next = _freeList[index];
	_freeList[index] = save;
      }
      Page* page = allocatePages(0);
      _reserveBytesAvailable = VPAGE_SIZE-PAGE_PREFIX_SIZE;
      _nextAvailableReserve = reinterpret_cast<char*>(&page->content);
      goto use_reserve;
    }
  }
#endif 
  return result;
} 


#if VDEBUG
void* Allocator::allocateUnknown(size_t size,const char* className)
#else
void* Allocator::allocateUnknown(size_t size)
#endif
{
  CALLC("Allocator::allocateUnknown",MAKE_CALLS);
  ASS(size>0);

  size += sizeof(Known);
  char* result = allocatePiece(size);
  Unknown* unknown = reinterpret_cast<Unknown*>(result);
  unknown->size = size;
  result += sizeof(Known);

#if VDEBUG
  Descriptor* desc = Descriptor::find(result);
  ASS(! desc->allocated);

  desc->address = result;
  desc->cls = className;
  desc->timestamp = ++Descriptor::globalTimestamp;
  desc->size = size;
  desc->allocated = 1;
  desc->known = 0;
  desc->page = 0;

#if TRACE_ALLOCATIONS
  cout << *desc << ": AU\n" << flush;
#endif
#endif

#if WATCH_ADDRESS
  unsigned addr = (unsigned)(void*)(result-sizeof(Known));
  unsigned cp = Debug::Tracer::passedControlPoints();
  if (addr <= WATCH_ADDRESS &&
      WATCH_ADDRESS < addr+size &&
      cp >= WATCH_FIRST &&
      cp <= WATCH_LAST) {
    unsigned currentValue = *((unsigned*)WATCH_ADDRESS);
    cout << "Watch! Unknown-size piece allocated!\n"
	 << "  Timestamp: " << cp << '\n'
	 << "  Piece addresses: " << (void*)addr << '-'
	 << (void*)(addr+size-1) << '\n';
    if (currentValue != watchAddressLastValue) {
      watchAddressLastValue = currentValue;
      cout << "  Value: " << (void*)watchAddressLastValue << '\n';
    }
    cout << "  " << *desc << '\n'
	 << "Watch! end\n";
  }
#endif
  return result;
} 


#if VDEBUG
Allocator::Descriptor* Allocator::Descriptor::find (const void* addr)
{    
  CALLC("Allocator::Descriptor::find",MAKE_CALLS);
  BYPASSING_ALLOCATOR;

  if (noOfEntries >= maxEntries) { 
    

    capacity = capacity ? 2*capacity : 2000000;

#if TRACE_ALLOCATIONS
    cout << "Allocator map expansion to capacity " << capacity << "\n" << flush;
#endif

    Descriptor* oldMap = map;
    try {
      map = new Descriptor [capacity];
    } catch(bad_alloc) {
      env.beginOutput();
      reportSpiderStatus('m');
      env.out() << "Memory limit exceeded!\n";
      env.endOutput();
      System::terminateImmediately(1);

      
      
    }
    Descriptor* oldAfterLast = afterLast;
    afterLast = map + capacity;
    maxEntries = (int)(capacity * 0.7);
    noOfEntries = 0;

    for (Descriptor* current = oldMap;current != oldAfterLast;current++) {
      if (! current->address) {
	continue;
      }
      
      Descriptor* d = find(current->address);
      *d = *current;
    }
    delete [] oldMap;
  }
  Descriptor* desc = map + (hash(addr) % capacity);
  while (desc->address) {
    if (desc->address == addr) {
      return desc;
    }

    desc++;
    
    if (desc == afterLast) {
      desc = map;
    }
  }

  desc->address = addr;
  noOfEntries++;

  return desc;
} 

ostream& Lib::operator<<(ostream& out, const Allocator::Descriptor& d) {
  CALLC("operator<<(ostream,Allocator::Descriptor)",MAKE_CALLS);
  
  out << (size_t)(&d)
      << " [address:" << d.address
      << ",timestamp:" << d.timestamp
      << ",class:" << d.cls
      << ",size:" << d.size
      << ",allocated:" << (d.allocated ? "yes" : "no")
      << ",known:" << (d.known ? "yes" : "no")
      << ",page:" << (d.page ? "yes" : "no") << ']';  
  
  return out;
}

Allocator::Descriptor::Descriptor ()
  : address(0),
    cls("???"),
    timestamp(0),
    size(0),
    allocated(0),
    known(0),
    page(0)
{

} 

unsigned Allocator::Descriptor::hash (const void* addr)
{
  CALLC("Allocator::Descriptor::hash",MAKE_CALLS);

  char* val = reinterpret_cast<char*>(&addr);
  unsigned hash = 2166136261u;
  for (int i = sizeof(void*)-1;i >= 0;i--) {
    hash = (hash ^ val[i]) * 16777619u;
  }
  return hash;
} 

#endif

#if VDEBUG 
  
void* operator new(size_t sz) {    
  ASS_REP(Allocator::_tolerantZone > 0,"Attempted to use global new operator, thus bypassing Allocator!");
  

  if(Allocator::_tolerantZone == 0){
    Debug::Tracer::printStack(cout);
  
    cout << "Warning, bypassing Allocator" << endl;
  }
  
  if (sz == 0)
    sz = 1;
      
  void* res = malloc(sz);  
  
  if (!res)
    throw bad_alloc();
  
  return res;
}

void* operator new[](size_t sz) {  
  ASS_REP(Allocator::_tolerantZone > 0,"Attempted to use global new[] operator, thus bypassing Allocator!");
  

  if(Allocator::_tolerantZone == 0){
    Debug::Tracer::printStack(cout);
    
    cout << "Warning, bypassing Allocator" << endl;
  }
  
  if (sz == 0)
    sz = 1;
      
  void* res = malloc(sz);  
  
  if (!res)
    throw bad_alloc();
  
  return res;
}

void operator delete(void* obj) throw() {  
  ASS_REP(Allocator::_tolerantZone > 0,"Custom operator new matched by global delete!");
  

  if(Allocator::_tolerantZone==0){
    Debug::Tracer::printStack(cout);
    
    cout << "Warning, custom new matched by global delete" << endl;
  }
  free(obj);
}

void operator delete[](void* obj) throw() {  
  ASS_REP(Allocator::_tolerantZone > 0,"Custom operator new[] matched by global delete[]!");
  

  if(Allocator::_tolerantZone==0){
        Debug::Tracer::printStack(cout);
  
    cout << "Warning, custom new matched by global delete[]" << endl;
  }
  free(obj);
}
#endif 

#if VTEST

#include "Random.hpp"
using namespace Lib;

struct Mem
{
  void* address; 
  int size;      
  bool known;
  const char* className;
  Mem() : address(0) {}
};

void testAllocator()
{
  CALLC("testAllocator",MAKE_CALLS);

  cout << "Testing the Allocator class...\n";

  Allocator* a = Allocator::current;

  int tries = 1000000000;  
  int pieces = 1000;  
  int maxsize = 1000000;    
  const char* classes[10] = {"a","b","c","d","e","f","g","h","i","j"};
  int frequency = 1000; 
  int out = frequency;   

   Mem* mems = new Mem[pieces]; 
  int total = 0;
  for (int i = 0; i < tries;i++) {
    out--;
    if (! out) {
      out = frequency;
      cout << '.' << flush;

    }
    int rand = Random::getInteger(pieces);

    Mem& m = mems[rand];
    if (m.address) { 
      if (m.known) {
	a->deallocateKnown(m.address,m.size,m.className);
      }
      else {
	a->deallocateUnknown(m.address,m.className);
      }
      m.address = 0;
    }
    else { 
      int size = Random::getInteger(maxsize)+1;
      m.size = size;
      total += size;
      const char* className = classes[Random::getInteger(10)];
      m.className = className;
      if (Random::getBit()) {
	m.known = false;
	m.address = a->allocateUnknown(size,className);
      }
      else {
	m.known = true;
	m.address = a->allocateKnown(size,className);
      }
    }
  }

  cout << "\nTest completed!\n";
} 

#endif 



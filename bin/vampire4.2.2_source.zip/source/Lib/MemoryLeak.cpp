
/*
 * File MemoryLeak.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#if CHECK_LEAKS

#include "Hash.hpp"
#include "Stack.hpp"
#include "MemoryLeak.hpp"

#include "Kernel/Clause.hpp"
#include "Kernel/Inference.hpp"
#include "Kernel/Formula.hpp"
#include "Kernel/FormulaUnit.hpp"

using namespace Kernel;

bool MemoryLeak::_cancelled = false;

void MemoryLeak::release(Formula* f)
{
  CALL("MemoryLeak::release(Formula*)");

  if (_released.contains(f)) {
    return;
  }
  _released.insert(f);
  switch (f->connective()) {
  case LITERAL:
  case TRUE:
  case FALSE:
    break;
  case AND:
  case OR:
    {
      FormulaList* fs = f->args();
      while (fs) {
	if (_released.contains(fs)) {
	  break;
	}
	_released.insert(fs);
	FormulaList* next = fs->tail();
	release(fs->head());
	delete fs;
	fs = next;
      }
    }
    break;
  case IMP:
  case IFF:
  case XOR:
    release(f->left());
    release(f->right());
    break;
  case NOT:
    release(f->uarg());
    break;
  case FORALL:
  case EXISTS:
    {
      Formula::VarList* vs = f->vars();
      while (vs) {
	if (_released.contains(vs)) {
	  break;
	}
	_released.insert(vs);
	Formula::VarList* next = vs->tail();
	delete vs;
	vs = next;
      }
    }
    release(f->qarg());
    break;
#if VDEBUG
  default:
    ASSERTION_VIOLATION;
#endif
  }
  f->destroy();
} 


void MemoryLeak::release(UnitList* units)
{
  Stack<Unit*> us(32);
  while (units) {
    UnitList* next = units->tail();
    Unit* u = units->head();
    if (_released.contains(u)) {
      continue;
    }
    _released.insert(u);
    us.push(u);
    delete units;
    units = next;
  }

  while (us.isNonEmpty()) {
    Unit* u = us.pop();
    Inference* inf = u->inference();
    Inference::Iterator ps = inf->iterator();
    while (inf->hasNext(ps)) {
      Unit* p = inf->next(ps);
      if (_released.contains(p)) {
	continue;
      }
      _released.insert(p);
      us.push(p);
    }

    if (! u->isClause()) {
      release(static_cast<FormulaUnit*>(u)->formula());
      u->destroy();
    }
  }
} 

#endif 

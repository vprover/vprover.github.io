
/*
 * File Array.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Array__
#define __Array__

#include "Debug/Assertion.hpp"

#include "Lib/Allocator.hpp"

namespace Lib {

template<typename C>
class Array
{
public:
 
  inline
  Array (size_t initialCapacity)
    : _capacity(initialCapacity)
  {
    if(initialCapacity) {
      void* mem = ALLOC_KNOWN(initialCapacity*sizeof(C),"Array<>");
      _array = array_new<C>(mem, initialCapacity);
    } else {
      _array=0;
    }
  }

 
  Array (const Array &o) : _capacity(o._capacity) {
    if (o._array) {
      void* mem = ALLOC_KNOWN(_capacity*sizeof(C),"Array<>");
      _array = static_cast<C*>(mem);
      for(size_t i=0; i<_capacity; i++) {
        new(&_array[i]) C(o._array[i]);
      }
    } else {
      _array = 0;
    }
  }

 
  inline Array ()
    : _capacity(31)
  {
    void* mem = ALLOC_KNOWN(sizeof(C)*31,"Array<>");
    _array = array_new<C>(mem, 31);
  }

 
  virtual void fillInterval (size_t start,size_t end)
  {
  } 

 
  virtual ~Array()
  {
    CALL("Array::~Array()");

    if(_array) {
      array_delete(_array, _capacity);
      DEALLOC_KNOWN(_array,_capacity*sizeof(C),"Array<>");
    }
  }

 
  inline
  C& operator[] (size_t n)
  {
    if (n >= _capacity) {
      expandToFit(n);
    }
    return _array[n];
  } 

 
  inline const C& operator[](size_t n) const
  {
    ASS(n < _capacity);

    return _array[n];
  }

 
  inline C& get(size_t n)
  {
    if (n >= _capacity) {
      expandToFit(n);
    }

    return _array[n];
  }

 
  inline void set (size_t n,C value)
  {
    ASS(n < _capacity);

    _array[n] = value;
  } 

 
  inline const C* content() { return _array; }

 
  size_t size() const { return _capacity; }

  inline C* begin() { return _array; }

  inline C* end() { return _array+_capacity; }


protected:
 
  size_t _capacity;
 
  C* _array;

 
  void expandToFit (size_t n)
  {
    CALL("Array::expandToFit");
    ASS(n >= _capacity);

    
    size_t newCapacity = 2 * _capacity;
    if (newCapacity <= n) {
      newCapacity = n+1;
    }

    
    void* mem = ALLOC_KNOWN(sizeof(C)*newCapacity,"Array<>");
    C* newArray = array_new<C>(mem, newCapacity);
    if(_capacity) {
      for (int i = _capacity-1;i >= 0;i--) {
	newArray[i] = _array[i];
      }
    }

    if(_array) {
      
      array_delete(_array,_capacity);
      DEALLOC_KNOWN(_array,_capacity*sizeof(C),"Array<>");
    }

    _array = newArray;
    fillInterval(_capacity,newCapacity);
    _capacity = newCapacity;
  } 
};

template <typename T>
class ZIArray
: public Array<T>
{
public:
  inline
  ZIArray(size_t initialCapacity) : Array<T>(initialCapacity)
  {
    fillInterval(0, Array<T>::_capacity);
  }
  inline
  ZIArray()
  {
    fillInterval(0, Array<T>::_capacity);
  }


  void fillInterval(size_t start,size_t end)
  {
    for(size_t i=start; i<end; i++) {
      Array<T>::_array[i]=static_cast<T>(0);
    }
  }
};

} 

#endif

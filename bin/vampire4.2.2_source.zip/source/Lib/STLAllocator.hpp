
/*
 * File STLAllocator.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#ifndef __STLAllocator__
#define __STLAllocator__

#include <limits>

#include "Lib/Allocator.hpp"

namespace Lib {

template<typename T>
class STLAllocator {
public : 
    
    typedef T value_type;
    typedef value_type* pointer;
    typedef const value_type* const_pointer;
    typedef value_type& reference;
    typedef const value_type& const_reference;
    typedef std::size_t size_type;
    typedef std::ptrdiff_t difference_type;

public : 
    
    template<typename U>
    struct rebind {
        typedef STLAllocator<U> other;
    };

public : 
    inline explicit STLAllocator() {}
    inline ~STLAllocator() {}
    inline explicit STLAllocator(STLAllocator const&) {}
    template<typename U>
    inline STLAllocator(STLAllocator<U> const&) {}

    
    inline pointer address(reference r) { return &r; }
    inline const_pointer address(const_reference r) { return &r; }

    
    inline pointer allocate(size_type cnt, 
       typename std::allocator<void>::const_pointer = 0) { 
      return reinterpret_cast<pointer>(ALLOC_UNKNOWN(cnt*sizeof(T),"STLAllocator<T>"));           
    }
    inline void deallocate(pointer p, size_type) { 
        DEALLOC_UNKNOWN(p,"STLAllocator<T>");
    }

    
    inline size_type max_size() const { 
        return std::numeric_limits<size_type>::max() / sizeof(T);
 }

    
    inline void construct(pointer p, const T& t) { new(p) T(t); }
    inline void destroy(pointer p) { p->~T(); }

    inline bool operator==(STLAllocator const&) const { return true; }
    inline bool operator!=(STLAllocator const& a) const { return !operator==(a); }
};    

extern const STLAllocator<void> global_stl_allocator;

} 

#endif 

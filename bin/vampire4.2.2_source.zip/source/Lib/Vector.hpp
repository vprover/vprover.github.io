
/*
 * File Vector.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Vector__
#define __Vector__

#include "Forwards.hpp"

#include "Debug/Assertion.hpp"
#include "Allocator.hpp"
#include "VString.hpp"

namespace Lib {

using namespace std;

template<typename C>
class Vector
{
public:
 
  inline C& operator[] (size_t n)
  {
    ASS(n < _length);
    return _array[n];
  } 

 
  inline const C& operator[](size_t n) const
  {
    ASS(n < _length);
    return _array[n];
  }

 
  size_t length() const { return _length; }

 
  static Vector* allocate(size_t length)
  {
    CALL("Vector::allocate");
    ASS_G(length,0);

    size_t sz=sizeof(Vector) + (length-1)*sizeof(C);
    Vector* v = reinterpret_cast<Vector*>(ALLOC_KNOWN(sz,"Vector"));
    v->_length = length;
    C* arr = v->_array;
    
    
    array_new<C>(arr,length);
    return v;
  } 

 
  void deallocate()
  {
    CALL("Vector::deallocate");

    
    
    array_delete(_array, _length);
    size_t sz=sizeof(Vector) + (_length-1)*sizeof(C);
    DEALLOC_KNOWN(this,sz,"Vector");
  } 

 
  vstring toString()
  {
    vstring res;
    for(size_t i=0;i<_length;i++) {
      if (i>0) {
	res+=",";
      }
      res+=(*this)[i].toString();
    }
    return res;
  } 

  friend class Indexing::CodeTree;
  friend class Indexing::ClauseCodeTree;

 
  class DestructiveIterator
  {
  public:
    DECL_ELEMENT_TYPE(C);

    DestructiveIterator(Vector& v)
    : cur(v._array), afterLast(v._array+v.length()), vec(&v)
    {
      if (cur==afterLast) {
	vec->deallocate();
      }
    }

    bool hasNext()
    {
      return cur!=afterLast;
    }

    C next()
    {
      CALL("Vector::DestructiveIterator::next");
      ASS(hasNext());

      C res=*cur;
      cur++;
      if (cur==afterLast) {
	vec->deallocate();
      }
      return res;
    }
  private:
    C* cur;
    C* afterLast;
    Vector* vec;
  }; 
protected:
 
  size_t _length;
 
  C _array[1];
private:
 
  void* operator new(size_t,size_t length);
 
  void operator delete(void*)
  {
    ASSERTION_VIOLATION
  }
 
  Vector();
}; 

} 

#endif

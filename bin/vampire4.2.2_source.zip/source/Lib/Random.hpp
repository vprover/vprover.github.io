
/*
 * File Random.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#ifndef __RANDOM__
#  define __RANDOM__


#include <cstdlib>
#include <ctime>

namespace Lib
{

class Random 
{
 
  static int _seed;
 
  static int _remainingBits;
 
  static const int _bitsPerInt; 
 
  static unsigned _bits; 

  static int bitsPerInt ();     

 public:

 
  static inline int getMax () { return RAND_MAX; }

 
  static inline int getInteger () { return rand(); } 
 
  static inline int getInteger (int modulus)
  { return getInteger () % modulus; }

 
  static double getDouble(double min, double max);
  static long double getDouble(long double min , long double max);
  
 
  static inline int getBit()
  {
    if ( _remainingBits == 0 ) {
      _remainingBits = _bitsPerInt;
      _bits = getInteger();
    }

    int result = _bits % 2;
    _bits /= 2;
    _remainingBits --;

    return result;
  } 

  
 
  inline static void setSeed(int s)
  {
    _seed = s;
    srand(s);
  }

 
  inline static int seed()
  {
    return _seed;
  }

 
  inline static void resetSeed ()
  { setSeed(static_cast<int>(time(0))); }
}; 


} 
#endif




/*
 * File VString.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#ifndef __VString__
#define __VString__

#include <string>
#include <sstream>

#include "STLAllocator.hpp"

namespace Lib {
  

typedef std::basic_ostringstream<char,std::char_traits<char>,STLAllocator<char> > vostringstream_base;

struct vostringstream : public vostringstream_base {
  CLASS_NAME(vostringstream);
  USE_ALLOCATOR(vostringstream);
  
  
  using vostringstream_base::vostringstream_base;
};


typedef std::basic_istringstream<char,std::char_traits<char>,STLAllocator<char> > vistringstream_base;

struct vistringstream : public vistringstream_base {
  CLASS_NAME(vistringstream);
  USE_ALLOCATOR(vistringstream);
  
  
  using vistringstream_base::vistringstream_base;
};


typedef std::basic_stringstream<char,std::char_traits<char>,STLAllocator<char> > vstringstream_base;

struct vstringstream : public vstringstream_base {
  CLASS_NAME(vstringstream);
  USE_ALLOCATOR(vstringstream);
  
  
  using vstringstream_base::vstringstream_base;
};


typedef std::basic_string<char,std::char_traits<char>,STLAllocator<char> > vstring;


} 

#endif 

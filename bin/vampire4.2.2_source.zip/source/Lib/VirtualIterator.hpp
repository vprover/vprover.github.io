
/*
 * File VirtualIterator.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __VirtualIterator__
#define __VirtualIterator__

#include "Forwards.hpp"

#include "Debug/Assertion.hpp"
#include "Debug/Tracer.hpp"

#include "Allocator.hpp"
#include "Exception.hpp"
#include "Reflection.hpp"

namespace Lib {




template<typename T>
  class VirtualIterator;

template<typename T>
class IteratorCore {
private:
  
  IteratorCore(const IteratorCore&);
  IteratorCore& operator=(const IteratorCore&);
public:
  DECL_ELEMENT_TYPE(T);
 
  IteratorCore() : _refCnt(0) {}
 
  virtual ~IteratorCore() { ASS(_refCnt==0); }
 
  virtual bool hasNext() = 0;
 
  virtual T next() = 0;
 
  virtual bool knowsSize() const { return false; }
 
  virtual size_t size() const { INVALID_OPERATION("This iterator cannot retrieve its size."); }

  CLASS_NAME(IteratorCore);

  USE_ALLOCATOR_UNK;
private:
 
  mutable int _refCnt;

  friend class VirtualIterator<T>;
};

template<typename T>
class EmptyIterator
: public IteratorCore<T>
{
public:
  CLASS_NAME(EmptyIterator);
  USE_ALLOCATOR(EmptyIterator);

  EmptyIterator() {}
  bool hasNext() { return false; };
  T next() { INVALID_OPERATION("next() called on EmptyIterator object"); };
  bool knowsSize() const { return true; }
  size_t size() const { return 0; }
};

template<typename T>
class VirtualIterator {
public:
  CLASS_NAME(VirtualIterator);
  USE_ALLOCATOR(VirtualIterator);
  DECLARE_PLACEMENT_NEW;
  
  DECL_ELEMENT_TYPE(T);

 
  static VirtualIterator getEmpty()
  {
    static VirtualIterator inst(new EmptyIterator<T>());
    return inst;
  }

 
  static VirtualIterator getInvalid()
  {
    return VirtualIterator();
  }

 
  inline
  VirtualIterator() : _core(0) {}

 
  inline
  explicit VirtualIterator(IteratorCore<T>* core) : _core(core) { _core->_refCnt++;}

  inline
  VirtualIterator(const VirtualIterator& obj) : _core(obj._core)
  {
    if(_core) {
      _core->_refCnt++;
    }
  }

  inline
  ~VirtualIterator()
  {
    CALL("VirtualIterator::~VirtualIterator");

    if(_core) {
	_core->_refCnt--;
	if(!_core->_refCnt) {
	  delete _core;
	}
    }
  }
  VirtualIterator& operator=(const VirtualIterator& obj)
  {
    CALL("VirtualIterator::operator=");

    IteratorCore<T>* oldCore=_core;
    _core=obj._core;
    if(_core) {
      _core->_refCnt++;
    }
    if(oldCore) {
      oldCore->_refCnt--;
      if(!oldCore->_refCnt) {
	delete oldCore;
      }
    }
    return *this;
  }

 
  inline
  bool drop()
  {
    CALL("VirtualIterator::drop");

    if(_core) {
      _core->_refCnt--;
      if(_core->_refCnt) {
	_core=0;
	return false;
      }
      else {
	delete _core;
	_core=0;
      }
    }
    _core=0;
    return true;
  }

 
  inline
  bool hasNext()
  {
    CALL("VirtualIterator::hasNext");
    ASS(_core);

    return _core->hasNext();
  }
 
  inline
  T next()
  {
    CALL("VirtualIterator::next");
    ASS(_core);

    return _core->next();
  }

 
  bool knowsSize() const
  {
    CALL("VirtualIterator::knowsSize");
    ASS(_core);

    return _core->knowsSize();
  }

 
  size_t size() const
  {
    CALL("VirtualIterator::size");
    ASS(_core);
    ASS(knowsSize());

    return _core->size();
  }

 
  bool isInvalid() { return !_core; }
private:
 
  IteratorCore<T>* _core;
};

template<typename T>
inline
VirtualIterator<T> vi(IteratorCore<T>* core)
{
  return VirtualIterator<T>(core);
}

template<typename T, class Inner>
class ProxyIterator
: public IteratorCore<T>
{
public:
  CLASS_NAME(ProxyIterator);
  USE_ALLOCATOR(ProxyIterator);
  
  explicit ProxyIterator(Inner inn) :_inn(inn) {}
  bool hasNext() { return _inn.hasNext(); };
  T next() { return _inn.next(); };
private:
  Inner _inn;
};

template<class Inner>
inline
VirtualIterator<ELEMENT_TYPE(Inner)> pvi(Inner it)
{
  return VirtualIterator<ELEMENT_TYPE(Inner)>(new ProxyIterator<ELEMENT_TYPE(Inner),Inner>(it));
}






}

#endif

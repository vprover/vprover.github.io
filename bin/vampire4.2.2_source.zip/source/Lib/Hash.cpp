
/*
 * File Hash.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Debug/Assertion.hpp"
#include "Debug/Tracer.hpp"

#include "Kernel/Unit.hpp"
#include "Kernel/InferenceStore.hpp"

#include "Portability.hpp"

#include "Hash.hpp"


namespace Lib
{

using namespace std;

unsigned Hash::hash(Kernel::Unit* u)
{
  if(!u) {
    return 75663234u; 
  }
  return hash(u->number());
}

unsigned Hash::hash (const char* val)
{
  CALL("Hash::hash/2");

  unsigned hash = 2166136261u;
  while (*val) {
    hash = (hash ^ *val) * 16777619u;
    val++;
  }
  return hash;
} 

unsigned Hash::hash (const unsigned char* val,size_t size)
{
  CALL("Hash::hash/1");
  ASS(size > 0);

  unsigned hash = 2166136261u;
  for (int i = size-1;i >= 0;i--) {
    hash = (hash ^ val[i]) * 16777619u;
  }
  return hash;
} 

unsigned Hash::hash (const unsigned char* val,size_t size,unsigned hash)
{
  CALL("Hash::hash/0");
  ASS(size > 0);

  for (int i = size-1;i >= 0;i--) {
    hash = (hash ^ val[i]) * 16777619u;
  }
  return hash;
} 

unsigned Hash::combineHashes(unsigned h1, unsigned h2){
  CALL("Hash::combineHashes");
  
  
  return (h1* 16777619u) ^ ( h2 + 2166136261u);
}

}

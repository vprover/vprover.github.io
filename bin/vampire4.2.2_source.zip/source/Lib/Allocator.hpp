
/*
 * File Allocator.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#ifndef __Allocator__
#define __Allocator__

#include <cstddef>

#include "Debug/Assertion.hpp"
#include "Debug/Tracer.hpp"

#include "Portability.hpp"

#if VDEBUG
#include <string>
#endif

#define MAKE_CALLS 0

#define USE_PRECISE_CLASS_NAMES 0

#define VPAGE_SIZE 131000


#define MAX_PAGES 40000
#define REQUIRES_PAGE (VPAGE_SIZE/2)
#define MAX_ALLOCATORS 256

#define MAXIMAL_ALLOCATION (static_cast<unsigned long long>(VPAGE_SIZE)*MAX_PAGES)


#if defined(__GNUC__) && !defined(__ICC) && (__GNUC__ > 4 || __GNUC__ == 4 && __GNUC_MINOR__ > 2)
# define ALLOC_SIZE_ATTR __attribute__((malloc, alloc_size(1)))
#else
# define ALLOC_SIZE_ATTR
#endif



namespace Lib {

class Allocator {
public:
  Allocator();
  ~Allocator();
  
 
  static size_t getUsedMemory()
  {
    CALLC("Allocator::getUsedMemory",MAKE_CALLS);
    return _usedMemory;
  }
 
  static size_t getMemoryLimit()
  {
    CALLC("Allocator::getMemoryLimit",MAKE_CALLS);
    return _memoryLimit;
  }
 
  static void setMemoryLimit(size_t size)
  {
    CALLC("Allocator::setMemoryLimit",MAKE_CALLS);
    _memoryLimit = size;
    _tolerated = size + (size/10);
  }
 
  static Allocator* current;

#if VDEBUG
  void* allocateKnown(size_t size,const char* className) ALLOC_SIZE_ATTR;
  void deallocateKnown(void* obj,size_t size,const char* className);
  void* allocateUnknown(size_t size,const char* className) ALLOC_SIZE_ATTR;
  void* reallocateUnknown(void* obj, size_t newsize,const char* className);
  void deallocateUnknown(void* obj,const char* className);
  static void addressStatus(const void* address);
  static void reportUsageByClasses();
#else
  void* allocateKnown(size_t size) ALLOC_SIZE_ATTR;
  void deallocateKnown(void* obj,size_t size);
  void* allocateUnknown(size_t size) ALLOC_SIZE_ATTR;
  void* reallocateUnknown(void* obj, size_t newsize);
  void deallocateUnknown(void* obj);
#endif

  class Initialiser {
  public:
   
    Initialiser()
    {
      CALLC("Allocator::Initialiser::Initialiser",MAKE_CALLS);

      if (Allocator::_initialised++ == 0) {
	Allocator::initialise();
      }
    } 

    ~Initialiser()
    {
      CALLC("Allocator::Initialiser::~Initialiser",MAKE_CALLS);
      if (--Allocator::_initialised == 0) {
	Allocator::cleanup();
      }
    }
  }; 

  static Allocator* newAllocator();

private:
  char* allocatePiece(size_t size);
  static void initialise();
  static void cleanup();
 
  static Allocator* _all[MAX_ALLOCATORS];
 
  static int _total;
 
  static int _initialised;

 
  struct Known {
   
    Known* next;
  }; 

 
  struct Unknown {
   
    size_t size;
   
    Unknown* next;
  }; 

  static size_t unknownsSize(void* obj) {
    ASS_LE(sizeof(size_t), sizeof(Known)); 

    char* mem = reinterpret_cast<char*>(obj) - sizeof(Known);
    Unknown* unknown = reinterpret_cast<Unknown*>(mem);
    return unknown->size - sizeof(Known);
  }

#if VDEBUG
public:
 
  struct EnableBypassChecking {
    unsigned _save;
    EnableBypassChecking() { _save = _tolerantZone; _tolerantZone = 0; }
    ~EnableBypassChecking() { _tolerantZone = _save; }
  };

   
  struct AllowBypassing {
    AllowBypassing() { _tolerantZone++; }
    ~AllowBypassing() { _tolerantZone--; }
  };
  
 
  struct Descriptor
  {
   
    const void* address;
   
    const char* cls;
   
    unsigned timestamp;
   
    unsigned size;
   
    unsigned allocated : 1;
   
    unsigned known : 1;
   
    unsigned page : 1;
    Descriptor();

    friend std::ostream& operator<<(std::ostream& out, const Descriptor& d);

    static unsigned hash (const void* addr);
    static Descriptor* find(const void* addr);
   
    static Descriptor* map;
   
    static unsigned globalTimestamp;
   
    static size_t noOfEntries;
   
    static size_t maxEntries;
   
    static Descriptor* afterLast;
   
    static size_t capacity;
  };
#endif

private:
 
  struct Page {
   
    Page* next;
   
    Page* previous;
   
    size_t size;    
   
    void* content[1];
  }; 

  Page* allocatePages(size_t size);
  void deallocatePages(Page* page);

 
  static size_t _memoryLimit;
 
  static size_t _tolerated;

  
 
  Known* _freeList[REQUIRES_PAGE/4];
 
  Page* _myPages;
 
  size_t _reserveBytesAvailable;
 
  char* _nextAvailableReserve;

 
  static size_t _usedMemory;
 
  static Page* _pages[MAX_PAGES];

  friend class Initialiser;
  
#if VDEBUG  
 
  static unsigned _tolerantZone;  
  friend void* ::operator new(size_t);
  friend void* ::operator new[](size_t);
  friend void ::operator delete(void*) noexcept;
  friend void ::operator delete[](void*) noexcept;
#endif
}; 

static Allocator::Initialiser _____;

template<typename T>
T* array_new(void* placement, size_t length)
{
  CALLC("array_new",MAKE_CALLS);
  ASS_NEQ(placement,0);
  ASS_G(length,0);

  T* res=static_cast<T*>(placement);
  T* p=res;
  while(length--) {
    ::new(static_cast<void*>(p++)) T();
  }
  return res;
} 

template<typename T>
void array_delete(T* array, size_t length)
{
  CALLC("array_delete",MAKE_CALLS);
  ASS_NEQ(array,0);
  ASS_G(length,0);

  array+=length;
  while(length--) {
    (--array)->~T();
  }
}

#define DECLARE_PLACEMENT_NEW                                           \
  void* operator new (size_t, void* buffer) { return buffer; } 		\
  void operator delete (void*, void*) {}


#if VDEBUG

std::ostream& operator<<(std::ostream& out, const Allocator::Descriptor& d);

#define USE_ALLOCATOR_UNK                                            \
  void* operator new (size_t sz)                                       \
  { return Lib::Allocator::current->allocateUnknown(sz,className()); } \
  void operator delete (void* obj)                                  \
  { if (obj) Lib::Allocator::current->deallocateUnknown(obj,className()); }
#define USE_ALLOCATOR(C)                                            \
  void* operator new (size_t sz)                                       \
  { ASS_EQ(sz,sizeof(C)); return Lib::Allocator::current->allocateKnown(sizeof(C),className()); } \
  void operator delete (void* obj)                                  \
  { if (obj) Lib::Allocator::current->deallocateKnown(obj,sizeof(C),className()); }
#define USE_ALLOCATOR_ARRAY \
  void* operator new[] (size_t sz)                                       \
  { return Lib::Allocator::current->allocateUnknown(sz,className()); } \
  void operator delete[] (void* obj)                                  \
  { if (obj) Lib::Allocator::current->deallocateUnknown(obj,className()); }


#if USE_PRECISE_CLASS_NAMES
#  if defined(__GNUC__)

     std::string ___prettyFunToClassName(std::string str);

#    define CLASS_NAME(C) \
       static const char* className () { \
	  static std::string res = ___prettyFunToClassName(std::string(__PRETTY_FUNCTION__)); return res.c_str(); }
#  else
#    define CLASS_NAME(C) \
       static const char* className () { return typeid(C).name(); }
#  endif
#else
#  define CLASS_NAME(C) \
    static const char* className () { return #C; }
#endif

#define ALLOC_KNOWN(size,className)				\
  (Lib::Allocator::current->allocateKnown(size,className))
#define ALLOC_UNKNOWN(size,className)				\
  (Lib::Allocator::current->allocateUnknown(size,className))
#define DEALLOC_KNOWN(obj,size,className)		        \
  (Lib::Allocator::current->deallocateKnown(obj,size,className))
#define REALLOC_UNKNOWN(obj,newsize,className)                    \
    (Lib::Allocator::current->reallocateUnknown(obj,newsize,className))
#define DEALLOC_UNKNOWN(obj,className)		                \
  (Lib::Allocator::current->deallocateUnknown(obj,className))
         
#define BYPASSING_ALLOCATOR_(SEED) Allocator::AllowBypassing _tmpBypass_##SEED;
#define BYPASSING_ALLOCATOR BYPASSING_ALLOCATOR_(__LINE__)

#define START_CHECKING_FOR_BYPASSES(SEED) Allocator::EnableBypassChecking _tmpBypass_##SEED;
#define START_CHECKING_FOR_ALLOCATOR_BYPASSES START_CHECKING_FOR_BYPASSES(__LINE__)
     
#else

#define CLASS_NAME(name)
#define ALLOC_KNOWN(size,className)				\
  (Lib::Allocator::current->allocateKnown(size))
#define DEALLOC_KNOWN(obj,size,className)		        \
  (Lib::Allocator::current->deallocateKnown(obj,size))
#define USE_ALLOCATOR_UNK                                            \
  inline void* operator new (size_t sz)                                       \
  { return Lib::Allocator::current->allocateUnknown(sz); } \
  inline void operator delete (void* obj)                                  \
  { if (obj) Lib::Allocator::current->deallocateUnknown(obj); }
#define USE_ALLOCATOR(C)                                        \
  inline void* operator new (size_t)                                   \
    { return Lib::Allocator::current->allocateKnown(sizeof(C)); }\
  inline void operator delete (void* obj)                               \
   { if (obj) Lib::Allocator::current->deallocateKnown(obj,sizeof(C)); }
#define USE_ALLOCATOR_ARRAY                                            \
  inline void* operator new[] (size_t sz)                                       \
  { return Lib::Allocator::current->allocateUnknown(sz); } \
  inline void operator delete[] (void* obj)                                  \
  { if (obj) Lib::Allocator::current->deallocateUnknown(obj); }          
#define ALLOC_UNKNOWN(size,className)				\
  (Lib::Allocator::current->allocateUnknown(size))
#define REALLOC_UNKNOWN(obj,newsize,className)                    \
    (Lib::Allocator::current->reallocateUnknown(obj,newsize))
#define DEALLOC_UNKNOWN(obj,className)		         \
  (Lib::Allocator::current->deallocateUnknown(obj))

#define START_CHECKING_FOR_ALLOCATOR_BYPASSES
#define BYPASSING_ALLOCATOR
     
#endif

} 

#undef ALLOC_SIZE_ATTR

#endif 

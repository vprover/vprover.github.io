
/*
 * File LastCopyWatcher.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#ifndef __LastCopyWatcher__
#define __LastCopyWatcher__

#include "Debug/Assertion.hpp"

namespace Lib {

class LastCopyWatcher
{
public:
  LastCopyWatcher()
  {
    _next=_previous=this;
  }
  LastCopyWatcher(const LastCopyWatcher& obj)
  {
    connect(&obj);
  }
  ~LastCopyWatcher()
  {
    disconnect();
  }
  LastCopyWatcher& operator=(const LastCopyWatcher& obj)
  {
    disconnect();
    connect(&obj);
    return *this;
  }
  bool isLast()
  {
    return this==_next;
  }
private:
  void disconnect()
  {
    _next->_previous=_previous;
    _previous->_next=_next;
  }

  void connect(const LastCopyWatcher* obj)
  {
    ASS_EQ(obj->_next->_previous, obj);

    _next=obj->_next;
    _previous=obj;

    _next->_previous=this;
    obj->_next=this;
  }

  mutable const LastCopyWatcher* _next;
  mutable const LastCopyWatcher* _previous;
};

};

#endif

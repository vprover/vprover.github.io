
/*
 * File Deque.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Deque__
#define __Deque__

#include "Forwards.hpp"

#include "Debug/Assertion.hpp"
#include "Debug/Tracer.hpp"

#include "Allocator.hpp"
#include "Reflection.hpp"

namespace Lib {

template<class C>
class Deque
{
private:
  
  Deque(const Deque&);
  Deque& operator=(const Deque&);
public:
  class Iterator;

  DECL_ELEMENT_TYPE(C);
  DECL_ITERATOR_TYPE(Iterator);

 
  inline
  explicit Deque (size_t initialCapacity=8)
    : _capacity(initialCapacity)
  {
    CALL("Deque::Deque");
    ASS_G(initialCapacity,1);

    void* mem = ALLOC_KNOWN(_capacity*sizeof(C),"Deque<>");
    _data = static_cast<C*>(mem);
    _front = _data;
    _back = _data;
    _end = _data+_capacity;
  }

 
  inline ~Deque()
  {
    CALL("Stack::~Stack");

    C* p=_back;
    while(p!=_front) {
      if(p==_data) {
	p=_end;
      }
      (--p)->~C();
    }
    DEALLOC_KNOWN(_data,_capacity*sizeof(C),"Deque<>");
  }

 
  inline
  C& operator[](size_t n)
  {
    ASS_L(n, size());

    C* ptr=_front+n;
    if(ptr>=_end) {
      ptr-=_capacity;
    }

    return *ptr;
  }

 
  inline
  const C& operator[](size_t n) const
  {
    return const_cast<Deque&>(*this)[n];
  }

 
  inline
  C& front() const
  {
    ASS(_front >= _data);
    ASS(_front < _end);

    return *_front;
  }

 
  inline
  void setFront(C elem)
  {
    CALL("Deuqe::setFront");

    front() = elem;
  }

 
  inline
  bool isEmpty() const
  {
    return _front == _back;
  } 

 
  inline
  bool isNonEmpty() const
  {
    return _front != _back;
  } 

 
  inline
  void push_back(C elem)
  {
    CALL("Deque::push_back");

    if(shouldExpand()) {
      expand();
    }
    ASS(_back < _end);
    new(_back) C(elem);

    _back++;
    if(_back==_end) {
      _back=_data;
    }
    ASS_NEQ(_front, _back);
  }

 
  inline
  void push_front(C elem)
  {
    CALL("Deque::push_front");

    if(shouldExpand()) {
      expand();
    }

    if(_front==_data) {
      _front=_end;
    }
    _front--;

    new(_front) C(elem);

    ASS_NEQ(_front, _back);
  }

 
  inline
  C pop_front()
  {
    CALL("Deque::pop_front");
    ASS(isNonEmpty());

    C res=*_front;
    _front->~C();

    _front++;
    if(_front==_end) {
      _front=_data;
    }

    return res;
  }

  
  inline
  C& back() const
  {
    CALL("Deque::back");
    ASS(isNonEmpty());

    C* res = _back;
    if(res==_data) {
      res=_end;
    }
    res--;
    return *res;
  }

  
 
  inline
  C pop_back()
  {
    CALL("Deque::pop_back");
    ASS(isNonEmpty());

    if(_back==_data) {
      _back=_end;
    }
    _back--;

    C res=*_back;
    _back->~C();

    return res;
  }


 
  inline
  void reset()
  {
    C* p=_back;
    while(p!=_front) {
      if(p==_data) {
	p=_end;
      }
      (--p)->~C();
    }

    _front = _data;
    _back = _data;
  }

 
  template<class It>
  void pushBackFromIterator(It it) {
    CALL("Deque::pushBackFromIterator");

    while(it.hasNext()) {
      push_back(it.next());
    }
  }

  
  template<class It>
  void pushFrontFromIterator(It it) {
    CALL("Deque::pushFrontFromIterator");

    while(it.hasNext()) {
      push_front(it.next());
    }
  }

 
  inline
  size_t size() const
  {
    if(_front>_back) {
      return (_back+_capacity) - _front;
    }
    return _back - _front;
  }

  friend class Iterator;

 
  class Iterator {
  public:
    DECL_ELEMENT_TYPE(C);
   
    inline
    explicit Iterator (Deque& d)
      : _pointer(d._front), _begin(d._data), _end(d._end), _afterLast(d._back)
    {
    }

   
    inline
    bool hasNext() const
    {
      return _pointer != _afterLast;
    }

   
    inline
    C next()
    {
      ASS(hasNext());
      C res=*_pointer;
      _pointer++;
      if(_pointer==_end) {
	_pointer=_begin;
      }
      return res;
    }

  private:
    C* _pointer;
    C* _begin;
    C* _end;
    C* _afterLast;
  };
  
   
  class FrontToBackIterator {
  public:
    DECL_ELEMENT_TYPE(C);
   
    inline
    explicit FrontToBackIterator (Deque& d)
      : _pointer(d._front), _begin(d._data), _end(d._end), _afterLast(d._back)
    {
    }

   
    inline
    bool hasNext() const
    {
      return _pointer != _afterLast;
    }

   
    inline
    const C& next()
    {
      ASS(hasNext());
      C* res=_pointer;
      _pointer++;
      if(_pointer==_end) {
	_pointer=_begin;
      }
      return *res;
    }

  private:
    C* _pointer;
    C* _begin;
    C* _end;
    C* _afterLast;
  };

 
  class BackToFrontIterator {
  public:
    DECL_ELEMENT_TYPE(C);
   
    inline
    explicit BackToFrontIterator (Deque& d)
      : _pointer(d._back), _begin(d._data), _end(d._end), _last(d._front)
    {
    }

   
    inline
    bool hasNext() const
    {
      return _pointer != _last;
    }

   
    inline
    const C& next()
    {
      ASS(hasNext());
      if(_pointer==_begin) {
	_pointer=_end;
      }
      _pointer--;
      return *_pointer;
    }

  private:
    C* _pointer;
    C* _begin;
    C* _end;
    C* _last;
  };


protected:
 
  size_t _capacity;
 
  C* _data;
 
  C* _front;
 
  C* _back;
 
  C* _end;

  bool shouldExpand()
  {
    return _back==_front-1 || (_front==_data && _back==_end-1);
  }

 
  void expand ()
  {
    CALL("Deque::expand");

    ASS(shouldExpand());

    size_t curSize=size();
    size_t newCapacity = 2 * _capacity;

    
    void* mem = ALLOC_KNOWN(newCapacity*sizeof(C),"Deque<>");

    C* newData = static_cast<C*>(mem);
    C* oldPtr=_front;
    for(size_t i = 0; i<curSize; i++) {
      new(newData+i) C(*oldPtr);
      oldPtr->~C();

      oldPtr++;
      if(oldPtr==_end) {
	oldPtr=_data;
      }
    }
    ASS_EQ(oldPtr, _back);
    
    DEALLOC_KNOWN(_data,_capacity*sizeof(C),"Deque<>");

    _data = newData;
    _front = _data;
    _back = _data + curSize;
    _end = _data + newCapacity;
    _capacity = newCapacity;
  }

};

}

#endif 

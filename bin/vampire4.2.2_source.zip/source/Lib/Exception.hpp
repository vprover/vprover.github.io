
/*
 * File Exception.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Exception__
#define __Exception__

#include <iostream>

#include "LastCopyWatcher.hpp"
#include "VString.hpp"

namespace Lib {

using namespace std;

class ThrowableBase
{
};

class Exception : public ThrowableBase
{
public:
 
  explicit Exception (const char* msg)
    : _message(msg)
  { s_exceptionCounter++; }
  Exception (const char* msg, int line);
  explicit Exception (const vstring msg)
    : _message(msg)
  { s_exceptionCounter++; }
  virtual void cry (ostream&);
  virtual ~Exception()
  {
    if(_lcw.isLast()) {
      s_exceptionCounter--;
      ASS_GE(s_exceptionCounter,0);
    }
  }

  static bool isThrown() { return s_exceptionCounter!=0; }
  static bool isThrownDuringExceptionHandling() { return s_exceptionCounter>1; }
  vstring msg() { return _message; }
protected:
 
  Exception () { s_exceptionCounter++; }
 
  vstring _message;

  LastCopyWatcher _lcw;

 
  static int s_exceptionCounter;

}; 


class UserErrorException
  : public Exception
{
 public:
  UserErrorException (const char* msg)
    : Exception(msg)
  {}
  UserErrorException (const vstring msg)
    : Exception(msg)
  {}
  void cry (ostream&);
}; 

class ValueNotFoundException
  : public Exception
{
 public:
   ValueNotFoundException ()
    : Exception("")
  {}
}; 

class MemoryLimitExceededException
: public Exception
{
public:



  MemoryLimitExceededException (bool badAlloc=false)
  : Exception(badAlloc?"bad_alloc received":"The memory limit exceeded")
  {}
}; 

class TimeLimitExceededException
: public Exception
{
public:
  TimeLimitExceededException ()
  : Exception("The time limit exceeded")
  {}
}; 

class ActivationLimitExceededException
: public Exception
{
public:
  ActivationLimitExceededException ()
  : Exception("The activation limit exceeded")
  {}
}; 


class InvalidOperationException
  : public Exception
{
 public:
   InvalidOperationException (const char* msg)
    : Exception(msg)
  {}
   InvalidOperationException (const vstring msg)
    : Exception(msg)
  {}
  void cry (ostream&);
}; 

class SystemFailException
  : public Exception
{
public:
  SystemFailException (const vstring msg, int err);
  void cry (ostream&);

  int err;
}; 

class NotImplementedException
  : public Exception
{
 public:
   NotImplementedException (const char* file,int line)
    : Exception(""), file(file), line(line)
  {}
   void cry (ostream&);
 private:
   const char* file;
   int line;
}; 


}

#define VAMPIRE_EXCEPTION \
  throw Lib::Exception(__FILE__,__LINE__)
#define USER_ERROR(msg) \
  throw Lib::UserErrorException(msg)
#define INVALID_OPERATION(msg) \
  throw Lib::InvalidOperationException(msg)
#define SYSTEM_FAIL(msg,err) \
  throw Lib::SystemFailException(msg,err)
#define NOT_IMPLEMENTED \
  throw Lib::NotImplementedException(__FILE__, __LINE__)

#endif 




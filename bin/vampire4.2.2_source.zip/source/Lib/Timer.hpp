
/*
 * File Timer.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Timer__
#define __Timer__

#include <iostream>

#include "Debug/Assertion.hpp"
#include "Forwards.hpp"               
#include "Allocator.hpp"
#include "VString.hpp"

#ifndef UNIX_USE_SIGALRM


#define UNIX_USE_SIGALRM 1 
#endif


#ifdef VAPI_LIBRARY
#if VAPI_LIBRARY

#undef UNIX_USE_SIGALRM
#define UNIX_USE_SIGALRM 0

#endif
#endif

namespace Lib
{

using namespace std;

class Timer
{
  Timer(bool mustIncludeChildren=false)
    :
    _mustIncludeChildren(mustIncludeChildren),
    _running(false),
    _elapsed(0)
  { (void)_mustIncludeChildren; 
    ensureTimerInitialized(); }

  ~Timer() { deinitializeTimer(); }
  friend void ::checked_delete<Timer>(Timer*);
  
public:
  CLASS_NAME(Timer);
  USE_ALLOCATOR(Timer);

  static Timer* instance();
  
 
  inline void reset()
  { _running = false;
    _elapsed = 0; }

 
  inline void stop()
  {
    ASS(_running);

    _elapsed += miliseconds() - _start;
    _running = false;
  }

 
  inline void start()
  {
    ASS(! _running);

    _running = true;
    _start = miliseconds();
  } 

 
  int elapsedSeconds()
  {
    return elapsed()/1000;
  }

 
  int elapsedDeciseconds()
  {
    return elapsed()/100;
  }

 
  int elapsedMilliseconds()
  {
    return elapsed();
  }

  void makeChildrenIncluded();

  static void ensureTimerInitialized();
  static void deinitializeTimer();
  static vstring msToSecondsString(int ms);
  static void printMSString(ostream& str, int ms);

  static void setTimeLimitEnforcement(bool enabled)
  { s_timeLimitEnforcement = enabled; }

  static void syncClock();

  static bool s_timeLimitEnforcement;
private:
 
  bool _mustIncludeChildren;
 
  bool _running;
 
  int _start;
 
  int _elapsed;

  int miliseconds();

#if UNIX_USE_SIGALRM
  static void suspendTimerBeforeFork();
  static void restoreTimerAfterFork();

  static int guaranteedMilliseconds();

  static long s_ticksPerSec;
  static int s_initGuarantedMiliseconds;
#endif

 
  inline
  int elapsed()
  {
    return _running ? miliseconds() - _start + _elapsed : _elapsed;
  }
}; 

} 

#endif

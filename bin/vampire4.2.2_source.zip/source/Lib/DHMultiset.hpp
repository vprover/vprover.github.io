
/*
 * File DHMultiset.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __DHMultiset__
#define __DHMultiset__

#include <cstdlib>
#include <algorithm>

#include "Debug/Assertion.hpp"
#include "Allocator.hpp"
#include "Exception.hpp"
#include "Hash.hpp"
#include "DHMap.hpp"
#include "Portability.hpp"

namespace Lib {

#define DHMULTISET_MAX_CAPACITY_INDEX DHMAP_MAX_CAPACITY_INDEX
#define DHMULTISET_MAX_MULTIPLICITY 0x3FFFFFFFu
#define DHMULTISET_FILL_UP_COEFFICIENT 0.7f


template <typename Val, class Hash1=Hash, class Hash2=Hash>
class DHMultiset
{
public:
  CLASS_NAME(DHMultiset);
  USE_ALLOCATOR(DHMultiset);
  
 
  DHMultiset()
  : _size(0), _multiplicities(0), _deleted(0), _capacityIndex(0), _capacity(0),
  _nextExpansionOccupancy(0), _entries(0), _afterLast(0)
  {
    ensureExpanded();
  }

 
  ~DHMultiset()
  {
    if(_entries) {
      array_delete(_entries, _capacity);
      DEALLOC_KNOWN(_entries,_capacity*sizeof(Entry),"DHMultiset::Entry");
    }
  }

 
  inline
  bool find(Val val) const
  {
    CALL("DHMultiset::find/1");
    const Entry* e=findEntry(val);
    return e;
  }

 
  inline
  unsigned multiplicity(Val val) const
  {
    CALL("DHMultiset::find/1");
    const Entry* e=findEntry(val);
    return e ? e->_info.multiplicity : 0;
  }

 
  inline
  int insert(Val val)
  {
    return insert(val,1);
  }

 
  int insert(Val val, int multiplicity)
  {
    CALL("DHMultiset::insert");
    ASS(multiplicity>0 && ((unsigned)multiplicity)<DHMULTISET_MAX_MULTIPLICITY);

    ensureExpanded();
    Entry* e=findEntryToInsert(val);
    bool exists = e->_info.multiplicity;
    if(exists) {
      ASS(e->_info.multiplicity+(unsigned)multiplicity<DHMULTISET_MAX_MULTIPLICITY);
      e->_info.multiplicity+=multiplicity;
      _multiplicities+=multiplicity;
    } else {
      ASS_EQ(e->_info.multiplicity, 0);
      e->_info.multiplicity=multiplicity;
      _multiplicities+=multiplicity-1;
      if(e->_info.deleted) {
	e->_info.deleted=0;
	_deleted--;
      }
      e->_val=val;
      _size++;
    }
    return e->_info.multiplicity;
  }

 
  bool remove(Val val)
  {
    CALL("DHMultiset::remove");
    Entry* e=findEntry(val);
    if(!e) {
      return false;
    }
    ASS(e->_info.multiplicity>0);
    e->_info.multiplicity--;
    if(e->_info.multiplicity==0) {
      e->_info.deleted=1;
      _size--;
      _deleted++;
    } else {
      _multiplicities--;
    }
    return true;
  }

 
  unsigned getMultiplicityAndRemove(Val val)
  {
    CALL("DHMultiset::getMultiplicityAndRemove");
    Entry* e=findEntry(val);
    if(!e) {
      return 0;
    }
    ASS(e->_info.multiplicity>0);
    e->_info.multiplicity--;
    if(e->_info.multiplicity==0) {
      e->_info.deleted=1;
      _size--;
      _deleted++;
    } else {
      _multiplicities--;
    }
    return e->_info.multiplicity+1;
  }


 
  inline
  int size() const
  {
    ASS(_size>=0);
    return _size+_multiplicities;
  }

 
  inline
  bool isEmpty() const
  {
    ASS(_size>=0);
    return _size==0;
  }

 
  Val getOneValue()
  {
    Iterator it(*this);
    ALWAYS(it.hasNext());
    return it.next();
  }

private:
  struct Entry
  {
   
    inline
    Entry() : _infoData(0) {}
   
    inline
    bool isEmpty() { return !_infoData; }
    union {
      struct {

	unsigned collision : 1;
	unsigned deleted : 1;
	unsigned multiplicity : 30;
      } _info;
      int32_t _infoData;
    };
    Val _val;
  };

 
  DHMultiset(const DHMultiset& obj);
 
  DHMultiset& operator=(const DHMultiset& obj);


 
  inline
  void ensureExpanded()
  {
    if(_size+_deleted>=_nextExpansionOccupancy) {
      expand();
    }
  }

 
  void expand()
  {
    CALL("DHMultiset::expand");

    if(_capacityIndex>=DHMULTISET_MAX_CAPACITY_INDEX) {
      throw Exception("Lib::DHMultiset::expand: MaxCapacityIndex reached.");
    }

    int newCapacity=DHMapTableCapacities[_capacityIndex+1];
    void* mem = ALLOC_KNOWN(newCapacity*sizeof(Entry),"DHMultiset::Entry");

    Entry* oldEntries=_entries;
    Entry* oldAfterLast=_afterLast;
    int oldCapacity=_capacity;

    _size=0;
    _multiplicities=0;
    _deleted=0;
    _capacityIndex++;
    _capacity = newCapacity;
    _nextExpansionOccupancy = DHMapTableNextExpansions[_capacityIndex];

    _entries = array_new<Entry>(mem, _capacity);
    _afterLast = _entries + _capacity;

    Entry* ep=oldEntries;
    while(ep!=oldAfterLast) {
      if(ep->_info.multiplicity) {
	insert(ep->_val, ep->_info.multiplicity);
      }
      (ep++)->~Entry();
    }

    if(oldCapacity) {
      DEALLOC_KNOWN(oldEntries,oldCapacity*sizeof(Entry),"DHMultiset::Entry");
    }
  }

 
  inline
  Entry* findEntry(Val val)
  {
    return const_cast<Entry*>(static_cast<const DHMultiset*>(this)->findEntry(val));
  }

 
  const Entry* findEntry(Val val) const
  {
    CALL("DHMultiset::findEntry");
    ASS(_capacity>_size+_deleted);

    unsigned h1=computeHash<Hash1>(val, _capacity);
    int pos=h1%_capacity;
    Entry* res=&_entries[pos];
    if(res->isEmpty()) {
      return 0;
    }
    if(res->_val==val) {
      return res->_info.deleted ? 0 : res;
    }

    

    if(!res->_info.collision) {
      
      
      return 0;
    }

    unsigned h2=Hash2::hash(val)%_capacity;
    if(h2==0) {
      h2=1;
    }
    do {
      pos=(pos+h2)%_capacity;
      res=&_entries[pos];
    } while (!res->isEmpty() && res->_val!=val);

    if(res->isEmpty()) {
      return 0;
    }

    ASS(res->_val==val);
    return res->_info.deleted ? 0 : res;
  }

 
  Entry* findEntryToInsert(Val val)
  {
    CALL("DHMultiset::findEntryToInsert");
    ASS(_capacity>_size+_deleted);

    unsigned h1=computeHash<Hash1>(val, _capacity);
    int pos=h1%_capacity;
    Entry* res=&_entries[pos];
    if( (res->_info.multiplicity==0 && res->_info.collision==0) || res->_val==val) {
      return res;
    }

    

    bool collisionBefore=res->_info.collision;

    
    res->_info.collision=1;

    unsigned h2=Hash2::hash(val)%_capacity;
    if(h2==0) {
      h2=1;
    }

    if(collisionBefore) {
      Entry* available=0;
      do {
        pos=(pos+h2)%_capacity;
        res=&_entries[pos];
        if(!available && res->_info.multiplicity==0) {
          available=res;
        }
      } while (!res->isEmpty() && res->_val!=val );
      if(res->isEmpty()) {
	
	
	
	res=available;
      }
    } else {
      
      do {
        pos=(pos+h2)%_capacity;
        res=&_entries[pos];
      } while (res->_info.multiplicity!=0);
    }

    return res;
  }


 
  int _size;
 
  int _multiplicities;
 
  int _deleted;
 
  int _capacityIndex;
 
  int _capacity;
 
  int _nextExpansionOccupancy;

 
  Entry* _entries;
 
  Entry* _afterLast;

public:

#if VDEBUG
  void assertValid()
  {
    int sz=size();
    int cnt=0;
    Iterator it(*this);
    while(it.hasNext()) {
      cnt++;
      it.next();
    }
    ASS_EQ(sz,cnt);
  }
#endif

 
  class SetIterator {
  public:
   
    inline SetIterator(const DHMultiset& set)
    : _next(set._entries), _afterLast(set._afterLast)
    {
    }

   
    bool hasNext()
    {
      CALL("DHMultiset::SetIterator::hasNext");
      while (_next != _afterLast) {
	
	
	if (_next->_info.multiplicity) {
	  return true;
	}
	_next++;
      }
      return false;
    }

   
    inline
    Val next()
    {
      CALL("DHMultiset::SetIterator::next");
      ASS_NEQ(_next, _afterLast);

      return (_next++)->_val;
    }

   
    inline
    Val next(unsigned& multiplicity)
    {
      CALL("DHMultiset::SetIterator::next/1");
      ASS_NEQ(_next, _afterLast);

      multiplicity=_next->multiplicity;
      return (_next++)->_val;
    }

  private:
   
    Entry* _next;
   
    Entry* _afterLast;
  };

 
  class Iterator {
  public:
   
    inline Iterator(const DHMultiset& set)
    : _next(set._entries), _afterLast(set._afterLast), _nextIndex(0)
    {
    }

   
    bool hasNext()
    {
      CALL("DHMultiset::Iterator::hasNext");
      if(_next->_info.multiplicity > _nextIndex)
	return true;
      _nextIndex=0;
      _next++;
      while (_next != _afterLast) {
	
	
	if (_next->_info.multiplicity) {
	  return true;
	}
	_next++;
      }
      return false;
    }

   
    inline
    Val next()
    {
      CALL("DHMultiset::Iterator::next");
      ASS(_next != _afterLast);
      ASS(_next->_info.multiplicity > _nextIndex);
      _nextIndex++;
      return _next->_val;
    }

  private:
   
    Entry* _next;
   
    Entry* _afterLast;
   
    unsigned _nextIndex;
  }; 


}; 

}

#endif 


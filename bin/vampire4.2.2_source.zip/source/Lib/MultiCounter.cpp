
/*
 * File MultiCounter.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Debug/Tracer.hpp"

#include "MultiCounter.hpp"
#include "Int.hpp"
#include "Allocator.hpp"
#include "XML.hpp"
#include "Exception.hpp"

using namespace Lib;

void MultiCounter::expandToFit (int v)
{
  CALL("MultiCounter::expandToFit");

  
  int newTop = max(_top*2,v+1);

  
  void* mem = ALLOC_KNOWN(newTop*sizeof(int),"MultiCounter");
  int* newCounts = array_new<int>(mem, newTop);
  
  for (int i = 0;i < _top;i++) {
    newCounts[i] = _counts[i];
  }
  for (int k = _top;k < newTop;k++) {
    newCounts[k] = 0;
  }
  if (_counts) {
    array_delete(_counts,_top);
    DEALLOC_KNOWN(_counts,_top*sizeof(int),"MultiCounter");
  }
  _counts = newCounts;
  _top = newTop;
} 


MultiCounter::~MultiCounter()
{
  if (_counts) {
    array_delete(_counts, _top);
    DEALLOC_KNOWN(_counts,_top*sizeof(int),"MultiCounter");
  }
} 


#if VDEBUG

















#endif

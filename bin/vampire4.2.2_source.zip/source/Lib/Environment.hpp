
/*
 * File Environment.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Environment__
#define __Environment__

#include <iostream>

#include "Forwards.hpp"
#include "Exception.hpp"
#include "DHMap.hpp"

namespace Lib {

using namespace std;
using namespace Sys;

class Environment
{
public:
  Environment();
  ~Environment();

 
  Shell::Options* options;
 
  Kernel::Sorts* sorts;
 
  Kernel::Signature* signature;
 
  Indexing::TermSharing* sharing;
 
  Shell::Statistics* statistics;
 
  Shell::Property* property;
 
  Timer* timer;

  DHMap<const Kernel::Unit*,unsigned>* clausePriorities;
  unsigned maxClausePriority;

  bool haveOutput();
  void beginOutput();
  void endOutput();
  ostream& out();

  void setPipeOutput(SyncPipe* pipe);
  SyncPipe* getOutputPipe() { return _pipe; }

  void setPriorityOutput(ostream* stm);
  ostream* getPriorityOutput() { return _priorityOutput; }

  bool timeLimitReached() const;

  template<int Period>
  void checkTimeSometime() const
  {
    static int counter=0;
    counter++;
    if(counter==Period) {
      counter=0;
      if(timeLimitReached()) {
        throw TimeLimitExceededException();
      }
    }
  }
 
  int remainingTime() const;
 
  bool colorUsed;
 
  bool interpretedOperationsUsed;

private:
  int _outputDepth;
 
  ostream* _priorityOutput;
  SyncPipe* _pipe;
}; 

extern Environment env;

}

#endif





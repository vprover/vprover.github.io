
/*
 * File Int.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include <cstdio>
#include <cstdlib>
#include <cerrno>
#include <iostream>
#include <climits>

#include "Int.hpp"
#include "Debug/Tracer.hpp"

using namespace Lib;

vstring Int::toString (int i)
{
  char tmp [20];
  sprintf(tmp,"%d",i);
  vstring result(tmp);

  return result;
} 


vstring Int::toString(double d)
{
  char tmp [256];
  sprintf(tmp,"%g",d);
  vstring result(tmp);

  return result;
} 


vstring Int::toString(long l)
{
  char tmp [256];
  sprintf(tmp,"%ld",l);
  vstring result(tmp);

  return result;
} 


vstring Int::toString(unsigned i)
{
  char tmp [256];
  sprintf(tmp,"%d",i);
  vstring result(tmp);

  return result;
} 

vstring Int::toString(unsigned long i)
{
  char tmp [256];
  sprintf(tmp,"%lu",i);
  vstring result(tmp);

  return result;
} 

vstring Int::toHexString(size_t i)
{
  char tmp [256];
  sprintf(tmp,"0x%zx",i);
  vstring result(tmp);

  return result;
} 


bool Int::stringToLong (const char* str,long& result)
{
  CALL("Int::stringToLong");

  if (! *str) { 
    return false;
  }

  errno = 0;
  char* endptr = 0;
  result = strtol(str,&endptr,10);

  if (*endptr ||
      (result == 0 && errno) ||
      ( (result == LONG_MAX || result == LONG_MIN) && errno==ERANGE ) ) { 
    return false;
  }

  return true;
} 


bool Int::stringToInt (const vstring& str,int& result)
{
  CALL("Int::stringToInt");
  return stringToInt(str.c_str(),result);
} 

bool Int::stringToUnsignedInt (const vstring& str,unsigned& result)
{
  CALL("Int::stringToUnsignedInt");
  return stringToUnsignedInt(str.c_str(),result);
} 

bool Int::stringToUnsignedInt (const char* str,unsigned& result)
{
  CALL("Int::stringToUnsignedInt");

  int i;
  if (stringToInt(str,i) && i >= 0) {
    result = i;
    return true;
  }
  return false;
} 

bool Int::stringToInt (const char* str,int& result)
{
  long ln;
  bool converted = stringToLong(str,ln);
  if (! converted || ln > INT_MAX || ln < INT_MIN) {
    return false;
  }
  result = (int)ln;
  return true;
} 


bool Int::stringToDouble (const char* str,double& result)
{
  CALL("Int::stringToDouble");

  errno = 0;
  char* endptr = 0;
  result = strtod(str,&endptr);

  if (*endptr ||
      (result == 0.0 && errno)) { 
    return false;
  }

  return true;
} 


bool Int::stringToFloat (const char* str,float& result)
{
  double d;
  bool converted = stringToDouble(str,d);



  if (! converted) {
    return false;
  }
  result = (float)d;
  return true;
} 


bool Int::stringToUnsigned64 (const char* str,long long unsigned& result)
{
  result = 0;
  if (! *str) { 
    return false;
  }
  
  while (*str == '0') {
    str++;
  }
  while (*str) {
    char nextChar = *str;
    str++;
    if (nextChar < '0' || nextChar > '9') {
      return false;
    }
    result = 10*result + (nextChar - '0');
  }
  return true;
} 

bool Int::stringToUnsigned64 (const vstring& str,long long unsigned& result)
{
  return stringToUnsigned64(str.c_str(),result);
} 

bool Int::isInteger(const char* str)
{
  CALL("Int::isInteger");

	if (*str == '-') {
		str++;
	}

	
	if (! *str) {
		return false;
	}

	
	do {
		if (*str < '0' || *str > '9') {
			return false;
		}
		str++;
	}
	while (*str);

	return true;
} 


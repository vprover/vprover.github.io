
/*
 * File XML.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __XML__
#define __XML__

#include <iostream>

#include "VString.hpp"

using namespace std;

namespace Lib {

class XMLAttribute {
public:
 
  enum Type {
    TEXT = 0u,
    LONG = 1u,
    INTEGER = 2u,
    DOUBLE = 3u,
    UNSIGNED = 4u
  };

  class Data;

 
  XMLAttribute() : _data(0) {}
  XMLAttribute(const XMLAttribute& attr);
  XMLAttribute(const vstring& name,const vstring& value);
  XMLAttribute(const vstring& name,int value);
  XMLAttribute(const vstring& name,long value);
  XMLAttribute(const vstring& name,double value);
  XMLAttribute(const vstring& name,unsigned value);
  ~XMLAttribute();
  void operator= (const XMLAttribute& rhs);
  void setNext(const XMLAttribute&);
  void find(const vstring& name,XMLAttribute&) const;
 
  bool isNull() const { return _data == 0; }
  const vstring& name() const;

  
  Type tag () const;
  bool operator == (const XMLAttribute& rhs) const;
  bool operator != (const XMLAttribute& rhs) const;

  
  void* operator new(size_t);

  
  void writeList(ostream&) const;

 
  Data* data() const { return _data; }
 private:
  
  Data* _data;
}; 


class XMLElement {
public:
 
  enum Type {
   
    DEEP = 0u,
   
    EMPTY = 1u,
   
    TEXT = 2u,
   
    INTEGER = 3u,
   
    FLOAT = 4u,
   
    LONG = 5u,
   
    DOUBLE = 6u
  };

  class Data;
  class ChildIterator;

 
  XMLElement() : _data(0) {}
 
  bool isNull() const { return _data == 0; }
  XMLElement(const vstring& name);  
  XMLElement(const vstring& name,bool dummy);  
  XMLElement(const vstring& name,const vstring& text);  
  XMLElement(const vstring& name,int content);         
  XMLElement(const vstring& name,long content);        
  XMLElement(const vstring& name,float content);       
  XMLElement(const vstring& name,double content);
  XMLElement(const XMLElement& elem);
  ~XMLElement();
  void operator= (const XMLElement& rhs);

  void addAttribute(const vstring& name,const vstring& value);
  void addAttribute(const vstring& name,int value);
  void addAttribute(const vstring& name,unsigned value);
  void addAttribute(const vstring& name,long value);
  void addAttribute(const vstring& name,double value);
  void addChild(const XMLElement& element);
  const vstring& name() const;
  const vstring* findStringValue(const vstring& name) const;
  void write(ostream&) const;
  void write(ostream&,int indent) const;
  void append(const vstring& file); 
  void copyAttributes(const XMLElement&);

  
  Type tag() const;
  const vstring& text() const;
  bool operator == (const XMLElement& rhs) const;
  bool operator != (const XMLElement& rhs) const;

  
  void* operator new(size_t);

  static void writeString(ostream& str,const vstring& s);

 
  Data* data() const { return _data; }

  void checkDeep() const;
  void checkEmpty() const;
  void checkText() const;
  bool isEmpty() const;

  XMLElement firstChild() const;
 private:
  
  Data* _data;
}; 


class XMLElement::ChildIterator {
public:
  explicit ChildIterator(const XMLElement&);
  bool hasNext() const;
  XMLElement next();
private:
  XMLElement _next;
};


} 

#endif


/*
 * File Exception.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include <string.h>

#include "Int.hpp"

#include "Exception.hpp"
#include "VString.hpp"

namespace Lib
{

int Exception::s_exceptionCounter=0;

Exception::Exception (const char* msg, int line)
  : _message((vstring(msg)+": "+Int::toString(line)).c_str())
{ s_exceptionCounter++; }

void Exception::cry (ostream& str)
{
  str << _message << endl;
} 


void UserErrorException::cry (ostream& str)
{
  str << "User error: " << _message << endl;
} 

void InvalidOperationException::cry (ostream& str)
{
  str << "Invalid operation: " << _message << endl;
} 


SystemFailException::SystemFailException(const vstring msg, int err)
: Exception(msg+" error "+Int::toString(err)+": "+strerror(err)), err(err)
{



}
void SystemFailException::cry (ostream& str)
{
  str << "System fail: " << _message << endl;
} 


void NotImplementedException::cry (ostream& str)
{
  str << "Not implemented at " << file << ":" << line << endl;
} 


}

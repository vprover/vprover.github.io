
/*
 * File SyncPipe.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Lib/Portability.hpp"

#include <cerrno>
#include <unistd.h>

#include "Lib/Environment.hpp"
#include "Lib/Exception.hpp"
#include "Lib/fdstream.hpp"
#include "Lib/List.hpp"
#include "Lib/System.hpp"

#include "Multiprocessing.hpp"

#include "SyncPipe.hpp"

namespace Lib
{
namespace Sys
{

SyncPipe::PipeList* SyncPipe::s_instances = 0;

SyncPipe::SyncPipe()
: _isReading(false), _isWriting(false), _syncSemaphore(3)
{
  ensureEventHandlersInstalled();

  int fd[2];
  errno=0;
  int res=pipe(fd);
  if(res==-1) {
    SYSTEM_FAIL("Pipe creation.", errno);
  }

  _readDescriptor=fd[0];
  _writeDescriptor=fd[1];

  {
    BYPASSING_ALLOCATOR;
  
    _istream=new fdstream(_readDescriptor);
    _ostream=new fdstream(_writeDescriptor);
  }
  
  _istream->rdbuf()->pubsetbuf(0,0);

  
  _syncSemaphore.set(0,1);
  _syncSemaphore.set(1,1);
  
  _syncSemaphore.set(2,256);

  PipeList::push(this, s_instances);
}

SyncPipe::~SyncPipe()
{
  CALL("SyncPipe::~SyncPipe");

  releasePrivileges();
  ASS(PipeList::member(this, s_instances));
  s_instances = PipeList::remove(this, s_instances);

  if(canRead()) {
    neverRead();
  }
  if(canWrite()) {
    neverWrite();
  }
}

void SyncPipe::acquireRead()
{
  CALL("SyncPipe::acquireRead");
  ASS(canRead());
  ASS(!isReading());
  ASS(!isWriting()); 

  _syncSemaphore.dec(0);

  
  int preRead=_syncSemaphore.get(2);
  if(preRead==256) {
    preRead=-1;
  }
  ASS_LE(preRead,255);
  _istream->setPreReadChar(preRead);

  _isReading=true;
}

void SyncPipe::releaseRead()
{
  CALL("SyncPipe::releaseRead");
  ASS(isReading());

  _isReading=false;

  int preRead=_istream->getPreReadChar();
  if(preRead==-1) {
    preRead=256;
  }
  ASS_GE(preRead,0);
  ASS_LE(preRead,256);
  _syncSemaphore.set(2,preRead);

  _syncSemaphore.inc(0);
}

void SyncPipe::neverRead()
{
  CALL("SyncPipe::neverRead");
  ASS(canRead());  
  ASS(!isReading());

  int res=close(_readDescriptor);
  if(res==-1) {
    SYSTEM_FAIL("Closing read descriptor of a pipe.", errno);
  }
  ASS_EQ(res,0);
  {
    BYPASSING_ALLOCATOR;
  
    delete _istream;
    _istream=0;
  }
}


void SyncPipe::acquireWrite()
{
  CALL("SyncPipe::acquireWrite");
  ASS(canWrite());
  ASS(!isWriting());
  ASS(!isReading()); 

  _syncSemaphore.dec(1);
  _isWriting=true;
}

void SyncPipe::releaseWrite()
{
  CALL("SyncPipe::releaseWrite");
  ASS(isWriting());

  _ostream->flush();
  _isWriting=false;
  _syncSemaphore.inc(1);
}

void SyncPipe::neverWrite()
{
  CALL("SyncPipe::neverWrite");
  ASS(canWrite());  
  ASS(!isWriting());
  ASS(env.getOutputPipe()!=this); 

  int res=close(_writeDescriptor);
  if(res==-1) {
    SYSTEM_FAIL("Closing write descriptor of a pipe.", errno);
  }
  ASS_EQ(res,0);

  {
    BYPASSING_ALLOCATOR;
    
    delete _ostream;
    _ostream=0;
  }
}
void SyncPipe::releasePrivileges()
{
  CALL("SyncPipe::releasePrivileges");
  ASS(_syncSemaphore.hasSemaphore());

  if(isReading()) {
    releaseRead();
  }
  if(isWriting()) {
    releaseWrite();
  }
}

void SyncPipe::postForkChildHadler()
{
  CALL("SyncPipe::postForkChildHadler");

  PipeList::Iterator pit(s_instances);
  while(pit.hasNext()) {
    SyncPipe* p=pit.next();
    p->releasePrivileges();
  }
}

void SyncPipe::terminationHadler()
{
  CALL("SyncPipe::terminationHadler");

  PipeList* listIter=s_instances;
  while(listIter) {
    if(listIter->head()) {
      SyncPipe* p=listIter->head();
      p->releasePrivileges();
      listIter->setHead(0);
    }
    listIter=listIter->tail();
  }
}

void SyncPipe::ensureEventHandlersInstalled()
{
  CALL("SyncPipe::ensureEventHandlersInstalled");

  static bool installed=false;
  if(installed) {
    return;
  }
  Multiprocessing::instance()->registerForkHandlers(0,0,postForkChildHadler);
  
  
  System::addTerminationHandler(terminationHadler,0);
  installed=true;
}


}
}


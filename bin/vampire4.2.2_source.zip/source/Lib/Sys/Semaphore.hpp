
/*
 * File Semaphore.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Semaphore__
#define __Semaphore__

#include <sys/types.h>

#include "Forwards.hpp"

#include "Lib/Portability.hpp"

namespace Lib {
namespace Sys {

class Semaphore
{
public:
  Semaphore() : semid(-1), semCnt(0) {};
  explicit Semaphore(int num);
  ~Semaphore();

  Semaphore(const Semaphore& s);
  const Semaphore& operator=(const Semaphore& s);

  bool hasSemaphore() { return semid!=-1; }

  void inc(int num);
  void incp(int num);
  void dec(int num);
  int get(int num);
  void set(int num, int val);

  bool isLastInstance();

private:

  void doInc(int num);
  void doIncPersistent(int num);
  void doDec(int num);
  void doSet(int num, int val);
  int doGet(int num);

  void registerInstance(bool addToInstanceList=true);
  void deregisterInstance();

  void acquireInstance();
  void releaseInstance();

  int semid;
 
  int semCnt;

  static void releaseAllSemaphores();
  static void postForkInChild();
  static void ensureEventHandlersInstalled();

  typedef List<Semaphore*> SemaphoreList;

  static SemaphoreList* s_instances;

  union semun {
      int              val;   
      struct semid_ds *buf;   
      unsigned short  *array; 
      struct seminfo  *__buf; 
  };
};

}
}

#endif 

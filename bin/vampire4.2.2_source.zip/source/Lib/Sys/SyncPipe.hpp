
/*
 * File SyncPipe.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __SyncPipe__
#define __SyncPipe__

#include <fstream>

#include "Forwards.hpp"

#include "Lib/fdstream.hpp"
#include "Lib/Exception.hpp"
#include "Lib/Portability.hpp"

#include "Semaphore.hpp"

namespace Lib {
namespace Sys {

class SyncPipe {
public:
  SyncPipe();
  ~SyncPipe();

 
  bool isReading() const { return _isReading; }
 
  bool canRead() const { return _istream; }

  void acquireRead();
  void releaseRead();
  void neverRead();

 
  bool isWriting() const { return _isWriting; }
 
  bool canWrite() const { return _ostream; }

  void acquireWrite();
  void releaseWrite();
  void neverWrite();

  void releasePrivileges();

 
  istream& in()
  {
    ASS(_istream);
    ASS(isReading());
    if(!isReading()) {
      INVALID_OPERATION("Unallowed read from pipe.");
    }
    return *_istream;
  }

 
  ostream& out()
  {
    ASS(_ostream);
    ASS(isWriting());
    if(!isWriting()) {
      INVALID_OPERATION("Unallowed write to pipe.");
    }
    return *_ostream;
  }

private:
  SyncPipe(const SyncPipe&); 
  const SyncPipe& operator=(const SyncPipe&); 

 
  fdstream *_istream;
 
  fdstream *_ostream;

  int _readDescriptor;
  int _writeDescriptor;
  bool _isReading;
  bool _isWriting;

 
  Semaphore _syncSemaphore;

  static void postForkChildHadler();
  static void terminationHadler();
  static void ensureEventHandlersInstalled();

  typedef List<SyncPipe*> PipeList;

  static PipeList* s_instances;
};

}
}

#endif 

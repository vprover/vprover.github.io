
/*
 * File Multiprocessing.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Multiprocessing__
#define __Multiprocessing__

#include "Forwards.hpp"
#include <unistd.h>

namespace Lib {
namespace Sys {

class Multiprocessing {
public:
  static Multiprocessing* instance();

  pid_t waitForChildTermination(int& resValue);
  pid_t waitForChildTerminationOrTime(unsigned timeMs,int& resValue);
  void waitForParticularChildTermination(pid_t child, int& resValue);

  pid_t fork();
  void registerForkHandlers(VoidFunc before, VoidFunc afterParent, VoidFunc afterChild);

  void sleep(unsigned ms);
  void kill(pid_t child, int signal);
private:
  Multiprocessing();
  ~Multiprocessing();

  static void executeFuncList(VoidFuncList* lst);

  VoidFuncList* _preFork;
  VoidFuncList* _postForkParent;
  VoidFuncList* _postForkChild;
};

}
}

#endif 

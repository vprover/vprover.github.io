
/*
 * File SafeRecursion.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __SafeRecursion__
#define __SafeRecursion__

#include <algorithm>

#include "Forwards.hpp"

#include "Stack.hpp"

namespace Lib {

template<typename Arg, typename Res, class Worker>
struct SafeRecursion
{
  SafeRecursion(Worker w) : w(w) {}

  Res operator()(Arg obj0)
  {
    ChildCallback callback(*this);

    children.push(obj0);

    for(;;) {

      {
	Arg obj = children.pop();

	size_t prevChildrenSz = children.size();
	w.pre(obj, callback);
	size_t chCnt = children.size() - prevChildrenSz;

	waiting.push(obj);
	childrenCounts.push(chCnt);
	childrenRemaining.push(chCnt);
	ASS_EQ(waiting.size(),childrenCounts.size());
	ASS_EQ(waiting.size(),childrenRemaining.size());
      }

      while(childrenRemaining.top()==0) {
	size_t childCnt = childrenCounts.top();
	
	std::reverse(results.end()-childCnt, results.end());

	
	Res res = w.post(waiting.top(), childCnt, results.end()-childCnt);

	
	results.truncate(results.size()-childCnt);
	
	results.push(res);

	waiting.pop();
	childrenCounts.pop();
	childrenRemaining.pop();

	if(waiting.isEmpty()) {
	  ASS(children.isEmpty());
	  ASS(childrenCounts.isEmpty());
	  ASS(childrenRemaining.isEmpty());
	  ASS_EQ(results.size(),1);
	  return results.pop();
	}

	ASS_NEQ(childrenRemaining.top(), 0);
	childrenRemaining.top()--;
      }
    }
  }
private:
  struct ChildCallback
  {
    ChildCallback(SafeRecursion& parent) : parent(parent) {}
    void operator()(Arg child) {
      parent.children.push(child);
    }
    SafeRecursion& parent;
  };

  Worker w;
  Stack<Arg> children;
  Stack<Arg> waiting;
  Stack<size_t> childrenCounts;
  Stack<size_t> childrenRemaining;
  Stack<Res> results;
};

}

#endif 

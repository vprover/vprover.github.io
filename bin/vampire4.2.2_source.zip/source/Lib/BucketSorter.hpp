
/*
 * File BucketSorter.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#ifndef __BucketSorter__
#define __BucketSorter__

#include "Stack.hpp"

namespace Lib {

template<typename T, class Evaluator>
class BucketSorter
{
public:
 
  BucketSorter(size_t bucketCnt)
  : _bucketCnt(bucketCnt), _size(0), _minOccupied(bucketCnt)
  {
    CALL("BucketSorter::BucketSorter");

    _buckets=static_cast<Stack<T>*>(ALLOC_KNOWN(_bucketCnt*sizeof(Stack<T>), "BucketSorter"));
    for(unsigned i=0;i<_bucketCnt;i++) {
      new (&_buckets[i]) Stack<T>(8);
    }
  }

 
  ~BucketSorter()
  {
    CALL("BucketSorter::~BucketSorter");

    for(unsigned i=0;i<_bucketCnt;i++) {
      _buckets[i].~Stack<T>();
    }
    DEALLOC_KNOWN(_buckets, _bucketCnt*sizeof(Stack<T>), "BucketSorter");
  }

 
  inline bool isEmpty() { return _size==0; }

 
  void insert(T obj)
  {
    CALL("BucketSorter::insert");

    _size++;
    size_t i=Evaluator::eval(obj);
    _buckets[i].push(obj);
    if(i<_minOccupied) {
      _minOccupied=i;
    }
  }

 
  T pop()
  {
    CALL("BucketSorter::pop");
    ASS_G(_size,0);

    _size--;
    T res=_buckets[_minOccupied].pop();
    if(_buckets[_minOccupied].isEmpty()) {
      if(_size) {
	while(_buckets[++_minOccupied].isEmpty()) {};
      } else {
	_minOccupied=_bucketCnt;
      }
    }
    return res;
  }

private:
 
  size_t _bucketCnt;
 
  Stack<T>* _buckets;

 
  size_t _size;
 
  size_t _minOccupied;
};

};

#endif

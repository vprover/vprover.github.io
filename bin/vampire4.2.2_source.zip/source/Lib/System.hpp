
/*
 * File System.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __System__
#define __System__

#include "Forwards.hpp"

#include "Array.hpp"
#include "List.hpp"
#include "Stack.hpp"
#include "Portability.hpp"
#include "VString.hpp"

#define VAMP_RESULT_STATUS_SUCCESS 0
#define VAMP_RESULT_STATUS_UNKNOWN 1
#define VAMP_RESULT_STATUS_OTHER_SIGNAL 2
#define VAMP_RESULT_STATUS_SIGINT 3
#define VAMP_RESULT_STATUS_UNHANDLED_EXCEPTION 4

namespace Lib {

using namespace std;

typedef void (*SignalHandler)(int);

class System {
public:

  static void setSignalHandlers();
  static vstring extractFileNameFromPath(vstring str);
  static bool extractDirNameFromPath(vstring path, vstring& dir);

  static vstring guessExecutableDirectory();
  static vstring guessExecutableName();

  static void ignoreSIGINT() { s_shouldIgnoreSIGINT=true; }
  static void heedSIGINT() { s_shouldIgnoreSIGINT=false; }
  static bool shouldIgnoreSIGINT() { return s_shouldIgnoreSIGINT; }

  static void ignoreSIGHUP() { s_shouldIgnoreSIGHUP=true; }
  static void heedSIGHUP() { s_shouldIgnoreSIGHUP=false; }
  static bool shouldIgnoreSIGHUP() { return s_shouldIgnoreSIGHUP; }

  static void addInitializationHandler(VoidFunc proc, unsigned priority=0);
  static void onInitialization();

  static void addTerminationHandler(VoidFunc proc, unsigned priority=0);
  static void onTermination();
  static void terminateImmediately(int resultStatus) __attribute__((noreturn));

  static void registerForSIGHUPOnParentDeath();

  static void readCmdArgs(int argc, char* argv[], StringStack& res);

 
  static void readDir(vstring dirName, Stack<vstring>& filenames);

 
  static void registerArgv0(const char* argv0) { s_argv0 = argv0; }

 
  static long long getSystemMemory();

 
  static unsigned getNumberOfCores();

  static bool fileExists(vstring fname);

  static pid_t getPID();

  static int executeCommand(vstring command, vstring input, Stack<vstring>& outputLines);

private:

  static ZIArray<List<VoidFunc>*>& initializationHandlersArray();

 
  static bool s_initialized;

 
  static ZIArray<List<VoidFunc>*> s_terminationHandlers;

  static bool s_shouldIgnoreSIGINT;
  static bool s_shouldIgnoreSIGHUP;

  static const char* s_argv0;
};

}

#endif

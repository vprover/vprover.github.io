
/*
 * File Random.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Debug/Assertion.hpp"
#include "Debug/Tracer.hpp"

#include "Random.hpp"

using namespace Lib;

int Random::_seed = 1;
int Random::_remainingBits = 0;
const int Random::_bitsPerInt = Random::bitsPerInt ();
unsigned Random::_bits;

double Random::getDouble (double min, double max)
{
    CALL("Random::getDouble");
    ASS_L(min, max);

    double diff = max-min;
    double part = (diff*(getInteger(RAND_MAX-2)+1))/RAND_MAX;
    return min+part;
}
long double Random::getDouble (long double min, long double max)
{
    CALL("Random::getDouble");
    ASS_L(min, max);

    long double diff = max-min;
    long double part = (diff*(getInteger(RAND_MAX-2)+1))/RAND_MAX;
    return min+part;
}

int Random::bitsPerInt ()
{
  int b = getMax() + 1;
  int bits = -1;

  while (b != 0) {
    b /= 2;
    bits ++;
  }

  return bits;
} 

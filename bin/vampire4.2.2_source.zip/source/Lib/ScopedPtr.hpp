
/*
 * File ScopedPtr.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __ScopedPtr__
#define __ScopedPtr__

#include "Forwards.hpp"

#include "Debug/Assertion.hpp"
#include "Debug/Tracer.hpp"

namespace Lib
{

template<typename T>
class ScopedPtr {
private:
  ScopedPtr(const ScopedPtr& ptr);
  ScopedPtr& operator=(const ScopedPtr& ptr);
public:
  inline
  ScopedPtr() : _obj(0) {}
 
  inline
  explicit ScopedPtr(T* obj)
  : _obj(obj) {ASS(obj);}
  inline
  ~ScopedPtr()
  {
    CALL("Lib::ScopedPtr::~ScopedPtr");
    if(_obj) {
      checked_delete(_obj);
    }
  }
  void operator=(T* obj)
  {
    CALL("SmartPtr::operator=");

    if(_obj) {
      checked_delete(_obj);
    }
    _obj = obj;
  }

  inline
  operator bool() const { return _obj; }

  inline
  T* operator->() const
  {
    CALL("ScopedPtr::operator->");
    ASS(_obj);

    return _obj;
  }
  inline
  T& operator*() const
  {
    CALL("ScopedPtr::operator*");
    ASS(_obj);

    return *_obj;
  }

  inline
  T* ptr() const { return _obj; }

  inline
  bool isEmpty() const { return !_obj; }

  template<class Target>
  inline
  Target* pcast() const { return static_cast<Target*>(_obj); }

 
  T* release() {
    T* res = _obj;
    _obj = 0;
    return res;
  }

private:
  T* _obj;
};

}

#endif 

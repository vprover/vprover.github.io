
/*
 * File Sort.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#ifndef __Sort__
#  define __Sort__

#include "Debug/Assertion.hpp"
#include "Debug/Tracer.hpp"

#include "Allocator.hpp"
#include "DArray.hpp"

namespace Lib {

struct DefaultComparator
{
  template<typename T>
  static Comparison compare(T a, T b)
  {
    CALL("DefaultComparator::compare");

    if(a==b) {
      return EQUAL;
    }
    else if(a<b) {
      return LESS;
    }
    else {
      ASS(a>b);
      return GREATER;
    }
  }
};

template <class Comparator, typename C>
void sort(C* first, C* afterLast)
{
  CALL("sort");
  

  C* arr=first;
  size_t size=afterLast-first;
  if(size<=1) {
    
    return;
  }

  
  static DArray<size_t> ft(32);

  size_t from = 0;
  size_t to=size-1;
  ft.ensure(to);

  size_t p = 0; 
  for (;;) {
    ASS(from<size && to<size); 
    
    size_t m = from + Random::getInteger(to-from+1);
    C mid = arr[m];
    size_t l = from;
    size_t r = to;
    while (l < m) {
      switch (Comparator::compare(arr[l],mid))
	{
	case EQUAL:
	case LESS:
	  l++;
	  break;
	case GREATER:
	  if (m == r) {
	    arr[m] = arr[l];
	    arr[l] = arr[m-1];
	    arr[m-1] = mid;
	    m--;
	    r--;
	  }
	  else {
	    ASS(m < r);
	    C aux = arr[l];
	    arr[l] = arr[r];
	    arr[r] = aux;
	    r--;
	  }
	  break;
	}
    }
    
    
    
    while (m < r) {
      switch (Comparator::compare(mid,arr[m+1]))
	{
	case LESS:
	  {
	    C aux = arr[r];
	    arr[r] = arr[m+1];
	    arr[m+1] = aux;
	    r--;
	  }
	  break;
	case EQUAL:
	case GREATER:
	  arr[m] = arr[m+1];
	  arr[m+1] = mid;
	  m++;
	}
    }
    
    
    if (m+1 < to) {
      ft[p++] = m+1;
      ft[p++] = to;
    }

    to = m-1;
    if (m!=0 && from < to) {
      continue;
    }
    if (p != 0) {
      p -= 2;
      ASS(p >= 0);
      from = ft[p];
      to = ft[p+1];
      continue;
    }
    return;
  }
}

template <typename ToCompare, class Comparator>
class Sort
{
 public:
 
  Sort (int length,Comparator& comparator)
    :
    _size(length),
    _length(0),
    _comparator(comparator)
    {
      CALL("Sort::Sort");

      void* mem = ALLOC_KNOWN(length*sizeof(ToCompare),"Sort<>");
      _elems = array_new<ToCompare>(mem, length);
    }

  inline ~Sort ()
  {
    CALL("Sort::~Sort");

    array_delete(_elems,_size);
    DEALLOC_KNOWN(_elems,_size*sizeof(ToCompare),"Sort<>");
  }

 
  inline int length () const { return _length; }

 
  inline ToCompare operator [] (int n) const
    {
      ASS(n < _length);
      return _elems[n];
    } 

 
  inline void add (ToCompare elem)
    {
      ASS(_length < _size);

      _elems[_length++] = elem;
    } 

 
  inline void sort ()
  {
    CALL("Sort::sort/0");
    sort (0,_length-1);
  }

 
   inline bool member (const ToCompare elem) const {
     return member (elem,0,_length-1);
   }

 protected:  
 
  ToCompare* _elems;
 
  int _size;
 
  int _length;
 
  Comparator& _comparator;

 
  void sort(int p,int r)
  {
    CALL("Sort::sort/2");
    ASS(r < _length);

    if (p >= r) {
      return;
    }
    int m = (p+r)/2;
    int i = p;
    int j = r;
    ToCompare a = _elems[m];
    while (i < m) {
      ToCompare b = _elems[i];
      if (! _comparator.lessThan(a,b)) { 
	i++;
	continue;
      }
      if (m < j) {
	_elems[i] = _elems[j];
	_elems[j] = b;
	j--;
	continue;
      }
      _elems[m] = b;
      _elems[i] = _elems[m-1];
      m--;
      j--;
    }
    while (m < j) {
      ToCompare b = _elems[j];
      if (! _comparator.lessThan(b,a)) { 
	j--;
	continue;
      }
      _elems[m] = b;
      _elems[j] = _elems[m+1];
      m++;
    }
    _elems[m] = a;
    sort(p,m-1);
    sort(m+1,r);
  } 

 
  bool member (const ToCompare elem, int fst, int lst) const
  {
    CALL("Sort::member");

    for (;;) {
      if (fst > lst) {
	return false;
      }

      int mid = (fst + lst) / 2;

      if (_elems[mid] == elem) {
	return true;
      }

      if (_comparator.lessThan(_elems[mid],elem)) {
	lst = mid-1;
      }
      else { 
	fst = mid+1;
      }
    }
  } 
};  

} 

#endif



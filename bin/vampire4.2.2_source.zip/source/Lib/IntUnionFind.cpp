
/*
 * File IntUnionFind.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include <algorithm>

#include "Allocator.hpp"

#include "IntUnionFind.hpp"

namespace Lib {

using namespace std;

IntUnionFind::IntUnionFind(int cnt)
: _cnt(cnt), _modified(true), _components(8)
{
  CALL("IntUnionFind::IntUnionFind");
  ASS_G(cnt, 0);

  _parents=reinterpret_cast<int*>(ALLOC_KNOWN(_cnt*sizeof(int), "IntUnionFind"));
  for(int i=0;i<_cnt;i++) {
    _parents[i]=-1;
  }
  _data=reinterpret_cast<int*>(ALLOC_KNOWN(_cnt*sizeof(int), "IntUnionFind"));
}

IntUnionFind::~IntUnionFind()
{
  DEALLOC_KNOWN(_parents, _cnt*sizeof(int), "IntUnionFind");
  DEALLOC_KNOWN(_data, _cnt*sizeof(int), "IntUnionFind");
}


void IntUnionFind::reset()
{
  CALL("IntUnionFind::reset");

  for(int i=0;i<_cnt;i++) {
    _parents[i]=-1;
  }
  _modified = true;
}


bool IntUnionFind::doUnion(int c1, int c2)
{
  CALL("IntUnionFind::doUnion");

  c1=root(c1);
  c2=root(c2);
  if(c1==c2) {
    return false;
  }
  if(c1>c2) {
    swap(c1,c2);
  }
  ASS_EQ(_parents[c2],-1);
  _parents[c2]=c1;

  
  _modified=true;
  return true;
}

int IntUnionFind::root(int c) const
{
  CALL("IntUnionFind::root");

  static Stack<int> path(8);
  ASS(path.isEmpty());
  int prev=-1;

  while(_parents[c]!=-1) {
    if(prev!=-1) {
      path.push(prev);
    }
    prev=c;
    c=_parents[c];
  }

  while(path.isNonEmpty()) {
    _parents[path.pop()]=c;
  }
  return c;
}

void IntUnionFind::evalComponents()
{
  CALL("IntUnionFind::evalComponents");

  if(!_modified) {
    
    return;
  }

  _components.reset();

  for(int i=0;i<_cnt;i++) {
    _data[i]=_parents[i];
  }
  for(int i=0;i<_cnt;i++) {
    if(_data[i]==-1) {
      _components.push(i);
    } else {
      int prev=_data[i];
      ASS_L(prev,i);
      _data[i]=_data[prev];
      _data[prev]=i;
    }
  }
  ASS_G(_components.size(),0);
  _modified=false;
}

int IntUnionFind::getComponentCount()
{
  CALL("IntUnionFind::getComponentCount");
  ASS(!_modified);

  return _components.size();
}


}

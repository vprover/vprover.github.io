
/*
 * File DynamicHeap.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __DynamicHeap__
#define __DynamicHeap__

#include <algorithm>

#include "Forwards.hpp"

#include "Debug/Assertion.hpp"

#include "Comparison.hpp"
#include "DArray.hpp"
#include "DHMap.hpp"

namespace Lib {

using namespace std;

template<class T, class Comparator, class ElMap = DHMap<T,size_t>, class TArg = T >
class DynamicHeap {
public:
  DynamicHeap(Comparator cmp=Comparator()) : _heap(0), _cmp(cmp) {}

 
  void addToEnd(TArg obj)
  {
    CALL("DynamicHeap::addToEnd");
    ASS(!contains(obj));

    size_t newIdx1 = size()+1;
    _heap.expand(newIdx1);
    getData1()[newIdx1] = obj;
    _elMap.insert(obj, newIdx1);    
  }  

   
  void heapify()
  {
    CALL("DynamicHeap::heapify");
        
    for (size_t i = (size() >> 1); i > 0; i--) {
      fixIncrease1(i);
    }
  }
  
 
  void insert(TArg obj)
  {
    CALL("DynamicHeap::insert");
    
    addToEnd(obj);
    size_t newIdx1 = size();
    fixDecrease1(newIdx1);
  }
  
  T pop()
  {
    CALL("DynamicHeap::pop");
    T res = _heap[0];

    T* data1 = getData1();
    size_t backIdx1 = size();
    data1[1] = data1[backIdx1];
    _heap.expand(backIdx1-1);
    _elMap.remove(res);

    if(backIdx1!=1) {
      
      _elMap.set(data1[1], 1);
      fixIncrease1(1);
    }

    return res;
  }

  void notifyIncrease(TArg obj)
  {
    CALL("DynamicHeap::notifyIncrease");
    
    size_t idx = _elMap.get(obj);
    ASS(idx==1 || !isGreater1(idx/2, idx)); 
    fixIncrease1(idx);
  }

  void notifyDecrease(TArg obj)
  {
    CALL("DynamicHeap::notifyDecrease");

    size_t idx = _elMap.get(obj);
    ASS(idx*2>size() || !isGreater1(idx, idx*2)); 
    ASS(idx*2+1>size() || !isGreater1(idx, idx*2+1)); 
    fixDecrease1(idx);
  }

  TArg top() const
  {
    CALL("DynamicHeap::insert");
    ASS(!isEmpty());

    return _heap[0];
  }

  bool contains(TArg obj)
  {
    CALL("DynamicHeap::contains");

    return _elMap.find(obj);
  }

  size_t size() const { return _heap.size(); }

  bool isEmpty() const { return size()==0; }

  ElMap& elMap() { return _elMap; }
private:
  


 
  void fixDecrease1(size_t idx)
  {
    CALL("DynamicHeap::fixDecrease1");
    ASS_G(idx, 0);
    ASS_LE(idx, size());

    while(idx>1) {
      size_t parent = idx/2;
      if(!isGreater1(parent, idx)) {
	break;
      }
      swapInHeap1(idx, parent);
      idx = parent;
    }
  }

 
  void fixIncrease1(size_t idx)
  {
    CALL("DynamicHeap::fixDecrease1");
    ASS_G(idx, 0);
    ASS_LE(idx, size());

    size_t maxIdx = size();

    for(;;) {
      size_t child1 = idx*2;
      if(child1>maxIdx) {
	break;
      }
      if(child1==maxIdx) {
	if(isGreater1(idx, child1)) {
	  swapInHeap1(idx, child1);
	}
	break;
      }

      size_t child2 = child1+1;
      if(isGreater1(idx, child1)) {
	if(isGreater1(child1, child2)) {
	  swapInHeap1(idx, child2);
	  idx = child2;
	}
	else {
	  swapInHeap1(idx, child1);
	  idx = child1;
	}
      }
      else if(isGreater1(idx, child2)) {
	swapInHeap1(idx, child2);
	idx = child2;
      }
      else {
	break;
      }
    }
  }

 
  bool isGreater1(size_t idxA, size_t idxB)
  {
    CALL("DynamicHeap::isGreater1");
    ASS_G(idxA, 0);
    ASS_LE(idxA, size());
    ASS_G(idxB, 0);
    ASS_LE(idxB, size());

    T* data1 = getData1();
    return _cmp.compare(data1[idxA], data1[idxB])==GREATER;
  }

 
  void swapInHeap1(size_t idxA, size_t idxB)
  {
    CALL("DynamicHeap::swapInHeap1");

    T* data1 = getData1();
    swap(data1[idxA], data1[idxB]);
    _elMap.set(data1[idxA], idxA);
    _elMap.set(data1[idxB], idxB);
  }

 
  T* getData1() { return _heap.array()-1; }

  DArray<T> _heap;
 
  ElMap _elMap;

  Comparator _cmp;
};

}

#endif 

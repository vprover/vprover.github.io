
/*
 * File Cache.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Cache__
#define __Cache__

#include <iostream>

#include "Forwards.hpp"

#include "Debug/Assertion.hpp"

#include "Shell/Options.hpp"

#include "Allocator.hpp"
#include "Environment.hpp"

#ifndef SIZE_MAX
# define SIZE_MAX ((size_t)-1)
#endif

#define REPORT_VACANCIES 0

#define NONEXPANDABLE_CACHE_THRESHOLD MAXIMAL_ALLOCATION/2


namespace Lib {

namespace __Cache_AUX {

using namespace Shell;

bool canExpandToBytes(size_t sz)
{
  return sz<(MAXIMAL_ALLOCATION/2) && sz<(env.options->memoryLimit()-Allocator::getUsedMemory());
}

}

using namespace __Cache_AUX;

template<typename Key, typename Val, class Hash>
class Cache {
private:
  struct Entry {
    Entry() : _occupied(false) {}
    Key _key;
    Val _value;
    bool _occupied;
  };
public:
  Cache() : _size(0), _data(0)
  {
    expand(32);
  }

  ~Cache()
  {
    if(_size) {
      ASS(_data);
      array_delete(_data, _size);
      DEALLOC_KNOWN(_data,_size*sizeof(Entry),"Cache<>");
    }
  }

  bool find(Key k, Val& v) const
  {
    Entry* e=_data+getPosition(k);
    if(e->_occupied && e->_key==k) {
      v=e->_value;
      return true;
    }
    return false;
  }

  bool find(Key k) const
  {
    Entry* e=_data+getPosition(k);
    return e->_occupied && e->_key==k;
  }

  void insert(Key k, Val v=Val())
  {
    Entry* e=_data+getPosition(k);

    if(e->_occupied) {
      if(e->_key==k) {
	return;
      }
      _evictionCounter++;

      if(shouldExpand()) {
	tryExpand();
	e=_data+getPosition(k);
	ASS(!e->_occupied);
      }
    }

    if(!e->_occupied) { 
      e->_occupied=true;
#if REPORT_VACANCIES
    _vacancies--;
#endif
    }
    e->_key=k;
    e->_value=v;
  }

  void resetEvictionCounter()
  {
    _evictionCounter=0;
  }
private:
 
  bool shouldExpand() const
  {
    return _evictionCounter>=_evictionThreshold;
  }

 
  size_t getPosition(Key k) const
  {
    return Hash::hash(k) & _sizeMask;
  }

 
  void tryExpand()
  {
    size_t newSize = _size*2;
    if(canExpandToBytes(newSize*sizeof(Entry))) {
      expand(newSize);
    }
    else {
      
      _evictionThreshold=SIZE_MAX;
    }
  }

 
  void expand(size_t newSize)
  {
    CALL("Cache::expand");
    ASS_G(newSize, _size);

    size_t oldSize=_size;
    Entry* oldData=_data;
#if REPORT_VACANCIES
    size_t oldVacancies=_vacancies;
#endif

    void* mem=ALLOC_KNOWN(newSize*sizeof(Entry),"Cache<>");
    _data=array_new<Entry>(mem, newSize);
    _size=newSize;
    _sizeMask=newSize-1;

    _evictionThreshold=2*newSize;
    _evictionCounter=0;

#if REPORT_VACANCIES
    _vacancies=newSize;
#endif

    if(oldSize) {
      ASS(oldData);
      array_delete(oldData, oldSize);
      DEALLOC_KNOWN(oldData,oldSize*sizeof(Entry),"Cache<>");
#if REPORT_VACANCIES
      std::cout<<"Expanding from "<<oldSize<<" with "<<oldVacancies<<" vacancies to "<<newSize<<endl;
#endif
    }


  }

 
  size_t _size;

 
  size_t _sizeMask;

 
  Entry* _data;

 
  size_t _evictionCounter;
 
  size_t _evictionThreshold;

#if REPORT_VACANCIES
 
  size_t _vacancies;
#endif
};

}

#endif 


/*
 * File CodeTree.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __CodeTree__
#define __CodeTree__

#include "Forwards.hpp"

#include "Lib/Allocator.hpp"
#include "Lib/DArray.hpp"
#include "Lib/DHMap.hpp"
#include "Lib/Hash.hpp"
#include "Lib/List.hpp"
#include "Lib/Stack.hpp"
#include "Lib/TriangularArray.hpp"
#include "Lib/Vector.hpp"
#include "Lib/VirtualIterator.hpp"

#include "Kernel/FlatTerm.hpp"

#include "Index.hpp"


#define LOG_OP(x)



namespace Indexing {

using namespace Lib;
using namespace Kernel;

class CodeTree
{
public:
  struct ILStruct;
  struct SearchStruct;
  struct CodeOp;
  
protected:  
 
  void (*_onCodeOpDestroying)(CodeOp* op);
      
public:
  CodeTree();
  ~CodeTree();
  
  struct LitInfo
  {
    LitInfo() {}
    LitInfo(Clause* cl, unsigned litIndex);
    void dispose();

    static LitInfo getReversed(const LitInfo& li);
    static LitInfo getOpposite(const LitInfo& li);

   
    unsigned liIndex;
   
    unsigned litIndex;
    FlatTerm* ft;
    bool opposite;
  };

  struct MatchInfo
  {
   
    unsigned liIndex;
   
    TermList bindings[1];

  private:
    void init(ILStruct* ils, unsigned liIndex, DArray<TermList>& bindingArray);

    static MatchInfo* alloc(unsigned bindCnt);

    void destroy(unsigned bindCnt);


    friend struct ILStruct;

    
    
    MatchInfo();
    ~MatchInfo();
    void operator delete(void*);
    void* operator new(size_t,unsigned length);
  };

 
  struct ILStruct
  {
    ILStruct(Literal* lit, unsigned varCnt, Stack<unsigned>& gvnStack);
    ~ILStruct();
    void putIntoSequence(ILStruct* previous_);

    bool equalsForOpMatching(const ILStruct& o) const;

    void ensureFreshness(unsigned globalTimestamp);

    CLASS_NAME(CodeTree::ILStruct);
    USE_ALLOCATOR(ILStruct);

    struct GVArrComparator;

    unsigned depth;
    ILStruct* previous;

    unsigned isVarEqLit:1;
    unsigned varEqLitSort:31;

    unsigned varCnt;
    unsigned* globalVarNumbers;

    unsigned* sortedGlobalVarNumbers;

   
    unsigned* globalVarPermutation;

    unsigned timestamp;
    

    void addMatch(unsigned liIndex, DArray<TermList>& bindingArray);
    void deleteMatch(unsigned matchIndex);
    MatchInfo*& getMatch(unsigned matchIndex);

    unsigned matchCnt;

   
    bool visited;
    bool finished;
    bool noNonOppositeMatches;
  private:
    DArray<MatchInfo*> matches;
  };

  enum InstructionPrefix
  {
    
    SUCCESS_OR_FAIL = 0,
    CHECK_GROUND_TERM = 1,
    LIT_END = 2,
   
    SUFFIX_INSTR = 3
  };
  enum InstructionSuffix
  {
    CHECK_FUN = 0,
    ASSIGN_VAR = 1,
    CHECK_VAR = 2,
    SEARCH_STRUCT = 3
  };

 
  struct CodeOp
  {
    static CodeOp getSuccess(void* data);
    static CodeOp getLitEnd(ILStruct* ils);
    static CodeOp getTermOp(InstructionSuffix i, unsigned num);
    static CodeOp getGroundTermCheck(Term* trm);

    bool equalsForOpMatching(const CodeOp& o) const;

   
    inline bool isSuccess() const { return instrPrefix()==SUCCESS_OR_FAIL && data(); }
    inline bool isFail() const { return !data(); }
    inline bool isLitEnd() const { return instrPrefix()==LIT_END; }
    inline bool isSearchStruct() const { return instrPrefix()==SUFFIX_INSTR && instrSuffix()==SEARCH_STRUCT; }
    inline bool isCheckFun() const { return instrPrefix()==SUFFIX_INSTR && instrSuffix()==CHECK_FUN; }
    inline bool isCheckGroundTerm() const { return instrPrefix()==CHECK_GROUND_TERM; }

    inline Term* getTargetTerm() const
    {
      ASS(isCheckGroundTerm());
      return reinterpret_cast<Term*>(data()&~static_cast<size_t>(CHECK_GROUND_TERM));
    }

    inline void* getSuccessResult() { ASS(isSuccess()); return _result; }

    inline ILStruct* getILS()
    {
      ASS(isLitEnd());
      return reinterpret_cast<ILStruct*>(data()&~static_cast<size_t>(LIT_END));
    }
    inline const ILStruct* getILS() const
    {
      return const_cast<CodeOp*>(this)->getILS();
    }

    SearchStruct* getSearchStruct();

    inline InstructionPrefix instrPrefix() const { return static_cast<InstructionPrefix>(_info.prefix); }
    inline InstructionSuffix instrSuffix() const
    {
      ASS_EQ(instrPrefix(), SUFFIX_INSTR);
      return static_cast<InstructionSuffix>(_info.suffix);
    }

    inline unsigned arg() const { return _info.arg; }
    inline CodeOp* alternative() const { return _alternative; }
    inline CodeOp*& alternative() { return _alternative; }

    inline void setAlternative(CodeOp* op) { ASS_NEQ(op, this); _alternative=op; }
    inline void setLongInstr(InstructionSuffix i) { _info.prefix=SUFFIX_INSTR; _info.suffix=i; }

    void makeFail() { _data=0; }

  private:
    inline size_t data() const { return _data; }

    inline void setArg(unsigned arg) { ASS_L(arg,1<<28); _info.arg=arg; }

    union {
      struct {
        unsigned prefix : 2;
        unsigned suffix : 2;
        unsigned arg : 28;
      } _info;
      void* _result;
      size_t _data;
    };
   
    CodeOp* _alternative;
  };

  struct SearchStruct
  {
    void destroy();
    bool isFixedSearchStruct() const { return true; }

    bool getTargetOpPtr(const CodeOp& insertedOp, CodeOp**& tgt);

    CodeOp* getTargetOp(const FlatTerm::Entry* ftPos);

    enum Kind
    {
      FN_STRUCT,
      GROUND_TERM_STRUCT
    };

    CodeOp landingOp;
    Kind kind;
  protected:
    SearchStruct(Kind kind);
  };

  struct FixedSearchStruct
  : public SearchStruct
  {
    FixedSearchStruct(Kind kind, size_t length);
    ~FixedSearchStruct();

    size_t length;
    CodeOp** targets;
  };

  struct FnSearchStruct
  : public FixedSearchStruct
  {
    FnSearchStruct(size_t length);
    ~FnSearchStruct();
    CodeOp*& targetOp(unsigned fn);

    CLASS_NAME(CodeTree::FnSearchStruct);
    USE_ALLOCATOR(FnSearchStruct);

    struct OpComparator;

    unsigned* values;
  };

  struct GroundTermSearchStruct
  : public FixedSearchStruct
  {
    GroundTermSearchStruct(size_t length);
    ~GroundTermSearchStruct();
    CodeOp*& targetOp(const Term* trm);

    CLASS_NAME(CodeTree::GroundTermSearchStruct);
    USE_ALLOCATOR(GroundTermSearchStruct);

    struct OpComparator;

    Term** values;
  };


  typedef Vector<CodeOp> CodeBlock;
  typedef Stack<CodeOp> CodeStack;

  struct BaseMatcher
  {
  public:
   
    CodeOp* op;
  protected:

    bool doCheckGroundTerm();

   
    size_t tp;
   
    FlatTerm* ft;

  };

  

  inline bool isEmpty() { return !_entryPoint; }
  inline CodeOp* getEntryPoint() { ASS(!isEmpty()); return &(*_entryPoint)[0]; }
  static CodeBlock* firstOpToCodeBlock(CodeOp* op);

  template<class Visitor>
  void visitAllOps(Visitor visitor);

  

  typedef DHMap<unsigned,unsigned> VarMap;

 
  struct CompileContext
  {
    void init();
    void deinit(CodeTree* tree, bool discarded=false);

    void nextLit();

    unsigned nextVarNum;
    unsigned nextGlobalVarNum;
    VarMap varMap;
    VarMap globalVarMap;
  };

  static CodeBlock* buildBlock(CodeStack& code, size_t cnt, ILStruct* prev);
  void incorporate(CodeStack& code);

  void compressCheckOps(CodeOp* chainStart, SearchStruct::Kind kind);

  static void compileTerm(Term* trm, CodeStack& code, CompileContext& cctx, bool addLitEnd);

  

  void optimizeMemoryAfterRemoval(Stack<CodeOp*>* firstsInBlocks, CodeOp* removedOp);

  struct RemovingMatcher
  : public BaseMatcher
  {
  public:
    bool next();

  protected:
    void init(CodeOp* entry_, LitInfo* linfos_, size_t linfoCnt_,
	CodeTree* tree_, Stack<CodeOp*>* firstsInBlocks_);


    bool prepareLiteral();
    bool backtrack();
    bool doSearchStruct();
    bool doCheckFun();
    bool doAssignVar();
    bool doCheckVar();


    struct BTPoint
    {
      BTPoint(size_t tp, CodeOp* op, size_t fibDepth)
      : tp(tp), op(op), fibDepth(fibDepth) {}

      size_t tp;
      CodeOp* op;
      size_t fibDepth;
    };

   
    DArray<unsigned> bindings;

    Stack<BTPoint> btStack;
    Stack<CodeOp*>* firstsInBlocks;
    bool fresh;
    size_t curLInfo;

    CodeOp* entry;
    size_t initFIBDepth;

    LitInfo* linfos;
    size_t linfoCnt;

    bool matchingClauses;
    CodeTree* tree;
  };

  

 
  struct BTPoint
  {
    BTPoint() {}
    BTPoint(size_t tp, CodeOp* op) : tp(tp), op(op) {}

   
    size_t tp;
   
    CodeOp* op;
  };

  typedef Stack<BTPoint> BTStack;
  typedef DArray<TermList> BindingArray;

 
  struct Matcher
  : public BaseMatcher
  {
    void init(CodeTree* tree, CodeOp* entry_);

    inline bool finished() const { return !_fresh && !_matched; }
    inline bool matched() const { return _matched && op->isLitEnd(); }
    inline bool success() const { return _matched && op->isSuccess(); }



  private:
    bool backtrack();
    bool doSearchStruct();
    bool doCheckFun();
    void doAssignVar();
    bool doCheckVar();

  protected:
    bool execute();
    bool prepareLiteral();

  public:
   
    BindingArray bindings;

  protected:
   
    bool _fresh;
    bool _matched;

   
    BTStack btStack;

    CodeOp* entry;

    CodeTree* tree;
   
    LitInfo* linfos;
   
    size_t linfoCnt;

   
    size_t curLInfo;

  };


  void incTimeStamp();

  


  bool _clauseCodeTree;
  unsigned _curTimeStamp;

 
  unsigned _maxVarCnt;

  CodeBlock* _entryPoint;

};

}

#endif 



/*
 * File ResultSubstitution.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */



#ifndef __ResultSubstitution__
#define __ResultSubstitution__

#include "Forwards.hpp"

#include "Lib/SmartPtr.hpp"
#include "Kernel/Term.hpp"
#include "Kernel/Renaming.hpp"

namespace Indexing {

using namespace Kernel;

class ResultSubstitution
{
public:
  virtual ~ResultSubstitution() {}
  virtual TermList applyToQuery(TermList t) { NOT_IMPLEMENTED; }
  virtual Literal* applyToQuery(Literal* l) { NOT_IMPLEMENTED; }
  virtual TermList applyToResult(TermList t) { NOT_IMPLEMENTED; }
  virtual Literal* applyToResult(Literal* l) { NOT_IMPLEMENTED; }

 
  virtual size_t getQueryApplicationWeight(TermList t) { return 0; }
 
  virtual size_t getQueryApplicationWeight(Literal* l) { return 0; }
 
  virtual size_t getResultApplicationWeight(TermList t) { return 0; }
 
  virtual size_t getResultApplicationWeight(Literal* l) { return 0; }

  template<typename T>
  T apply(T t, bool result)
  {
    if(result) {
      return applyToResult(t);
    } else {
      return applyToQuery(t);
    }
  }

 
  template<typename T>
  size_t getApplicationWeight(T t, bool result)
  {
    if(result) {
      return getResultApplicationWeight(t);
    } else {
      return getQueryApplicationWeight(t);
    }
  }

 
  virtual TermList applyToBoundResult(TermList t)
  { return applyToResult(t); }

 
  virtual Literal* applyToBoundResult(Literal* lit)
  { return applyToResult(lit); }

 
  virtual bool isIdentityOnQueryWhenResultBound() {return false;}


 
  virtual TermList applyToBoundQuery(TermList t)
  { return applyToQuery(t); }

 
  virtual bool isIdentityOnResultWhenQueryBound() {return false;}

  virtual RobSubstitution* tryGetRobSubstitution() { return 0; }

  static ResultSubstitutionSP fromSubstitution(RobSubstitution* s,
	  int queryBank, int resultBank);


#if VDEBUG
  virtual vstring toString(){ NOT_IMPLEMENTED; }
#endif
};


class IdentitySubstitution
: public ResultSubstitution
{
public:
  CLASS_NAME(IdentitySubstitution);
  USE_ALLOCATOR(IdentitySubstitution);
  
  static ResultSubstitutionSP instance();

  TermList applyToQuery(TermList t) { return t; }
  Literal* applyToQuery(Literal* l) { return l; }
  TermList applyToResult(TermList t) { return t; }
  Literal* applyToResult(Literal* l) { return l; }
  bool isIdentityOnQueryWhenResultBound() {return true;}
#if VDEBUG
  virtual vstring toString(){ return "identity"; }
#endif
};

class DisjunctQueryAndResultVariablesSubstitution
: public ResultSubstitution
{
public:
  CLASS_NAME(DisjunctQueryAndResultVariablesSubstitution);
  USE_ALLOCATOR(DisjunctQueryAndResultVariablesSubstitution);
  
  TermList applyToQuery(TermList t);
  Literal* applyToQuery(Literal* l);
  TermList applyToResult(TermList t);
  Literal* applyToResult(Literal* l);

 
  bool isIdentityOnQueryWhenResultBound() {return true;}
#if VDEBUG
  virtual vstring toString(){ return "DisjunctQueryAndResultVariablesSubstitution"; }
#endif
private:
  struct Applicator;
  Renaming _renaming;
};

};

#endif

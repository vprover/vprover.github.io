
/*
 * File LiteralIndex.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Kernel/Clause.hpp"
#include "Kernel/LiteralComparators.hpp"
#include "Kernel/Matcher.hpp"
#include "Kernel/MLVariant.hpp"
#include "Kernel/Ordering.hpp"

#include "LiteralIndexingStructure.hpp"
#include "LiteralSubstitutionTree.hpp"

#include "LiteralIndex.hpp"

namespace Indexing
{

using namespace Kernel;

LiteralIndex::~LiteralIndex()
{
  delete _is;
}

SLQueryResultIterator LiteralIndex::getAll()
{
  return _is->getAll();
}

SLQueryResultIterator LiteralIndex::getUnifications(Literal* lit,
	  bool complementary, bool retrieveSubstitutions)
{
  return _is->getUnifications(lit, complementary, retrieveSubstitutions);
}

SLQueryResultIterator LiteralIndex::getUnificationsWithConstraints(Literal* lit,
          bool complementary, bool retrieveSubstitutions)
{
  return _is->getUnificationsWithConstraints(lit, complementary, retrieveSubstitutions);
}

SLQueryResultIterator LiteralIndex::getGeneralizations(Literal* lit,
	  bool complementary, bool retrieveSubstitutions)
{
  return _is->getGeneralizations(lit, complementary, retrieveSubstitutions);
}

SLQueryResultIterator LiteralIndex::getInstances(Literal* lit,
	  bool complementary, bool retrieveSubstitutions)
{
  return _is->getInstances(lit, complementary, retrieveSubstitutions);
}

size_t LiteralIndex::getUnificationCount(Literal* lit, bool complementary)
{
  return _is->getUnificationCount(lit, complementary);
}

void LiteralIndex::handleLiteral(Literal* lit, Clause* cl, bool add)
{
  CALL("LiteralIndex::handleLiteral");

  if(add) {
    _is->insert(lit, cl);
  } else {
    _is->remove(lit, cl);
  }
}

void GeneratingLiteralIndex::handleClause(Clause* c, bool adding)
{
  CALL("GeneratingLiteralIndex::handleClause");

  TimeCounter tc(TC_BINARY_RESOLUTION_INDEX_MAINTENANCE);

  int selCnt=c->numSelected();
  for(int i=0; i<selCnt; i++) {
    handleLiteral((*c)[i], c, adding);
  }
}

void SimplifyingLiteralIndex::handleClause(Clause* c, bool adding)
{
  CALL("SimplifyingLiteralIndex::handleClause");

  TimeCounter tc(TC_BACKWARD_SUBSUMPTION_INDEX_MAINTENANCE);

  unsigned clen=c->length();
  for(unsigned i=0; i<clen; i++) {
    handleLiteral((*c)[i], c, adding);
  }
}

void FwSubsSimplifyingLiteralIndex::handleClause(Clause* c, bool adding)
{
  CALL("FwSubsSimplifyingLiteralIndex::handleClause");

  unsigned clen=c->length();
  if(clen<2) {
    return;
  }
  TimeCounter tc(TC_FORWARD_SUBSUMPTION_INDEX_MAINTENANCE);

  Literal* best=(*c)[0];
  unsigned bestVal=best->weight()-best->getDistinctVars();
  for(unsigned i=1;i<clen;i++) {
    Literal* curr=(*c)[i];
    unsigned currVal=curr->weight()-curr->getDistinctVars();
    if(currVal>bestVal || (currVal==bestVal && curr>best) ) {
      best=curr;
      bestVal=currVal;
    }
  }
  handleLiteral(best, c, adding);
}

void UnitClauseLiteralIndex::handleClause(Clause* c, bool adding)
{
  CALL("UnitClauseLiteralIndex::handleClause");

  if(c->length()==1) {
    TimeCounter tc(TC_SIMPLIFYING_UNIT_LITERAL_INDEX_MAINTENANCE);

    handleLiteral((*c)[0], c, adding);
  }
}

void NonUnitClauseLiteralIndex::handleClause(Clause* c, bool adding)
{
  CALL("NonUnitClauseLiteralIndex::handleClause");

  unsigned clen=c->length();
  if(clen<2) {
    return;
  }
  TimeCounter tc(TC_NON_UNIT_LITERAL_INDEX_MAINTENANCE);
  unsigned activeLen = _selectedOnly ? c->numSelected() : clen;
  for(unsigned i=0; i<activeLen; i++) {
    handleLiteral((*c)[i], c, adding);
  }
}

RewriteRuleIndex::RewriteRuleIndex(LiteralIndexingStructure* is, Ordering& ordering)
: LiteralIndex(is), _ordering(ordering)
{
  _partialIndex=new LiteralSubstitutionTree();
}

RewriteRuleIndex::~RewriteRuleIndex()
{
  delete _partialIndex;
}

Literal* RewriteRuleIndex::getGreater(Clause* c)
{
  CALL("RewriteRuleIndex::getGreater");
  ASS_EQ(c->length(), 2);

  static LiteralComparators::NormalizedLinearComparatorByWeight<true> comparator;

  Comparison comp=comparator.compare((*c)[0], (*c)[1]);

  Literal* greater=
    ( comp==GREATER ) ? (*c)[0] :
    ( comp==LESS ) ? (*c)[1] : 0;

  if( !greater && (*c)[0]->polarity()==(*c)[1]->polarity() ) {
    if((*c)[0]>(*c)[1]) {
      greater=(*c)[0];
    } else {
      greater=(*c)[1];
      
      
      
      ASS_NEQ((*c)[0],(*c)[1])
    }
  }

  return greater;
}

void RewriteRuleIndex::handleClause(Clause* c, bool adding)
{
  CALL("RewriteRuleIndex::handleClause");

  if(c->length()!=2) {
    return;
  }

  TimeCounter tc(TC_LITERAL_REWRITE_RULE_INDEX_MAINTENANCE);

  Literal* greater=getGreater(c);

  if(greater) {
    if(adding) {
      
      SLQueryResultIterator vit=_partialIndex->getVariants(greater,true,false);
      while(vit.hasNext()) {
        SLQueryResult qr=vit.next();

        
        if(!MLVariant::isVariant(c ,qr.clause, true)) {
          continue;
        }

        
        handleEquivalence(c, greater, qr.clause, qr.literal, true);
        return;
      }
      
      _partialIndex->insert(greater, c);
    }
    else {
      Clause* d;
      if(_counterparts.find(c, d)) {
	Literal* dgr=getGreater(d);
	ASS(MatchingUtils::isVariant(greater, dgr, true))
	handleEquivalence(c, greater, d, dgr, false);
      }
      else {
	_partialIndex->remove(greater, c);
      }
    }
  }
  else {
    
    
    if((*c)[0]->containsAllVariablesOf((*c)[1]) && (*c)[1]->containsAllVariablesOf((*c)[0])) {
      if((*c)[0]->isPositive()) {
	handleLiteral((*c)[0], c, adding);
      }
      else {
	ASS((*c)[1]->isPositive());
	handleLiteral((*c)[1], c, adding);
      }
      if(adding) {
        _counterparts.insert(c, c);
      } else {
        _counterparts.remove(c);
      }
    }

  }
}

void RewriteRuleIndex::handleEquivalence(Clause* c, Literal* cgr, Clause* d, Literal* dgr, bool adding)
{
  CALL("RewriteRuleIndex::handleEquivalence");

  Literal* csm = (cgr==(*c)[0]) ? (*c)[1] : (*c)[0];
  Literal* dsm = (dgr==(*d)[0]) ? (*d)[1] : (*d)[0];

  Ordering::Result cmpRes;
  
  
  if(cgr->isPositive()) {
    
    
    cmpRes=_ordering.compare(cgr,Literal::complementaryLiteral(csm));
  }
  else {
    cmpRes=_ordering.compare(Literal::complementaryLiteral(cgr),csm);
  }
  switch(cmpRes) {
  case Ordering::GREATER:
  case Ordering::GREATER_EQ:
    if(cgr->containsAllVariablesOf(csm)) {
      if(cgr->isPositive()) {
        handleLiteral(cgr, c, adding);
      }
      else {
        handleLiteral(dgr, d, adding);
      }
    }
    break;
  case Ordering::LESS:
  case Ordering::LESS_EQ:
    if(csm->containsAllVariablesOf(cgr)) {
      if(csm->isPositive()) {
        handleLiteral(csm, c, adding);
      }
      else {
        handleLiteral(dsm, d, adding);
      }
    }
    break;
  case Ordering::INCOMPARABLE:
    if(cgr->containsAllVariablesOf(csm)) {
      if(cgr->isPositive()) {
	handleLiteral(cgr, c, adding);
      }
      else {
	handleLiteral(dgr, d, adding);
      }
    }
    if(csm->containsAllVariablesOf(cgr)) {
      if(csm->isPositive()) {
	handleLiteral(csm, c, adding);
      }
      else {
	handleLiteral(dsm, d, adding);
      }
    }
    break;
  case Ordering::EQUAL:
    
    ASSERTION_VIOLATION;
  }

  if(adding) {
    ALWAYS(_counterparts.insert(c, d));
    ALWAYS(_counterparts.insert(d, c));

    
    _partialIndex->remove(dgr, d);
  }
  else {
    _counterparts.remove(c);
    _counterparts.remove(d);

    
    _partialIndex->insert(dgr, d);
  }

}


void DismatchingLiteralIndex::handleClause(Clause* c, bool adding)
{
  CALL("DismatchingLiteralIndex::handleClause");

  

  unsigned clen=c->length();
  for(unsigned i=0; i<clen; i++) {
    handleLiteral((*c)[i], c, adding);
  }
}
void DismatchingLiteralIndex::addLiteral(Literal* l)
{
  CALL("DismatchingLiteralIndex::addLiteral");
  
  handleLiteral(l,0,true);
}

}

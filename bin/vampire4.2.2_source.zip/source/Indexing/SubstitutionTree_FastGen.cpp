
/*
 * File SubstitutionTree_FastGen.cpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#include "Lib/Allocator.hpp"
#include "Lib/Recycler.hpp"

#include "Kernel/Matcher.hpp"
#include "Kernel/SubstHelper.hpp"

#include "SubstitutionTree.hpp"

namespace Indexing
{

class SubstitutionTree::GenMatcher
{
public:
  GenMatcher(Term* query, unsigned nextSpecVar);
  ~GenMatcher();

  CLASS_NAME(SubstitutionTree::GenMatcher);
  USE_ALLOCATOR(GenMatcher);

 
  void bindSpecialVar(unsigned var, TermList term)
  {
    (*_specVars)[var]=term;
  }
 
  TermList getSpecVarBinding(unsigned specVar)
  { return (*_specVars)[specVar]; }

  bool matchNext(unsigned specVar, TermList nodeTerm, bool separate=true);
  void backtrack();
  bool tryBacktrack();

  ResultSubstitutionSP getSubstitution(Renaming* resultNormalizer);

  int getBSCnt()
  {
    int res=0;
    VarStack::Iterator vsit(_boundVars);
    while(vsit.hasNext()) {
	if(vsit.next()==BACKTRACK_SEPARATOR) {
	  res++;
	}
    }
    return res;
  }

protected:
  static const unsigned BACKTRACK_SEPARATOR=0xFFFFFFFF;

  struct Binder;
  struct Applicator;
  class Substitution;

  VarStack _boundVars;

  DArray<TermList>* _specVars;


 
  unsigned _maxVar;

 
  ArrayMap<TermList>* _bindings;
};

struct SubstitutionTree::GenMatcher::Binder
{
 
  inline
  Binder(GenMatcher* parent)
  : _parent(parent), _maxVar(parent->_maxVar) {}
 
  bool bind(unsigned var, TermList term)
  {
    if(var > _maxVar) {
      return false;
    }
    TermList* aux;
    if(_parent->_bindings->getValuePtr(var,aux,term)) {
      _parent->_boundVars.push(var);
      return true;
    } else {
      return *aux==term;
    }
  }
 
  inline
  void specVar(unsigned var, TermList term)
  {
    (*_parent->_specVars)[var]=term;
  }
private:
  GenMatcher* _parent;
 
  unsigned _maxVar;
};

struct SubstitutionTree::GenMatcher::Applicator
{
  CLASS_NAME(SubstitutionTree::GenMatcher::Applicator);
  USE_ALLOCATOR(SubstitutionTree::GenMatcher::Applicator); 

  inline
  Applicator(GenMatcher* parent, Renaming* resultNormalizer)
  : _parent(parent), _resultNormalizer(resultNormalizer) {}
  TermList apply(unsigned var)
  {
    TermList* cacheEntry;
    if(_cache.getValuePtr(var,cacheEntry)) {
      ASS(_resultNormalizer->contains(var));
      unsigned nvar=_resultNormalizer->get(var);
      ASS(_parent->_bindings->find(nvar));
      *cacheEntry=_parent->_bindings->get(nvar);
    }
    return *cacheEntry;
  }
private:
  GenMatcher* _parent;
  Renaming* _resultNormalizer;
  BindingMap _cache;
};

class SubstitutionTree::GenMatcher::Substitution
: public ResultSubstitution
{
public:
  CLASS_NAME(SubstitutionTree::GenMatcher::Substitution);
  USE_ALLOCATOR(SubstitutionTree::GenMatcher::Substitution);
  
  Substitution(GenMatcher* parent, Renaming* resultNormalizer)
  : _parent(parent), _resultNormalizer(resultNormalizer),
  _applicator(0)
  {}
  ~Substitution()
  {
    if(_applicator) {
      delete _applicator;
    }
  }

  TermList applyToBoundResult(TermList t)
  { return SubstHelper::apply(t, *getApplicator()); }

  Literal* applyToBoundResult(Literal* lit)
  { return SubstHelper::apply(lit, *getApplicator()); }

  bool isIdentityOnQueryWhenResultBound() {return true;}

#if VDEBUG
  virtual vstring toString(){ return _resultNormalizer->toString(); }
#endif

private:
  Applicator* getApplicator()
  {
    if(!_applicator) {
      _applicator=new Applicator(_parent, _resultNormalizer);
    }
    return _applicator;
  }

  GenMatcher* _parent;
  Renaming* _resultNormalizer;
  Applicator* _applicator;
};

SubstitutionTree::GenMatcher::GenMatcher(Term* query, unsigned nextSpecVar)
: _boundVars(256)
{
  Recycler::get(_specVars);
  if(_specVars->size()<nextSpecVar) {
    
    
    _specVars->ensure(max(static_cast<unsigned>(_specVars->size()*2), nextSpecVar));
  }
  Recycler::get(_bindings);
  _bindings->ensure(query->weight());
  _bindings->reset();

  _maxVar=query->weight()-1;
}
SubstitutionTree::GenMatcher::~GenMatcher()
{
  Recycler::release(_bindings);
  Recycler::release(_specVars);
}

bool SubstitutionTree::GenMatcher::matchNext(unsigned specVar, TermList nodeTerm, bool separate)
{
  CALL("SubstitutionTree::GenMatcher::matchNext");

  if(separate) {
    _boundVars.push(BACKTRACK_SEPARATOR);
  }

  TermList queryTerm=(*_specVars)[specVar];
  ASSERT_VALID(queryTerm);

  bool success;
  if(nodeTerm.isTerm()) {
    Term* nt=nodeTerm.term();
    if(nt->shared() && nt->ground()) {
      
      success = nodeTerm==queryTerm;
    } else {
      Binder binder(this);
      ASS(nt->arity()>0);

      success = queryTerm.isTerm() && queryTerm.term()->functor()==nt->functor() &&
	MatchingUtils::matchArgs(nt, queryTerm.term(), binder);
    }
  } else {
    ASS_METHOD(nodeTerm,isOrdinaryVar());
    unsigned var=nodeTerm.var();
    Binder binder(this);
    success=binder.bind(var,queryTerm);
  }

  if(!success) {
    
    
    
    if(separate) {
      
      for(;;) {
	unsigned boundVar=_boundVars.pop();
	if(boundVar==BACKTRACK_SEPARATOR) {
	  break;
	}
	_bindings->remove(boundVar);
      }
    }
  }

  return success;
}

void SubstitutionTree::GenMatcher::backtrack()
{
  CALL("SubstitutionTree::GenMatcher::backtrack");

  for(;;) {
    unsigned boundVar=_boundVars.pop();
    if(boundVar==BACKTRACK_SEPARATOR) {
      break;
    }
    _bindings->remove(boundVar);
  }
}

bool SubstitutionTree::GenMatcher::tryBacktrack()
{
  CALL("SubstitutionTree::GenMatcher::tryBacktrack");

  while(_boundVars.isNonEmpty()) {
    unsigned boundVar=_boundVars.pop();
    if(boundVar==BACKTRACK_SEPARATOR) {
      return true;
    }
    _bindings->remove(boundVar);
  }
  return false;
}


ResultSubstitutionSP SubstitutionTree::GenMatcher::getSubstitution(
	Renaming* resultNormalizer)
{
  return ResultSubstitutionSP(
	  new Substitution(this, resultNormalizer));
}



SubstitutionTree::FastGeneralizationsIterator::FastGeneralizationsIterator(SubstitutionTree* parent, Node* root, Term* query, bool retrieveSubstitution, bool reversed, bool withoutTop, bool useC)
: _literalRetrieval(query->isLiteral()), _retrieveSubstitution(retrieveSubstitution),
  _inLeaf(false), _ldIterator(LDIterator::getEmpty()), _root(root), _tree(parent),
  _alternatives(64), _specVarNumbers(64), _nodeTypes(64)
{
  CALL("SubstitutionTree::FastGeneralizationsIterator::FastGeneralizationsIterator");
  ASS(root);
  ASS(!root->isLeaf());

#if VDEBUG
  _tree->_iteratorCnt++;
#endif

  _subst=new GenMatcher(query,parent->_nextVar);

  if(withoutTop){
    _subst->bindSpecialVar(0,TermList(query));
  }else{
   if(reversed) {
     createReversedInitialBindings(query);
   } else {
     createInitialBindings(query);
   }
  }
}



SubstitutionTree::FastGeneralizationsIterator::~FastGeneralizationsIterator()
{
  CALL("SubstitutionTree::FastGeneralizationsIterator::~FastGeneralizationIterator");

#if VDEBUG
  _tree->_iteratorCnt--;
#endif
  delete _subst;
}


void SubstitutionTree::FastGeneralizationsIterator::createInitialBindings(Term* t)
{
  CALL("SubstitutionTree::FastGeneralizationsIterator::createInitialBindings");

  TermList* args=t->args();
  int nextVar = 0;
  while (! args->isEmpty()) {
    unsigned var = nextVar++;
    _subst->bindSpecialVar(var,*args);
    args = args->next();
  }
}

void SubstitutionTree::FastGeneralizationsIterator::createReversedInitialBindings(Term* t)
{
  CALL("SubstitutionTree::FastGeneralizationsIterator::createReversedInitialBindings");
  ASS(t->isLiteral());
  ASS(t->commutative());
  ASS_EQ(t->arity(),2);

  _subst->bindSpecialVar(1,*t->nthArgument(0));
  _subst->bindSpecialVar(0,*t->nthArgument(1));
}

bool SubstitutionTree::FastGeneralizationsIterator::hasNext()
{
  CALL("SubstitutionTree::FastGeneralizationsIterator::hasNext");

  while(!_ldIterator.hasNext() && findNextLeaf()) {}
  return _ldIterator.hasNext();
}

SubstitutionTree::QueryResult SubstitutionTree::FastGeneralizationsIterator::next()
{
  CALL("SubstitutionTree::FastGeneralizationsIterator::next");

  while(!_ldIterator.hasNext() && findNextLeaf()) {}
  ASS(_ldIterator.hasNext());
  LeafData& ld=_ldIterator.next();

  if(_retrieveSubstitution) {
    _resultNormalizer.reset();
    if(_literalRetrieval) {
      _resultNormalizer.normalizeVariables(ld.literal);
    } else {
      _resultNormalizer.normalizeVariables(ld.term);
    }

    return QueryResult(
          make_pair(&ld,_subst->getSubstitution(&_resultNormalizer)),UnificationConstraintStackSP());
  } else {
    return QueryResult(make_pair(&ld, ResultSubstitutionSP()),UnificationConstraintStackSP());
  }
}

bool SubstitutionTree::FastGeneralizationsIterator::findNextLeaf()
{
  CALL("SubstitutionTree::FastGeneralizationsIterator::findNextLeaf");

  Node* curr;
  bool sibilingsRemain;
  if(_inLeaf) {
    if(_alternatives.isEmpty()) {
      return false;
    }
    _subst->backtrack();
    _inLeaf=false;
    curr=0;
  } else {
    if(!_root) {
      
      
      return false;
    }
    curr=_root;
    _root=0;
    sibilingsRemain=enterNode(curr);
  }
  for(;;) {
main_loop_start:
    unsigned currSpecVar;

    if(curr) {
      if(sibilingsRemain) {
	ASS(_nodeTypes.top()!=UNSORTED_LIST || *static_cast<Node**>(_alternatives.top()));
	currSpecVar=_specVarNumbers.top();
      } else {
	currSpecVar=_specVarNumbers.pop();
      }
    }
    
    while(curr==0 && _alternatives.isNonEmpty()) {
      void* currAlt=_alternatives.pop();
      if(!currAlt) {
	
	_nodeTypes.pop();
	_specVarNumbers.pop();
	if(_alternatives.isNonEmpty()) {
	  _subst->backtrack();
	}
	continue;
      }

      NodeAlgorithm parentType=_nodeTypes.top();

      
      
      if(parentType==UNSORTED_LIST) {
	Node** alts=static_cast<Node**>(currAlt);
	while(*alts && !(*alts)->term.isVar()) {
	  alts++;
	}
	curr=*(alts++);
	while(*alts && !(*alts)->term.isVar()) {
	  alts++;
	}
	if(*alts) {
	  _alternatives.push(alts);
	  sibilingsRemain=true;
	} else {
	  sibilingsRemain=false;
	}
      } else {
	ASS_EQ(parentType,SKIP_LIST)
	NodeList* alts=static_cast<NodeList*>(currAlt);
	if(alts->head()->term.isVar()) {
	  curr=alts->head();
	  if(alts->tail() && alts->second()->term.isVar()) {
	    _alternatives.push(alts->tail());
	    sibilingsRemain=true;
	  } else {
	    sibilingsRemain=false;
	  }
	}
      }

      if(sibilingsRemain) {
	currSpecVar=_specVarNumbers.top();
      } else {
	_nodeTypes.pop();
	currSpecVar=_specVarNumbers.pop();
      }
      if(curr) {
	break;
      }
    }
    if(!curr) {
      
      return false;
    }
    if(!_subst->matchNext(currSpecVar, curr->term, sibilingsRemain)) {	
      
      curr=0;
      if(!sibilingsRemain && _alternatives.isNonEmpty()) {
	_subst->backtrack();
      }
      continue;
    }
    while(!curr->isLeaf() && curr->algorithm()==UNSORTED_LIST && static_cast<UArrIntermediateNode*>(curr)->_size==1) {
      
      unsigned specVar=static_cast<UArrIntermediateNode*>(curr)->childVar;
      curr=static_cast<UArrIntermediateNode*>(curr)->_nodes[0];
      ASS(curr);
      ASSERT_VALID(*curr);
      if(!_subst->matchNext(specVar, curr->term, false)) {
	
	
	if(sibilingsRemain || _alternatives.isNonEmpty()) {
	  
	  
	  
	  _subst->backtrack();
	}
        curr=0;
        goto main_loop_start;
      }
    }
    if(curr->isLeaf()) {
      
      _ldIterator=static_cast<Leaf*>(curr)->allChildren();
      _inLeaf=true;
      return true;
    }

    
    sibilingsRemain=enterNode(curr);
    if(curr==0 && _alternatives.isNonEmpty()) {
      _subst->backtrack();
    }
  }
}

bool SubstitutionTree::FastGeneralizationsIterator::enterNode(Node*& curr)
{
  IntermediateNode* inode=static_cast<IntermediateNode*>(curr);
  NodeAlgorithm currType=inode->algorithm();

  TermList binding=_subst->getSpecVarBinding(inode->childVar);
  curr=0;

  if(currType==UNSORTED_LIST) {
    Node** nl=static_cast<UArrIntermediateNode*>(inode)->_nodes;
    if(binding.isTerm()) {
      unsigned bindingFunctor=binding.term()->functor();
      
      while(*nl && (*nl)->term.isTerm()) {
        
        if(!curr && (*nl)->term.term()->functor()==bindingFunctor) {
          curr=*nl;
        }
        nl++;
      }
      if(!curr && *nl) {
        
        
        Node** nl2=nl+1;
        while(*nl2) {
          if((*nl2)->term.isTerm() && (*nl2)->term.term()->functor()==bindingFunctor) {
            curr=*nl2;
            break;
          }
          nl2++;
        }
      }
    } else {
      
      while(*nl && (*nl)->term.isTerm()) {
        nl++;
      }
    }
    if(!curr && *nl) {
      curr=*(nl++);
      while(*nl && (*nl)->term.isTerm()) {
	nl++;
      }
    }
    if(curr) {
      _specVarNumbers.push(inode->childVar);
    }
    if(*nl) {
      _alternatives.push(nl);
      _nodeTypes.push(currType);
      return true;
    }
  } else {
    NodeList* nl;
    ASS_EQ(currType, SKIP_LIST);
    nl=static_cast<SListIntermediateNode*>(inode)->_nodes.toList();
    if(binding.isTerm()) {
      Node** byTop=inode->childByTop(binding, false);
      if(byTop) {
	curr=*byTop;
      }
    }
    if(!curr && nl->head()->term.isVar()) {
      curr=nl->head();
      nl=nl->tail();
    }
    
    
    if(nl && nl->head()->term.isTerm()) {
      nl=0;
    }
    if(curr) {
      _specVarNumbers.push(inode->childVar);
    }
    if(nl) {
      _alternatives.push(nl);
      _nodeTypes.push(currType);
      return true;
    }
  }
  return false;
}


}

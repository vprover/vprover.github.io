
/*
 * File SMTLIB2.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __SMTLIB2__
#define __SMTLIB2__

#include "Forwards.hpp"

#include "Lib/Set.hpp"

#include "Kernel/Signature.hpp"
#include "Kernel/Sorts.hpp"
#include "Kernel/Term.hpp"

#include "Shell/LispParser.hpp"


namespace Parse {

using namespace Lib;
using namespace Kernel;
using namespace Shell;


class SMTLIB2 {
public:
  SMTLIB2(const Options& opts);

 
  void parse(istream& str);
 
  void parse(LExpr* bench);

 
  UnitList* getFormulas() const { return _formulas; }

 
  SMTLIBLogic getLogic() const {
    return _logic;
  }

private:

  static const char * s_smtlibLogicNameStrings[];

 
  static SMTLIBLogic getLogicFromString(const vstring& str);

 
  bool _logicSet;

 
  SMTLIBLogic _logic;

 
  bool _numeralsAreReal;

 
  void readLogic(const vstring& logicStr);

 
  vstring _statusStr;
 
  vstring _sourceInfo;

  enum BuiltInSorts
  {
    BS_ARRAY,
    BS_BOOL,
    BS_INT,
    BS_REAL,

    BS_INVALID
  };
  static const char * s_builtInSortNameStrings[];

 
  static BuiltInSorts getBuiltInSortFromString(const vstring& str);

 
  bool isAlreadyKnownSortSymbol(const vstring& name);

 
  DHMap<vstring,unsigned> _declaredSorts;

 
  void readDeclareSort(const vstring& name, const vstring& arity);

 
  struct SortDefinition {
    SortDefinition() : args(0), body(0) {}
    SortDefinition(LExprList* args, LExpr* body)
     : args(args), body(body) {}

    LExprList* args;
    LExpr* body;
  };

 
  DHMap<vstring,SortDefinition> _sortDefinitions;

 
  void readDefineSort(const vstring& name, LExprList* args, LExpr* body);

 
  unsigned declareSort(LExpr* sExpr);

 
  enum FormulaSymbol
  {
    FS_LESS,
    FS_LESS_EQ,
    FS_EQ,
    FS_IMPLIES,
    FS_GREATER,
    FS_GREATER_EQ,
    FS_AND,
    FS_DISTINCT,
    FS_EXISTS,
    FS_FALSE,
    FS_FORALL,
    FS_IS_INT,
    FS_NOT,
    FS_OR,
    FS_TRUE,
    FS_XOR,

    FS_USER_PRED_SYMBOL
  };
  static const char * s_formulaSymbolNameStrings[];

 
  static FormulaSymbol getBuiltInFormulaSymbol(const vstring& str);

 
  enum TermSymbol
  {
    TS_MULTIPLY,
    TS_PLUS,
    TS_MINUS,
    TS_DIVIDE,
    TS_ABS,
    TS_DIV,
    TS_ITE,
    TS_LET,
    TS_MOD,
    TS_SELECT,
    TS_STORE,
    TS_TO_INT,
    TS_TO_REAL,

    TS_USER_FUNCTION
  };
  static const char * s_termSymbolNameStrings[];

 
  static TermSymbol getBuiltInTermSymbol(const vstring& str);

 
  bool isAlreadyKnownFunctionSymbol(const vstring& name);

 
  typedef std::pair<unsigned,bool> DeclaredFunction;
 
  DHMap<vstring, DeclaredFunction> _declaredFunctions;

 
  DeclaredFunction declareFunctionOrPredicate(const vstring& name, signed rangeSort, const Stack<unsigned>& argSorts);

 
  void readDeclareFun(const vstring& name, LExprList* iSorts, LExpr* oSort);

 
  void readDefineFun(const vstring& name, LExprList* iArgs, LExpr* oSort, LExpr* body);

  void readDeclareDatatypes(LExprList* sorts, LExprList* datatypes, bool codatatype = false);

  TermAlgebraConstructor* buildTermAlgebraConstructor(vstring constrName, unsigned taSort,
                                                      Stack<vstring> destructorNames, Stack<unsigned> argSorts);

 
  struct ParseResult {
   
    ParseResult() : sort(0), formula(true), frm(nullptr) {}

    bool isSeparator() { return sort == 0 && formula && !frm; }

    bool isSharedTerm() { return !formula && (!trm.isTerm() || trm.term()->shared()); }

   
    ParseResult(Formula* frm) : sort(Sorts::SRT_BOOL), formula(true), frm(frm) {}
   
    ParseResult(unsigned sort, TermList trm) : sort(sort), formula(false), trm(trm) {}

    unsigned sort;
    bool formula;
    union {
      Formula* frm;
      TermList trm;
    };

   
    bool asFormula(Formula*& resFrm);
   
    unsigned asTerm(TermList& resTrm);

    vstring toString();
  };

 
  Interpretation getFormulaSymbolInterpretation(FormulaSymbol fs, unsigned firstArgSort);
 
  Interpretation getUnaryMinusInterpretation(unsigned argSort);
 
  Interpretation getTermSymbolInterpretation(TermSymbol ts, unsigned firstArgSort);
  

  

 
  unsigned _nextVar;

 
  typedef pair<TermList,unsigned> SortedTerm;
 
  typedef DHMap<vstring,SortedTerm> TermLookup;
  typedef Stack<TermLookup*> Scopes;
 
  Scopes _scopes;

 
  Stack<ParseResult> _results;

 
  enum ParseOperation {
    
    PO_PARSE,              
    
    PO_PARSE_APPLICATION,  
    
    PO_CHECK_ARITY,        
    
    PO_LET_PREPARE_LOOKUP, 
    PO_LET_END             
  };
 
  Stack<pair<ParseOperation,LExpr*> > _todo;

  

  

  void complainAboutArgShortageOrWrongSorts(const vstring& symbolClass, LExpr* exp) NO_RETURN;

  void parseLetBegin(LExpr* exp);
  void parseLetPrepareLookup(LExpr* exp);
  void parseLetEnd(LExpr* exp);

  void parseQuantBegin(LExpr* exp);

  void parseAnnotatedTerm(LExpr* exp);

 
  bool parseAsScopeLookup(const vstring& id);
 
  bool parseAsSpecConstant(const vstring& id);
 
  bool parseAsUserDefinedSymbol(const vstring& id, LExpr* exp);
 
  bool parseAsBuiltinFormulaSymbol(const vstring& id, LExpr* exp);
 
  bool parseAsBuiltinTermSymbol(const vstring& id, LExpr* exp);

 
  void parseRankedFunctionApplication(LExpr* exp);

 
  ParseResult parseTermOrFormula(LExpr* body);

 
  void readAssert(LExpr* body);

 
  UnitList* _formulas;

 
  Set<vstring> _overflow;

 
  void readBenchmark(LExprList* bench);
};

}

#endif 

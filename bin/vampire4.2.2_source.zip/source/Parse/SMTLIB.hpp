
/*
 * File SMTLIB.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __SMTLIB__
#define __SMTLIB__

#include "Forwards.hpp"

#include "Kernel/Sorts.hpp"
#include "Kernel/Term.hpp"

#include "Shell/LispParser.hpp"


namespace Parse {

using namespace Lib;
using namespace Kernel;
using namespace Shell;

class SMTLIB {
public:
  enum Mode {
    READ_BENCHMARK = 0,
    DECLARE_SORTS = 1,
    DECLARE_SYMBOLS = 2,
    BUILD_FORMULA = 3
  };

 
  struct FunctionInfo {
    FunctionInfo(vstring name, Stack<vstring> argSorts, vstring domainSort)
     : name(name), argSorts(argSorts), rangeSort(domainSort) {}

    vstring name;
    Stack<vstring> argSorts;
    vstring rangeSort;
  };

  SMTLIB(const Options& opts, Mode mode = BUILD_FORMULA);
  void setIntroducedSymbolColor(Color clr) { _introducedSymbolColor = clr; }

 
  void parse(LExpr* bench);
  void parse(istream& str);

  
  const Stack<vstring>& getUserSortNames() const { return _userSorts; }
  const Stack<FunctionInfo>& getFuncInfos() const { return _funcs; }
  LExpr* getLispFormula() const { ASS(_lispFormula); return _lispFormula; }

 
  BaseType* getSymbolType(const FunctionInfo& fnInfo);

 
  UnitList* getFormulas() const { ASS(_formulas); return _formulas; }
  UnitList* getDefinitions() const { ASS(_formulas); return _definitions; }

private:

  enum BuiltInSorts
  {
    BS_ARRAY1,
    BS_ARRAY2,
    BS_INT,
    BS_REAL,
    BS_U,

    BS_INVALID
  };
  static const char * s_builtInSortNameStrings[];

  static BuiltInSorts getBuiltInSort(vstring str);

  void readBenchmark(LExprList* bench);
  void readSort(vstring name);
  void readFunction(LExprList* decl);
  void readPredicate(LExprList* decl);

  unsigned getSort(vstring name);
  unsigned getSort(BuiltInSorts srt);
  void doSortDeclarations();
  void doFunctionDeclarations();

  vstring _benchName;
  vstring _statusStr;

  Stack<vstring> _userSorts;
  Stack<FunctionInfo> _funcs;
  LExprList* _lispAssumptions;
  LExpr* _lispFormula;

  UnitList* _definitions;
 
  UnitList* _formulas;

  Mode _mode;
  bool _treatIntsAsReals;
  
  bool _fletAsDefinition;
  Color _introducedSymbolColor;
#if VDEBUG
  bool _haveParsed;
#endif

private:
  

  
  unsigned _array1Sort;
  unsigned _array2Sort;

private:
  

 
  enum FormulaSymbol
  {
    FS_LESS,
    FS_LESS_EQ,
    FS_EQ,
    FS_GREATER,
    FS_GREATER_EQ,
    FS_AND,
    FS_DISTINCT,
    FS_EXISTS,
    FS_FLET,
    FS_FORALL,
    FS_IF_THEN_ELSE,
    FS_IFF,
    FS_IMPLIES,
    FS_LET,
    FS_NOT,
    FS_OR,
    FS_XOR,

    FS_USER_PRED_SYMBOL
  };
  static const char * s_formulaSymbolNameStrings[];

  enum TermSymbol
  {
    TS_MULTIPLY,
    TS_PLUS,
    TS_MINUS,
    TS_DIVIDE,
    TS_ITE,
    TS_SELECT,
    TS_STORE,
    TS_UMINUS,
      
    TS_USER_FUNCTION
  };
  static const char * s_termSymbolNameStrings[];

  DHMap<LExpr*,Formula*> _forms;
  DHMap<LExpr*,TermList> _terms;

  
  
  DHMap<vstring,Formula*> _formVars;
  DHMap<vstring,TermList> _termVars;

 
  unsigned _nextQuantVar;

 
  Stack<unsigned> _varSorts;

 
  typedef pair<LExpr*,bool> ToDoEntry;
 
  Stack<ToDoEntry> _todo;

 
  bool _entering;
  ToDoEntry _current;

  bool tryGetArgumentTerm(LExpr* parent, LExpr* argument, TermList& res);
  bool tryGetArgumentFormula(LExpr* parent, LExpr* argument, Formula*& res);

  void requestSubexpressionProcessing(LExpr* subExpr, bool formula);

  static FormulaSymbol getFormulaSymbol(vstring str);
  static TermSymbol getTermSymbol(vstring str, unsigned arity);
  static Interpretation getFormulaSymbolInterpretation(FormulaSymbol ts, unsigned firstArgSort);
  static Interpretation getTermSymbolInterpretation(TermSymbol ts, unsigned firstArgSort);
  static unsigned getMandatoryConnectiveArgCnt(FormulaSymbol fsym);


  unsigned getSort(TermList t);
  void ensureArgumentSorts(bool pred, unsigned symNum, TermList* args);

  bool readTermArgs(LExpr* parent, LispListReader& rdr, TermStack& args);


  TermList readTermFromAtom(vstring str);
  bool tryReadTermIte(LExpr* e, TermList& res);
  unsigned getTermSelectOrStoreFn(LExpr* e, TermSymbol tsym, const TermStack& args);
  bool tryReadTerm(LExpr* e, TermList& res);

  Formula* readFormulaFromAtom(vstring str);
  bool tryReadNonPropAtom(FormulaSymbol fsym, LExpr* e, Literal*& res);
  bool tryReadConnective(FormulaSymbol fsym, LExpr* e, Formula*& res);
  bool tryReadQuantifier(bool univ, LExpr* e, Formula*& res);
  bool tryReadDistinct(LExpr* e, Formula*& res);
  bool tryReadFlet(LExpr* e, Formula*& res);
  bool tryReadLet(LExpr* e, Formula*& res);
  bool tryReadFormula(LExpr* e, Formula*& res);
  Formula* readFormula(LExpr* e);
  void buildFormula();

  Formula* nameFormula(Formula* f, vstring fletVarName);

};

}

#endif 

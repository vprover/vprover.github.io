
/*
 * File TPTP.hpp.
 *
 * This file is part of the source code of the software program
 * Vampire 4.2.2. It is protected by applicable
 * copyright laws.
 *
 * This source code is distributed under the licence found here
 * https://vprover.github.io/license.html
 *
 * In summary, you are allowed to use Vampire for non-commercial
 * uses but not allowed to distribute, modify, copy, create derivatives,
 * or use in competitions. 
 * For other uses of Vampire please contact developers for a different
 * licence, which we will make an effort to provide. 
 */


#ifndef __Parser_TPTP__
#define __Parser_TPTP__

#include <iostream>

#include "Lib/Array.hpp"
#include "Lib/Set.hpp"
#include "Lib/Stack.hpp"
#include "Lib/Exception.hpp"
#include "Lib/IntNameTable.hpp"

#include "Kernel/Formula.hpp"
#include "Kernel/Unit.hpp"
#include "Kernel/Theory.hpp"



using namespace std;
using namespace Lib;
using namespace Kernel;

namespace Kernel {
  class Clause;
};

namespace Parse {

class TPTP;

class TPTP 
{
public:
 
  enum Tag {
   
    T_EOF,
   
    T_NAME,
   
    T_VAR,
   
    T_LPAR,
   
    T_RPAR,
   
    T_LBRA,
   
    T_RBRA,
   
    T_COMMA,
   
    T_COLON,
   
    T_SEMICOLON,
   
    T_NOT,
   
    T_AND,
   
    T_EQUAL,
   
    T_STRING,
   
    T_NEQ,
   
    T_FORALL,
   
    T_EXISTS,
   
    T_PI,
   
    T_SIGMA,
   
    T_IMPLY,
   
    T_XOR,
   
    T_IFF,
   
    T_REVERSE_IMP,
   
    T_DOT,
   
    T_REAL,
   
    T_RAT,
   
    T_INT,
   
    T_OR,
   
    T_ASS,
   
    T_LAMBDA,
   
    T_APP,
   
    T_STAR,
   
    T_UNION,
   
    T_ARROW,
   
    T_SUBTYPE,
   
    T_NOT_OR,
   
    T_NOT_AND,
   
    T_SEQUENT,
   
    T_THF_QUANT_ALL,
   
    T_THF_QUANT_SOME,
   
    T_APP_PLUS,
   
    T_APP_MINUS,
   
    T_TRUE,
   
    T_FALSE,
   
    T_TTYPE,
   
    T_BOOL_TYPE,
   
    T_DEFAULT_TYPE,
   
    T_INTEGER_TYPE,
   
    T_RATIONAL_TYPE,
   
    T_REAL_TYPE,
   
    T_TUPLE,
   
    T_THEORY_FUNCTION,
   
    T_THEORY_SORT,
   
    T_FOT,
   
    T_FOF,
   
    T_TFF,
   
    T_THF,
   
    T_DOLLARS,
   
    T_ITE,
   
    T_LET
  };

 
  enum State {
   
    UNIT_LIST,
   
    CNF,
   
    FOF,
   
    VAMPIRE,
   
    FORMULA,
   
    END_FOF,
   
    SIMPLE_FORMULA,
   
    END_FORMULA,
   
    FORMULA_INSIDE_TERM,
   
    TERM_INFIX,
   
    END_FORMULA_INSIDE_TERM,
   
    END_TERM_AS_FORMULA,
   
    VAR_LIST,
   
    FUN_APP,
   
    FORMULA_INFIX,
   
    ARGS,
   
    TERM,
   
    END_TERM,
   
    TAG,
   
    INCLUDE,
   
    END_EQ,
   
    TFF,
   
    THF,
   
    TYPE,
   
    END_TFF,
   
    END_TYPE,
   
    SIMPLE_TYPE,
   
    UNBIND_VARIABLES,
   
    END_ITE,
   
    END_TUPLE,
   
    END_ARGS,
   
    MID_EQ,
   
    END_LET,
   
    BINDING,
   
    TUPLE_BINDING,
   
    END_BINDING,
   
    END_TUPLE_BINDING,
   
    END_THEORY_FUNCTION
  };

 
  struct Token {
   
    Tag tag;
   
    int start;
   
    vstring content;
    vstring toString() const;
  };

 
  class ParseErrorException 
    : public ::Exception
  {
  public:
    ParseErrorException(vstring message,unsigned ln) : _message(message), _ln(ln) {}
    ParseErrorException(vstring message,Token& tok,unsigned ln);
    ParseErrorException(vstring message,int position,unsigned ln);
    void cry(ostream&);
    ~ParseErrorException() {}
  protected:
    vstring _message;
    unsigned _ln;
  }; 
  friend class Exception;

#define PARSE_ERROR(msg,tok) \
  throw ParseErrorException(msg,tok,_lineNumber)

  TPTP(istream& in);
  ~TPTP();
  void parse();
  static UnitList* parse(istream& str);
 
  inline UnitList* units() { return _units.list(); }
 
  bool containsConjecture() const { return _containsConjecture; }
  void addForbiddenInclude(vstring file);
  static bool findAxiomName(const Unit* unit, vstring& result);
  
  static void assignAxiomName(const Unit* unit, vstring& name);
  unsigned lineNumber(){ return _lineNumber; }
private:
 
  const char* input() { return _chars.content(); }

  enum TypeTag {
    TT_ATOMIC,
    TT_PRODUCT,
    TT_ARROW
  };

 
  class Type {
  public:
    CLASS_NAME(Type);
    USE_ALLOCATOR(Type);
    explicit Type(TypeTag tag) : _tag(tag) {}
   
    TypeTag tag() const {return _tag;}
  protected:
   
    TypeTag _tag;
  };

 
  class AtomicType
    : public Type
  {
  public:
    CLASS_NAME(AtomicType);
    USE_ALLOCATOR(AtomicType);
    explicit AtomicType(unsigned sortNumber)
      : Type(TT_ATOMIC), _sortNumber(sortNumber)
    {}
   
    unsigned sortNumber() const {return _sortNumber;}
  private:
   
    unsigned _sortNumber;
  }; 

 
  class ArrowType
    : public Type
  {
  public:
    CLASS_NAME(ArrowType);
    USE_ALLOCATOR(ArrowType);
    ArrowType(Type* lhs,Type* rhs)
      : Type(TT_ARROW), _lhs(lhs), _rhs(rhs)
    {}
   
    Type* argumentType() const {return _lhs;}
   
    Type* returnType() const {return _rhs;}
  private:
   
    Type* _lhs;
   
    Type* _rhs;
  }; 

 
  class ProductType
    : public Type
  {
  public:
    CLASS_NAME(ProductType);
    USE_ALLOCATOR(ProductType);
    ProductType(Type* lhs,Type* rhs)
      : Type(TT_PRODUCT), _lhs(lhs), _rhs(rhs)
    {}
   
    Type* lhs() const {return _lhs;}
   
    Type* rhs() const {return _rhs;}
  private:
   
    Type* _lhs;
   
    Type* _rhs;
  }; 

 
  class UnitStack {
  public:
   
    inline explicit UnitStack()
      : _initial(0),
	_last(&_initial)
    {}

   
    inline void push(Unit* u)
    {
      UnitList* newList = new UnitList(u);
      *_last = newList;
      _last = reinterpret_cast<UnitList**>(&newList->tailReference());
    }

   
    UnitList* list() { return _initial; }

  private:
   
    UnitList* _initial;
   
    UnitList** _last;
  }; 

  enum TheorySort {
   
    TS_ARRAY,
  };
  static bool findTheorySort(const vstring name, TheorySort &ts) {
    static const vstring theorySortNames[] = {
      "$array"
    };
    static const unsigned theorySorts = sizeof(theorySortNames)/sizeof(vstring);
    for (unsigned sort = 0; sort < theorySorts; sort++) {
      if (theorySortNames[sort] == name) {
        ts = static_cast<TheorySort>(sort);
        return true;
      }
    }
    return false;
  }
  static bool isTheorySort(const vstring name) {
    static TheorySort dummy;
    return findTheorySort(name, dummy);
  }
  static TheorySort getTheorySort(const Token tok) {
    ASS_REP(tok.tag == T_THEORY_SORT, tok.content);
    TheorySort ts;
    if (!findTheorySort(tok.content, ts)) {
      ASSERTION_VIOLATION_REP(tok.content);
    }
    return ts;
  }

  enum TheoryFunction {
   
    TF_SELECT, TF_STORE
  };
  static bool findTheoryFunction(const vstring name, TheoryFunction &tf) {
    static const vstring theoryFunctionNames[] = {
      "$select", "$store"
    };
    static const unsigned theoryFunctions = sizeof(theoryFunctionNames)/sizeof(vstring);
    for (unsigned fun = 0; fun < theoryFunctions; fun++) {
      if (theoryFunctionNames[fun] == name) {
        tf = static_cast<TheoryFunction>(fun);
        return true;
      }
    }
    return false;
  }
  static bool isTheoryFunction(const vstring name) {
    static TheoryFunction dummy;
    return findTheoryFunction(name, dummy);
  }
  static TheoryFunction getTheoryFunction(const Token tok) {
    ASS_REP(tok.tag == T_THEORY_FUNCTION, tok.content);
    TheoryFunction tf;
    if (!findTheoryFunction(tok.content, tf)) {
      ASSERTION_VIOLATION_REP(tok.content);
    }
    return tf;
  }

 
  bool _containsConjecture;
 
  Set<vstring>* _allowedNames;
 
  Stack<Set<vstring>*> _allowedNamesStack;
 
  Set<vstring> _forbiddenIncludes;
 
  istream* _in;
 
  Stack<istream*> _inputs;
 
  vstring _includeDirectory;
 
  Stack<vstring> _includeDirectories;
 
  Array<char> _chars;
 
  int _gpos;
 
  int _cend;
 
  Array<Token> _tokens;
 
  int _tend;
 
  unsigned _lineNumber;
 
  UnitStack _units;
 
  Stack<State> _states;
  
  int _lastInputType;
  
  bool _isQuestion;
  
  bool _isFof;
 
  Stack<vstring> _strings;
  
  Stack<int> _connectives;
 
  Stack<bool> _bools;
 
  Stack<int> _ints;
 
  Stack<Formula::VarList*> _varLists;
 
  Stack<Formula::SortList*> _sortLists;
 
  Stack<Formula::VarList*> _bindLists;
 
  Stack<Tag> _tags;
 
  Stack<Formula*> _formulas;
 
  Stack<Literal*> _literals;
 
  Stack<TermList> _termLists;
 
  IntNameTable _vars;
 
  Stack<Type*> _types;
 
  Stack<TypeTag> _typeTags;
  typedef List<unsigned> SortList;
 
  Stack<TheoryFunction> _theoryFunctions;
 
  Map<int,SortList*> _variableSorts;
 
  Set<vstring> _overflow;
 
  Color _currentColor;
 
  typedef pair<vstring, unsigned> LetFunctionName;
 
  typedef pair<unsigned, bool> LetFunctionReference;
 
  typedef pair<LetFunctionName, LetFunctionReference> LetFunction;
 
  typedef Stack<LetFunction> LetFunctionsScope;
 
  Stack<LetFunctionsScope> _letScopes;
 
  bool findLetSymbol(bool isPredicate, vstring name, unsigned arity, unsigned& symbol);
 
  LetFunctionsScope _currentLetScope;

  typedef pair<unsigned, bool> LetBinding;
  typedef Stack<LetBinding> LetBindingScope;
  Stack<LetBindingScope> _letBindings;
  LetBindingScope _currentBindingScope;

 
  bool _modelDefinition;

  
  
  unsigned _insideEqualityArgument;

 
  inline char getChar(int pos)
  {
    CALL("TPTP::getChar");

    while (_cend <= pos) {
      int c = _in->get();
      
      _chars[_cend++] = c == -1 ? 0 : c;
    }
    return _chars[pos];
  } 

 
  inline void shiftChars(int n)
  {
    CALL("TPTP::shiftChars");
    ASS(n > 0);
    ASS(n <= _cend);

    for (int i = 0;i < _cend-n;i++) {
      _chars[i] = _chars[n+i];
    }
    _cend -= n;
    _gpos += n;
  } 

 
  inline void resetChars()
  {
    _gpos += _cend;
    _cend = 0;
  } 

 
  inline Token& getTok(int pos)
  {
    CALL("TPTP::getTok");

    while (_tend <= pos) {
      Token& tok = _tokens[_tend++];
      readToken(tok);
    }
    return _tokens[pos];
  } 

 
  inline void shiftToks(int n)
  {
    CALL("TPTP::shiftToks");

    ASS(n > 0);
    ASS(n <= _tend);

    for (int i = 0;i < _tend-n;i++) {
      _tokens[i] = _tokens[n+i];
    }
    _tend -= n;
  } 

 
  inline void resetToks()
  {
    _tend = 0;
  } 

  
  bool readToken(Token& t);
  void skipWhiteSpacesAndComments();
  void readName(Token&);
  void readReserved(Token&);
  void readString(Token&);
  void readAtom(Token&);
  Tag readNumber(Token&);
  int decimal(int pos);
  int positiveDecimal(int pos);
  static vstring toString(Tag);

  
  static Formula* makeJunction(Connective c,Formula* lhs,Formula* rhs);
  void unitList();
  void fof(bool fo);
  void tff();
  void vampire();
  void consumeToken(Tag);
  vstring name();
  void formula();
  void funApp();
  void simpleFormula();
  void simpleType();
  void args();
  void varList();
  void tupleBinding();
  void term();
  void termInfix();
  void endTerm();
  void endArgs();
  Literal* createEquality(bool polarity,TermList& lhs,TermList& rhs);
  Formula* createPredicateApplication(vstring name,unsigned arity);
  TermList createFunctionApplication(vstring name,unsigned arity);
  void endEquality();
  void midEquality();
  void formulaInfix();
  void endFormula();
  void formulaInsideTerm();
  void endFormulaInsideTerm();
  void endTermAsFormula();
  void endType();
  void tag();
  void endFof();
  void endTff();
  void include();
  void type();
  void endIte();
  void binding();
  void endBinding();
  void endTupleBinding();
  void endLet();
  void endTheoryFunction();
  void endTuple();
  void addTagState(Tag);

  unsigned readSort();
  void bindVariable(int var,unsigned sortNumber);
  void unbindVariables();
  void skipToRPAR();
  void skipToRBRA();
  unsigned addFunction(vstring name,int arity,bool& added,TermList& someArgument);
  int addPredicate(vstring name,int arity,bool& added,TermList& someArgument);
  unsigned addOverloadedFunction(vstring name,int arity,int symbolArity,bool& added,TermList& arg,
				 Theory::Interpretation integer,Theory::Interpretation rational,
				 Theory::Interpretation real);
  unsigned addOverloadedPredicate(vstring name,int arity,int symbolArity,bool& added,TermList& arg,
				  Theory::Interpretation integer,Theory::Interpretation rational,
				  Theory::Interpretation real);
  unsigned sortOf(TermList term);
  static bool higherPrecedence(int c1,int c2);

  bool findInterpretedPredicate(vstring name, unsigned arity);

public:
  
  static unsigned addIntegerConstant(const vstring&, Set<vstring>& overflow, bool defaultSort);
  static unsigned addRationalConstant(const vstring&, Set<vstring>& overflow, bool defaultSort);
  static unsigned addRealConstant(const vstring&, Set<vstring>& overflow, bool defaultSort);
  static unsigned addUninterpretedConstant(const vstring& name, Set<vstring>& overflow, bool& added);

 
  struct SourceRecord{
    virtual bool isFile() = 0;
  };
  struct FileSourceRecord : SourceRecord {
    const vstring fileName;
    const vstring nameInFile;
    bool isFile(){ return true; } 
    FileSourceRecord(vstring fN, vstring nF) : fileName(fN), nameInFile(nF) {}
  };
  struct InferenceSourceRecord : SourceRecord{
    const vstring name;
    Stack<vstring> premises; 
    bool isFile(){ return false; } 
    InferenceSourceRecord(vstring n) : name(n) {}
  };
  
  void setUnitSourceMap(DHMap<Unit*,SourceRecord*>* m){
    _unitSources = m;
  }
  SourceRecord* getSource();

  void setFilterReserved(){ _filterReserved=true; }

private:
  DHMap<Unit*,SourceRecord*>* _unitSources;

 
  static DHMap<unsigned, vstring> _axiomNames;

  bool _filterReserved;
  bool _seenConjecture;


#if VDEBUG
  void printStates(vstring extra);
  void printInts(vstring extra);
  const char* toString(State s);
#endif
#ifdef DEBUG_SHOW_STATE
  void printStacks();
#endif
}; 

}

#endif

